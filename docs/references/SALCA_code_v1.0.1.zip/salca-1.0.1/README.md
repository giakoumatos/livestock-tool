# SALCA - Swiss Agricultural Life Cycle Assessment



SALCA is a life cycle assessment method geared to the agricultural and food sector. It is suitable for the life cycle assessment of products, production systems, farms, or even the entire agricultural sector.



![SALCA models](figures/SALCA_models_scripts.png)



## Documentation



The SALCA method is documented in a [scientific article](https://doi.org/10.1007/s11367-023-02255-w), and the latest appendices are available on the [SALCA website](https://www.agroscope.admin.ch/en/salcas-own-emission-and-impact-assessment-models).

The biodiversity impact assessment method is described in more detail in a separate [scientific article](https://doi.org/10.1016/j.ecolind.2014.06.030), with later extensions specifically for vegetables through another [scientific article](https://doi.org/10.1016/j.ecolind.2023.110098) and for vineyards through a master's thesis by Lindsay Neel in 2021 at the Jean Monnet University in connection with an internship at INRAE under the supervision of Adrien Rusch, Pauline Tolle, Josépha Guenser, and Lauren Inchboard.



## Use



The SALCA method is provided as modular Python code. Agroscope's LCA group runs the code within the SALCAfuture framework and links to a database integrated in there. To run the code, you will have to replace the import and export statements.

Please note that the code uses pandas version 1 and does not yet work with pandas version 2 because of functions that have been removed. However, you can create a suitable environment to run the code with the provided environment.yaml or requirements.txt file. SALCAbiodiversity has a separate requirements.txt file.



## Changes



The SALCA method remains under development. We plan to refactor some of the code, make it compatible with newer package versions, where necessary, and update some of the modelling approaches. We will report the main changes of future versions here.



[1.0.1] - 2026-10-14



Added

* Parameter tables



Changed

* Refactored SALCAsoilquality code
* Updated scripts to align with cleaned parameter tables
* Field workprocesses are now mapped on crop level instead of farm level in SALCAmapping
* Bugfixes



## Licences



Code: GNU LGPLv3 (see LICENCE.md)

Data: CC BY 4.0 (see [URL](https://creativecommons.org/licenses/by/4.0/))



## Citation



If you use the SALCA method and code, please cite the following scientific article:

> Nemecek, T., Roesch, A., Bystricky, M., Jeanneret, P., Lansche, J., Stüssi, M., & Gaillard, G. (2024). Swiss agricultural life cycle assessment: a method to assess the emissions and environmental impacts of agricultural systems and products. *The International Journal of Life Cycle Assessment*, 29(3), 433-455.

Depending on the focus of the application, it might be appropriate to cite additional publications, such as the articles on biodiversity mentioned under [Documentation](#documentation).



## Contact



If you want to report a bug or are interested in a collaboration, you can contact us by email:

[_Agroscope-SALCAfuture](mailto:salcafuture@agroscope.admin.ch)
