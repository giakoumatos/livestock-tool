import pandas as pd
import numpy as np
import math


def build_empty_df(indicator, df_type, for_summary=False):

    if df_type == 'culture':
        added = 'C'
        mi_level = 5
    elif df_type == 'field':
        added = 'P'
        mi_level = 3
    else:
        added = 'F'
        mi_level = 1

    if for_summary:
        mi_level += 1

    groups = indicator.index.tolist()
    index_tuples = []

    index_tuples.append(('Summary GAV', 'Total ' + added))
    index_tuples.append(('Summary GAV', 'Mean ' + added))
    index_tuples.append(('Summary HÖA', 'Total ' + added))
    index_tuples.append(('Summary HÖA', 'Mean ' + added))
    index_tuples.append(('', ''))

    for group in groups:
        index_tuples.append((group + ' GAV', 'BD Points ' + added))
        index_tuples.append((group + ' GAV', 'BD Potential ' + added))
        index_tuples.append((group + ' GAV', 'Maximum ' + added))
        index_tuples.append((group + ' GAV', 'Minimum ' + added))
        index_tuples.append((group + ' GAV', 'Maximum H'))
        index_tuples.append((group + ' GAV', 'Minimum H'))

        if indicator.at[group, 'HÖA']:
            index_tuples.append((group + ' HÖA', 'BD Points ' + added))
            index_tuples.append((group + ' HÖA', 'BD Potential ' + added))
            index_tuples.append((group + ' HÖA', 'Maximum ' + added))
            index_tuples.append((group + ' HÖA', 'Minimum ' + added))
            index_tuples.append((group + ' HÖA', 'Maximum H'))
            index_tuples.append((group + ' HÖA', 'Minimum H'))

    index = pd.MultiIndex.from_tuples(index_tuples)
    columns = pd.MultiIndex(levels=[[]]*mi_level, codes=[[]]*mi_level)
    out_df = pd.DataFrame(index=index, columns=columns)
    return out_df


def get_R2_dataframe(in_df, indicator):
    columns = pd.MultiIndex(levels=[[], []], codes=[[], []])
    out_df = pd.DataFrame(index=in_df.index, columns=columns)

    for scen in in_df['Scenarios']:
        scen_col = in_df.loc[:, ('Scenarios', scen)]
        scen_col.replace(True, 1, inplace=True)
        scen_col.replace(False, np.nan, inplace=True)
        out_df['Scenarios', 'Scenario ' + str(scen)] = scen_col
    groups = indicator.index.tolist()
    for group in groups:
        out_df = _build_R2_group(in_df, out_df, group, 'GAV')
        if indicator.at[group, 'HÖA']:
            out_df = _build_R2_group(in_df, out_df, group, 'HÖA')
    return out_df


def _build_R2_group(in_df, out_df, group, hoa):
    if hoa == 'GAV':
        added1 = ' GAV'
        added2 = ''
    else:
        added1 = ' HÖA'
        added2 = ' HÖA'
    out_df[(group + added1, 'Habitat Coefficient II')] = in_df[(group, 'Habitat Coefficient II')].fillna(0)
    out_df[(group + added1, 'Management Coefficient III')] = in_df[(group, 'Management Coefficient III')].fillna(0)
    out_df[(group + added1, 'Final Coefficient')] = in_df[(group, 'Final Coefficient')].fillna(0)
    out_df[(group + added1, 'Rating')] = in_df[(group, 'Rating' + added2)].fillna(0)
    out_df[(group + added1, 'Nopt')] = in_df[(group, 'Nopt' + added2)].fillna(0)
    for scen in in_df['Scenarios']:
        scen_value = out_df[(group + added1, 'Nopt')] * out_df['Scenarios', 'Scenario ' + str(scen)]
        out_df[(group + added1, 'Scenario ' + str(scen))] = scen_value
    out_df[(group + added1, 'Minimum Scenario')] = in_df[(group, 'Minimum Scenario' + added2)]
    out_df[(group + added1, 'Maximum Scenario')] = in_df[(group, 'Maximum Scenario' + added2)]
    return out_df


def calculate_scenario(culture, scen, ct, field_name, year, culture_name, r1_df, measures='measures'):
    indicator = ct.indicator_df
    minmax = ct.minmax_df
    scenario = 'Scenario ' + str(scen)
    if culture_name == 'Soil Cover':
        duration = 0
    else:
        duration = culture.duration[scen]
    if measures == 'border':
        culture_name = str(culture_name) + ' (Border)'
    r1_df[field_name, scenario, year, culture_name, duration] = np.nan
    groups = indicator.index.tolist()
    for group in groups:
        nopt_min = indicator.at[group, 'Nopt,min']
        r1_df = _calculate_group(culture, group, scen, minmax, field_name, year, nopt_min, culture_name, duration,
                                 'GAV', r1_df, measures)

        if indicator.at[group, 'HÖA']:
            r1_df = _calculate_group(culture, group, scen, minmax, field_name, year, nopt_min, culture_name, duration,
                                     'HÖA', r1_df, measures)
    return r1_df


def _calculate_group(culture, group, scen, minmax, field_name, year, nopt_min, culture_name, duration, hoa, r1_df,
                     measures='measures'):
    if hoa == 'GAV':
        added = ''
    else:
        added = ' HÖA'

    scenario = 'Scenario ' + str(scen)

    if measures == 'border':
        df = culture.border.copy()
    else:
        df = culture.measures.copy()

    scen_value = df.loc[:, (group, 'Nopt' + added)] * df.loc[:, ('Scenarios', scen)]
    df.loc[:, (group, scenario + added)] = scen_value
    df_nan = df[group, scenario + added].replace(0, np.nan)
    grouped_ml3 = df_nan.groupby(level=['Management Level I', 'Management Level II', 'Management Level III'])
    if nopt_min:
        val_per_ml3 = grouped_ml3.min()
    else:
        val_per_ml3 = grouped_ml3.mean()

    bd_points = val_per_ml3.mean()
    if np.isnan(bd_points):
        bd_points = 0
    ht2 = df.index[0][0:2]
    culture_max = minmax.at[ht2, (group + ' ' + hoa, 'Maximum')]
    culture_min = minmax.at[ht2, (group + ' ' + hoa, 'Minimum')]
    hab_max = minmax[group + ' ' + hoa, 'Maximum'].max()
    hab_min = minmax[group + ' ' + hoa, 'Minimum'].replace(0, np.nan).min()
    numerator = bd_points - culture_min
    denominator = culture_max - culture_min

    if denominator == 0:
        if culture_max == 0:
            bd_potential = 0
        else:
            bd_potential = 1
    else:
        bd_potential = numerator / denominator

    r1_df.at[(group + ' ' + hoa, 'BD Points C'), (field_name, scenario, year, culture_name, duration)] = bd_points
    r1_df.at[(group + ' ' + hoa, 'BD Potential C'), (field_name, scenario, year, culture_name, duration)] \
        = bd_potential
    r1_df.at[(group + ' ' + hoa, 'Maximum C'), (field_name, scenario, year, culture_name, duration)] = culture_max
    r1_df.at[(group + ' ' + hoa, 'Minimum C'), (field_name, scenario, year, culture_name, duration)] = culture_min
    r1_df.at[(group + ' ' + hoa, 'Maximum H'), (field_name, scenario, year, culture_name, duration)] = hab_max
    r1_df.at[(group + ' ' + hoa, 'Minimum H'), (field_name, scenario, year, culture_name, duration)] = hab_min
    return r1_df


def aggregate_indicator_groups(df, indicator, column, df_type, consider_zero_values):
    if df_type == 'culture':
        added = 'C'
    elif df_type == 'field':
        added = 'P'
    else:
        added = 'F'
        column = df.loc[:, column].columns[0]

    groups = df.index.get_level_values(0).drop_duplicates()[3:]
    list_GAV = []
    list_HÖA = []
    for group in groups:
        if group.endswith('GAV'):
            list_GAV.append(group)
        else:
            list_HÖA.append(group)

    weights_GAV = indicator.loc[[group[0:-4] for group in list_GAV], 'Weight'].reset_index(drop=True)
    weights_HÖA = indicator.loc[[group[0:-4] for group in list_HÖA], 'Weight'].reset_index(drop=True)

    values_GAV = df.loc[pd.IndexSlice[list_GAV, 'BD Points ' + added], column].reset_index(drop=True)
    values_HÖA = df.loc[pd.IndexSlice[list_HÖA, 'BD Points ' + added], column].reset_index(drop=True)

    if not consider_zero_values:
        for i, val in enumerate(values_GAV):
            if val == 0:
                values_GAV = values_GAV.drop(i)
                weights_GAV = weights_GAV.drop(i)

        for i, val in enumerate(values_HÖA):
            if val == 0:
                values_HÖA = values_HÖA.drop(i)
                weights_HÖA = weights_HÖA.drop(i)

    sum_GAV = weights_GAV.sum()
    sum_HÖA = weights_HÖA.sum()

    mean_GAV = values_GAV.mean()
    mean_HÖA = values_HÖA.mean()
    total_GAV = (values_GAV*weights_GAV).sum()/sum_GAV
    total_HÖA = (values_HÖA*weights_HÖA).sum()/sum_HÖA
    
    # if consider_zero_values is false but all values for HÖA are zero, we want the result be zero instead of nan.
    if math.isnan(total_GAV): total_GAV = 0
    if math.isnan(mean_GAV): mean_GAV = 0
    if math.isnan(total_HÖA): total_HÖA = 0
    if math.isnan(mean_HÖA): mean_HÖA = 0

    df.loc[('Summary GAV', 'Total ' + added), column] = total_GAV
    df.loc[('Summary GAV', 'Mean ' + added), column] = mean_GAV
    df.loc[('Summary HÖA', 'Total ' + added), column] = total_HÖA
    df.loc[('Summary HÖA', 'Mean ' + added), column] = mean_HÖA
    df.loc[('', ''), column] = ''

    return df


def calculate_for_comparison(pi, ct, consider_zero_values = False):
    indicator = ct.indicator_df
    r1_df = build_empty_df(indicator, 'culture')
    r3_df = build_empty_df(indicator, 'field')
    r4_df = build_empty_df(indicator, 'farm')

    for field in pi.fields:
        for culture in field.cultures:
            r1_df = culture._calculate_in_iteration(ct, False, field.identifier, field.number, r1_df, consider_zero_values)
        for soil_cover in field.soil_covers:
            r1_df = soil_cover._calculate_in_iteration(ct, False, field.identifier, field.number, r1_df, consider_zero_values)
        for scen in field.cultures[0].measures['Scenarios']:
            r3_df = field._aggregate(r1_df, indicator, scen, r3_df)
    for scen in pi.fields[0].cultures[0].measures['Scenarios']:
        r4_df = pi._aggregate_farm(r3_df, scen, indicator, r4_df)
    return r1_df, r3_df, r4_df
