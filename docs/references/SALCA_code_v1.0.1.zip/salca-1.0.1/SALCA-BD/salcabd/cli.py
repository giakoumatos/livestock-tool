from argparse import ArgumentParser
from .full_pipeline.full_pipeline import full_pipeline


def main():
    parser = ArgumentParser(prog='salcabd', description='Applies the Salca BD model to production inventories and '
                            'saves the results in new excel files.')
    parser.add_argument('inventory_folder', help='The path to the folder containing multiple production inventories. '
                        'Or the path to a single production inventory.')
    parser.add_argument('-cf', '--control_file', help='The path to the control file. Leave empty to use the '
                        'preinstalled control table instead.', nargs='?')
    parser.add_argument('-zv', '--consider_zero_values', help='This boolean controls if zero-values are considered '
                        'for all aggregation levels. Default is True.', nargs='?')
    parser.add_argument('-sf', '--export_single_files', help='Should the output for each single file be generated as '
                        'well? If False, only the summary file will be created. Default is True.', nargs='?')
    args = parser.parse_args()

    # Convert strings to bools
    if args.consider_zero_values in ['false', 'False']:
        consider_zero_values = False
    elif args.consider_zero_values in ['true', 'True']:
        consider_zero_values = True
    elif args.consider_zero_values is None:
        consider_zero_values = True
    else:
        raise(Exception('Invalid entry for "Consider Zero Values". Entry must be "True" or "False"'))

    if args.export_single_files in ['false', 'False']:
        export_single_files = False
    elif args.export_single_files in ['true', 'True']:
        export_single_files = True
    elif args.export_single_files is None:
        export_single_files = True
    else:
        raise(Exception('Invalid entry for "Export Single Files". Entry must be "True" or "False"'))

    full_pipeline(args.inventory_folder, args.control_file, consider_zero_values, export_single_files)


if __name__ == '__main__':
    main()
