import pandas as pd
import warnings
import itertools
import os
from datetime import datetime

from ..pkg_resources.default_control_table import get_default_control_table
from ..control_table.import_control_table import import_and_build_control_table
from ..control_table.control_table import ControlTable
from ..production_inventory.import_production_inventory import import_production_inventory
from ..calculation.calculation import calculate_for_comparison


def compare_folder_with_legacy(inventory_folder, result_folder, log_folder, ct_filename=None):
    """
    Compares the results calculated using the new application with the old results from the legacy application.

    Parameters
    ----------
    inventory_folder : str
        Folder containing the production inventories
    result_folder : str
        Folder containing the results
    log_folder : str
        Folder where the resulting log should be stored
    ct_filename : str, ControlTable, optional
        Path to the Excel file containing the control table or existing instance of the class ControlTable. If left
        empty, the default control table will be loaded.

    """
    if ct_filename is None:
        ct = get_default_control_table()
    elif type(ct_filename) is ControlTable:
        ct = ct_filename
    else:
        ct = import_and_build_control_table(ct_filename)

    file_list = get_file_list(inventory_folder, result_folder)
    timestamp = datetime.now().strftime("%Y_%m_%d")
    log_path = os.path.join(log_folder, "log_" + timestamp + ".log")
    log = open(log_path, 'w')
    num_errs = 0
    err_list = []
    for file_tuple in file_list:
        msg, add_errs = compare_file_with_legacy(file_tuple[0], file_tuple[1], ct)
        log.write(msg)
        num_errs += add_errs
        if add_errs > 0:
            err_list.append(file_tuple[0])

    log.close()
    log_summary_path = os.path.join(log_folder, "summary_" + timestamp + ".log")
    log_summary = open(log_summary_path, 'w')
    if num_errs == 1:
        log_summary.write("There was a total of " + str(num_errs) + " error!\n\n")
    else:
        log_summary.write("There was a total of " + str(num_errs) + " errors!\n\n")
    if num_errs > 0:
        log_summary.write("The errors came from the following files:\n")
        for filename in err_list:
            log_summary.write("\t" + filename + "\n")
    log_summary.close()


def compare_file_with_legacy(pi_file, result_file, ct):
    pi = import_production_inventory(pi_file, ct)
    r1_new, r3_new, r4_new = calculate_for_comparison(pi, ct)
    r1_leg, r3_leg, r4_leg = get_result_dataframes(result_file)
    filename = os.path.split(pi_file)[1]
    msg = filename + "\n"
    num_errs = 0
    msg += "\tLevel Culture (Total/Mean GAV/HÖA)\n"
    for i in range(len(r1_new.columns)):
        add_msg, add_errs = compare_cultures(r1_new, r1_leg, i)
        msg += add_msg
        num_errs += add_errs
    msg += "\tLevel Field (Amphibia GAV/HÖA)\n"
    for i in range(len(r3_new.columns)):
        add_msg, add_errs = compare_fields(r3_new, r3_leg, i)
        msg += add_msg
        num_errs += add_errs
    msg += "\tLevel Farm (Molluscs GAV/HÖA)\n"
    for i in range(len(r4_new.columns)):
        add_msg, add_errs = compare_farm(r4_new, r4_leg, i)
        msg += add_msg
        num_errs += add_errs
    if num_errs == 1:
        msg += "ATTENTION: " + str(num_errs) + " ERROR!\n\n"
    elif num_errs > 1:
        msg += "ATTENTION: " + str(num_errs) + " ERRORS!\n\n"
    else:
        msg += "\n"
    return msg, num_errs


def get_result_dataframes(filename):
    warnings.simplefilter("ignore")
    r1_df = pd.read_excel(filename, 'R1', skiprows=5, header=[0, 1, 2, 3], index_col=[0, 1])
    r1_df.dropna(axis=1, how='all', inplace=True)
    r3_df = pd.read_excel(filename, 'R3', skiprows=7, header=[0, 1], index_col=[0, 1])
    r3_df.dropna(axis=1, how='all', inplace=True)
    r4_df = pd.read_excel(filename, 'R4', skiprows=7, header=[0, 1], index_col=[0, 1])
    r4_df.dropna(axis=1, how='all', inplace=True)
    return r1_df, r3_df, r4_df


def compare_cultures(r1_new, r1_leg, i):
    num_errs = 0
    if r1_new.columns[i][3] == r1_leg.columns[i][2]:
        is_equal = True
    else:
        is_equal = False
        num_errs += 1
        error_type = 'ID'
    for j in range(4):
        if abs(r1_new.iloc[j, i] - r1_leg.iloc[j, i]) > 1e-6:
            is_equal = False
            num_errs += 1
            error_type = 'Value'

    if is_equal:
        msg = "\t\tSUCCESS! Culture " + str(r1_new.columns[i][3])
    elif error_type == 'ID':
        msg = "\t\tERROR!   Culture " + str(r1_new.columns[i][3]) + ": Different ID than " + str(r1_leg.columns[i][2])
    else:
        msg = "\t\tERROR!   Culture " + str(r1_new.columns[i][3]) + ": Discrepancy between values!"
    msg += "\n"
    return msg, num_errs


def compare_fields(r3_new, r3_leg, i):
    num_errs = 0
    if r3_new.columns[i][0] == r3_leg.columns[i][0]:
        is_equal = True
    else:
        is_equal = False
        num_errs += 1
        error_type = 'ID'
    comparison_range = itertools.chain(range(29, 33), range(35, 39))
    for j in comparison_range:
        if abs(r3_new.iloc[j, i] - r3_leg.iloc[j, i]) > 1e-6:
            is_equal = False
            num_errs += 1
            error_type = 'Value'

    if is_equal:
        msg = "\t\tSUCCESS! Field " + str(r3_new.columns[i][0])
    elif error_type == 'ID':
        msg = "\t\tERROR!   Field " + str(r3_new.columns[i][0]) + ": Different ID than " + str(r3_leg.columns[i][0])
    else:
        msg = "\t\tERROR!   Field " + str(r3_new.columns[i][0]) + ": Discrepancy between values!"
    msg += "\n"
    return msg, num_errs


def compare_farm(r4_new, r4_leg, i):
    num_errs = 0
    is_equal = True
    comparison_range = itertools.chain(range(41, 45), range(47, 51))
    for j in comparison_range:
        if abs(r4_new.iloc[j, i] - r4_leg.iloc[j, i]) > 1e-6:
            is_equal = False
            num_errs += 1

    if is_equal:
        msg = "\t\tSUCCESS! Farm " + r4_leg.columns[i][0]
    else:
        msg = "\t\tERROR!   Farm " + r4_leg.columns[i][0] + ": Discrepancy between values!"
    msg += "\n"
    return msg, num_errs


def get_file_list(inventory_folder, result_folder):
    file_list = []
    for inventory_file in os.listdir(inventory_folder):
        inventory_path = os.path.join(inventory_folder, inventory_file)
        if inventory_file.endswith('.xlsm') and not inventory_file.startswith('~'):
            inventory_number = extract_int(inventory_file)
            result_file = 'Resultat_noNullValues_' + inventory_number + '.xlsx'
            result_path = os.path.join(result_folder, result_file)
            if os.path.exists(result_path):
                file_list.append((inventory_path, result_path))
    return file_list


def extract_int(text: str):
    only_numbers = ''.join([x for x in text if x.isdigit()])
    if only_numbers.isdigit():
        return only_numbers
    return None
