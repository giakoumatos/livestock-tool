import numpy as np
import pandas as pd
import itertools

from .validator import Validator


class ControlTable:
    def __init__(self, control_df, indicator_df, validation_df):
        self.control_df = control_df
        self.indicator_df = indicator_df
        self.validation_df = validation_df
        self.validator = None
        self.minmax_df = None

    def build(self):
        """
        Gets all the additional information that's not stored in the control table file but can be extracted from the
        data. The following three steps are done:

            - Build the validator. For each validation criterion, get a list of options that have to fulfill the
                    criterion. Stored as a Validator class containing MultiIndexes.
            - Build the Nopt. Calculate the Nopt for each option, based on the coefficients and ratings. Stored in the
                    control_df.
            - Build the mininum and maximum scenarios. Calculate them for each Habitat Type II, show the selected
                    options in the control_df and store the biodiversity points per indicator group as minmax_df.

        """
        self._build_validator()
        self._build_nopt()
        self._build_minmax()

    def get_variable_category_by_id(self, identifier: int, level: str):
        """
        Gets the value of any MultiIndex level (Habitat Types, Management Levels, Option) for a specific ID.

        Parameters
        ----------
        identifier : int
            ID of the selected option.
        level : str
            Selected level of the MultiIndex, e.g. "Habitat Type II".

        Returns
        -------
        output : str
            The variable category for the selected ID and level.

        """
        try:
            return self.control_df.xs(identifier, level='ID').index.get_level_values(level)[0]
        except KeyError:
            print('ID not found in control_table:')
            print(identifier)
            return None

    def get_variables_by_category(self, identifier: str, level: str):
        """
        Gets all the options that fulfill a selected criterion on a seleccted MultiIndex level (Habitat Types,
        Management Levels).

        Parameters
        ----------
        identifier : str
            The selected variable category that should appear in level.
        level : str
            Selected level of the MultiIndex, e.g. "Habitat Type II".

        Returns
        -------
        output : pd.DataFrame
            Dataframe containing all the options with the selected category.

        """
        try:
            return self.control_df.xs(identifier, level=level, drop_level=False)
        except KeyError:
            return None

    def _build_validator(self):
        '''
        Builds the validators (list of indexes, where the different validation options are true) from the validation
        dataframe.

        '''
        val = self.validation_df

        zero_option = val[val['Zero-Option']].index
        mandatory = val[val['Mandatory']].index
        multiple_choice = val[val['Multiple Choice']].index

        self.validator = Validator(zero_option, mandatory, multiple_choice)

    def _build_nopt(self):
        '''
        Calculates the Final Coefficient and the Nopt for each option in each indicator group and writes them in the
        control dataframe.

        '''
        df = self.control_df
        ind = self.indicator_df

        groups = df.columns.get_level_values(0).drop_duplicates().tolist()

        for group in groups:
            # Calculate the FC, it can be wrong in the control table
            hc2 = df[group, 'Habitat Coefficient II']
            mc3 = df[group, 'Management Coefficient III']
            fc = (hc2 + mc3)/2
            df[group, 'Final Coefficient'] = fc

            rating = df[group, 'Rating']
            df[group, 'Nopt'] = rating * fc

            # Repeat these steps for HÖA if HÖA is relevant for this group
            if ind.at[group, 'HÖA']:
                rating = df[group, 'Rating HÖA']
                df[group, 'Nopt HÖA'] = rating * fc

        self.control_df = df

    def _build_minmax(self):
        '''
        Builds the dataframe containing the minimum and maximum scenarios for each habitat-type and indicator group.
        The selected options are also marked in the control dataframe.

        '''
        df = self.control_df
        ind = self.indicator_df

        groups = df.columns.get_level_values(0).drop_duplicates().tolist()

        for group in groups:
            df[group, 'Minimum Scenario'] = np.nan
            df[group, 'Maximum Scenario'] = np.nan

            # Repeat these steps for HÖA if HÖA is relevant for this group
            if ind.at[group, 'HÖA']:
                df[group, 'Minimum Scenario HÖA'] = np.nan
                df[group, 'Maximum Scenario HÖA'] = np.nan

        results = []

        for i, habitat_df in df.groupby(level=['Habitat Type I', 'Habitat Type II']):

            for group in groups:
                results, df = self._calculate_minmax(df, group, results, 'GAV', habitat_df, i)

                # Repeat for HÖA if HÖA is relevant for this group
                if ind.at[group, 'HÖA']:
                    results, df = self._calculate_minmax(df, group, results, 'HÖA', habitat_df, i)

        self.minmax_df = self._get_minmax_df(results)
        self.control_df = df

    def _calculate_minmax(self, df, group, results, subgroup, habitat_df, i):
        '''
        Calculates the minimum and maximum scenario for one indicator group and habitat type. The results are added to
        the result list and the control dataframe is appended with the selected options from this iteration.

        Input:
            df:         The current control dataframe from the last iteration
            group:      The indicator group for this iteration
            results:    The current result list from the last iteration
            subgroup:   A string that indicates GAV or HÖA
            habitat_df: The control dataframe only containing data for the current habitat type of this iteration
            i:          Current indexes from this iteration

        Output:
            results:    The new result list after the iteration
            df:         The new control dataframe after the iteration

        '''
        if subgroup == 'GAV':
            added_string = ''
        elif subgroup == 'HÖA':
            added_string = ' HÖA'
        else:
            raise ValueError('Subgroup must be GAV or HÖA')

        idx = pd.IndexSlice

        stacks = self._get_stacks(habitat_df, group, added_string)

        # Explanation of the stacks in _get_stacks
        zero_stack = stacks[0]
        max_stack = stacks[1]
        min_stack = stacks[2]
        pre_selected_min = stacks[3]
        pre_selected_max = stacks[4]

        # Combined list of zero_options vs minimum options. Where both the
        # zero-option and the minimum are NaN, the element is removed
        zipped = list(zip(zero_stack, min_stack))
        zipped_noNaN = []
        for j in zipped:
            if not all([np.isnan(j[0][0][0]).all(), all([item[0] for item in np.isnan(j[1])])]):
                zipped_noNaN.append(j)

        lowest, final_indexes, final_options = self._get_min(zipped_noNaN, pre_selected_min)
        results.append([i[0], i[1], group + ' ' + subgroup, 'Minimum', lowest])

        df.loc[idx[:, :, :, :, :, :, final_indexes], [[group, 'Minimum Scenario' + added_string]]] = final_options

        # Combined list of zero_options vs maximum options. Where both the
        # zero-option and the minimum are NaN, the element is removed
        zipped = list(zip(zero_stack, max_stack))
        zipped_noNaN = []
        for j in zipped:
            if not all([np.isnan(j[0][0][0]).all(), all([item[0] for item in np.isnan(j[1])])]):
                zipped_noNaN.append(j)

        highest, final_indexes, final_options = self._get_max(zipped_noNaN, pre_selected_max)

        results.append([i[0], i[1], group + ' ' + subgroup, 'Maximum', highest])

        df.loc[idx[:, :, :, :, :, :, final_indexes], [[group, 'Maximum Scenario' + added_string]]] = final_options

        return results, df

    def _get_stacks(self, habitat_df, group, added_string):
        '''
        From the control dataframe from the current habitat type, this function extracts different lists with data for
        later iteration. These lists contain the zero-options, the maximum and minimum options and also the pre-selected
        options for min and max (Those that don't need to be compared with the zero-options)

        Input:
        ----------
        habitat_df:         The control dataframe only containing data for the current habitat type of this iteration
        group:              The indicator group for this iteration
        added_string:       Indication if GAV or HÖA

        Returns
        -------
        zero_stack:             Contains all the Nopts with selected zero-options, and the corresponding indexes
        max_stack:              Contains all the Nopts where the maximum options were selected (excluding zero-options),
                                and the corresponding indexes
        min_stack:              Contains all the Nopts where the minimum options were selected (excluding zero-options),
                                and the corresponding indexes
        pre_selected_min:       Contains all the minimum Nopts that don't need to be compared with any zero-option, and
                                the corresponding indexes
        pre_selected_max:       Contains all the maximum Nopts that don't need to be compared with any zero-option, and
                                the corresponding indexes

        '''
        # Validation DF with only ID as index
        val = self.validation_df

        # Only keep the ID as index
        val = val.reset_index(level=[0, 1, 2, 3, 4, 5])
        habitat_df = habitat_df.reset_index(level=[0, 1, 2, 3, 4, 5])

        zero_stack = []
        max_stack = []
        min_stack = []
        pre_selected_min = []
        pre_selected_max = []

        # Group by ML2

        for i2, ml2_df in habitat_df.groupby(['Habitat Type I', 'Habitat Type II', 'Management Level I',
                                              'Management Level II']):

            zero = []
            max_extreme = []
            min_extreme = []
            # Group by ML3

            for i3, ml3_df in ml2_df.groupby(['Habitat Type I', 'Habitat Type II', 'Management Level I',
                                              'Management Level II', 'Management Level III']):

                val_ml3 = val.loc[ml3_df.index.tolist()]
                if val_ml3['Zero-Option'].sum() > 0:
                    res = ml3_df[group, 'Nopt' + added_string]
                    idx = val_ml3['Zero-Option'].idxmax()
                    if res[idx] == 0:
                        zero.append([np.nan, idx])
                    else:
                        zero.append([res[idx], idx])
                    if res.drop(idx)[res > 0].empty:
                        idx_min = 0
                        idx_max = 0
                    else:
                        idx_min = res.drop(idx)[res > 0].idxmin()
                        idx_max = res.drop(idx)[res > 0].idxmax()
                    min_extreme.append([res.drop(idx)[res > 0].min(), idx_min])
                    max_extreme.append([res.drop(idx)[res > 0].max(), idx_max])
                else:
                    res = ml3_df[group, 'Nopt' + added_string]
                    if res[res > 0].empty:
                        idx_min = 0
                        idx_max = 0
                    else:
                        idx_min = res[res > 0].idxmin()
                        idx_max = res[res > 0].idxmax()

                    min_extreme.append([res[res > 0].min(), idx_min])
                    max_extreme.append([res[res > 0].max(), idx_max])
            if zero == []:
                pre_selected_max.extend(max_extreme)
                pre_selected_min.extend(min_extreme)
            else:
                zero_stack.append(zero)
                max_stack.append(max_extreme)
                min_stack.append(min_extreme)

        return (zero_stack, max_stack, min_stack, pre_selected_min, pre_selected_max)

    def _get_min(self, zipped_noNaN, pre_selected_min):
        '''
        Get the minimum scenario from a list of zero-options and min-options

        Input:
            zipped_noNaN:       List of zero-options and their alternative minimum options
            pre_selected_min:   List of pre_selected values that are for sure part of the minimum scenario

        Output:
            lowest:             The average of the mimimum scenario
            final_indexes:      The indexes of the selected options
            final_options:      The selected options for the minimum scenario

        '''
        selections = []

        for j in zipped_noNaN:
            # If all elements of the min_stack are NaN, nothing can be pre-selected. It could lead to rare mistakes
            # otherwise, where the Zero-Option has a value but the min_stack doesn't
            if np.isnan([item[0] for item in j[1]]).all():
                selections.append(j)
            else:
                # If both the Zero-Option and the minimum only contain one option, pre-select the lower one.
                # Otherwise move to selection
                if len(j[0]) == len(j[1]):
                    if j[1][0][0] < j[0][0][0]:
                        pre_selected_min.append(j[1][0])
                    else:
                        pre_selected_min.append(j[0][0])
                else:
                    selections.append(j)

        lowest = 10000000
        current_options = []
        current_indexes = []

        # Iterate through all possible combinations and select the lowest one
        for j in itertools.product(*selections):
            selected_options = [item[0] for item in pre_selected_min]
            selected_indexes = [item[1] for item in pre_selected_min]
            for k in j:
                selected_options.extend([item[0] for item in k])
                selected_indexes.extend([item[1] for item in k])
            if np.isnan(selected_options).all():
                mean = np.nan
            else:
                mean = np.nanmean(selected_options)
            if mean < lowest:
                lowest = mean
                current_options = selected_options
                current_indexes = selected_indexes
        final_options = []
        final_indexes = []
        for j in range(len(current_options)):
            if current_indexes[j] != 0:
                final_options.append(current_options[j])
                final_indexes.append(current_indexes[j])
        if lowest == 10000000:
            lowest = 0

        return lowest, final_indexes, final_options

    def _get_max(self, zipped_noNaN, pre_selected_max):
        '''
        Get the maximum scenario from a list of zero-options and max-options

        Input:
            zipped_noNaN:       List of zero-options and their alternative maximum options
            pre_selected_max:   List of pre_selected values that are for sure part of the maximum scenario

        Output:
            highest:            The average of the maximum scenario
            final_indexes:      The indexes of the selected options
            final_options:      The selected options for the maximum scenario

        '''
        selections = []

        for j in zipped_noNaN:
            # If all elements of the max_stack are NaN, nothing can be pre-selected. It could lead to rare mistakes
            # otherwise, where the Zero-Option has a value but the max_stack doesn't
            if np.isnan([item[0] for item in j[1]]).all():
                selections.append(j)
            else:
                # If both the Zero-Option and the maximum only contain one option, pre-select the higher one.
                # Otherwise move to selection
                if len(j[0]) == len(j[1]):
                    if j[1][0][0] > j[0][0][0]:
                        pre_selected_max.append(j[1][0])
                    else:
                        pre_selected_max.append(j[0][0])
                else:
                    selections.append(j)

        highest = 0
        current_options = []
        current_indexes = []

        # Iterate through all possible combinations and select the lowest one
        for j in itertools.product(*selections):
            selected_options = [item[0] for item in pre_selected_max]
            selected_indexes = [item[1] for item in pre_selected_max]
            for k in j:
                selected_options.extend([item[0] for item in k])
                selected_indexes.extend([item[1] for item in k])
            if np.isnan(selected_options).all():
                mean = np.nan
            else:
                mean = np.nanmean(selected_options)
            if mean > highest:
                highest = mean
                current_options = selected_options
                current_indexes = selected_indexes
        final_options = []
        final_indexes = []
        for j in range(len(current_options)):
            if current_indexes[j] != 0:
                final_options.append(current_options[j])
                final_indexes.append(current_indexes[j])

        return highest, final_indexes, final_options

    def _get_minmax_df(self, results):
        '''
        This function creates a Dataframe out of the results, which were previously built in a list

        Input:
            results:    All Min and Max in list form

        Output:
            minmax_df:  All Min and Max in dataframe form

        '''
        l1 = []
        l2 = []
        first = True
        columns = True
        col1 = []
        col2 = []
        ind1 = []
        ind2 = []

        for i in results:
            if first:
                name = i[1]
                ind1.append(i[0])
                ind2.append(name)
                first = False
            if i[1] != name:
                name = i[1]
                l2.append(l1)
                l1 = []
                l1.append(i[4])
                columns = False
                ind1.append(i[0])
                ind2.append(name)
            else:
                l1.append(i[4])
            if columns:
                col1.append(i[2])
                col2.append(i[3])

        l2.append(l1)
        col_tuples = list(zip(col1, col2))
        columns = pd.MultiIndex.from_tuples(col_tuples, names=('Type Group', 'Min/Max'))
        ind_tuples = list(zip(ind1, ind2))
        indexes = pd.MultiIndex.from_tuples(ind_tuples, names=('Habitat Type I', 'Habitat Type II'))
        minmax_df = pd.DataFrame.from_records(l2, index=indexes, columns=columns)

        return minmax_df
