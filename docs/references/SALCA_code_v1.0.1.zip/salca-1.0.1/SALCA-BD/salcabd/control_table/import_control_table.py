import pandas as pd
import numpy as np

from ..control_table.control_table import ControlTable


def import_and_build_control_table(filename):
    """
    Imports a control table from an Excel file and calculates additional information, like the maximum and minimum
    scenario

    Parameters
    ----------
    filename : str
        Name of the file containing the control table

    Returns
    -------
    control_table : ControlTable
        All the necessary information from the control table. Including the information not directly in Excel
    """
    control_table = import_control_table(filename)
    control_table.build()
    return control_table


def import_control_table(filename):
    """
    Parameters
    ----------
    filename : str
        Name of the file containing the control table

    Returns
    -------
    control_table : ControlTable
        All the necessary information from the control table
    """
    if type(filename) is ControlTable:
        return filename

    if type(filename) is not str:
        raise TypeError('The input for the control table must be of the type ControlTable or String')

    control_df, validation_df = import_control_table_sheet(filename)
    indicator_df = import_indicator(filename)

    control_table = ControlTable(control_df, indicator_df, validation_df)

    return control_table


def import_control_table_sheet(filename):
    """
    Parameters
    ----------
    filename : str
        Name of the file containing the control table

    Returns
    -------
    control_df : pd.DataFrame
        The coefficients for all type groups from the control table
    validation_df : pd.DataFrame
        The validation information from the control table
    """
    input_df = pd.read_excel(filename, sheet_name='Kontrolltabelle', header=[3, 4], true_values=['z', 'n', 'm'])

    if (input_df.columns[4][1] != 'Management level II'):
        raise ValueError('This control table is not compatible. Please select another one or adjust the code.')

    # Drop empty or unnecessary rows
    input_df = input_df.drop('Rating.1', level=1, axis=1)
    input_df = input_df.drop('Rating HÖA.1', level=1, axis=1)

    input_df.iloc[:, 0:6] = input_df.iloc[:, 0:6].fillna('')

    index = input_df.iloc[:, [1, 2, 3, 4, 5, 6, 0]].columns.tolist()
    input_df = input_df.set_index(index)

    input_df.columns.names = [None, None]
    input_df.index.names = [
        'Habitat Type I',
        'Habitat Type II',
        'Management Level I',
        'Management Level II',
        'Management Level III',
        'Option',
        'ID']

    control_df = input_df.drop('Validation', level=0, axis=1)

    # Replace all strings by NaN
    control_df = control_df.apply(pd.to_numeric, errors='coerce')

    validation_df = input_df['Validation'][['mandatory (z)', 'multiple choice (m)', 'zero-option (n)']]
    validation_df.columns = ['Mandatory', 'Multiple Choice', 'Zero-Option']
    validation_df.columns.names = ['Validation']
    validation_df = validation_df.fillna(False)

    return control_df, validation_df


def import_indicator(filename):
    """
    Parameters
    ----------
    filename : str
        Name of the file containing the control table

    Returns
    -------
    df : pd.DataFrame
        containing the indicator information

    """

    df = pd.read_excel(filename, sheet_name='Indikator-Konfiguration', index_col=0, header=2, true_values=['Ja'])

    df.columns = ['HÖA', 'Nopt,min', 'Weight']
    df.columns.names = ['Variables']
    df.index.names = ['Indicator group']
    df = df.fillna(False)

    if not isinstance(df.iloc[0, 0], np.bool_):
        raise ValueError('This control table is not compatible. Please select another one or adjust the code.')

    return df
