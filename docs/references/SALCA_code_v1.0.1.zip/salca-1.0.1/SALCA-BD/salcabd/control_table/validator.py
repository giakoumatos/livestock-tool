class Validator:
    def __init__(self, zero_option, mandatory, multiple_choice):
        self.zero_option = zero_option
        self.mandatory = mandatory
        self.multiple_choice = multiple_choice
