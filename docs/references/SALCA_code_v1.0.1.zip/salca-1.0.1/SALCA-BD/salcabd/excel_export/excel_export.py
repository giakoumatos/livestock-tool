import pandas as pd
import warnings
import datetime

from .sheet_builders import write_R1, write_R2, write_R3, write_R4, write_R5
from .summary_sheet_builders import write_summary_R1, write_summary_R3, write_summary_R4
from .format_builders import build_formats
from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table


def export_to_excel(pi, ct, filename, consider_zero_values, export_single_files=True):
    """
    Applies the SALCA BD model to a production inventory and creates an Excel file showing the results on multiple
    levels

    Parameters
    ----------
    pi : ProductionInventory
        The production inventory of which the results should be calculated and exported
    ct : ControlTable
        The control table that should be used. Use None or any string to use the default table instead
    filename : str
        Path to the desired output file. Doesn't need to exist already
    consider_zero_values : boolean
        This boolean controls if zero-values are considered for all aggregation levels. Default is True.
    export_single_files : boolean (Optional)
        Should each single file be created for the inventories in the Pipeline? Default is True.

    """
    if type(ct) is not ControlTable:
        ct = get_default_control_table()
        print('Default control table loaded')

    warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)
    indicator = ct.indicator_df
    r1_df, r2_list, r2_meta, r3_df, r4_df, nnrot_and_nnder = pi._calculate_for_export(ct, consider_zero_values)
    farm_id = r2_meta[-1]

    if export_single_files:
        writer = pd.ExcelWriter(filename, engine='xlsxwriter', mode='w')
        wb = writer.book
        wb, formats = build_formats(wb)

        wb = write_R1(wb, formats, r1_df, indicator, farm_id)
        for i in range(len(r2_list)):
            r2_df = r2_list[i]
            meta = r2_meta[i]
            r1_scen = r1_df.loc[:, pd.IndexSlice[meta[0], :, meta[1], meta[2], :]]
            try:
                r1_border = r1_df.loc[:, pd.IndexSlice[meta[0], :, meta[1], meta[2] + ' (Border)', :]]
            except KeyError:
                r1_border = None
            wb = write_R2(wb, formats, r2_df, r1_scen, r1_border, meta, writer, farm_id)
        wb = write_R3(wb, formats, r3_df, indicator, farm_id)
        wb = write_R4(wb, formats, r4_df, indicator, farm_id)
        for scen in r4_df.columns:
            wb = write_R5(wb, formats, r1_df, r3_df, r4_df, indicator, scen[0], farm_id, nnrot_and_nnder)
        wb.close()

    return r1_df, r3_df, r4_df, farm_id


def export_summary_file(r1_summary, r3_summary, r4_summary):
    r1_data = r1_summary.transpose().reset_index().drop(labels=("", ""), axis=1)
    r3_data = r3_summary.transpose().reset_index().drop(labels=("", ""), axis=1)
    r4_data = r4_summary.transpose().reset_index().drop(labels=("", ""), axis=1)

    filename = 'pipeline_summary_' + datetime.datetime.now().strftime("%Y_%m_%d") + '.xlsx'

    writer = pd.ExcelWriter(filename, engine='xlsxwriter', mode='w')
    wb = writer.book

    wb = write_summary_R1(wb, writer, r1_data)
    wb = write_summary_R3(wb, writer, r3_data)
    wb = write_summary_R4(wb, writer, r4_data)

    wb.close()
