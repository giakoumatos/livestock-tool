def build_format(wb, formats, params):
    new_format = wb.add_format()

    if params.get('font_size'):
        new_format.set_font_size(params.get('font_size'))

    if params.get('bold'):
        new_format.set_bold()

    if params.get('align'):
        new_format.set_align(params.get('align'))

    if params.get('valign'):
        new_format.set_valign(params.get('valign'))

    if params.get('left'):
        new_format.set_left(params.get('left'))

    if params.get('rotation'):
        new_format.set_rotation(params.get('rotation'))

    if params.get('num_format'):
        new_format.set_num_format(params.get('num_format'))

    if params.get('right'):
        new_format.set_right(params.get('right'))

    if params.get('top'):
        new_format.set_top(params.get('top'))

    if params.get('bottom'):
        new_format.set_bottom(params.get('bottom'))

    if params.get('bg_color'):
        new_format.set_bg_color(params.get('bg_color'))

    if params.get('name'):
        formats[params.get('name')] = new_format
    else:
        raise KeyError('Format needs a name')

    return wb, formats


def build_formats(wb):

    param_list = []

    param_list.append({'name': 'title', 'font_size': 18, 'bold': True})
    param_list.append({'name': 'subtitle', 'font_size': 12, 'bold': True})
    param_list.append({'name': 'subtitle_centered', 'font_size': 12, 'bold': True, 'align': 'center'})
    param_list.append({'name': 'subtitle_right', 'font_size': 12, 'bold': True, 'align': 'right'})
    param_list.append({'name': 'top_bottom', 'top': 1, 'bottom': 1})
    param_list.append({'name': 'scen_title', 'bg_color': '#FFCC00'})
    param_list.append({'name': 'scen_header', 'bg_color': '#FFFF99', 'right': 1, 'left': 1, 'rotation': 90,
                       'align': 'center', 'bold': True})
    param_list.append({'name': 'scen', 'bg_color': '#FFFF99', 'left': 1, 'right': 1})
    param_list.append({'name': 'scen_line', 'bg_color': '#FFFF99', 'left': 1, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'group', 'bg_color': '#99CCFF', 'left': 2, 'right': 1, 'bottom': 1, 'top': 1})
    param_list.append({'name': 'hab_coeff', 'bg_color': '#CCFFCC', 'left': 2, 'right': 1})
    param_list.append({'name': 'hab_coeff_line', 'bg_color': '#CCFFCC', 'left': 2, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'hab_coeff_header', 'bg_color': '#CCFFCC', 'left': 2, 'right': 1, 'rotation': 90,
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'coeff', 'bg_color': '#CCFFCC', 'left': 1, 'right': 1})
    param_list.append({'name': 'coeff_line', 'bg_color': '#CCFFCC', 'left': 1, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'coeff_header', 'bg_color': '#CCFFCC', 'left': 1, 'right': 1, 'rotation': 90,
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'rating', 'bg_color': '#99CC00', 'left': 1, 'right': 1})
    param_list.append({'name': 'rating_line', 'bg_color': '#99CC00', 'left': 1, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'rating_header', 'bg_color': '#99CC00', 'left': 1, 'right': 1, 'rotation': 90,
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'nopt', 'bg_color': '#008000', 'left': 1, 'right': 1})
    param_list.append({'name': 'nopt_line', 'bg_color': '#008000', 'left': 1, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'nopt_header', 'bg_color': '#008000', 'left': 1, 'right': 1, 'rotation': 90,
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'minmax', 'bg_color': '#FFCC99', 'left': 1, 'right': 1})
    param_list.append({'name': 'minmax_line', 'bg_color': '#FFCC99', 'left': 1, 'right': 1, 'bottom': 2})
    param_list.append({'name': 'minmax_header', 'bg_color': '#FFCC99', 'left': 1, 'right': 1, 'rotation': 90,
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'index_line', 'left': 1, 'right': 1, 'top': 1, 'bottom': 2})
    param_list.append({'name': 'left_border', 'right': 1})
    param_list.append({'name': 'bd_points', 'top': 2, 'bold': True, 'num_format': '0.0', 'align': 'right'})
    param_list.append({'name': 'bd_potential', 'bottom': 2, 'bold': True, 'num_format': '0%', 'align': 'right'})
    param_list.append({'name': 'alternating1', 'bg_color': '#99CCFF', 'valign': 'vcenter', 'num_format': '0.00'})
    param_list.append({'name': 'alternating1_line', 'bg_color': '#99CCFF', 'valign': 'vcenter', 'num_format': '0.00',
                       'bottom': 1})
    param_list.append({'name': 'alternating1_percent', 'bg_color': '#99CCFF', 'valign': 'vcenter', 'num_format': '0%'})
    param_list.append({'name': 'alternating2', 'bg_color': '#FFFFFF', 'valign': 'vcenter', 'num_format': '0.00'})
    param_list.append({'name': 'alternating2_line', 'bg_color': '#FFFFFF', 'valign': 'vcenter', 'num_format': '0.00',
                       'bottom': 1})
    param_list.append({'name': 'alternating2_percent', 'bg_color': '#FFFFFF', 'valign': 'vcenter', 'num_format': '0%'})
    param_list.append({'name': 'alt_light', 'bg_color': '#FFFFCC', 'left': 2, 'right': 2, 'bold': True,
                       'align': 'center'})
    param_list.append({'name': 'alt_light_header', 'bg_color': '#FFFFCC', 'left': 2, 'right': 2, 'top': 2, 'bottom': 2,
                       'bold': True, 'align': 'center', 'rotation': -90})
    param_list.append({'name': 'alt_dark', 'bg_color': '#FFFF99', 'left': 2, 'right': 2, 'bold': True,
                       'align': 'center'})
    param_list.append({'name': 'alt_dark_header', 'bg_color': '#FFFF99', 'left': 2, 'right': 2, 'top': 2, 'bottom': 2,
                       'bold': True, 'align': 'center', 'rotation': -90})
    param_list.append({'name': 'field', 'bg_color': '#CCFFCC', 'left': 1, 'right': 1, 'bold': True, 'align': 'center'})
    param_list.append({'name': 'year', 'bg_color': '#33CCCC', 'left': 1, 'right': 1, 'bold': True, 'align': 'center'})
    param_list.append({'name': 'culture', 'bg_color': '#FFCC99', 'left': 1, 'right': 1, 'bold': True,
                       'align': 'center'})
    param_list.append({'name': 'farm', 'bg_color': '#99CCFF', 'left': 1, 'right': 1, 'bold': True, 'align': 'center'})
    param_list.append({'name': 'summary', 'bg_color': '#FFFFCC', 'valign': 'vcenter', 'num_format': '0.00'})
    param_list.append({'name': 'r5_header', 'left': 2, 'right': 2, 'top': 2, 'bottom': 2, 'bold': True})
    param_list.append({'name': 'r5_farm', 'bg_color': '#99CCFF', 'top': 2, 'left': 1, 'right': 1, 'num_format': '0.00'})
    param_list.append({'name': 'r5_farm_bold', 'bg_color': '#99CCFF', 'top': 2, 'left': 2, 'right': 2,
                       'num_format': 41})
    param_list.append({'name': 'r5_nrot', 'bg_color': '#99CCFF', 'left': 1, 'right': 1, 'num_format': '0.00'})
    param_list.append({'name': 'r5_nrot_bold', 'bg_color': '#99CCFF', 'left': 2, 'right': 2, 'num_format': 41})
    param_list.append({'name': 'r5_field', 'bg_color': '#CCFFCC', 'top': 1, 'left': 1, 'right': 1,
                       'num_format': '0.00'})
    param_list.append({'name': 'r5_field_bold', 'bg_color': '#CCFFCC', 'top': 1, 'left': 2, 'right': 2,
                       'num_format': 41})
    param_list.append({'name': 'r5_soil', 'bg_color': '#CCFFCC', 'left': 1, 'right': 1, 'num_format': '0.00'})
    param_list.append({'name': 'r5_soil_bold', 'bg_color': '#CCFFCC', 'left': 2, 'right': 2, 'num_format': 41})
    param_list.append({'name': 'r5_culture', 'bg_color': '#FFCC99', 'left': 1, 'right': 1, 'num_format': '0.00'})
    param_list.append({'name': 'r5_culture_bold', 'bg_color': '#FFCC99', 'left': 2, 'right': 2, 'num_format': 41})
    param_list.append({'name': 'duration_area', 'bg_color': '#F4E46C', 'left': 1, 'right': 1, 'num_format': '0',
                       'bold': True, 'align': 'center'})
    param_list.append({'name': 'bottom_line', 'bottom': 2})

    formats = {}
    for params in param_list:
        wb, formats = build_format(wb, formats, params)

    return wb, formats
