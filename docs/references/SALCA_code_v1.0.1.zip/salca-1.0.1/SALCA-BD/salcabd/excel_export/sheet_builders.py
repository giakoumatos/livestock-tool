import pandas as pd
import numpy as np


def write_R1(wb, formats, df, indicator, farm_id):
    groups = df.index.get_level_values(0).drop_duplicates()[3:]

    sheet_name = 'R1'
    ws = wb.add_worksheet(sheet_name)

    start_row = 9
    ind2 = [i[1] for i in df.index.tolist()]
    ws = write_title(ws, formats, 'CULTURE', farm_id)
    ws.write_column(start_row, 1, ind2)
    last_col = len(df.columns)*4
    ws = format_summary_rows(ws, formats, last_col)
    ws = format_alternating_rows(ws, formats, groups, last_col)
    ws.write(7, 1, 'Duration:', wb.add_format({'align': 'right', 'bold': 'true'}))

    col_nr = -1
    p_name = ''
    y_name = ''
    c_name = ''
    first_col = 3
    p_end = None
    p_start = None
    y_end = None
    y_start = None
    c_end = None
    c_start = None
    for col in df.columns:
        values = get_r1_values(ws, formats, col, col_nr, c_name, c_start, c_end, y_name, y_start, y_end, p_name,
                               p_start, p_end)
        (ws, col_nr, c_name, c_start, c_end, y_name, y_start, y_end, p_name, p_start, p_end) = values
        data = df[col]
        ws.write_column(start_row, col_nr, data)

        ws = write_overview_header(ws, formats, col_nr, col, 'C')
        ws.write(start_row + 4, col_nr, '', formats['top_bottom'])
        final_col = col_nr

    ws = merge_header(ws, c_start, c_end, 6, c_name, formats['culture'])
    ws = merge_header(ws, y_start, y_end, 5, y_name, formats['year'])
    ws = merge_header(ws, p_start, p_end, 4, p_name, formats['field'])

    if first_col == final_col:
        ws.write(3, first_col, farm_id, formats['farm'])
    else:
        ws.merge_range(3, first_col, 3, final_col, farm_id, formats['farm'])
    ws.freeze_panes(start_row, 2)

    return wb


def write_R2(wb, formats, r2_df, r1_scen, r1_border, meta, writer, farm_id):

    if np.where(r2_df.index == (' ', ' ', ' ', ' ', ' ', ' ', ' '))[0].any():
        split = np.where(r2_df.index == (' ', ' ', ' ', ' ', ' ', ' ', ' '))[0][0]
        measure_df = r2_df.iloc[:split]
        border_df = r2_df.iloc[split+1:]
        has_border = True
    else:
        measure_df = r2_df
        has_border = False

    num_scens = len(r2_df['Scenarios'].columns)
    first_row = 8
    wb, ws = write_r2_measures(wb, formats, measure_df, r1_scen, meta, writer, farm_id, first_row, num_scens)

    if has_border:
        first_row = 12 + split
        wb, ws = write_r2_border(wb, formats, border_df, r1_border, meta, writer, farm_id, first_row, num_scens)

    ws.freeze_panes(9, 7 + num_scens)
    return wb


def write_R3(wb, formats, df, indicator, farm_id):
    groups = df.index.get_level_values(0).drop_duplicates()[3:]

    sheet_name = 'R3'
    ws = wb.add_worksheet(sheet_name)

    start_row = 9
    ind2 = [i[1] for i in df.index.tolist()]
    ws = write_title(ws, formats, 'FIELD', farm_id)
    ws.write_column(start_row, 1, ind2)
    last_col = len(df.columns)*4
    ws = format_summary_rows(ws, formats, last_col)
    ws = format_alternating_rows(ws, formats, groups, last_col)
    ws.write(7, 1, 'Area:', wb.add_format({'align': 'right', 'bold': 'true'}))

    col_nr = 1
    first_col = 3
    p_name = ''
    p_end = None
    p_start = None
    for col in df.columns:
        values = get_r3_values(col, col_nr, p_name, p_start, p_end, ws, formats)
        (ws, col_nr, p_name, p_start, p_end) = values
        data = df[col]
        ws.write_column(start_row, col_nr, data)

        ws = write_overview_header(ws, formats, col_nr, col, 'P')
        ws.write(start_row + 4, col_nr, '', formats['top_bottom'])

        final_col = col_nr
    ws = merge_header(ws, p_start, p_end, 6, p_name, formats['field'])

    if first_col == final_col:
        ws.write(5, first_col, farm_id, formats['farm'])
    else:
        ws.merge_range(5, first_col, 5, final_col, farm_id, formats['farm'])
    ws.freeze_panes(start_row, 2)

    return wb


def write_R4(wb, formats, df, indicator, farm_id):
    groups = df.index.get_level_values(0).drop_duplicates()[3:]

    sheet_name = 'R4'
    ws = wb.add_worksheet(sheet_name)

    start_row = 9
    ind2 = [i[1] for i in df.index.tolist()]
    ws = write_title(ws, formats, 'FARM', farm_id)
    ws.write_column(start_row, 1, ind2)
    last_col = len(df.columns)*4
    ws = format_summary_rows(ws, formats, last_col)
    ws = format_alternating_rows(ws, formats, groups, last_col)

    col_nr = 2
    first_col = 3
    for col in df.columns:
        col_nr += 1
        data = df[col]
        ws.write_column(start_row, col_nr, data)

        ws = write_overview_header(ws, formats, col_nr, col, 'F')
        ws.write(start_row + 4, col_nr, '', formats['top_bottom'])

        final_col = col_nr
    if first_col == final_col:
        ws.write(7, first_col, farm_id, formats['farm'])
    else:
        ws.merge_range(7, first_col, 7, final_col, farm_id, formats['farm'])
    ws.freeze_panes(start_row, 2)

    return wb


def write_R5(wb, formats, r1_df, r3_df, r4_df, indicator, scen, farm_id, nnrot_and_nnder):

    sheet_name = 'R5 (' + scen + ')'
    ws = wb.add_worksheet(sheet_name)
    top_row = 5
    first_col = 4

    groups = r4_df.index.get_level_values(0).drop_duplicates()[3:]
    area_list = r3_df.loc[:, pd.IndexSlice[:, scen, :]].columns.get_level_values(2)

    measure_areas, border_areas, full_areas = get_areas(area_list)

    scen_df = r1_df.loc[:, pd.IndexSlice[:, scen, :, :, :]]

    durations = scen_df.columns.get_level_values(4)

    ws, last_col = write_r5_header(ws, formats, farm_id, scen, top_row, first_col, indicator)
    ws = write_farm_line(ws, formats, first_col, last_col, top_row, sum(full_areas), groups, r4_df, scen)

    if isinstance(nnrot_and_nnder, pd.DataFrame):
        ws = write_nrot_line(ws, formats, first_col, last_col, top_row+4, groups, nnrot_and_nnder, scen, 'nnrot')
        ws = write_nrot_line(ws, formats, first_col, last_col, top_row+5, groups, nnrot_and_nnder, scen, 'nnder')
        row = top_row + 6
    else:
        row = top_row + 4

    field_name = ''
    field_count = -1
    culture_count = 0

    for cul in scen_df.columns:
        year = extract_int(cul[2])
        if cul[0] != field_name:
            field_name = cul[0]
            field_count += 1
            field = r3_df.loc[:, (field_name, scen)]
            ws = write_field_summary_line(ws, formats, row, field, field_name, groups, last_col,
                                          full_areas[field_count])
            row += 1
            cul_nr = 1

        if cul[3] == 'Soil Cover':
            soil_df = scen_df[cul]
            ws = write_soil_cover_line(ws, formats, soil_df, row, field_name, groups, year, last_col,
                                       measure_areas[field_count])
            row += 1
        else:
            df = scen_df[cul]
            if cul[3].endswith('(Border)'):
                area = border_areas[field_count]
            else:
                area = measure_areas[field_count]
            ws = write_culture_line(ws, formats, row, df, field_name, cul[3], groups, year, last_col, cul_nr, area,
                                    durations[culture_count])
            row += 1
            cul_nr += 1
        culture_count += 1

    ws.freeze_panes(8, 0)

    return wb


def get_r1_values(ws, formats, col, col_nr, c_name, c_start, c_end, y_name, y_start, y_end, p_name, p_start, p_end):
    if (col[3] == c_name) and (col[2] == y_name) and (col[0] == p_name):
        col_nr += 1
        p_end = col_nr
        y_end = col_nr
        c_end = col_nr
    elif (col[2] == y_name) and (col[0] == p_name):
        ws = merge_header(ws, c_start, c_end, 6, c_name, formats['culture'])
        c_name = col[3]
        col_nr += 2
        p_end = col_nr
        y_end = col_nr
        c_start = col_nr
    elif col[0] == p_name:
        ws = merge_header(ws, c_start, c_end, 6, c_name, formats['culture'])
        ws = merge_header(ws, y_start, y_end, 5, y_name, formats['year'])
        y_name = col[2]
        c_name = col[3]
        col_nr += 2
        p_end = col_nr
        y_start = col_nr
        c_start = col_nr
    else:
        ws = merge_header(ws, c_start, c_end, 6, c_name, formats['culture'])
        ws = merge_header(ws, y_start, y_end, 5, y_name, formats['year'])
        ws = merge_header(ws, p_start, p_end, 4, p_name, formats['field'])
        p_name = col[0]
        y_name = col[2]
        c_name = col[3]
        col_nr += 4
        p_start = col_nr
        y_start = col_nr
        c_start = col_nr
    return ws, col_nr, c_name, c_start, c_end, y_name, y_start, y_end, p_name, p_start, p_end


def write_overview_header(ws, formats, col_nr, col, level):
    if level == 'C':
        ws.write(4, col_nr, col[0], formats['field'])
        ws.write(5, col_nr, col[2], formats['year'])
        ws.write(6, col_nr, col[3], formats['culture'])
        ws.write(7, col_nr, col[4], formats['duration_area'])
        ws.write(8, col_nr, col[1], formats['scen_header'])
    elif level == 'P':
        ws.write(6, col_nr, col[0], formats['field'])
        ws.write(7, col_nr, col[2], formats['duration_area'])
        ws.write(8, col_nr, col[1], formats['scen_header'])
    elif level == 'F':
        ws.write(8, col_nr, col[0], formats['scen_header'])
    return ws


def write_r2_measures(wb, formats, r2_df, r1_scen, meta, writer, farm_id, first_row, num_scens):
    num_idx = len(r2_df.index)
    last_row = 8 + num_idx
    width = 7+num_scens

    field_name = meta[0]
    year = meta[1]
    culture_name = meta[2]
    sheet_name = meta[3]

    groups = r1_scen.index.get_level_values(0).drop_duplicates()[3:]
    num_groups = len(groups)

    ml3_size = [0]
    for i, df in r2_df.groupby(level=[2, 3, 4], sort=False):
        ml3_size.append(len(df))

    r2_df.to_excel(writer, sheet_name=sheet_name, startrow=6)

    ws = wb.get_worksheet_by_name(sheet_name)

    ws = write_r2_title(ws, formats, farm_id, field_name, year, culture_name, first_row, num_scens, width, num_groups)

    row = first_row
    for i in ml3_size:

        row = row + i
        ws.conditional_format(row, 0, row, 6, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                               'format': formats['index_line']})

    ws.conditional_format(6, 6, 7, 6, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                       'format': formats['left_border']})

    col = 7
    for i in range(0, num_scens):
        col += i
        ws = format_r2_col(ws, formats['scen_header'], formats['scen_line'], formats['scen'], first_row, last_row,
                           col, 'Scenario ' + str(i+1), ml3_size)

    ws.set_column(5, 5, 25)

    ws.merge_range(last_row + 1, 5, last_row + 1, 6, 'Biodiversity Points', formats['bd_points'])
    ws.merge_range(last_row + 2, 5, last_row + 2, 6, 'Biodiversity Potential', formats['bd_potential'])

    for k in range(0, num_groups):
        wb = format_r2_group(wb, ws, formats, groups, k, width, num_scens, r1_scen, first_row, last_row, ml3_size)
    return wb, ws


def write_r2_border(wb, formats, r2_df, r1_scen, meta, writer, farm_id, first_row, num_scens):
    num_idx = len(r2_df.index)
    last_row = first_row + num_idx
    width = 7+num_scens

    sheet_name = meta[3]

    groups = r1_scen.index.get_level_values(0).drop_duplicates()[3:]
    num_groups = len(groups)

    last_col = 6+num_scens+num_groups*width

    ml3_size = [0]
    for i, df in r2_df.groupby(level=[2, 3, 4], sort=False):
        ml3_size.append(len(df))

    r2_df.to_excel(writer, sheet_name=sheet_name, startrow=first_row, header=False)

    ws = wb.get_worksheet_by_name(sheet_name)

    ws.conditional_format(first_row, 0, first_row, last_col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                              'format': formats['bottom_line']})

    row = first_row
    for i in ml3_size:

        row = row + i
        ws.conditional_format(row, 0, row, 6, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                               'format': formats['index_line']})

    col = 7
    for i in range(0, num_scens):
        col += i
        ws = format_r2_col(ws, formats['scen_header'], formats['scen_line'], formats['scen'], first_row, last_row,
                           col, 'Scenario ' + str(i+1), ml3_size, True)

    ws.merge_range(last_row + 1, 5, last_row + 1, 6, 'Biodiversity Points', formats['bd_points'])
    ws.merge_range(last_row + 2, 5, last_row + 2, 6, 'Biodiversity Potential', formats['bd_potential'])

    for k in range(0, num_groups):
        wb = format_r2_group(wb, ws, formats, groups, k, width, num_scens, r1_scen, first_row, last_row, ml3_size, True)
    return wb, ws


def write_r2_title(ws, formats, farm_id, field_name, year, culture_name, first_row, num_scens, width, num_groups):
    ws.write(0, 0, 'Detailed Results Level Culture', formats['title'])
    ws.write(2, 2, 'Farm', formats['subtitle_right'])
    ws.merge_range(2, 3, 2, 5, farm_id, formats['subtitle_centered'])
    ws.write(3, 2, 'Field', formats['subtitle_right'])
    ws.merge_range(3, 3, 3, 5, field_name, formats['subtitle_centered'])
    ws.write(4, 2, 'Year', formats['subtitle_right'])
    ws.merge_range(4, 3, 4, 5, year, formats['subtitle_centered'])
    ws.write(5, 2, 'Culture', formats['subtitle_right'])
    ws.merge_range(5, 3, 5, 5, culture_name, formats['subtitle_centered'])

    ws.conditional_format(first_row-2, 7, first_row-2, 7+num_scens-1,
                          {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': formats['scen_title']})

    ws.conditional_format(first_row-2, 7+num_scens, first_row-2, 7+num_scens+width*num_groups-1,
                          {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': formats['group']})
    return ws


def format_r2_group(wb, ws, formats, groups, k, width, num_scens, r1_scen, first_row, last_row, ml3_size,
                    is_border=False):
    group = groups[k]
    add = k * width
    col = 7 + add + num_scens

    minimum = r1_scen.loc[(group, 'Minimum C')].values[0]
    maximum = r1_scen.loc[(group, 'Maximum C')].values[0]

    ws = format_r2_col(ws, formats['hab_coeff_header'], formats['hab_coeff_line'], formats['hab_coeff'], first_row,
                       last_row, col, 'Habitat Coefficient II', ml3_size, is_border)

    col += 1
    ws = format_r2_col(ws, formats['coeff_header'], formats['coeff_line'], formats['coeff'], first_row, last_row, col,
                       'Management Coefficient III', ml3_size, is_border)

    col += 1
    ws = format_r2_col(ws, formats['coeff_header'], formats['coeff_line'], formats['coeff'], first_row, last_row, col,
                       'Final Coefficient', ml3_size, is_border)

    col += 1
    ws = format_r2_col(ws, formats['rating_header'], formats['rating_line'], formats['rating'], first_row, last_row,
                       col, 'Rating', ml3_size, is_border)

    col += 1
    ws = format_r2_col(ws, formats['nopt_header'], formats['nopt_line'], formats['nopt'], first_row, last_row,
                       col, 'Nopt', ml3_size, is_border)

    for i in range(0, num_scens):
        col += 1
        ws = format_r2_col(ws, formats['scen_header'], formats['scen_line'], formats['scen'], first_row, last_row,
                           col, 'Scenario ' + str(i+1), ml3_size, is_border)
        bd_points = r1_scen.loc[(group, 'BD Points C')].values[i]
        bd_potential = r1_scen.loc[(group, 'BD Potential C')].values[i]
        ws = format_r2_bd(ws, formats, last_row, col, bd_points, bd_potential)

    col += 1
    ws = format_r2_col(ws, formats['minmax_header'], formats['minmax_line'], formats['minmax'], first_row, last_row,
                       col, 'Minimum Scenario', ml3_size, is_border)
    ws = format_r2_bd(ws, formats, last_row, col, minimum, 0)

    col += 1
    ws = format_r2_col(ws, formats['minmax_header'], formats['minmax_line'], formats['minmax'], first_row, last_row,
                       col, 'Maximum Scenario', ml3_size, is_border)
    ws = format_r2_bd(ws, formats, last_row, col, maximum, 1)

    return wb


def format_r2_col(ws, header_format, line_format, regular_format, first_row, last_row, col, name, ml3_size,
                  is_border=False):
    if not is_border:
        ws.write(first_row - 1, col, name, header_format)
    row = first_row
    for i in ml3_size:
        row = row + i
        if not (i == 0 and is_border):
            ws.conditional_format(row, col, row, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                       'format': line_format})

    ws.conditional_format(first_row + 1, col, last_row, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                              'format': regular_format})
    return ws


def format_r2_bd(ws, formats, last_row, col, points, potential):
    ws.write(last_row + 1, col, points, formats['bd_points'])
    ws.write(last_row + 2, col, potential, formats['bd_potential'])
    return ws


def get_r3_values(col, col_nr, p_name, p_start, p_end, ws, formats):
    if col[0] == p_name:
        col_nr += 1
        p_end = col_nr
    else:
        ws = merge_header(ws, p_start, p_end, 6, p_name, formats['field'])
        p_name = col[0]
        col_nr += 2
        p_start = col_nr
    return ws, col_nr, p_name, p_start, p_end


def extract_int(text: str):
    only_numbers = ''.join([x for x in text if x.isdigit()])
    if only_numbers.isdigit():
        return int(only_numbers)
    return None


def write_r5_header(ws, formats, farm_id, scen, top_row, first_col, indicator):
    ws.write(0, 0, 'Detailed Overview Level Field/Farm', formats['title'])
    ws.write(2, 2, 'Farm', formats['subtitle_right'])
    ws.write(2, 3, farm_id, formats['subtitle_centered'])
    ws.write(3, 2, 'Scenario', formats['subtitle_right'])
    ws.write(3, 3, scen, formats['subtitle_centered'])

    ws.write(top_row+2, 0, 'Field', formats['r5_header'])
    ws.set_column(0, 0, 16)

    ws.write(top_row+2, 1, 'Year', formats['r5_header'])
    ws.set_column(1, 1, 8)

    ws.write(top_row+2, 2, 'Culture', formats['r5_header'])
    ws.set_column(2, 2, 8)

    ws.write(top_row, 3, 'Indicator', formats['r5_header'])
    ws.write(top_row+1, 3, 'GAV/HÖA', formats['r5_header'])
    ws.write(top_row+2, 3, 'Relative weight', formats['r5_header'])
    ws.set_column(3, 3, 25)

    column = first_col
    ws, last_col = format_r5_header(ws, formats, indicator, top_row, column)

    ws.write(top_row+2, last_col, 'Area (m2)', formats['r5_header'])
    ws.write(top_row+2, last_col+1, 'Duration', formats['r5_header'])

    return ws, last_col


def format_r5_header(ws, formats, indicator, top_row, column):
    active_format = formats['alt_light']
    active_header_format = formats['alt_light_header']

    for ind in indicator.index.tolist():
        if indicator.loc[ind, 'HÖA']:
            ws.merge_range(top_row, column, top_row, column+1, ind, active_header_format)
            ws.write(top_row+1, column, 'GAV', active_format)
            ws.write(top_row+1, column+1, 'HÖA', active_format)
            ws.write(top_row+2, column, indicator.loc[ind, 'Weight'], active_format)
            ws.write(top_row+2, column+1, indicator.loc[ind, 'Weight'], active_format)
            column += 2

        else:
            ws.write(top_row, column, ind, active_header_format)
            ws.write(top_row+1, column, 'GAV', active_format)
            ws.write(top_row+2, column, indicator.loc[ind, 'Weight'], active_format)
            column += 1

        if active_format == formats['alt_light']:
            active_format = formats['alt_dark']
            active_header_format = formats['alt_dark_header']
        else:
            active_format = formats['alt_light']
            active_header_format = formats['alt_light_header']
    return ws, column


def write_farm_line(ws, formats, first_col, last_col, top_row, area, groups, r4_df, scen):
    ws.set_column(first_col, last_col-1, 6)
    ws.set_column(last_col, last_col, 12)
    ws.set_column(last_col+1, last_col+1, 8)

    ws.write(top_row+3, 0, 'Farm', formats['r5_farm_bold'])
    ws.write(top_row+3, 1, 0, formats['r5_farm_bold'])
    ws.write(top_row+3, 2, 0, formats['r5_farm_bold'])
    ws.write(top_row+3, 3, 0, formats['r5_farm_bold'])
    ws.write(top_row+3, last_col, area, formats['r5_farm_bold'])
    ws.write(top_row+3, last_col+1, 0, formats['r5_farm_bold'])
    iter_col = first_col

    for group in groups:
        value = r4_df.loc[(group, 'BD Points F'), scen]
        ws.write(top_row+3, iter_col, value, formats['r5_farm'])
        iter_col += 1

    return ws


def write_nrot_line(ws, formats, first_col, last_col, row, groups, df, scen, rot_type):
    ws.write(row, 0, 'Farm', formats['r5_nrot_bold'])
    ws.write(row, 1, 0, formats['r5_nrot_bold'])
    ws.write(row, 2, 0, formats['r5_nrot_bold'])
    ws.write(row, 3, 'Crop rotation (' + rot_type + ')', formats['r5_nrot_bold'])
    ws.write(row, last_col, 0, formats['r5_nrot_bold'])
    ws.write(row, last_col+1, 0, formats['r5_nrot_bold'])
    iter_col = first_col

    for group in groups:
        value = df.loc[(group, 'BD Points F'), rot_type]
        ws.write(row, iter_col, value, formats['r5_nrot'])
        iter_col += 1

    return ws


def write_field_summary_line(ws, formats, row, field, field_name, group_list, last_col, area):
    ws.write(row, 0, field_name, formats['r5_field_bold'])
    ws.write(row, 1, 0, formats['r5_field_bold'])
    ws.write(row, 2, 0, formats['r5_field_bold'])
    ws.write(row, 3, 'Field summary', formats['r5_field_bold'])
    ws.write(row, last_col, area, formats['r5_field_bold'])
    ws.write(row, last_col+1, 0, formats['r5_field_bold'])
    iter_col = 4
    for group in group_list:
        value = field.loc[(group, 'BD Points P')].values[0]
        ws.write(row, iter_col, value, formats['r5_field'])
        iter_col += 1

    return ws


def write_soil_cover_line(ws, formats, df, row, field_name, group_list, year, last_col, area):
    ws.write(row, 0, field_name, formats['r5_soil_bold'])
    ws.write(row, 1, year, formats['r5_soil_bold'])
    ws.write(row, 2, 0, formats['r5_soil_bold'])
    ws.write(row, 3, 'Soil cover', formats['r5_soil_bold'])
    ws.write(row, last_col, area, formats['r5_soil_bold'])
    ws.write(row, last_col+1, 0, formats['r5_soil_bold'])

    iter_col = 4
    for group in group_list:
        if df is None:
            value = 0
        else:
            value = df[group, 'BD Points C']

        ws.write(row, iter_col, value, formats['r5_soil'])
        iter_col += 1

    return ws


def write_culture_line(ws, formats, row, df, field_name, culture_name, group_list, year, last_col, cul_nr, area,
                       duration):

    ws.write(row, 0, field_name, formats['r5_culture_bold'])
    ws.write(row, 1, year, formats['r5_culture_bold'])
    ws.write(row, 2, cul_nr, formats['r5_culture_bold'])
    ws.write(row, 3, culture_name, formats['r5_culture_bold'])
    ws.write(row, last_col, area, formats['r5_culture_bold'])
    ws.write(row, last_col+1, duration, formats['r5_culture_bold'])

    iter_col = 4
    for group in group_list:
        value = df[group, 'BD Points C']
        ws.write(row, iter_col, value, formats['r5_culture'])
        iter_col += 1

    return ws


def merge_header(ws, start, end, row, name, formatting):
    if end is not None:
        if end > start:
            ws.merge_range(row, start, row, end, name, formatting)
    return ws


def write_title(ws, formats, level, farm_id):
    ws.write(0, 0, 'Results overview', formats['title'])
    ws.write(1, 0, 'Level ' + level, formats['subtitle'])
    ws.write(3, 0, 'Farm: ' + str(farm_id), formats['subtitle'])
    return ws


def format_summary_rows(ws, formats, last_col):
    start = 9
    ws.merge_range(start, 0, start + 1, 0, 'Summary GAV', formats['summary'])
    ws.merge_range(start + 2, 0, start + 3, 0, 'Summary HÖA', formats['summary'])

    ws.conditional_format(start, 1, start + 3, last_col, {'type': 'no_blanks', 'criteria': '>', 'value': '-10000',
                                                          'format': formats['summary']})
    ws.write(start + 4, 0, '', formats['top_bottom'])
    ws.write(start + 4, 1, '', formats['top_bottom'])
    ws.set_column(0, 0, 22)
    ws.set_column(1, 1, 17)
    return ws


def format_alternating_rows(ws, formats, groups, last_col):
    active_format = formats['alternating1']
    active_line_format = formats['alternating1_line']
    active_percent_format = formats['alternating1_percent']
    for i in range(0, len(groups)):

        start = 14+6*i
        end = 19+6*i
        ws.merge_range(start, 0, end, 0, groups[i], active_line_format)

        ws.conditional_format(start+1, 1, start+1, last_col, {'type': 'no_blanks', 'criteria': '>', 'value': '-10000',
                                                              'format': active_percent_format})

        ws.conditional_format(end, 1, end, last_col, {'type': 'no_blanks', 'criteria': '>', 'value': '-10000',
                                                      'format': active_line_format})

        ws.conditional_format(start, 1, end, last_col, {'type': 'no_blanks', 'criteria': '>', 'value': '-10000',
                                                        'format': active_format})

        if active_format == formats['alternating1']:
            active_format = formats['alternating2']
            active_line_format = formats['alternating2_line']
            active_percent_format = formats['alternating2_percent']
        else:
            active_format = formats['alternating1']
            active_line_format = formats['alternating1_line']
            active_percent_format = formats['alternating1_percent']
    return ws


def get_areas(area_list):
    full_areas = []
    measure_areas = []
    border_areas = []
    for area in area_list:
        if type(area) is str:
            split = area.split(', ')
            full_areas.append(int(split[0]) + int(split[1]))
            measure_areas.append(int(split[0]))
            border_areas.append(int(split[1]))
        else:
            full_areas.append(area)
            measure_areas.append(area)
            border_areas.append(0)
    return measure_areas, border_areas, full_areas
