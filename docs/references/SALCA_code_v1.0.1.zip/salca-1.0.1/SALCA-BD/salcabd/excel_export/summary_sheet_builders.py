def write_summary_R1(wb, writer, r1_data):
    sheet_name = 'R1'
    n_rows = len(r1_data.index)
    n_cols = len(r1_data.columns)
    r1_data.to_excel(writer, sheet_name=sheet_name)
    ws = wb.get_worksheet_by_name(sheet_name)
    header_format = wb.add_format({'bold': 'true', 'align': 'center', 'right': 1})
    ws.write('B1', 'Farm', header_format)
    ws.write('C1', 'Field', header_format)
    ws.write('D1', 'Scenario', header_format)
    ws.write('E1', 'Year', header_format)
    ws.write('F1', 'Culture', header_format)
    ws.write('G1', 'Duration', header_format)

    right_border_format = wb.add_format({'right': 2})
    right_border_format_header = wb.add_format({'right': 2, 'left': 1, 'top': 1, 'bottom': 1})
    left_column_color = wb.add_format({'bg_color': '#FFFF99'})
    metadata_color = wb.add_format({'bg_color': '#D8E4BC'})
    summary_color = wb.add_format({'bg_color': '#E6B8B7'})
    group_color = wb.add_format({'bg_color': '#92CDDC'})

    columns = [0, 6, 10]

    for i in range(17):
        columns.append(16 + i * 6)

    for col in columns:
        ws.conditional_format(0, col, 1, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                               'format': right_border_format_header})
        ws.conditional_format(2, col, 2 + n_rows, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                        'format': right_border_format})

    ws.conditional_format(0, 0, 2 + n_rows, 0, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                'format': left_column_color})
    ws.conditional_format(0, 1, 1, 6, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': metadata_color})
    ws.conditional_format(0, 7, 1, 10, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': summary_color})
    ws.conditional_format(0, 11, 1, n_cols, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': group_color})
    ws.set_column(0, n_cols, 15)

    return wb


def write_summary_R3(wb, writer, r3_data):
    sheet_name = 'R3'
    n_rows = len(r3_data.index)
    n_cols = len(r3_data.columns)
    r3_data.to_excel(writer, sheet_name=sheet_name)
    ws = wb.get_worksheet_by_name(sheet_name)
    header_format = wb.add_format({'bold': 'true', 'align': 'center', 'right': 1})
    ws.write('B1', 'Farm', header_format)
    ws.write('C1', 'Field', header_format)
    ws.write('D1', 'Scenario', header_format)
    ws.write('E1', 'Area', header_format)

    right_border_format = wb.add_format({'right': 2})
    right_border_format_header = wb.add_format({'right': 2, 'left': 1, 'top': 1, 'bottom': 1})
    left_column_color = wb.add_format({'bg_color': '#FFFF99'})
    metadata_color = wb.add_format({'bg_color': '#D8E4BC'})
    summary_color = wb.add_format({'bg_color': '#E6B8B7'})
    group_color = wb.add_format({'bg_color': '#92CDDC'})

    columns = [0, 4, 8]

    for i in range(17):
        columns.append(14 + i * 6)

    for col in columns:
        ws.conditional_format(0, col, 1, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                               'format': right_border_format_header})
        ws.conditional_format(2, col, 2 + n_rows, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                        'format': right_border_format})

    ws.conditional_format(0, 0, 2 + n_rows, 0, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                'format': left_column_color})
    ws.conditional_format(0, 1, 1, 4, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': metadata_color})
    ws.conditional_format(0, 5, 1, 8, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': summary_color})
    ws.conditional_format(0, 9, 1, n_cols, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': group_color})

    ws.set_column(0, n_cols, 15)

    return wb


def write_summary_R4(wb, writer, r4_data):
    sheet_name = 'R4'
    n_rows = len(r4_data.index)
    n_cols = len(r4_data.columns)
    r4_data.to_excel(writer, sheet_name=sheet_name)
    ws = wb.get_worksheet_by_name(sheet_name)
    header_format = wb.add_format({'bold': 'true', 'align': 'center', 'right': 1})
    ws.write('B1', 'Farm', header_format)
    ws.write('C1', 'Scenario', header_format)

    right_border_format = wb.add_format({'right': 2})
    right_border_format_header = wb.add_format({'right': 2, 'left': 1, 'top': 1, 'bottom': 1})
    left_column_color = wb.add_format({'bg_color': '#FFFF99'})
    metadata_color = wb.add_format({'bg_color': '#D8E4BC'})
    summary_color = wb.add_format({'bg_color': '#E6B8B7'})
    group_color = wb.add_format({'bg_color': '#92CDDC'})

    columns = [0, 2, 6]

    for i in range(17):
        columns.append(12 + i * 6)

    for col in columns:
        ws.conditional_format(0, col, 1, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                               'format': right_border_format_header})
        ws.conditional_format(2, col, 2 + n_rows, col, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                        'format': right_border_format})

    ws.conditional_format(0, 0, 2 + n_rows, 0, {'type': 'cell', 'criteria': '>', 'value': '-10000',
                                                'format': left_column_color})
    ws.conditional_format(0, 1, 1, 2, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': metadata_color})
    ws.conditional_format(0, 3, 1, 6, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': summary_color})
    ws.conditional_format(0, 7, 1, n_cols, {'type': 'cell', 'criteria': '>', 'value': '-10000', 'format': group_color})

    ws.set_column(0, n_cols, 15)

    return wb
