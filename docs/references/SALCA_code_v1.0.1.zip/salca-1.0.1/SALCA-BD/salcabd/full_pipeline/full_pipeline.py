import os
import glob
from time import time

from ..calculation.calculation import build_empty_df
from ..control_table.control_table import ControlTable
from ..control_table.import_control_table import import_and_build_control_table
from ..production_inventory.import_production_inventory import import_production_inventory
from ..excel_export.excel_export import export_to_excel, export_summary_file
from ..pkg_resources.default_control_table import get_default_control_table


def full_pipeline(pi_folder, ct_filename=None, consider_zero_values=True, export_single_files=True):
    '''
    Imports a control table and a list of production inventories. The datasets are validated and the bd points are
    calculated on all aggregation levels. The results are placed in pi_folder/Results.
    If the input folder contains subfolders, the pipeline will also handle all production inventories in subfolders.

    Parameters
    ----------
    pi_folder : str
        Path to the folder containing the production inventories. Or to a single production inventory.
    ct_filename : str, ControlTable (Optional)
        Path to the Excel file containing the control table or existing instance of the class ControlTable. If left
        empty, the default control table will be loaded.
    consider_zero_values : boolean (Optional)
        This boolean controls if zero-values are considered for all aggregation levels. Default is True.
    export_single_files : boolean (Optional)
        When multiple inventories are entered in the pipeline, should the output for each single file be generated as
        well? If false, only the summary file will be created. Default is True

    '''
    print('Pipeline started...')
    t2 = time()
    if type(ct_filename) is ControlTable:
        ct = ct_filename
        print('Control table given as argument')
    elif ct_filename is None:
        ct = get_default_control_table()
        print('Default control table loaded')
    else:
        t0 = time()
        ct = import_and_build_control_table(ct_filename)
        t1 = '{:.1f}'.format(time() - t0)
        print('Control table imported in ' + t1 + ' seconds...')
    if pi_folder.endswith('.xlsm'):
        pipeline_single_file(pi_folder, ct, consider_zero_values)
    else:
        pipeline_folder(pi_folder, ct, consider_zero_values, export_single_files)
    t3 = '{:.1f}'.format(time() - t2)
    print('Pipeline done in ' + t3 + ' seconds!')


def pipeline_single_file(filename, ct, consider_zero_values):
    t0 = time()
    pi = import_production_inventory(filename, ct)
    t1 = '{:.1f}'.format(time() - t0)
    print('Production inventory loaded in ' + t1 + ' seconds...')
    t0 = time()
    pi.validate(ct)
    t1 = '{:.1f}'.format(time() - t0)
    print('Production inventory validated in ' + t1 + ' seconds...')
    t0 = time()
    out_filename = get_out_filename(filename, consider_zero_values)
    export_to_excel(pi, ct, out_filename, consider_zero_values)
    t1 = '{:.1f}'.format(time() - t0)
    print('Calculation and Export done in ' + t1 + ' seconds...')


def pipeline_folder(pi_folder, ct, consider_zero_values, export_single_files):
    file_list = []
    for subfolder in os.walk(pi_folder):
        file_list.extend(glob.glob(subfolder[0] + '/*.xlsm'))
    i = 1
    num_files = str(len(file_list))

    r1_summary = build_empty_df(ct.indicator_df, 'culture', True)
    r3_summary = build_empty_df(ct.indicator_df, 'field', True)
    r4_summary = build_empty_df(ct.indicator_df, 'farm', True)

    for pi_filename in file_list:
        try:

            t0 = time()
            pi = import_production_inventory(pi_filename, ct)
            t1 = '{:.1f}'.format(time() - t0)
            print('Production inventory ' + str(i) + '/' + num_files + ' loaded in ' + t1 + ' seconds...')
            t0 = time()
            pi.validate(ct)
            t1 = '{:.1f}'.format(time() - t0)
            print('Production inventory ' + str(i) + '/' + num_files + ' validated in ' + t1 + ' seconds...')
            t0 = time()

            out_filename = get_out_filename(pi_filename, consider_zero_values)

            r1_df, r3_df, r4_df, farm_id = export_to_excel(pi, ct, out_filename, consider_zero_values,
                                                           export_single_files)

            for col in r1_df:
                index = (farm_id,) + col
                r1_summary[index] = r1_df[col]
            for col in r3_df:
                index = (farm_id,) + col
                r3_summary[index] = r3_df[col]
            for col in r4_df:
                index = (farm_id,) + col
                r4_summary[index] = r4_df[col]

            t1 = '{:.1f}'.format(time() - t0)
            print('Calculation and Export ' + str(i) + '/' + num_files + ' done in ' + t1 + ' seconds...')
        except ValueError:
            print('File ' + str(i) + '/' + num_files + ' (' + pi_filename + ') is not a production inventory!')
        i += 1

    t0 = time()
    export_summary_file(r1_summary, r3_summary, r4_summary)
    t1 = '{:.1f}'.format(time() - t0)
    print('Summary file created in ' + t1 + ' seconds...')


def get_out_filename(filename, consider_zero_values):
    if os.path.split(filename)[0] == '':
        folder = ''
    else:
        folder, filename = os.path.split(filename)
    out_folder = os.path.join(folder, 'Results')
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)

    if consider_zero_values:
        append = ''
    else:
        append = 'NoZeroValues_'

    new_filename = 'Results_' + append + filename[:-1] + 'x'
    out_filename = os.path.join(out_folder, new_filename)

    return out_filename
