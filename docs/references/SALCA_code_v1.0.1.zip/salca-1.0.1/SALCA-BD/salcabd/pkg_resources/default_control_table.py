import importlib.resources
import pickle
import os

from ..control_table.control_table import ControlTable


def get_default_control_table():
    """
    Loads the default control table currently stored in the package.

    Returns
    -------
    ct : ControlTable
        Default control table

    """
    text = importlib.resources.read_binary('salcabd.pkg_resources', 'control_table.ct')
    ct = pickle.loads(text)
    return ct


def overwrite_default_control_table(ct):
    """
    Sets the selected control table as the new default control table for the package.

    Attention: This will permanently overwrite the default control table stored in the package. Only do this if you
    don't need the original defaul control table anymore.

    Parameters
    ----------
    ct : ControlTable
        The control table that should be set as the new default control table
    """
    if type(ct) is not ControlTable:
        raise ValueError('You can only overwrite the default control table with an instance of the type ControlTable!')

    script_path = os.path.abspath(__file__)
    folder = os.path.split(script_path)[0]
    filename = 'control_table.ct'
    path = os.path.join(folder, filename)
    pickle.dump(ct, open(path, 'wb'))


if __name__ == '__main__':
    ct = get_default_control_table()
    overwrite_default_control_table(ct)
