import pandas as pd
import numpy as np

from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table
from ..calculation.calculation import build_empty_df, get_R2_dataframe, calculate_scenario, aggregate_indicator_groups


class Culture:
    def __init__(self, identifier: str, number: int, year: int, habitat_type_2: str, habitat_type_2_border: str,
                 measures, border):
        self.__identifier = identifier
        self.__number = number
        self.__duration = {}
        self.__year = year
        self.__habitat_type_2 = habitat_type_2
        self.__habitat_type_2_border = habitat_type_2_border
        self.measures = measures
        self.border = border

    @property
    def identifier(self):
        return self.__identifier

    @property
    def habitat_type_2(self):
        return self.__habitat_type_2

    @property
    def habitat_type_2_border(self):
        return self.__habitat_type_2_border

    @property
    def number(self):
        return self.__number

    @property
    def duration(self):
        return self.__duration

    @property
    def year(self):
        return self.__year

    def add_scenario(self, scenario_number: int, duration: float, values):
        """
        Adds a scenario to the measures dataframe and adds the duration of the scenario to the duration dictionary.

        Parameters
        ----------
        scenario_number : int
            The number of the scenario, e.g "1" for the first scenario.
        duration : float
            The duration of the culture in this scenario. Will be added to the duration dictionary.
        values : pd.Series
            The values to be set for the scenario. A series of bools.

        """
        column_index = pd.MultiIndex.from_tuples([('Scenarios', scenario_number)])
        values.name = None
        scenario_values = pd.DataFrame(values, columns=column_index)
        self.__duration[scenario_number] = duration
        self.measures = self.measures.merge(scenario_values, left_on="ID", right_index=True)

    def add_border_scenario(self, scenario_number: int, values):
        """
        Adds a scenario to the border dataframe.

        Parameters
        ----------
        scenario_number : int
            The number of the scenario, e.g "1" for the first scenario.
        values : pd.Series
            The values to be set for the scenario. A series of bools.

        """
        column_index = pd.MultiIndex.from_tuples([('Scenarios', scenario_number)])
        values.name = None
        scenario_values = pd.DataFrame(values, columns=column_index)
        self.border = self.border.merge(scenario_values, left_on="ID", right_index=True)

    def validate(self, ct=None):
        """
        Validates this culture based on the validation criteria (Mandatory, Zero-Option and Multiple Choice). Raises an
        error if one of the criteria is not fulfilled.

        Parameters
        ----------
        ct : ControlTable (optional)
            The control table to use for the validation. If None, the default control table is loaded.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')

        ht2 = self.habitat_type_2

        idx = ct.validator.zero_option.tolist()
        bools = [(i[1] == ht2) for i in idx]
        zero_filtered = [i for (i, v) in zip(idx, bools) if v]

        idx = ct.validator.mandatory.tolist()
        bools = [(i[1] == ht2) for i in idx]
        mandatory_filtered = [i for (i, v) in zip(idx, bools) if v]

        idx = ct.validator.multiple_choice.tolist()
        bools = [(i[1] == ht2) for i in idx]
        multiple_filtered = [i for (i, v) in zip(idx, bools) if v]

        for scen in self.measures['Scenarios']:
            df = self.measures['Scenarios', scen]
            for i, new_df in df.groupby(level=['Management Level I', 'Management Level II', 'Management Level III']):
                if new_df.sum() < 1:
                    if new_df.index.isin(mandatory_filtered).any():
                        raise ValueError('Validation failed for culture ' + self.identifier + ' at ' + str(i)
                                         + ' (Mandatory). Crop ID: ' + str(self.number) + ', Habitat Type II: ' + self.habitat_type_2)

                if new_df.sum() > 1:
                    if new_df.index.isin(multiple_filtered).sum() == 0:
                        raise ValueError('Validation failed for culture ' + self.identifier + ' at ' + str(i)
                                         + ' (Multiple Choice). Crop ID: ' + str(self.number) + ', Habitat Type II: ' + self.habitat_type_2)

            for i, new_df in df.groupby(level=['Management Level I', 'Management Level II']):
                if new_df.sum() > 1:
                    ind = new_df.index.isin(zero_filtered)
                    if ind.sum() == 1:
                        idx = np.where(ind)[0][0]
                        if new_df.iloc[idx] > 0:
                            raise ValueError('Validation failed for culture ' + self.identifier + ' at ' + str(i)
                                             + ' (Zero-Option). Crop ID: ' + str(self.number) + ', Habitat Type II: ' + self.habitat_type_2)

    def calculate_nhab(self, ct=None, consider_zero_values=True):
        """
        Calculates Nhab for each indicator group and each scenario within the culture (both measures and border).

        Parameters
        ----------
        ct : ControlTable, optional
            The control table to use for the calculations. If None, the default control table is loaded.
        consider_zero_values : boolean (Optional)
            This boolean controls if zero-values are considered for all aggregation levels. Default is True.

        Returns
        -------
        r1_df : pd.DataFrame
            The resulting biodiversity points, biodiversity potential, maximum and minimum for the habitat and maximum
            and minimum over all habitats. For each indicator group, and also aggregated over all indicator groups
            for GAV and HÖA.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        indicator = ct.indicator_df
        year = 'Year ' + str(self.year)
        r1_df = build_empty_df(indicator, 'culture')
        for scen in self.measures['Scenarios']:
            r1_df = calculate_scenario(self, scen, ct, 'Field', year, self.identifier, r1_df)
            column = ('Field', 'Scenario ' + str(scen), year, self.identifier, self.duration[scen])
            r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
        if self.border is not None:
            for scen in self.border['Scenarios']:
                r1_df = calculate_scenario(self, scen, ct, 'Field', year, self.identifier, r1_df, 'border')
                column = ('Field', 'Scenario ' + str(scen), year, self.identifier + ' (Border)', self.duration[scen])
                r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
        return r1_df

    def _calculate_in_iteration(self, ct, include_r2, field_name, field_number, r1_df, consider_zero_values,
                                r2_list=None, r2_meta=None):
        indicator = ct.indicator_df
        year = 'Year ' + str(self.year)
        for scen in self.measures['Scenarios']:
            r1_df = calculate_scenario(self, scen, ct, field_name, year, self.identifier, r1_df)
            column = (field_name, 'Scenario ' + str(scen), year, self.identifier, self.duration[scen])
            r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
        if self.border is not None:
            for scen in self.border['Scenarios']:
                r1_df = calculate_scenario(self, scen, ct, field_name, year, self.identifier, r1_df, 'border')
                column = (field_name, 'Scenario ' + str(scen), year, self.identifier + ' (Border)', self.duration[scen])
                r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
        if include_r2:
            r2_list.append(self._build_R2_dataframe(indicator))
            r2_meta.append([field_name, year, self.identifier,
                            'R2 (P' + str(field_number) + '-Y' + str(self.year) + '-C' + str(self.number) + ')'])
            return r1_df, r2_list, r2_meta
        else:
            return r1_df

    def _build_R2_dataframe(self, indicator):
        out_df = get_R2_dataframe(self.measures, indicator)
        if self.border is not None:
            border_df = get_R2_dataframe(self.border, indicator)
            empty_index = pd.MultiIndex.from_tuples([(' ', ' ', ' ', ' ', ' ', ' ', ' ')])
            empty_line = pd.DataFrame(index=empty_index, columns=out_df.columns)
            out_df = out_df.append(empty_line)
            out_df = out_df.append(border_df)
        return out_df
