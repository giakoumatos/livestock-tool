import pandas as pd
import numpy as np
import warnings

from .culture import Culture
from .soil_cover import SoilCover
from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table
from ..calculation.calculation import build_empty_df, aggregate_indicator_groups


class Field:

    def __init__(self, identifier: str, number: int, area: float, border_area: float, crop_number: int,
                 num_catch_crops: int):
        self.cultures = []
        self.soil_covers = []
        self.__identifier = identifier
        self.__number = number
        self.__area = area
        self.__border_area = border_area
        self.__crop_number = crop_number
        self.__num_catch_crops = num_catch_crops

    @property
    def identifier(self) -> str:
        return self.__identifier

    @property
    def number(self) -> int:
        return self.__number

    @property
    def area(self) -> float:
        return self.__area

    @property
    def border_area(self) -> float:
        return self.__border_area

    @property
    def crop_number(self) -> int:
        return self.__crop_number

    @property
    def num_catch_crops(self) -> int:
        return self.__num_catch_crops

    def add_culture(self, culture: Culture):
        self.cultures.append(culture)

    def add_soil_cover(self, soil_cover: SoilCover):
        self.soil_covers.append(soil_cover)

    def validate(self, ct=None):
        """
        Validates each culture on the field based on the validation criteria (Mandatory, Zero-Option and Multiple
        Choice). Raises an error if one of the criteria is not fulfilled.

        Parameters
        ----------
        ct : ControlTable (optional)
            The control table to use for the validation. If None, the default control table is loaded.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        for culture in self.cultures:
            culture.validate(ct)

    def calculate_npar(self, ct=None, consider_zero_values=True):
        """
        Calculates Npar for each indicator group and scenario. Aggregated over all cultures and soil covers, based on
        the durations. If available, borders are also included, aggregated based on the areas.

        Parameters
        ----------
        ct : ControlTable, optional
            The control table to use for the calculations. If None, the default control table is loaded.
        consider_zero_values : boolean (Optional)
            This boolean controls if zero-values are considered for all aggregation levels. Default is True.

        Returns
        -------
        r3_df : pd.DataFrame
            The resulting biodiversity points, biodiversity potential, maximum and minimum for the habitat and maximum
            and minimum over all habitats. For each indicator group, and also aggregated over all indicator groups
            for GAV and HÖA.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        indicator = ct.indicator_df
        r1_df = build_empty_df(indicator, 'culture')
        r3_df = build_empty_df(indicator, 'field')
        for culture in self.cultures:
            r1_df = culture._calculate_in_iteration(ct, False, self.identifier, self.number, r1_df,
                                                    consider_zero_values)
        for soil_cover in self.soil_covers:
            r1_df = soil_cover._calculate_in_iteration(ct, False, self.identifier, self.number, r1_df,
                                                       consider_zero_values)
        r1_df.sort_index(axis=1, level=[0, 1, 2], sort_remaining=False, inplace=True)
        for scen in self.cultures[0].measures['Scenarios']:
            r3_df = self._aggregate(r1_df, indicator, scen, r3_df, consider_zero_values)
        return r3_df

    def calculate_nrot(self, ct=None, consider_zero_values=True):
        """
        Calculates Nrot for the crop rotation in the field. Based on the formula in the Salca BD documentation.

        Parameters
        ----------
        ct : ControlTable, optional
            The control table to use for the calculations. If None, the default control table is loaded.
        consider_zero_values : boolean (Optional)
            This boolean controls if zero-values are considered for all aggregation levels. Default is True.

        Returns
        -------
        r3_df : pd.DataFrame
            The resulting biodiversity points, biodiversity potential, maximum and minimum for the habitat and maximum
            and minimum over all habitats. For each indicator group, and also aggregated over all indicator groups
            for GAV and HÖA.

        """
        if not self.crop_number:
            print("No crop rotation available")
            return None
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        indicator = ct.indicator_df
        r1_df = build_empty_df(indicator, 'culture')
        r3_df = build_empty_df(indicator, 'field')
        for culture in self.cultures:
            r1_df = culture._calculate_in_iteration(ct, False, self.identifier, self.number, r1_df,
                                                    consider_zero_values)
        for soil_cover in self.soil_covers:
            r1_df = soil_cover._calculate_in_iteration(ct, False, self.identifier, self.number, r1_df,
                                                       consider_zero_values)
        r1_df.sort_index(axis=1, level=[0, 1, 2], sort_remaining=False, inplace=True)
        nnrot_and_nnder = self._get_nnrot_and_nnder(ct)
        for scen in self.cultures[0].measures['Scenarios']:
            r3_df = self._aggregate_nrot(r1_df, indicator, scen, r3_df, nnrot_and_nnder, consider_zero_values)
        return r3_df

    def _calculate_in_iteration(self, ct, r1_df, r2_list, r2_meta, r3_df, nnrot_and_nnder, consider_zero_values):
        indicator = ct.indicator_df
        for culture in self.cultures:
            r1_df, r2_list, r2_meta = culture._calculate_in_iteration(ct, True, self.identifier, self.number, r1_df,
                                                                      consider_zero_values, r2_list, r2_meta)
        for soil_cover in self.soil_covers:
            r1_df, r2_list, r2_meta = soil_cover._calculate_in_iteration(ct, True, self.identifier, self.number, r1_df,
                                                                         consider_zero_values, r2_list, r2_meta)
        r1_df.sort_index(axis=1, level=[0, 1, 2], sort_remaining=False, inplace=True)
        if self.crop_number:
            for scen in self.cultures[0].measures['Scenarios']:
                r3_df = self._aggregate_nrot(r1_df, indicator, scen, r3_df, nnrot_and_nnder, consider_zero_values)
        else:
            for scen in self.cultures[0].measures['Scenarios']:
                r3_df = self._aggregate(r1_df, indicator, scen, r3_df, consider_zero_values)
        return r1_df, r2_list, r2_meta, r3_df

    def _aggregate(self, r1_df, indicator, scen, r3_df, consider_zero_values):
        warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)
        scenario = 'Scenario ' + str(scen)
        field_name = self.identifier
        if self.border_area == 0:
            field_area = self.area
        else:
            field_area = str(self.area) + ', ' + str(self.border_area)
        scen_df = r1_df[field_name, scenario]
        if scen_df.columns[-1][1] == 'Soil Cover':
            has_soil_cover = True
        else:
            has_soil_cover = False

        if len(scen_df.columns) == 1:
            r3_df[field_name, scenario, field_area] = scen_df.values
        else:
            r3_df[field_name, scenario, field_area] = np.nan
            groups = r1_df.index.get_level_values(0).drop_duplicates()[3:]
            for group in groups:
                r3_df = self._aggregate_group(scen_df, has_soil_cover, group, indicator, field_name, scenario,
                                              field_area, r3_df, consider_zero_values)
        column = (field_name, scenario, field_area)
        r3_df = aggregate_indicator_groups(r3_df, indicator, column, 'field', consider_zero_values)
        return r3_df

    def _aggregate_group(self, scen_df, has_soil_cover, group, indicator, field_name, scenario, field_area, r3_df,
                         consider_zero_values):
        measure_cols = []
        border_cols = []
        for col in scen_df.columns:
            if str(col[1]).endswith('(Border)'):
                border_cols.append(col)
            else:
                measure_cols.append(col)
        measure_df = scen_df[measure_cols]
        border_df = scen_df[border_cols]
        if len(measure_cols) == 1:
            bd_points = measure_df.loc[group, 'BD Points C'].values[0]
            field_min = measure_df.loc[group, 'Minimum C'].values[0]
            field_max = measure_df.loc[group, 'Maximum C'].values[0]

        elif indicator.at[group[0:-4], 'Nopt,min']:
            if has_soil_cover:
                soil_df = measure_df.iloc[:, -1]
                measure_df = measure_df.iloc[:, :-1]
                bd_points = (measure_df.loc[group, 'BD Points C'].min() + soil_df.loc[group, 'BD Points C']) / 2
                field_min = (measure_df.loc[group, 'Minimum C'].min() + soil_df.loc[group, 'Minimum C']) / 2
                field_max = (measure_df.loc[group, 'Maximum C'].min() + soil_df.loc[group, 'Maximum C']) / 2
            else:
                bd_points = measure_df.loc[group, 'BD Points C'].min()
                field_min = measure_df.loc[group, 'Minimum C'].min()
                field_max = measure_df.loc[group, 'Maximum C'].min()
        else:
            if has_soil_cover:
                soil_df = measure_df.iloc[:, -1]
                measure_df = measure_df.iloc[:, :-1]
                bd_points = (self._aggregate_with_duration(measure_df, group, 'BD Points C', consider_zero_values)
                             + soil_df.loc[group, 'BD Points C']) / 2
                field_min = (self._aggregate_with_duration(measure_df, group, 'Minimum C', consider_zero_values)
                             + soil_df.loc[group, 'Minimum C']) / 2
                field_max = (self._aggregate_with_duration(measure_df, group, 'Maximum C', consider_zero_values)
                             + soil_df.loc[group, 'Maximum C']) / 2
            else:
                bd_points = self._aggregate_with_duration(measure_df, group, 'BD Points C', consider_zero_values)
                field_min = self._aggregate_with_duration(measure_df, group, 'Minimum C', consider_zero_values)
                field_max = self._aggregate_with_duration(measure_df, group, 'Maximum C', consider_zero_values)

        hab_min = measure_df.loc[group, 'Minimum H'][0]
        hab_max = measure_df.loc[group, 'Maximum H'][0]

        if len(border_cols) == 1:
            bd_border = border_df.loc[group, 'BD Points C'].values[0]
            border_min = border_df.loc[group, 'Minimum C'].values[0]
            border_max = border_df.loc[group, 'Maximum C'].values[0]
            bd_points, field_max, field_min = self._aggregate_with_border(bd_points, bd_border, field_max, border_max,
                                                                          field_min, border_min)
        elif len(border_cols) != 0:
            bd_border = self._aggregate_with_duration(border_df, group, 'BD Points C', consider_zero_values)
            border_min = self._aggregate_with_duration(border_df, group, 'BD Points C', consider_zero_values)
            border_max = self._aggregate_with_duration(border_df, group, 'BD Points C', consider_zero_values)
            bd_points, field_max, field_min = self._aggregate_with_border(bd_points, bd_border, field_max, border_max,
                                                                          field_min, border_min)
        numerator = bd_points - field_min
        denominator = field_max - field_min
        if denominator == 0:
            bd_potential = 0
        else:
            bd_potential = numerator / denominator

        r3_df.at[(group, 'BD Points P'), (field_name, scenario, field_area)] = bd_points
        r3_df.at[(group, 'BD Potential P'), (field_name, scenario, field_area)] = bd_potential
        r3_df.at[(group, 'Maximum P'), (field_name, scenario, field_area)] = field_max
        r3_df.at[(group, 'Minimum P'), (field_name, scenario, field_area)] = field_min
        r3_df.at[(group, 'Maximum H'), (field_name, scenario, field_area)] = hab_max
        r3_df.at[(group, 'Minimum H'), (field_name, scenario, field_area)] = hab_min
        return r3_df

    def _aggregate_with_duration(self, scen_df, group, subgroup, consider_zero_values):
        durations = scen_df.columns.get_level_values(2)
        values = scen_df.loc[group, subgroup].values
        value_sum = 0
        duration_sum = 0
        for i in range(len(values)):
            if ((values[i] != 0) or consider_zero_values):
                value_sum += values[i] * durations[i]
                duration_sum += durations[i]
        if duration_sum == 0:
            value = 0
        else:
            value = value_sum / duration_sum
        return value

    def _aggregate_with_border(self, bd_points, bd_border, field_max, border_max, field_min, border_min):
        area = self.area
        border_area = self.border_area
        sum_area = area + border_area

        bd_points = (bd_points * area + bd_border * border_area) / sum_area
        field_max = (field_max * area + border_max * border_area) / sum_area
        field_min = (field_min * area + border_min * border_area) / sum_area

        return bd_points, field_max, field_min

    def _get_nnrot_and_nnder(self, ct):
        groups = ct.indicator_df.index.tolist()
        result_df = build_empty_df(ct.indicator_df, 'farm')
        result_df['nnrot'] = np.nan
        result_df['nnder'] = np.nan
        for group in groups:
            row = (group + ' GAV', 'BD Points F')
            nnrot_nopt = ct.control_df.loc[pd.IndexSlice[:, :, :, :, :, :, self.crop_number], (group, 'Nopt')]
            result_df.at[row, 'nnrot'] = nnrot_nopt.values[0]
            nnder_nopt = ct.control_df.loc[pd.IndexSlice[:, :, :, :, :, :, self.num_catch_crops], (group, 'Nopt')]
            result_df.at[row, 'nnder'] = nnder_nopt.values[0]
            row = (group + ' GAV', 'Maximum F')
            val_max = ct.minmax_df.at[('A. Cropland', 'Crop rotation'), (group + ' GAV', 'Maximum')]
            result_df.at[row, 'nnrot'] = val_max
            result_df.at[row, 'nnder'] = val_max
            row = (group + ' GAV', 'Minimum F')
            val_min = ct.minmax_df.at[('A. Cropland', 'Crop rotation'), (group + ' GAV', 'Minimum')]
            result_df.at[row, 'nnrot'] = val_min
            result_df.at[row, 'nnder'] = val_min
            if ct.indicator_df.at[group, 'HÖA']:
                row = (group + ' HÖA', 'BD Points F')
                nnrot_nopt = ct.control_df.loc[pd.IndexSlice[:, :, :, :, :, :, self.crop_number], (group, 'Nopt HÖA')]
                result_df.at[row, 'nnrot'] = nnrot_nopt.values[0]
                nnder_nopt = ct.control_df.loc[pd.IndexSlice[:, :, :, :, :, :, self.num_catch_crops],
                                               (group, 'Nopt HÖA')]
                result_df.at[row, 'nnder'] = nnder_nopt.values[0]
                row = (group + ' HÖA', 'Maximum F')
                val_max = ct.minmax_df.at[('A. Cropland', 'Crop rotation'), (group + ' HÖA', 'Maximum')]
                result_df.at[row, 'nnrot'] = val_max
                result_df.at[row, 'nnder'] = val_max
                row = (group + ' HÖA', 'Minimum F')
                val_min = ct.minmax_df.at[('A. Cropland', 'Crop rotation'), (group + ' HÖA', 'Minimum')]
                result_df.at[row, 'nnrot'] = val_min
                result_df.at[row, 'nnder'] = val_min

        return result_df

    def _aggregate_nrot(self, r1_df, indicator, scen, r3_df, nnrot_and_nnder, consider_zero_values):
        warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)
        scenario = 'Scenario ' + str(scen)
        field_name = self.identifier
        scen_df = r1_df[field_name, scenario]
        r3_df[field_name, scenario, self.area] = np.nan
        groups = r1_df.index.get_level_values(0).drop_duplicates()[3:]
        for group in groups:
            r3_df = self._aggregate_nrot_group(scen_df, group, indicator, field_name, scenario, self.area, r3_df,
                                               nnrot_and_nnder)
        column = (field_name, scenario, self.area)
        r3_df = aggregate_indicator_groups(r3_df, indicator, column, 'field', consider_zero_values)
        return r3_df

    def _aggregate_nrot_group(self, scen_df, group, indicator, field_name, scenario, area, r3_df, nnrot_and_nnder):
        nculrot = self._get_nculrot(scen_df, group)
        nrubrot = self._get_nrubrot(scen_df, group, nnrot_and_nnder)

        bd_points = (nculrot[0] + nrubrot[0]) / 2
        field_max = (nculrot[1] + nrubrot[1]) / 2
        field_min = (nculrot[2] + nrubrot[2]) / 2

        numerator = bd_points - field_min
        denominator = field_max - field_min
        if denominator == 0:
            bd_potential = 0
        else:
            bd_potential = numerator / denominator

        hab_min = scen_df.loc[group, 'Minimum H'][0]
        hab_max = scen_df.loc[group, 'Maximum H'][0]

        r3_df.at[(group, 'BD Points P'), (field_name, scenario, area)] = bd_points
        r3_df.at[(group, 'BD Potential P'), (field_name, scenario, area)] = bd_potential
        r3_df.at[(group, 'Maximum P'), (field_name, scenario, area)] = field_max
        r3_df.at[(group, 'Minimum P'), (field_name, scenario, area)] = field_min
        r3_df.at[(group, 'Maximum H'), (field_name, scenario, area)] = hab_max
        r3_df.at[(group, 'Minimum H'), (field_name, scenario, area)] = hab_min

        return r3_df

    def _get_nculrot(self, scen_df, group):
        culture_df = scen_df.drop(scen_df.loc[:, pd.IndexSlice[:, 'Soil Cover', :]].columns, axis=1)
        group_df = culture_df.loc[group]

        durations = [values[2] for values in group_df.columns]
        sum_durations = sum(durations)

        sum_bd = (group_df.loc['BD Points C']*durations).sum()
        bd_points = sum_bd / sum_durations

        sum_max = (group_df.loc['Maximum C']*durations).sum()
        val_max = sum_max / sum_durations

        sum_min = (group_df.loc['Minimum C']*durations).sum()
        val_min = sum_min / sum_durations
        return bd_points, val_max, val_min

    def _get_nrubrot(self, scen_df, group, nnrot_and_nnder):
        soil_df = scen_df.loc[:, pd.IndexSlice[:, 'Soil Cover', :]]
        group_df = soil_df.loc[group]

        mean_bd = (group_df.loc['BD Points C']).mean()
        nnrot_bd = nnrot_and_nnder.loc[(group, 'BD Points F')].at['nnrot']
        nnder_bd = nnrot_and_nnder.loc[(group, 'BD Points F')].at['nnder']
        bd_points = (mean_bd + nnrot_bd + nnder_bd) / 3

        mean_max = (group_df.loc['Maximum C']).mean()
        nnrot_max = nnrot_and_nnder.loc[(group, 'Maximum F')].at['nnrot']
        nnder_max = nnrot_and_nnder.loc[(group, 'Maximum F')].at['nnder']
        val_max = (mean_max + nnrot_max + nnder_max) / 3

        mean_min = (group_df.loc['Minimum C']).mean()
        nnrot_min = nnrot_and_nnder.loc[(group, 'Minimum F')].at['nnrot']
        nnder_min = nnrot_and_nnder.loc[(group, 'Minimum F')].at['nnder']
        val_min = (mean_min + nnrot_min + nnder_min) / 3
        return bd_points, val_max, val_min
