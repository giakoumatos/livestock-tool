import pandas as pd

from .production_inventory import ProductionInventory
from .field import Field
from .culture import Culture
from .soil_cover import SoilCover
from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table


def import_production_inventory(excel_file: str, control_table=None) -> ProductionInventory:
    """Imports a production inventory from an excel file.

    Parameters
    ----------
    excel_file : str
        Path to the excel file to be imported.
    control_table : ControlTable
        Control table to use for the inventory.
    """
    if type(excel_file) is not str:
        raise TypeError('excel_file should be a valid path to an production inventory excel file.')

    if type(control_table) is not ControlTable:
        control_table = get_default_control_table()
        print('Default control table loaded')

    meta_information_df = read_meta_information(excel_file)
    values_df = read_values(excel_file)

    identifier, crop_number, num_catch_crops = read_id_and_catch_crop(excel_file)
    inventory = ProductionInventory(identifier)

    field: Field = None
    year: int = None
    culture: Culture = None
    soil_cover = None

    for column_id, column in meta_information_df.iteritems():

        field_number = extract_int(column.field_name)
        if field_number is not None:
            field = Field(column.field_id, field_number, column.field_area, column.field_border_area, crop_number,
                          num_catch_crops)
            inventory.add_field(field)

        if column.year != '':
            year = extract_int(column.year)

        if column.culture_name != '':
            is_soil_cover = column.culture_name == 'Bodenbedeckung'
            if field.border_area > 0:
                border_df = values_df[column_id + 1]
            else:
                border_df = None

            culture = None if is_soil_cover else create_culture(column, values_df[column_id], border_df, year,
                                                                control_table)
            if culture is not None:
                field.add_culture(culture)
            soil_cover = SoilCover(year, control_table.get_variables_by_category('Soil cover', 'Habitat Type II')) \
                if is_soil_cover else None
            if soil_cover is not None:
                field.add_soil_cover(soil_cover)

        if culture is None and soil_cover is None:
            continue

        scenario_number = extract_int(column.scenario)
        if scenario_number is None:
            continue

        if culture is not None:
            culture.add_scenario(scenario_number, column.duration, values_df[column_id])
            if field.border_area > 0:
                culture.add_border_scenario(scenario_number, values_df[column_id + 1])

        if soil_cover is not None:
            soil_cover.add_scenario(scenario_number, values_df[column_id])

    return inventory


def create_culture(column, measures, border, year, control_table: ControlTable):
    culture_number = extract_int(column.culture_name)
    if culture_number is None or column.duration is None or column.culture_id == '<Name>':
        return None
    ids_with_true_values = measures.index[measures]
    if len(ids_with_true_values) == 0:
        return None
    habitat_type_2 = control_table.get_variable_category_by_id(ids_with_true_values[0], 'Habitat Type II')

    if border is not None:
        ids_with_true_values_b = border.index[border]
        habitat_type_2_border = control_table.get_variable_category_by_id(ids_with_true_values_b[0], 'Habitat Type II')
        border_df = control_table.get_variables_by_category(habitat_type_2_border, 'Habitat Type II')
    else:
        habitat_type_2_border = None
        border_df = None

    return Culture(
        column.culture_id,
        culture_number,
        year,
        habitat_type_2,
        habitat_type_2_border,
        control_table.get_variables_by_category(habitat_type_2, 'Habitat Type II'),
        border_df)


def extract_int(text: str):
    only_numbers = ''.join([x for x in text if x.isdigit()])
    if only_numbers.isdigit():
        return int(only_numbers)
    return None


def read_values(excel_file: str) -> pd.DataFrame:
    return pd.read_excel(excel_file,
                         sheet_name='Produktionsinventar',
                         index_col=0,
                         header=None,
                         skiprows=15,
                         keep_default_na=False,
                         false_values=[''],
                         true_values=[1],
                         usecols=lambda x: x > 6 or x == 0)


def read_id_and_catch_crop(excel_file: str) -> (str, int, int):
    values = pd.read_excel(excel_file,
                           'Produktionsinventar',
                           index_col=None,
                           header=None,
                           skiprows=2,
                           nrows=5,
                           usecols='D')
    identifier = values.iloc[0, 0]

    crop_number = values.iloc[3, 0]
    if pd.isna(crop_number):
        crop_number = None
    elif (crop_number < 5) or (crop_number > 7):
        raise ValueError('The identifier for "Number of crops" must be between 5 and 7')

    num_catch_crops = values.iloc[4, 0]
    if pd.isna(num_catch_crops):
        num_catch_crops = None
    elif (num_catch_crops < 8) or (num_catch_crops > 10):
        raise ValueError('The identifier for "Number of catch crops" must be between 8 and 10')

    return identifier, crop_number, num_catch_crops


def read_meta_information(excel_file: str) -> pd.DataFrame:
    index = pd.Index([
        "field_name",
        "field_id",
        "field_area",
        "field_border_area",
        "year",
        "culture_name",
        "culture_id",
        "scenario",
        "duration",
        "measures"])

    return pd.read_excel(excel_file,
                         sheet_name='Produktionsinventar',
                         index_col=None,
                         header=None,
                         keep_default_na=False,
                         skiprows=5,
                         nrows=10,
                         usecols=lambda x: x > 6).set_index(index)
