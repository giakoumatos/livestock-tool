import pandas as pd
import numpy as np

from .field import Field
from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table
from ..calculation.calculation import build_empty_df, aggregate_indicator_groups


class ProductionInventory:
    def __init__(self, identifier: str):
        self.fields = []
        self.__identifier = identifier

    @property
    def identifier(self):
        return self.__identifier

    def add_field(self, field: Field):
        self.fields.append(field)

    def validate(self, ct=None):
        """
        Validates each culture on the production inventory based on the validation criteria (Mandatory, Zero-Option and
        Multiple Choice). Raises an error if one of the criteria is not fulfilled.

        Parameters
        ----------
        ct : ControlTable (optional)
            The control table to use for the validation. If None, the default control table is loaded.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        for field in self.fields:
            field.validate(ct)

    def calculate_nexp(self, ct=None, consider_zero_values=True):
        """
        Calculates Nexp for each indicator group and scenario. Aggregated over all fields based on the areas of the
        fields.

        Parameters
        ----------
        ct : ControlTable (optional)
            The control table to use for the calculations. If None, the default control table is loaded.
        consider_zero_values : boolean (Optional)
            This boolean controls if zero-values are considered for all aggregation levels. Default is True.

        Returns
        -------
        r4_df : pd.DataFrame
            The resulting biodiversity points, biodiversity potential, maximum and minimum for the habitat and maximum
            and minimum over all habitats. For each indicator group, and also aggregated over all indicator groups
            for GAV and HÖA.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')
        indicator = ct.indicator_df

        r3_df = build_empty_df(indicator, 'field')
        r4_df = build_empty_df(indicator, 'farm')

        for field in self.fields:
            field_r3 = field.calculate_npar(ct, consider_zero_values)
            r3_df = r3_df.merge(field_r3, left_index=True, right_index=True)
        for scen in self.fields[0].cultures[0].measures['Scenarios']:
            r4_df = self._aggregate_farm(r3_df, scen, indicator, r4_df, consider_zero_values)

        return r4_df

    def _calculate_for_export(self, ct, consider_zero_values):
        indicator = ct.indicator_df

        r1_df = build_empty_df(indicator, 'culture')
        r2_list = []
        r2_meta = []
        r3_df = build_empty_df(indicator, 'field')
        r4_df = build_empty_df(indicator, 'farm')
        if self.fields[0].crop_number:
            nnrot_and_nnder = self.fields[0]._get_nnrot_and_nnder(ct)
        else:
            nnrot_and_nnder = None
        for field in self.fields:
            r1_df, r2_list, r2_meta, r3_df = field._calculate_in_iteration(ct, r1_df, r2_list, r2_meta, r3_df,
                                                                           nnrot_and_nnder, consider_zero_values)

        for scen in self.fields[0].cultures[0].measures['Scenarios']:
            r4_df = self._aggregate_farm(r3_df, scen, indicator, r4_df, consider_zero_values)
        r2_meta.append(self.identifier)
        return r1_df, r2_list, r2_meta, r3_df, r4_df, nnrot_and_nnder

    def _aggregate_farm(self, r3_df, scen, indicator, r4_df, consider_zero_values):
        scenario = 'Scenario ' + str(scen)
        scen_df = r3_df.loc[:, pd.IndexSlice[:, scenario, :]]
        if len(scen_df.columns) == 1:
            r4_df[scenario] = scen_df.values
        else:
            r4_df[scenario] = np.nan
            groups = r3_df.index.get_level_values(0).drop_duplicates()[3:]
            for group in groups:
                r4_df = self._aggregate_farm_group(scen_df, group, scenario, r4_df, consider_zero_values)
        column = scenario
        r4_df = aggregate_indicator_groups(r4_df, indicator, column, 'farm', consider_zero_values)
        return r4_df

    def _aggregate_farm_group(self, scen_df, group, scenario, r4_df, consider_zero_values):
        bd_points = self._aggregate_with_area(scen_df, group, 'BD Points P', consider_zero_values)
        field_min = self._aggregate_with_area(scen_df, group, 'Minimum P', consider_zero_values)
        field_max = self._aggregate_with_area(scen_df, group, 'Maximum P', consider_zero_values)

        hab_min = scen_df.loc[group, 'Minimum H'].values[0]
        hab_max = scen_df.loc[group, 'Maximum H'].values[0]
        numerator = bd_points - field_min
        denominator = field_max - field_min
        if denominator == 0:
            bd_potential = 0
        else:
            bd_potential = numerator / denominator

        r4_df.at[(group, 'BD Points F'), scenario] = bd_points
        r4_df.at[(group, 'BD Potential F'), scenario] = bd_potential
        r4_df.at[(group, 'Maximum F'), scenario] = field_max
        r4_df.at[(group, 'Minimum F'), scenario] = field_min
        r4_df.at[(group, 'Maximum H'), scenario] = hab_max
        r4_df.at[(group, 'Minimum H'), scenario] = hab_min
        return r4_df

    def _aggregate_with_area(self, scen_df, group, subgroup, consider_zero_values):
        area_list = scen_df.columns.get_level_values(2)
        areas = []
        for area in area_list:
            if type(area) is str:
                split = area.split(', ')
                areas.append(int(split[0]) + int(split[1]))
            else:
                areas.append(area)

        values = scen_df.loc[group, subgroup].values
        value_sum = 0
        area_sum = 0
        for i in range(len(values)):
            if ((values[i] != 0) or consider_zero_values):
                value_sum += values[i] * areas[i]
                area_sum += areas[i]

        if area_sum == 0:
            value = 0
        else:
            value = value_sum / area_sum
        return value
