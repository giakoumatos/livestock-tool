import pandas as pd

from ..control_table.control_table import ControlTable
from ..pkg_resources.default_control_table import get_default_control_table
from ..calculation.calculation import build_empty_df, get_R2_dataframe, calculate_scenario, aggregate_indicator_groups


class SoilCover:
    def __init__(self, year: int, measures):
        self.__year = year
        self.measures = measures

    @property
    def year(self):
        return self.__year

    def add_scenario(self, scenario_number: int, values):
        """
        Adds a scenario to the measures dataframe.

        Parameters
        ----------
        scenario_number : int
            The number of the scenario, e.g "1" for the first scenario.
        values : pd.Series
            The values to be set for the scenario. A series of bools.

        """
        column_index = pd.MultiIndex.from_tuples([('Scenarios', scenario_number)])
        values.name = None
        scenario_values = pd.DataFrame(values, columns=column_index)
        self.measures = self.measures.merge(scenario_values, left_on="ID", right_index=True)

    def calculate_ncou(self, ct=None, consider_zero_values=True):
        """
        Calculates Ncou for each indicator group and each scenario within the soil cover.

        Parameters
        ----------
        ct : ControlTable, optional
            The control table to use for the calculations. If None, the default control table is loaded.
        consider_zero_values : boolean (Optional)
            This boolean controls if zero-values are considered for all aggregation levels. Default is True.

        Returns
        -------
        r1_df : pd.DataFrame
            The resulting biodiversity points, biodiversity potential, maximum and minimum for the habitat and maximum
            and minimum over all habitats. For each indicator group, and also aggregated over all indicator groups
            for GAV and HÖA.

        """
        if type(ct) is not ControlTable:
            ct = get_default_control_table()
            print('Default control table loaded')

        if (self.measures['Scenarios'].sum() > 0).any():
            indicator = ct.indicator_df
            year = 'Year ' + str(self.year)
            r1_df = build_empty_df(indicator, 'culture')
            for scen in self.measures['Scenarios']:
                r1_df = calculate_scenario(self, scen, ct, 'Field', year, 'Soil Cover', r1_df)
                column = ('Field', 'Scenario ' + str(scen), year, 'Soil Cover', 0)
                r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
            return r1_df
        else:
            return 0

    def _calculate_in_iteration(self, ct, include_r2, field_name, field_number, r1_df, consider_zero_values,
                                r2_list=None, r2_meta=None):
        if (self.measures['Scenarios'].sum() > 0).any():
            indicator = ct.indicator_df
            year = 'Year ' + str(self.year)
            for scen in self.measures['Scenarios']:
                r1_df = calculate_scenario(self, scen, ct, field_name, year, 'Soil Cover', r1_df)
                column = (field_name, 'Scenario ' + str(scen), year, 'Soil Cover', 0)
                r1_df = aggregate_indicator_groups(r1_df, indicator, column, 'culture', consider_zero_values)
            if include_r2:
                r2_list.append(get_R2_dataframe(self.measures, indicator))
                r2_meta.append([field_name, year, 'Soil Cover',
                                'R2 (P' + str(field_number) + '-Y' + str(self.year) + '-SC)'])
                return r1_df, r2_list, r2_meta
            else:
                return r1_df
        else:
            if include_r2:
                return r1_df, r2_list, r2_meta
            else:
                return r1_df
