# -*- coding: utf-8 -*-
"""
File name: salcabd_farm.py
Created on Wed Sep 28 16:11:04 2022

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script assesses the impact of crops and grassland on biodiversity

Calculation level:
    Farm (entity comprising all fields, crops and animal groups)
"""


# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import re
import logging
import warnings as w
from importlib import reload
from sys import stderr
from pathlib import Path

import pandas as pd
import numpy as np

import salcabd
from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCA-BD_farm'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define classes ===========================================================

class PppEvent:
    """
    Class for the plant protection events on a crop. Contains the data needed
    to translate the management practices that occured on a crop into the
    corresponding true/false list of the SALCA-BD management level III.

    Input-Parameters
    ----------
    date : str, format: 'yyyy-mm-dd'
        Date the plant protection event occurred.
    products : list of str
        List of the names of applied plant protection products (PPP).
    amounts : list of float
        List of the applied amounts of products.
    perc_treated_area : float
        Value for the percentage of the crop area that has been treated during that event.
    crop_index : int
        Index of the crop on which the event occurred.
        
    Further Parameters
    ----------
    type : list of str
        List of the types of PPP.
    """
    def __init__(self, date, products, amounts, perc_treated_area, crop_index):
        self.date = date
        self.products = [x for x in products if x]
        self.amounts = [x for x in amounts if x is not None]
        self.type = []
        self.area_treated_perc = perc_treated_area
        self.crop_index = crop_index
        self.mollusc = []
    
    def get_type(self):
        self.type = []
        olca_types = [tab_ppp.loc[tab_ppp['NameEN'] == x,"OLCA-Pest_type"].item() for x in self.products]
        for olca_type in olca_types:
            if olca_type in ["Fun", "Ins"]:
                self.type.append(olca_type)
            # acaricides are assessed under the category insecticides
            elif olca_type == "Ac/Mi":
                self.type.append("Ins")
            else:
                if olca_type in ["Hrb-pre", "Hrb-post"]:
                    self.type.append("Hrb")
                else:
                    self.type.append("unknown")
        return "Pesticide types have been determined!"
        
    def eval_mollusc(self):
        mollusc = ['ppp_metaldehyde', 'ppp_ferric_phosphate', 'ppp_ferric_pyrophosphate']
        self.mollusc = [True for x in self.products if x in mollusc]
        return "Molluscicide application has been evaluated!"

        
class TrSoilEvent:
    """
    Class for the soil treatment and seeding events on a crop. Contains the
    data needed to translate the management practices that occured on a crop
    into the corresponding true/false list of the SALCA-BD management level III.

    Input-Parameters
    ----------
    date : str, format: 'yyyy-mm-dd'
        Date of the harvest event.
    maco_id : str
        ID string of the machine combination used for the harvest event.
    crop_index : int
        Index of the crop on which the event occurred.
    event_type : str
        Used to differentiate between the soil treatments and sowing treatments.
        
    Further Parameters
    ----------
    machinery : list
        List of the machinery used in the machine combination with ID: maco_id.
    bd_category : Series
        Series with the SALCA-BD IDs of the SALCA-BD management level III
        option the machinery correspond to. Used to determine soil treatment
        depth and the cutting technique by a mapping that is available in
        SALCAtables_machinery.
    """
    def __init__(self, date, maco_id, crop_index, event_type):
        self.date = date
        self.id = maco_id
        self.crop_index = crop_index
        self.event_type = event_type
        if maco_id in mc_dict.index:
            self.machinery = mc_dict.loc[maco_id,].tolist()
            self.bd_category = tab_mach[tab_mach["PythonName"].isin(self.machinery)]["SALCA-BD_mapping"]
        else:
            self.machinery = 'unknown'
            self.bd_category = pd.Series([0])
        
class TrHarvEvent:
    """
    Class for the harvest events on a crop. Contains the data needed to
    translate the management practices that occured on a crop into the
    corresponding true/false list of the SALCA-BD management level III.

    Input-Parameters
    ----------
    date : str, format: 'yyyy-mm-dd'
        Date of the harvest event.
    maco_id : str
        ID string of the machine combination used for the harvest event.
    maco_id_ff : list
        List of ID strings of the machine combinations used for the harvest
        event as additional treatment steps.
    crop_index : int
        Index of the crop on which the harvest event occurred.
    crop_yield : int
        Sum of all harvest amounts on that crop. Used to determine if residues
        of green manure crops are left on the field.
    val_rare_cut : str
        String value that describes how often the crop is cut if it is a litter
        field (never, once a year, every 2 years, every 3 years)
        
    Further Parameters
    ----------
    crop_name : str
        Name of the crop with index: crop_index.
    crop_landuse : str
        Land use category in SALCAtables_crops for the current crop. Used to
        differentiate between grassland and arable land.
    machinery : list
        List of the machinery used in the machine combination with ID: maco_id.
    bd_category : Series
        Series with the SALCA-BD IDs of the SALCA-BD management level III
        option the machinery correspond to. Used to determine soil treatment
        depth and the cutting technique by a mapping that is available in
        SALCAtables_machinery.
    """
    def __init__(self, date, maco_id, crop_index, crop_yield, val_rare_cut, maco_id_ff=[]):
        self.date = date
        self.id = maco_id
        self.crop_index = crop_index
        self.crop_yield = crop_yield
        self.val_rare_cut = val_rare_cut
        self.crop_name = ctx.farm.crops[crop_index][2]
        self.crop_landuse = tab_crops[tab_crops["NameEN"] == self.crop_name]["land use"].values[0]
        if maco_id in mc_dict.index:
            self.machinery = mc_dict.loc[maco_id,].tolist()
            # extend with the additional machinery used in the harvest
            self.machinery.extend([y for element in maco_id_ff for y in mc_dict.loc[element,].tolist()])
            self.bd_category = tab_mach[tab_mach["PythonName"].isin(self.machinery)]["SALCA-BD_mapping"]
        else:
            self.machinery = 'unknown'
            self.bd_category = pd.Series([0])

class GrazingEvent:
    def __init__(self, date, days, LU, animal_type, crop_id):
        self.date = date
        self.date_end = dt.datetime.strptime(self.date, '%Y-%m-%d') + dt.timedelta(days = days)
        self.date_end = dt.datetime.strftime(self.date_end, '%Y-%m-%d')
        self.LU = LU
        self.animal_type = animal_type
        self.crop_id = crop_id
        
        self.bd_category = tab_ls[tab_ls["NameEN"] == self.animal_type]["SALCA-BD_mapping"]


# %% define functions =========================================================

def load_intensity_table(table):
    path = Path(".") / "salcabd" / "pkg_resources" / "prep_tables" / table
    df_table = pd.read_csv(path,
                      sep=None,
                      header=0,
                      encoding='utf-8-sig',
                      engine='python')
    return df_table
# functions to gather input data:
def add_ids2dict_prep(ids, d_dict):
    result = {key: d_dict[i] for i,key in enumerate(ids)}
    return result
def add_ids2dict(id_s, the_dict):
    result = {k: add_ids2dict_prep(id_s, v) for k,v in the_dict.items()}
    return result

def eval_frequency(dates_list):
    """
    Translates a list of event dates into the correct true/false list
    corresponding to the categories of the SALCA-BD management level III:
    Frequency.

    Parameter
    ----------
    dates_list : list
        List of the event dates to be evaluated.
    """
    freq_cats = {'a':0,'b':1,'c':3,'d':5}
    c_freq = len(dates_list)
    categories = [index for index,value in enumerate(freq_cats.values()) if c_freq >= value]

    category = [False] * 4
    category[max(categories)] = True
    return category

def eval_date(dates_list, date_category):
    """
    Translates a list of event dates into the correct true/false list
    corresponding to the categories of the SALCA-BD management level III: Date.

    Parameters
    ----------
    dates_list : list
        List of the event dates to be evaluated.
    date_category : string
        To determine for which of the three groups of date categories in
        SALCA-BD the evaluation shall be carried out.
    """
    if date_category == '3groups':
        date_cats = {'a':[1,2,3,4,5],'b':[6,7,8],'c':[9,10,11,12]}
        category = [False] * 3
    else:
        if date_category == '9groups':
            date_cats = {'a':[11,12,1,2],'b':[3],'c':[4],'d':[5],'e':[6],'f':[7],'g':[8],'h':[9],'i':[10]}
            category = [False] * 9
        else:
            if date_category == '7groups':
                date_cats = {'a':[12,1,2,3,4,5],'b':[6],'c':[7],'d':[8],'e':[9],'f':[10],'g':[11]}
                category = [False] * 7
            else:
                logging.debug("Error: Wrong date_category! Choose between 3groups, 7groups or 9groups.")
    
    dates_list_months = [dt.datetime.strptime(x, '%Y-%m-%d').month for x in dates_list]
    # check where in date_cats the months from the event dates match
    cat = [[key for key, value in date_cats.items() if x in value] for x in dates_list_months]
    cat = [item for sublist in cat for item in sublist]
    cat = set(cat)
    
    index = [list(date_cats.keys()).index(x) for x in cat]
    for i in index:
        category[i] = True
    return category

def eval_fert_types(fert_types):
    """
    Maps and converts the fertiliser types into the correct true/false list
    corresponding to the fertiliser categories of the SALCA-BD management level III.

    Parameter
    ----------
    fert_types : set
        Set of the fertiliser types used on the crop.
    """
    # Attention: The first two numbers (=21) determine the crop in SALCA-BD.
    fert_cats = {'slurry':21020501,
                 'fresh manure':21020502,
                 'compost':21020503,
                 'biosolids':21020504,
                 'ammonium salpetre':21020505,
                 'ammonium salpetre lime':21020506,
                 'salpetre lime':21020507,
                 'ammonium sulfate':21020508,
                 'Harnstoff':21020509,
                 'nitrogen lime':21020510,
                 'triple superphosphate':21020511,
                 'superphosphate':21020512,
                 'diammonphosphate':21020513,
                 'potassium salt 60%':21020514,
                 'potassium chloride with magnesium salts 40%':21020515,
                 'specific more-nutrient fertilizer':21020516,
                 'potassium sulfate':21020517,
                 'potassium nitrate':21020518,
                 'magnesium sulfate':21020519,
                 'Thomasmeal 17%':21020520,
                 'Thomaskali':21020521,
                 'Others':21020522}
    fertlist_bd = []
    
    for item in fert_types:
        if item == 'liquid_farm_manure':
            fertlist_bd.append(21020501)
        elif item == 'solid_farm_manure':
            fertlist_bd.append(21020502)
        elif item in tab_manu["NameEN"].values:
            fertlist_bd.append(int(tab_manu.loc[tab_manu['NameEN'] == item,"SALCA-BD_mapping"].item()))
        elif item in fert_cats.values():
            fertlist_bd.append(item)
        else:
            raise ValueError(f"Could not map Fertiliser = {item}")
    fertdict = fert_cats.copy()
    # set true for the used fertiliser categories, false for unused
    for key, val in fertdict.items():
        if val in fertlist_bd:
            fertdict[key] = True
        else:
            fertdict[key] = False
    return list(fertdict.values())

def eval_fert_tech(fert_incorp):
    """
    Translates the list of fertiliser incorporation event data into the correct
    true/false list corresponding to the fertiliser technique categories of the
    SALCA-BD management level III.
    
    "Incorporation" is true if solid manure is incorporated at least once
    (indicated by a positive value for the number of hours of incorporation
    after manure application). "No incorporation" is true if no incorporation
    hours are indicated or if -1 (no incorporation) is indicated at least once.
    In SALCA-BD, incorporation and no incorporation can occur in parallel 
    on a specific crop.

    Parameter
    ----------
    fert_incorp : list of int
        List of times in hours after which fertilisers are incorporated
        following application.
    """
    category = [False, False]
    if any(n >= 0 for n in fert_incorp) and fert_incorp != []:
        category[0] = True
    if any(n < 0 for n in fert_incorp) or fert_incorp == []:
        category[1] = True
    return category

def append_date2type(dict_res, event):
    """
    Append an event.date to a result dict with the event.crop_index as keys.
    Output is a dict with all crop_id's as keys and a list of event dates as
    values. Used for for the assessment of applying PPP.
    """
    if event.crop_index not in dict_res.keys():
        dict_res[event.crop_index] = [event.date]
    else:
        dict_res[event.crop_index].append(event.date)
    return dict_res

def eval_grazing_animals(animal_types):
    """
    Maps and converts the animal types that grazed on the crops into the
    correct true/false list corresponding to the animal categories of the
    SALCA-BD management level III.

    Parameter
    ----------
    animal_types : set
        Set of the animal types grazed on the crop.
    """
    # Attention: The first two numbers (=21) determine the crop in SALCA-BD.
    animal_cats = {'dairy cow':21080401,
                 'mother cow / mother cow calf':21080402,
                 'breeding cattle aged < 1 year':21080403,
                 'breeding cattle aged 1-2 years':21080404,
                 'breeding cattle aged > 2 years':21080405,
                 'female horse with foal':21080406,
                 'other horse / foal':21080407,
                 'goat':21080408,
                 'sheep / milk sheep':21080409,
                 'fallow deer':21080410,
                 'red deer':21080411,
                 'Bison aged <3 years':21080412,
                 'Bison aged >3 years':21080413,
                 'Lama aged < 2 years':21080414,
                 'Lama aged > 2 years':21080415,
                 'alpaca < 2 years of age':21080416,
                 'alpaca > 2 years of age':21080417,
                 'Others':21080418}

    grazinglist_bd = []
    
    for item in animal_types:
        if item in tab_ls["NameEN"].values:
            grazinglist_bd.append(int(tab_ls.loc[tab_ls['NameEN'] == item,"SALCA-BD_mapping"].item()))
        elif item in animal_cats.values():
            grazinglist_bd.append(item)
        else:
            raise ValueError(f"Could not map grazed animal_type = {item}")
    animaldict = animal_cats.copy()
    # set true for the used fertiliser categories, false for unused
    for key, val in animaldict.items():
        if val in grazinglist_bd:
            animaldict[key] = True
        else:
            animaldict[key] = False
    return list(animaldict.values())

def eval_intensity(amount, intensity_cats, farm_altitude, table, crop_category, opt_zero = 0):
    if crop_category in set(table.habitat):
        df_subset = table.loc[(table.height_upper > farm_altitude) &\
                           (table.height_lower <= farm_altitude) &\
                           (table.habitat == crop_category)]
        if opt_zero == 1:
            # grazing evaluation (stocking density) needs different boundaries
            intensity = df_subset.loc[(df_subset.amount_upper > amount) &\
                                      (df_subset.amount_lower <= amount), 'category_level'].values[0]
            if amount == -1:
                # the zero-option (no grazing) is assessed here by a defined
                # stocking density of -1 livestock units
                intensity = 1
        else:
            intensity = df_subset.loc[(df_subset.amount_upper >= amount) &\
                                      (df_subset.amount_lower < amount), 'category_level'].values[0]
    else:
        if opt_zero == 1:
            # grazing evaluation (stocking density) has a zero-option (no
            # grazing), and if a habitat is not in the table, grazing is set to
            # zero grazing here.
            intensity = 1
        else:
            intensity = 0
    intensity_dict = [True if index == intensity else False for index in intensity_cats.keys()]
    return intensity_dict

def eval_fert_norm(dict_intensity_norm):
    categories = {21020401:0,
                  21020402:0.7499,
                  21020403:1,
                  21020404:float('inf')}
    vector = {}
    for key in dict_intensity_norm:
        result = min([index for index,value in categories.items() if dict_intensity_norm[key] <= value])
        vector[key] = [False] * 4
        index = [ix for ix,val in enumerate(categories.keys()) if val == result]
        # zero-option assurance (no fertilisation is a zero-option in ID 21020101)
        if index[0] != 0:
            vector[key][index[0]] = True
    return vector

def eval_ppp_amount(dict_amount_area, ppp_type):
    categories_hrb = {21030501:0,
                      21030502:0.25,
                      21030503:0.5,
                      21030504:0.75,
                      21030505:1}
    categories_fun = {21040301:0.25,
                      21040302:0.5,
                      21040303:0.75,
                      21040304:1}
    categories_ins = {21070301:0.25,
                      21070302:0.5,
                      21070303:0.75,
                      21070304:1}
    categories = dict(hrb = categories_hrb, fun = categories_fun, ins = categories_ins)
    result = min([index for index,value in categories[ppp_type].items() if dict_amount_area <= value])
    vector = [False] * len(categories[ppp_type])
    index = [ix for ix,val in enumerate(categories[ppp_type].keys()) if val == result]
    vector[index[0]] = True
    return vector


# %% inputs ===================================================================

# load table for manure
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                         columns=js.loads(inp.tab_manu)['columns'],
                         index=js.loads(inp.tab_manu)['index']
                         )
# load table for PPP
tab_ppp = pd.DataFrame(data=js.loads(inp.tab_ppp)['data'],
                         columns=js.loads(inp.tab_ppp)['columns'],
                         index=js.loads(inp.tab_ppp)['index']
                         )
# load crop table
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )
# load table for machinery
tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                         columns=js.loads(inp.tab_mach)['columns'],
                         index=js.loads(inp.tab_mach)['index']
                         )
# load animal table
tab_ls = pd.DataFrame(data=js.loads(inp.tab_ls)['data'],
                         columns=js.loads(inp.tab_ls)['columns'],
                         index=js.loads(inp.tab_ls)['index']
                         )
# load intensity tables
df_fert = load_intensity_table('tab_intensity_fertilisation.txt')
df_grazing = load_intensity_table('tab_intensity_stocking_density.txt')
df_harvestcut = load_intensity_table('tab_intensity_cuts.txt')

# information from the farm level:
# year of the assessment:
eval_year = dt.datetime.strptime(inp.f_end_evaluation, '%Y-%m-%d').year
# list of machine combinations by ID:
maco_list = inp.get_events('treatment_maco_event')
if maco_list != []:
    mc_dict = pd.DataFrame(maco_list).set_index("f_maco_id")
    mc_dict.drop(columns=['event_context'], inplace=True)
    mc_dict = mc_dict.applymap(lambda a: a[4:])
else:
    mc_dict = pd.DataFrame(maco_list)
# salcabd farm-level variables:
ruderal_area = inp.f_ruderal_ha
len_drywalls = inp.f_len_drywalls_m
len_trails = inp.f_len_trails_m
nbr_single_trees = inp.f_singl_tree_nbr
nbr_hist_trees = inp.f_hist_tree_nbr
# altitude: needed to define the intensity levels for grassland fertilisation
# and havesting
if hasattr(inp, 'f_altitude') and inp.f_altitude is not None:
    farm_altitude = inp.f_altitude
else:
    heights = {'001 Tal':500, '002 Huegel':900, '003 Berg':1300}
    farm_altitude = heights[inp.f_region]
# information from the field level:
if ctx.farm.fields == {}:
    total_kgN_crop = []
else:
    # total kg nitrogen applied in all crops:
    total_kgN_list = []
    for string in inp.fi_total_kgN_crop:
        total_kgN_list.append(js.loads(string))
    total_kgN_crop = {key: val for d in total_kgN_list for key, val in d.items()}

# crop management information from SALCAprep_crop:
c_salcaprep = []
# dicts for all crops:
c_fertilisation_dates = {}
c_fert_types = {}
c_fert_incorp = {}
c_ppp = {}
c_soil = {}
c_sowi = {}
c_harv = {}
c_harv_sepr = {}
c_maint = {}
c_irri = {}
c_grazing = {}
pre_harv_sowi = {}
c_hare_inco_bool = {}
c_rodent_regulation = {}
total_farm_area = 0
crop_area_ha = {}
crop_duration_m = {}
# load c_salcaprep if there are crops on the farm:
if ctx.farm.crops != {}:
    for i in inp.c_salcaprep:
        c_salcaprep.append(js.loads(i))
for j in c_salcaprep:
    # total_farm_area = sum of the crop areas (for the assessment of ruderal_area)
    total_farm_area += (j['c_areatime']/j['c_duration_years'])
    crop_area_ha[j['crop_id']] = j['c_areatime']/j['c_duration_years']
    # crop duration:
    dt_start = dt.datetime.strptime(j['c_start'], '%Y-%m-%d')
    dt_end   = dt.datetime.strptime(j['c_end'], '%Y-%m-%d')
    crop_duration_m[j['crop_id']] = 12 * (dt_end.year - dt_start.year) +\
                                        (dt_end.month - dt_start.month)
    # fertilisation:
    subset_id = [index for index,value in enumerate(j['tr_fert']['MC']) if value != 'fertilizer_multiplication']    
    datelist = [j['tr_fert']['date'][i] for i in subset_id]
    datelist.extend(j['tr_manure_l']['date'])
    datelist.extend(j['tr_manure_s']['date'])
    c_fertilisation_dates[j['crop_id']] = datelist
    c_fert_types[j['crop_id']] = set(list(filter(lambda x: x != 0, j['tr_fert']['salcabd_type']))\
                                + list(j['tr_manure_l']['variable'])\
                                + list(j['tr_manure_s']['variable']))
    c_fert_incorp[j['crop_id']] = j['tr_manure_s']['incorporation']  # incorporation of manure
    c_ppp[j['crop_id']] = j['tr_ppp']  # plant protection
    c_harv[j['crop_id']] = j['tr_harv']  # harvest of main products
    c_harv_sepr[j['crop_id']] = j['tr_harv_sepr']  # harvest of secondary products
    c_soil[j['crop_id']] = j['tr_soil']  # soil treatment
    c_sowi[j['crop_id']] = j['tr_sowi']  # seeding treatment
    c_maint[j['crop_id']] = j['tr_maint']  # maintenance treatment
    c_irri[j['crop_id']] = j['tr_irri']  # irrigation events
    c_grazing[j['crop_id']] = j['tr_grazing']  # grazing events
    pre_harv_sowi[j['crop_id']] = j['c_sowi_pre_harv']  # pre-harvest sowing
    c_hare_inco_bool[j['crop_id']] = j['c_hare_inco_bool']  # incorporation of crop residues
    c_rodent_regulation[j['crop_id']] = j['c_rodent_regulation']  # rodent regulation
    
# grazing:
grazing_event = []
grazed_crops = []
for key in c_grazing:
    for i, element in enumerate(c_grazing[key]["date"]):
        grazing_event.append(GrazingEvent(c_grazing[key]["date"][i],
                                          c_grazing[key]["days"][i],
                                          c_grazing[key]["LU"][i],
                                          c_grazing[key]["animal_type"][i],
                                          key
                                          ))
        grazed_crops.append(key)
grazed_crops = set(grazed_crops)

# crop management information from SALCAprep_crop_bd:
if ctx.farm.crops == {}:
    c_bd_vege_grho_bool = {}
else:
    c_bd_vege_grho_bool = {}
    for i in inp.c_salcaprep_bd:
        c_salcaprep_bd = js.loads(i)
        c_bd_vege_grho_bool[c_salcaprep_bd['crop_id']] = c_salcaprep_bd['c_bd_vege_grho_bool']

# list of crops:
crops = ctx.farm.crops
crop_ids = ctx.farm.crops.keys()
crop_names = {x:ctx.farm.crops[x].crop_definition_name for x in ctx.farm.crops}
# get salcabd crop categories for all crops on the farm
crop_bdcategories = {}
for key in crops:
    crop_bdcategories[key] = tab_crops.loc[tab_crops['NameEN'] == crops[key][2],"SALCA_BD_cropid"].values[0]
df_crop_and_field = pd.DataFrame({"fields": [], "crops": []})
for field_id in ctx.farm.fields:
    for crop_id in ctx.farm.fields[field_id].crops:
        new_row = [field_id, crop_id]
        df_crop_and_field.loc[len(df_crop_and_field)] = new_row


# %% calculations: special case assessments ===================================

# Special cases are assessed and added as a separate crop with their
# corresponding area

# Share of ruderal areas
ruderal_cats = {1160101:1,
                1160102:8,
                1160103:13,
                1160104:21,
                1160105:float('inf')}
ruderal_eval = {key: False for key in ruderal_cats.keys()}
if total_farm_area != 0:
    value_eval = ruderal_area / total_farm_area * 100 # Anteil in % der LN
    category = min([index for index,value in ruderal_cats.items() if value_eval < value])
    ruderal_eval[category] = True

# values needed to add ruderal area as a separate crop
speccase_duration = 12  # months
ruderal_eval_area = ruderal_area * 10000  # convert to m2
# convert into a separate crop:
ruderal_crop = {1.1: ruderal_eval}

# Length of stone walls and unpaved farmland trails
len_cats_drywall = {2160201:0,
                    2160202:50,
                    2160203:100,
                    2160204:200,
                    2160205:float('inf')}
len_cats_trail = {3160301:0,
                  3160302:50,
                  3160303:100,
                  3160304:200,
                  3160305:float('inf')}
category = min([index for index,value in len_cats_drywall.items() if len_drywalls <= value])
drywall_eval = {key: False for key in len_cats_drywall.keys()}
drywall_eval[category] = True
category = min([index for index,value in len_cats_trail.items() if len_trails <= value])
trail_eval = {key: False for key in len_cats_trail.keys()}
trail_eval[category] = True

# values needed to add as separate crops
# Assumption: per meter of length, 3 m2 area are used by the trail or stone wall
reserved_area_per_meter = 3
drywall_area = len_drywalls * reserved_area_per_meter  # area in m2
trail_area = len_trails * reserved_area_per_meter  # area in m2
# convert into a separate crop:
drywall_crop = {2.1: drywall_eval}
trail_crop = {3.1: trail_eval}

# Indivudual trees and high-stem fruit trees
tree_cats_single = {4160401:1,
                    4160402:5,
                    4160403:21}
                    # 4160404:0  # zero-option added separately because of the higher id
tree_cats_hist = {5160501:1,
                  5160502:5,
                  5160503:21}
                  # 5160504:0  # zero-option added separately because of the higher id

singletree_numbers = {key: False for key in tree_cats_single.keys()}
if nbr_single_trees != 0:
    category = max([index for index,value in tree_cats_single.items() if nbr_single_trees >= value])
    singletree_numbers[category] = True
    # zero-option added separately because of the higher id
    singletree_numbers[4160404] = False
else:
    singletree_numbers[4160404] = True

hist_tree_numbers = {key: False for key in tree_cats_hist.keys()}
if nbr_hist_trees != 0:
    category_hist = max([index for index,value in tree_cats_hist.items() if nbr_hist_trees >= value])
    hist_tree_numbers[category_hist] = True
    # zero-option added separately because of the higher id
    hist_tree_numbers[5160504] = False
else:
    hist_tree_numbers[5160504] = True

# values needed to add as separate crops
area_per_tree = 0.01  # ha, assumption: every tree occupies 10 m2
singletree_area = nbr_single_trees * area_per_tree * 10000  # convert to m2
hist_tree_area = nbr_hist_trees * area_per_tree * 10000  # convert to m2
# convert into a separate crop:
singletree_crop = {4.1: singletree_numbers}
hist_tree_crop = {5.1: hist_tree_numbers}


# Soil cover
# Determine the number of months a crop is on the field. The soil is defined as
# uncovered between the first soil treatment and the last sowing treatment on
# the crop. 
# Since in SALCA-BD the soil cover is assessed as a separate crop, the crop_id
# gets an addition of 0.5 in order to define the soil cover as a new crop. 
cover_thresholds = [0,0.5,0.75,0.9]
date_uncovered = {}
for crop in c_soil:
    if c_soil[crop]['date_dt'] == []:
        date_uncovered[crop+0.5] = [False]
    else:
        date_uncovered[crop+0.5] = [min(c_soil[crop]['date_dt'])]
for crop in c_sowi:
    if c_sowi[crop]['date_dt'] == []:
        date_uncovered[crop+0.5].append(False)
    else:
        date_uncovered[crop+0.5].append(max(c_sowi[crop]['date_dt']))
# If neither a date for tillage nor for sowing is specified, the soil is
# assumed to be permanently covered. If both dates are specified, the soil is
# assumed to be uncovered between both dates.
for crop in date_uncovered:
    if False in date_uncovered[crop]:
        date_uncovered[crop] = [False, False, False, True]
    else:
        delta = dt.datetime.strptime(date_uncovered[crop][1], '%Y-%m-%d') -\
                dt.datetime.strptime(date_uncovered[crop][0], '%Y-%m-%d')
        uncovered_perc = delta.days/30/12  # share of months per year the soil is uncovered
        covered_perc = 1 - uncovered_perc
        categories = [value for value in cover_thresholds if covered_perc > value]
        category = [False] * 4
        index = cover_thresholds.index(max(categories))
        category[index] = True
        date_uncovered[crop] = category


# %% calculations: regular assessments: fertilisation =========================

# fertilisation frequency
# dict for all crops with the category values for fertilisation frequency
fertilisation_freq = {}
for key in c_fertilisation_dates:
    fertilisation_freq[key] = eval_frequency(c_fertilisation_dates[key])

# fertilisation dates
category='3groups'
fertilisation_dt = {}
for key in c_fertilisation_dates:
    fertilisation_dt[key] = eval_date(c_fertilisation_dates[key], category)

# fertilisation quantity on grassland (intensity)
intensity_cats = {1:21020301,
                  2:21020302,
                  3:21020303,
                  4:21020304,
                  5:21020305}
fert_intensity = {}
for key in crop_area_ha:
    fert_amount = total_kgN_crop[str(key)] / crop_area_ha[key]
    fert_intensity[key] = eval_intensity(fert_amount, intensity_cats, farm_altitude, df_fert, crop_bdcategories[key])
    # zero-option assurance: when the zero-option for fertilisation frequency
    # is True, no other fertilisation values are allowed to be True!
    if fertilisation_freq[key][0] == True:
        fert_intensity[key] = [False, False, False, False, False]

# fertilisation quantity on arable land (in % of the Swiss fertilisation norm)
# get the norm values from SALCAtables_crops
df_norm_fert = tab_crops.loc[tab_crops['NameEN'].isin(crop_names.values()),['NameEN','Normertrag','Norm-N']]
# extract the norm values into a dict per crop_id (over the names of the crops)
fert_norm = {key: df_norm_fert.loc[df_norm_fert['NameEN'] == crop_names[key],'Norm-N'].values[0] for key in crop_names}
# divide the amount of nitrogen fertilisation through the norm values:
# If the norm is zero but fertilisation has been applied, it leads to option d. high fertilisation (more than 100% of the norm), 
# while in case of no fertilisation, the quantity is not assessed at all, because the zero option is on frequency level. This
# is ensured in eval_fert_norm.
fert_intensity_norm = {key: (total_kgN_crop[str(key)]/fert_norm[key] if fert_norm[key] != 0 else 0 if total_kgN_crop[str(key)] == 0 else 2) for key in fert_norm}
# evaluate into the true/false vector
dict_fert_norm = eval_fert_norm(fert_intensity_norm)

# fertilisation types
fertilisation_type = {}
for key in c_fert_types:
    fertilisation_type[key] = eval_fert_types(c_fert_types[key])

# fertilisation technique/incorporation
fert_tech = {}
for key in c_fert_incorp:
    fert_tech[key] = eval_fert_tech(c_fert_incorp[key])
    # zero-option assurance:
    if fertilisation_freq[key][0] == True:
        fert_tech[key] = [False, False]


# %% calculations: regular assessments: plant protection ======================

ppp_event = []
for key in c_ppp:
    for i, element in enumerate(c_ppp[key]["date"]):
        # Add the plant protection treatment events and their dates as objects
        # to an event list:
        ppp_event.append(PppEvent(c_ppp[key]["date"][i],
                                  c_ppp[key]["variable"][i],
                                  c_ppp[key]["amount_kg"][i],
                                  c_ppp[key]["area_treated_perc"][i],
                                  key))

[x.get_type() for x in ppp_event]
[x.eval_mollusc() for x in ppp_event]

# Mechanical cleaning cut (on flower strips, rotational fallow, temporary
# grassland, fodder cover crops):
# Could be evaluated by SALCA-BD. However, here these cuts get converted to a
# normal grass cutting event, so that the mechanical cleaning cut gets the same
# evaluation as a normal cut on meadows.
dict_clean_cut = {key : {21030201 : False, 21030202 : False} for key in crop_ids}

# Mechanical and thermic weed control:
# There is a dual function and a mutual exclusion between the use of plant
# protection products and the use of mechanical or thermal weed control
# methods. If both are used, the PPP take precedence.
# Frequency and timing therefore apply to mechanical/thermic weeding, where no
# PPP are used. Otherwise, the analysis focusses exclusively on the use of
# PPP, and mechanical/thermal weeding are not assessed in terms of frequency
# and timing.


# weed_mechanic: ID's 701-703 are for arable crops and ID's 704-705 for vegetables
weed_mechanic = {key : {21030701 : False, 21030702 : False, 21030703 : False, 21030704 : False, 21030705 : False} for key in crop_ids}
weed_thermic = {key : {21030801 : False, 21030802 : ""} for key in crop_ids}
weed_ctrl_dates = {key : [] for key in crop_ids}
maint_categories_cutting = ['001_hoeing', '002_weeding', '004_mulching']
maint_categories_pouring = ['006_potato_hoeing_and_hilling']
maint_categories_thermic = '005_burning_weed'
# Priority of herbicide application over mechanical/thermic weeding if both occur:
# Careful: The order of the commands/lines below is important.
for event in ppp_event:
    if 'Hrb' in event.type:
        weed_mechanic[event.crop_index][21030703] = True
        weed_thermic[event.crop_index][21030802] = True

for key in c_maint:
    # mechanic weed control
    intersection_maint = list(set(maint_categories_cutting + maint_categories_pouring) & set(c_maint[key]['variable']))
    intersect_cutting =list(set(maint_categories_cutting) & set(c_maint[key]['variable']))
    intersect_pouring =list(set(maint_categories_pouring) & set(c_maint[key]['variable']))
    if weed_mechanic[key][21030703] == False:
        if intersection_maint == []:
            # no mechanical weed control and no herbicide applications means
            # zero-option is True, which means no other True values are allowed
            weed_mechanic[key][21030703] = False
        elif intersect_cutting != []:
            # mechanical weed control (cutting) is present in c_maint for that crop
            weed_mechanic[key][21030702] = True
            if intersect_pouring != []:
                # mechanical weed control (pouring) is present too
                weed_mechanic[key][21030701] = True
        elif intersect_pouring != []:
            # mechanical weed control (pouring) is present in c_maint for that crop
            weed_mechanic[key][21030701] = True
        else:
            logging.info("Unexpected outcome in mechanical weed control. Please check! Crop_id = %s", key)
    # mechanical hoeing (vegetables)
    categories_vege_hoeing = ['001_hoeing', '006_potato_hoeing_and_hilling']
    if categories_vege_hoeing in c_maint[key]['variable']:
        weed_mechanic[key][21030704] = True
        weed_mechanic[key][21030705] = False
    else:
        weed_mechanic[key][21030704] = False
        weed_mechanic[key][21030705] = True
    # thermic weeding:
    if maint_categories_thermic in c_maint[key]['variable'] and weed_thermic[key][21030802] == "":
        # thermic weed control is present in c_maint for that crop
        weed_thermic[key][21030801] = True
        weed_thermic[key][21030802] = False
    if weed_thermic[key][21030802] == "":
        # if still = 0, that means: no herbicides and no thermic weeding.
        # Then "NO" must be true.
        if weed_mechanic[key][21030701] == False and weed_mechanic[key][21030702] == False and weed_mechanic[key][21030703] == False:
            # zero-option assurance: no herbicides, no thermic, no mechanic
            # means zero-option is True and everything else is False
            weed_thermic[key][21030802] = False
        else:
            weed_thermic[key][21030802] = True
        
    # dates of mechanical and thermic weed control: evaluated as dates &
    # frequency further below, instead of herbicide application
    weed_ctrl_dates[key] = [c_maint[key]['date'][i] for i, x in enumerate(c_maint[key]['variable'])\
                       if x in list(maint_categories_cutting + maint_categories_pouring + [maint_categories_thermic])]

# application frequency, dates and amounts:
hrb_date_result = {}
fun_date_result = {}
ins_date_result = {}
amount_area = {}
freq_single = {key : [] for key in crop_ids}
# preparation: get a PPP dict in the correct form:
for event in ppp_event:
    if event.crop_index not in amount_area.keys():
        amount_area[event.crop_index] = [event.area_treated_perc]
    else:
        amount_area[event.crop_index].append(event.area_treated_perc)
    if event.area_treated_perc < 0.01:
        for tp in event.type:
            if tp in ['Hrb']:
                # Spot treatment / single-plant application for herbicides:
                freq_single[event.crop_index].append(tp)
    # dates:
    if "Hrb" in set(event.type):
        hrb_date_result = append_date2type(hrb_date_result, event)
    if "Fun" in set(event.type):
        fun_date_result = append_date2type(fun_date_result, event)
    if "Ins" in set(event.type):
        ins_date_result = append_date2type(ins_date_result, event)

# evaluation of amounts:
amount_hrb_eval = {}
amount_fun_eval = {}
amount_ins_eval = {}
for key in hrb_date_result:
    if key in amount_area.keys():
        amount_hrb_eval[key] = eval_ppp_amount(np.mean(amount_area[key]), 'hrb')
for key in fun_date_result:
    if key in amount_area.keys():
        amount_fun_eval[key] = eval_ppp_amount(np.mean(amount_area[key]), 'fun')
for key in ins_date_result:
    if key in amount_area.keys():
        amount_ins_eval[key] = eval_ppp_amount(np.mean(amount_area[key]), 'ins')
# special case mechanical/thermical weed control:
for key in crop_ids:
    if weed_ctrl_dates[key] != [] and key not in hrb_date_result:
        # mechanical weed control but no herbicides applied: evaluated whether
        # the amount of herbicides is 0
        amount_hrb_eval[key] = eval_ppp_amount(0, 'hrb')
    if weed_ctrl_dates[key] == [] and key not in hrb_date_result:
        # no weed control at all, no mechanical, no thermical, no herbicides
        # (zero-option needs amount_hrb_eval to be False in case of vegetables)
        if crop_bdcategories[key] >= 40 and crop_bdcategories[key] < 60:
            amount_hrb_eval[key] = [False, False, False, False, False]
        else:
            amount_hrb_eval[key] = eval_ppp_amount(0, 'hrb')

# evaluation of frequency:
herb_mgmt_freq = {}
fungicide_freq = {}
insecticide_freq = {}
for key in crop_ids:
    # herbicides & weed control:
    if key in hrb_date_result.keys():
        herb_mgmt_freq[key] = eval_frequency(hrb_date_result[key])
    else:
        # no herbicide applied, but mechanical/thermical weed control: 
        # frequency of disturbances needs to be assessed as well.
        if weed_ctrl_dates[key] != []:
            herb_mgmt_freq[key] = eval_frequency(weed_ctrl_dates[key])
        else:
            # zero-option = no herbicide, no mechanical/thermic weed control
            herb_mgmt_freq[key] = [True, False, False, False]
    # fungicides:
    if key in fun_date_result.keys():
        fungicide_freq[key] = eval_frequency(fun_date_result[key])
    else:
        fungicide_freq[key] = [True, False, False, False]
    # insecticides:
    if key in ins_date_result.keys():
        insecticide_freq[key] = eval_frequency(ins_date_result[key])
    else:
        insecticide_freq[key] = [True, False, False, False]

# evaluation of dates:
category='3groups'
herb_mgmt_dates = {}
fungicide_dates = {}
insecticide_dates = {}
for key in crop_ids:
    if key in hrb_date_result.keys():
        # evaluate dates of herbicide application
        herb_mgmt_dates[key] = eval_date(hrb_date_result[key], category)
    elif weed_ctrl_dates[key] != []:
        # evaluate dates of mechanical/thermical weed control
        herb_mgmt_dates[key] = eval_date(weed_ctrl_dates[key], category)
for key in fun_date_result.keys():
    fungicide_dates[key] = eval_date(fun_date_result[key], category)
for key in ins_date_result.keys():
    insecticide_dates[key] = eval_date(ins_date_result[key], category)

# type of herbicide and insecticide
hrb_type = {key : {21030601 : False, 21030602 : False, 21030603 : False} for key in crop_ids}
ins_type = {key : {21070401 : False, 21070402 : False} for key in crop_ids}
# When there is no information about the pesticides being selective or
# non-selective, non-selective is implemented as standard value for herbicide
# and insecticides application.
for event in ppp_event:
    if 'Ins' in event.type:
        ins_type[event.crop_index][21070402] = True
    if 'Hrb' in event.type:
        hrb_type[event.crop_index][21030602] = True
# mechanical/thermical weed control are of type "no herbicide":
for key in weed_ctrl_dates:
    if weed_ctrl_dates[key] != [] and all(value == False for value in hrb_type[key].values()) == True:
        hrb_type[key][21030603] = True

# molluscicides
dict_mollusc = {}
for key in crops:
    dict_mollusc[key] = [True, False]
for event in ppp_event:
    if True in event.mollusc:
        dict_mollusc[event.crop_index] = [False, True]
# molluscicides are applied if at least one PPP product in an event belongs to
# the list of molluscicides inside the method of the ppp_event Class.

# spot treatment / single-plant application
dict_freq_single = {}
for key in freq_single:
    if 'Hrb' in freq_single[key]:
        dict_freq_single[key] = {21030101: True, 21030102: False}
    elif key in hrb_date_result.keys():
        dict_freq_single[key] = {21030101: False, 21030102: True}
    else:
        dict_freq_single[key] = {21030101: False, 21030102: False}

# rodent regulation
dict_rod_reg = {}
for key in c_rodent_regulation:
    if c_rodent_regulation[key] == '004_gazing':
        dict_rod_reg[key] = {21050101: False, 21050102: False, 21050103: False, 21050104: True}
    if c_rodent_regulation[key] == '003_bait':
        dict_rod_reg[key] = {21050101: False, 21050102: False, 21050103: True, 21050104: False}
    if c_rodent_regulation[key] == '002_traps':
        dict_rod_reg[key] = {21050101: False, 21050102: True, 21050103: False, 21050104: False}
    if c_rodent_regulation[key] == '001_no_regulation':
        dict_rod_reg[key] = {21050101: True, 21050102: False, 21050103: False, 21050104: False}

# plant growth regulators
d_pgr = {key: {21120101: False, 21120102: True} for key in crop_ids} # nullvalue is no PGR's
for event in ppp_event:
    if 'PGR' in event.type:
        d_pgr[event.crop_index] = {21120101: True, 21120102: False}


# %% calculations: regular assessments: grazing

# grazing dates
c_grazing_dates = {}
category='9groups'
grazing_dt = {}
animal_type_grazing = {}
animal_category_grazing = {}
c_grazing_LU = {}
for element in grazing_event:
    if element.crop_id not in c_grazing_dates.keys():
        c_grazing_dates[element.crop_id] = [element.date]
        c_grazing_dates[element.crop_id].append(element.date_end)
        animal_type_grazing[element.crop_id] = [element.animal_type]
        c_grazing_LU[element.crop_id] = [element.LU]
    else:
        c_grazing_dates[element.crop_id].append(element.date)
        c_grazing_dates[element.crop_id].append(element.date_end)
        animal_type_grazing[element.crop_id].append(element.animal_type)
        c_grazing_LU[element.crop_id].append(element.LU)
for key in c_grazing_dates:
    grazing_dt[key] = eval_date(c_grazing_dates[key], category)
# grazing dates 2
category='7groups'
grazing_dt2 = {}
for key in c_grazing_dates:
    grazing_dt2[key] = eval_date(c_grazing_dates[key], category)
# grazing animals
for key in animal_type_grazing:
    animal_category_grazing[key] = eval_grazing_animals(set(animal_type_grazing[key]))
# grazing intensity
intensity_cats = {1:21080301,
                  2:21080302,
                  3:21080303,
                  4:21080304,
                  5:21080305}
grazing_intensity = {}
for key in crops:
    if key in c_grazing_LU:
        density = np.mean(c_grazing_LU[key]) / crop_area_ha[key]
    else:
        # if no number of livestock units is given, there is no grazing. This
        # is assured by evaluating a stocking density of -1
        density = -1
    grazing_intensity[key] = eval_intensity(density, intensity_cats, farm_altitude, df_grazing, crop_bdcategories[key], opt_zero = 1)
# zero-option: If there are no grazing events on the crop, then grazing_event = []

# pasture maintenance
pasture_maint = {}
past_maint_dates = {}
for key in c_maint:
    maint_options = [False]*4
    if key in grazed_crops:  # only relevant for used pastures
        past_maint_dates[key] = []
        if '002_weeding' in c_maint[key]['variable']:
            maint_options[1] = True
        if '004_mulching' in c_maint[key]['variable']:
            maint_options[3] = True
            
        maint_dates = [c_maint[key]['date'][i] for i, x in enumerate(c_maint[key]['variable']) if x in ['002_weeding', '004_mulching']]
        past_maint_dates[key].extend(maint_dates)
    # cleaning cuts are evaluated under grass cutting, therefore they do not
    # appear here.
    if maint_options == [False]*4:
        maint_options[0] = True
    pasture_maint[key] = maint_options
# pasture maintenance dates
c_past_maint_dates = {}
category='9groups'
for key in past_maint_dates:
    c_past_maint_dates[key] = eval_date(past_maint_dates[key], category)


# %% calculations: regular assessments: soil treatment

soil_event = []
for key in c_soil:
    for i, element in enumerate(c_soil[key]["date"]):
        # add the soil treatment events and their dates as objects to an event list:
        soil_event.append(TrSoilEvent(c_soil[key]["date"][i], 
                                  c_soil[key]["MC"][i], 
                                  key,
                                  event_type = "soil"))
# add sowing to the soil treatment events:
for key in c_sowi:
    for i, element in enumerate(c_sowi[key]["date"]):
        # Add the sowing treatment events and their dates as objects to an event list:
        soil_event.append(TrSoilEvent(c_sowi[key]["date"][i], 
                                  c_sowi[key]["MC"][i], 
                                  key,
                                  event_type = "sowi"))
# get the correct soil treatment depth per crop:
depth_vector = [21110101,21110102,21110103,21110104]
depth = {}
for element in soil_event:
    # Find the deepest soil treatment per crop. 
    # The higher the category ID, the deeper the treatment.
    if element.crop_index in depth.keys():
        depth[element.crop_index] = np.nanmax([depth[element.crop_index],np.nanmax(element.bd_category)])
    else:
        depth[element.crop_index] = np.nanmax(element.bd_category)
for key in crop_ids:
    # build a true/false vector from the category found.
    if key in depth.keys():
        depth[key] = list(depth_vector == depth[key])
    else:
        depth[key] = [False]*len(depth_vector)
# get the correct soil treatment depth for potatoes (planting) from the
# previous evaluation (depth):
potato_crops = list(tab_crops.loc[tab_crops["NameEN"].str.contains('potatoes', flags=re.IGNORECASE, regex=True),"NameEN"])
depth_planting = {}
for key in depth.keys():
    if crops[key][2] in potato_crops:
        sotr_depth_category = max(np.multiply(depth[key],depth_vector))
        # plowing remains plowing
        if sotr_depth_category == 21110104:
            depth_planting[key] = [False, True]
        # all other soil treatments are without plow
        else:
            depth_planting[key] = [True, False]
    # for crops other than potatoes:
    else:
        depth_planting[key] = [False, False]
# evaluation of the soil treatment dates
eval_soil_dates = {}
soil_dates = {key:[] for key in crop_ids}
for element in soil_event:
    soil_dates[element.crop_index].append(element.date)
for key in soil_dates:
    eval_soil_dates[key] = eval_date(soil_dates[key], '3groups')


# %% calculations: regular assessments: harvest assessment ====================

# harvest treatment
harv_event = []
for key in c_harv:
    crop_yield = sum(c_harv[key]["amount_kg"])
    for i, element in enumerate(c_harv[key]["date"]):
        # get indices to select the machine combination with the same date as
        # the current harvest date
        indices = [k for k, x in enumerate(c_harv[key]["date_ff"]) if x == element]
        # add the harvest treatment events and their dates as objects to an
        # event list, adding the crop yield to every harvest event of the crop:
        harv_event.append(TrHarvEvent(c_harv[key]["date"][i], 
                                  c_harv[key]["MC"][i], 
                                  key,
                                  crop_yield,
                                  c_harv[key]["value_rare_cut"][i],
                                  [c_harv[key]["MC_ff"][i] for i in indices if c_harv[key]["MC_ff"][i] != 'keine_befahrung']))
# divert into grassland harvest (including fodder catch crops) and harvest of
# arable crops (including green manure)
catch_crop_ids = [k for k, v in crops.items() if 'Catch_crop' in v[2]]
grassland = ['Permanent grassland extensive','Permanent grassland intensive','Temporary grassland']
harv_event_grass = []
harv_event_arable = []
for element in harv_event:
    if(element.crop_landuse in grassland or element.crop_index in catch_crop_ids):
        harv_event_grass.append(element)
    else:
        harv_event_arable.append(element)


# harvest assessment for grassland ============================================
# Cleaning cuts on pastures and cutting on meadows: mowing technique
# 21100601 = a. bar mower
# 21100602 = b. rotary mower
# 21100603 = c. rotary mower with conditioner
# 21100604 = d. mowing technique not determined
# Cleaning cuts on pastures get evaluated the same as cuts on meadows.
# Therefore, there is only one evaluation. The cleaning cut category remains empty.
cut_tech = {21100601, 21100602, 21100603, 21100604}
d_cuttech = {key: {21100601: False, 21100602: False, 21100603: False, 21100604: False} for key in crop_ids}

dict_cuttech = {}
dict_cutdates = {}
for element in harv_event_grass:
    # get a dict with all harvest event dates per crop
    if element.crop_index in dict_cutdates.keys():
        dict_cutdates[element.crop_index].extend([element.date])
    else:
        dict_cutdates[element.crop_index] = [element.date]
    # get a dict with the IDs of all cutting techniques used
    if element.crop_index in dict_cuttech.keys():
        dict_cuttech[element.crop_index].extend(list(set(element.bd_category) & cut_tech))
    else:
        dict_cuttech[element.crop_index] = list(set(element.bd_category) & cut_tech)

# copy the dict with the cutting technique IDs per cut for the evaluation of
# the harvesting frequency
dict_cuts = dict_cuttech.copy()
for index in dict_cuttech:
    dict_cuttech[index] = list(set(dict_cuttech[index]))
# convert the dict with the cutting techniques used per crop into the true/
# false category-vector
for key in dict_cuttech:
    for x in dict_cuttech[key]:
        d_cuttech[key][x] = True

# number of harvests, number of cuts and intensity
# Deriving the number and dates of cuts: Only mowing machinery categorised as such
# in SALCAtables_machinery are recognised as mowing event! When the machinery
# mapping fails, the respective mowing event is not included in the assessment.
for key in dict_cuts:
    if dict_cuts[key] is not None:
        dict_cuts[key] = len(dict_cuts[key])
# intensity
intensity_cats = {1:21100201,
                  2:21100202,
                  3:21100203,
                  4:21100204,
                  5:21100205}
cut_intensity = {}
for key in dict_cuts:
    cut_intensity[key] = eval_intensity(dict_cuts[key], intensity_cats, farm_altitude, df_harvestcut, crop_bdcategories[key])

# Special case for land uses where cuts are only rarely allowed: litter fields
rarecut_categories = {'cut_000_noeco':21100301,
                      'cut_003_1p3yr':21100302,
                      'cut_002_1p2yr':21100303,
                      'cut_001_1pyr':21100304}
dict_rarecut = {}
for element in harv_event_grass:
    dict_rarecut[element.crop_index] = rarecut_categories[element.val_rare_cut]
d_rarecut = {key: {21100301: False, 21100302: False, 21100303: False, 21100304: False} for key in crop_ids}
for key in dict_rarecut:
    d_rarecut[key][dict_rarecut[key]] = True
    
# cutting dates
cutting_g7_dt = {}
cutting_g9_dt = {}
for key in dict_cutdates:
    cutting_g7_dt[key] = eval_date(dict_cutdates[key], '7groups')
    cutting_g9_dt[key] = eval_date(dict_cutdates[key], '9groups')

# silage baling
baling_tech = {21100701}
d_balingtech = {key: {21100701: False, 21100702: False} for key in crop_ids}
dict_balingtech = {}
for element in harv_event_grass:
    # get a dict with the IDs of all cutting techniques used
    if element.crop_index in dict_balingtech.keys():
        dict_balingtech[element.crop_index].extend(list(set(element.bd_category) & baling_tech))
    else:
       dict_balingtech[element.crop_index] = list(set(element.bd_category) & baling_tech)
# convert the dict per crop into the true/false category-vector
for key in dict_cutdates:
    if key in dict_balingtech.keys():
        for x in dict_balingtech[key]:
            d_balingtech[key][x] = True
        if d_balingtech[key][21100701] == False:
            d_balingtech[key][21100702] = True

# harvest cuts (yes/no)
d_cuts = {key: {21100101: False, 21100102: True} for key in crop_ids}
for key in dict_cutdates:
    d_cuts[key] = {21100101: True, 21100102: False}
# ensuring correctness of zero-option:
for key in dict_cuts:
    #if the zero-option is true, all other values need to be false
    if cut_intensity[key][0] == True:
        cutting_g7_dt[key] = [False, False, False, False, False, False, False]
        cutting_g9_dt[key] = [False, False, False, False, False, False, False, False, False]
        d_cuttech[key] = {k: False for k in d_cuttech[key]}
        d_balingtech[key] = {k: False for k in d_balingtech[key]}
    # litter fields have d_rarecut as the zero-option element
    if d_rarecut[key][21100301] == True and crop_bdcategories[key] == 14:
        cutting_g9_dt[key] = [False, False, False, False, False, False, False, False, False]
        d_cuttech[key] = {k: False for k in d_cuttech[key]}


# harvest assessment for green manure =========================================
bool_mulching = {}
# get the maintenance events of the green manure crops
green_manure_ids = [k for k, v in crops.items() if 'Green_manure' in v[2]]
green_manure_maint = {k:v for k,v in c_maint.items() if k in green_manure_ids and v['date'] != []}

# harvest treatment
for key in green_manure_maint:
    for i, element in enumerate(green_manure_maint[key]["date"]):
        # Add the green manure maintenace treatment to the event list if it is
        # mulching:
        if green_manure_maint[key]["variable"][i] == '004_mulching':
            harv_event_arable.append(TrHarvEvent(green_manure_maint[key]["date"][i], 
                                     green_manure_maint[key]["MC"][i], 
                                     key,
                                     sum(c_harv[key]["amount_kg"]),  # add the crop yield to every harvest event of the crop
                                     'cut_000_noeco'))  # green manure is no litter field, therefore append the nullvalue
            bool_mulching[key] = True

# evaluate the dates of harvest and mulching treatments as well as crop residue
# handling on green manure:
gm_datelist = {}
gm_residues = {}
for key in green_manure_ids:
    gm_residues[key] = [21200201, 21200202, 21200203]
    
for element in harv_event_arable:
    if element.crop_index in green_manure_ids:
        if element.crop_index in gm_datelist.keys():
            gm_datelist[element.crop_index].append(element.date)
        else:
           gm_datelist[element.crop_index] = [element.date]
        # check for harvest with a mulching machine
        if 21140202 in element.bd_category.values:
            bool_mulching[element.crop_index] = True
        else:
            if element.crop_index not in bool_mulching.keys():
                bool_mulching[element.crop_index] = False
        # check whether there is a harvest where the yield was left on the field
        if element.crop_yield == 0:
            gm_residues[element.crop_index][0] = True
            gm_residues[element.crop_index][1] = False
            gm_residues[element.crop_index][2] = False

# evaluation of mulching/incorporation
for key in green_manure_ids:
    # check whether the green manure crop was mulched
    if bool_mulching[key] == True:
        gm_residues[key][1] = True
    # check whether the residues were incorporated into the soil
    if c_hare_inco_bool[key] == True:
        gm_residues[key][2] = True
    # priority determination (no multiplechoice):
    # incorporation > mulching > residues left on field
        if gm_residues[key][2] == True:
            gm_residues[key][1] = False
            gm_residues[key][0] = False
        else:
            if gm_residues[key][1] == True:
                gm_residues[key][0] = False

# evaluation of dates:
gm_date_eval = {}
for key in gm_datelist:
    gm_date_eval[key] = eval_date(gm_datelist[key], '3groups')


# harvest assessment for arable land ==========================================
dict_harv_dates = {}
harv_residues = {}
# initialize dict for harvesting residues with all harvested arable crops
for element in harv_event_arable:
    key = element.crop_index
    if key not in green_manure_ids:
        harv_residues[key] = [21140201, 21140202, 21140203, 21140204]
# assess the harvested crops
for element in harv_event_arable:
    key = element.crop_index
    if key not in green_manure_ids:
        # get a dict with all harvest event dates per crop
        if key in dict_harv_dates.keys():
            dict_harv_dates[key].extend([element.date])
        else:
            dict_harv_dates[key] = [element.date]
        # check for harvest with a mulching machine
        if 21140202 in element.bd_category.values:
            bool_mulching[key] = True
        else:
            if key not in bool_mulching.keys():
                bool_mulching[key] = False
        # check whether there was mulching as maintenance
        if c_maint[key]['date'] !=[] and '004_mulching' in c_maint[key]["variable"]:
            bool_mulching[key] = True
        # check whether the residues were incorporated into the soil
        if c_hare_inco_bool[key] == True:
            harv_residues[key][2] = True
        # check whether the secondary product was harvested
        if c_harv_sepr[key]['date'] !=[]:
            harv_residues[key][0] = False
            harv_residues[key][3] = True
        else:
            harv_residues[key][0] = True
            harv_residues[key][3] = False

# evaluation of harvest dates
harv_g3_dt = {}
for key in dict_harv_dates:
    harv_g3_dt[key] = eval_date(dict_harv_dates[key], '3groups')

# crop residue handling
for key in harv_residues:
    # check whether there was mulching on the crop
    if bool_mulching[key] == True:
        harv_residues[key][1] = True
    else:
        harv_residues[key][1] = False
    # priority determination (no multiplechoice):
    # harvested > incorporation > mulching > residues left on field
    if harv_residues[key][3] == True:
        harv_residues[key][0] = False
        harv_residues[key][1] = False
        harv_residues[key][2] = False
    elif harv_residues[key][2] == True:
        harv_residues[key][0] = False
        harv_residues[key][1] = False
    else:
        harv_residues[key][2] = False
        if harv_residues[key][1] == True:
            harv_residues[key][0] = False


# %% calculations: regular assessments: various ===============================

# haulm removal (potatoes) with weeding techniques
# initialize weed dict for all harvested potato crops
weed_rm = {}
for element in harv_event_arable:
    key = element.crop_index
    if element.crop_name in potato_crops:
        weed_rm[key] = [21180101, 21180102, 21180103, 21180104]
for element in harv_event_arable:
    key = element.crop_index
    if element.crop_name in potato_crops:
        if 21180101 in element.bd_category:
            weed_rm[key][0] = True
        else:
            weed_rm[key][0] = False
        if c_maint[key]['date'] !=[] and '005_burning_weed' in c_maint[key]["variable"]:
            weed_rm[key][2] = True
        else:
            weed_rm[key][2] = False
        # compare harvest date with PPP events within 60 days of the
        # harvesting event
        harvest_date = element.date
        for event in ppp_event:
            if event.type == "Hrb":
                delta = dt.datetime.strptime(harvest_date, '%Y-%m-%d') -\
                        dt.datetime.strptime(event.date, '%Y-%m-%d')
                if delta <= dt.timedelta(days = 60) and delta >= dt.timedelta(days = 0):
                    weed_rm[key][1] = True
# final evaluation of haulm removal
for key in weed_rm:
    if weed_rm[key][1] == 21180102:
        # if no herbicides were applied within 60 days before harvest, there
        # was no chemical haulm removal
        weed_rm[key][1] = False 
    if True not in weed_rm[key]:
        # if there was no weed removal at all (none of the categories are
        # true), the zero-option is true
        weed_rm[key][3] = True
    else:
        weed_rm[key][3] = False


# hedge trimming
hedgecut = {}
for crop in c_maint:
    if '008_hedgecut' in c_maint[crop]['variable']:
        hedgecut[crop] = [True, False]
    else:
        hedgecut[crop] = [False, True]

# irrigation
irrigation = {}
for crop in c_irri:
    if c_irri[crop]['type'] !=[]:  # check if there is any irrigation event on the crop
        irrigation[crop] = [True, False]
    else:
        irrigation[crop] = [False, True]

# sowing before harvest
for crop in pre_harv_sowi:
    if pre_harv_sowi[crop] == True:
        pre_harv_sowi[crop] = [True, False]
    else:
        pre_harv_sowi[crop] = [False, True]


# %% gathering the input data =================================================

# soil cover
id_s = [6010101,
        6010102,
        6010103,
        6010104]
d_date_uncovered = add_ids2dict(id_s, date_uncovered)
# Soil cover needs to be inserted as separate crops in separate columns, next
# to each crop. Therefore a nulldict is needed for the true crops:
nulldict_soilcover = {key:{6010101: False, 6010102: False, 6010103: False, 6010104: False} for key in crop_ids}

# fertilisation
# fertilisation frequency
id_s = [21020101,
        21020102,
        21020103,
        21020104]
d_fertilisation_freq = add_ids2dict(id_s, fertilisation_freq)
# fertilisation dates
id_s = [21020201,
        21020202,
        21020203]
d_fertilisation_dt = add_ids2dict(id_s, fertilisation_dt)
# fertilisation quantity on grassland (intensity)
id_s = [21020301,
        21020302,
        21020303,
        21020304,
        21020305]
d_fert_intensity = add_ids2dict(id_s, fert_intensity)
# fertilisation quantity on arable land (in % of the Swiss fertilisation norm)
id_s = [21020401,
        21020402,
        21020403,
        21020404]
d_dict_fert_norm = add_ids2dict(id_s, dict_fert_norm)
# fertilisation types
id_s = [21020501,
        21020502,
        21020503,
        21020504,
        21020505,
        21020506,
        21020507,
        21020508,
        21020509,
        21020510,
        21020511,
        21020512,
        21020513,
        21020514,
        21020515,
        21020516,
        21020517,
        21020518,
        21020519,
        21020520,
        21020521,
        21020522]
d_fertilisation_type = add_ids2dict(id_s, fertilisation_type)
# fertilisation technique/incorporation
id_s = [21020601,
        21020602]
d_fert_tech = add_ids2dict(id_s, fert_tech)

# plant protection
# spot treatment / single-plant application of herbicides
dict_freq_single
# mechanical cleaning cut
dict_clean_cut
# frequency of weed management
id_s = [21030301,
        21030302,
        21030303,
        21030304]
d_herb_mgmt_freq = add_ids2dict(id_s, herb_mgmt_freq)
# dates of weed management
id_s = [21030401,
        21030402,
        21030403]
d_herb_mgmt_dates = add_ids2dict(id_s, herb_mgmt_dates)
# amount of herbicide application
id_s = [21030501,
        21030502,
        21030503,
        21030504,
        21030505]
d_amount_hrb_eval = add_ids2dict(id_s, amount_hrb_eval)
# herbicide type
hrb_type
# mechanical weed control
weed_mechanic
# thermic weed control
weed_thermic
# fungicide frequency
id_s = [21040101,
        21040102,
        21040103,
        21040104]
d_fungicide_freq = add_ids2dict(id_s, fungicide_freq)
# dates of fungicide application
id_s = [21040201,
        21040202,
        21040203]
d_fungicide_dates = add_ids2dict(id_s, fungicide_dates)
# fungicide amounts
id_s = [21040301,
        21040302,
        21040303,
        21040304]
d_amount_fun_eval = add_ids2dict(id_s, amount_fun_eval)
# rodent regulation
dict_rod_reg
# molluscicides
id_s = [21060101,
        21060102]
d_dict_mollusc = add_ids2dict(id_s, dict_mollusc)
# insecticide frequency
id_s = [21070101,
        21070102,
        21070103,
        21070104]
d_insecticide_freq = add_ids2dict(id_s, insecticide_freq)
# dates of insecticide application
id_s = [21070201,
        21070202,
        21070203]
d_insecticide_dates = add_ids2dict(id_s, insecticide_dates)
# insecticide amounts
id_s = [21070301,
        21070302,
        21070303,
        21070304]
d_amount_ins_eval = add_ids2dict(id_s, amount_ins_eval)
# insecticide type
ins_type

# grazing
# grazing dates
id_s = [21080101,
        21080102,
        21080103,
        21080104,
        21080105,
        21080106,
        21080107,
        21080108,
        21080109]
d_grazing_dt = add_ids2dict(id_s, grazing_dt)
# grazing dates (with exclusion)
id_s = [21080201,
        21080202,
        21080203,
        21080204,
        21080205,
        21080206,
        21080207]
d_grazing_dt2 = add_ids2dict(id_s, grazing_dt2)
# grazing intensity
id_s = [21080301,
        21080302,
        21080303,
        21080304,
        21080305]
d_grazing_intensity = add_ids2dict(id_s, grazing_intensity)
# animal category
id_s = [21080401,
        21080402,
        21080403,
        21080404,
        21080405,
        21080406,
        21080407,
        21080408,
        21080409,
        21080410,
        21080411,
        21080412,
        21080413,
        21080414,
        21080415,
        21080416,
        21080417,
        21080418]
d_animal_category_grazing = add_ids2dict(id_s, animal_category_grazing)
# pasture maintenance type
id_s = [21090101,
        21090102,
        21090103,
        21090104]
d_pasture_maint = add_ids2dict(id_s, pasture_maint)
# pasture maintenance cutting technique: assessed as normal cut under harvest
# nulldict as placeholder:
nulldict_pasture_cuttech = {key:{21090201: False, 21090202: False, 21090203: False, 21090204: False} for key in crop_ids}
# pasture maintenance dates
id_s = [21090301,
        21090302,
        21090303,
        21090304,
        21090305,
        21090306,
        21090307,
        21090308,
        21090309]
d_past_maint_dates = add_ids2dict(id_s, c_past_maint_dates)

# cuts, harvest of grassland
# harvest cuts (yes/no)
d_cuts
# number of cuts (intensity)
id_s = [21100201,
        21100202,
        21100203,
        21100204,
        21100205]
d_cut_intensity = add_ids2dict(id_s, cut_intensity)
# number of cuts (rare cuts, litter fields only)
d_rarecut
# cutting dates (with exclusion)
id_s = [21100401,
        21100402,
        21100403,
        21100404,
        21100405,
        21100406,
        21100407]
d_cutting_g7_dt = add_ids2dict(id_s, cutting_g7_dt)
# cutting dates
id_s = [21100501,
        21100502,
        21100503,
        21100504,
        21100505,
        21100506,
        21100507,
        21100508,
        21100509]
d_cutting_g9_dt = add_ids2dict(id_s, cutting_g9_dt)
# cutting technique
d_cuttech
# silage baling
d_balingtech

# soil treatment & sowing
# treatment depth
id_s = [21110101,
        21110102,
        21110103,
        21110104]
d_depth = add_ids2dict(id_s, depth)
# treatment date
id_s = [21110201, 
        21110202, 
        21110203]
d_soil_dates = add_ids2dict(id_s, eval_soil_dates)

# plant growth regulators
d_pgr

# irrigation
id_s = [21130101,
        21130102]
d_irrigation = add_ids2dict(id_s, irrigation)

# harvest of arable crops
# harvest dates
id_s = [21140101,
        21140102,
        21140103]
d_harv_g3_dt = add_ids2dict(id_s, harv_g3_dt)
# harvest residue management
id_s = [21140201,
        21140202,
        21140203,
        21140204]
d_harv_residues = add_ids2dict(id_s, harv_residues)

# hedge trimming
id_s = [21150101,
        21150102]
d_hedgecut = add_ids2dict(id_s, hedgecut)

# soil treatment & planting (potatoes)
# treatment depth
id_s = [21170101,
        21170102]
d_depth_planting = add_ids2dict(id_s, depth_planting)
# treatment date
# for potatoes, the soil treatment and planting date evaluation is the same as
# the previous general date evaluation for all crops:
d_dates_planting = {key: {21170201: False, 21170202: False, 21170203: False} for key in crop_ids}
for key in d_soil_dates:
    if crops[key][2] in potato_crops:
        d_dates_planting[key] = d_soil_dates[key]

# haulm removal (potatoes)
id_s = [21180101, 
        21180102, 
        21180103, 
        21180104]
d_weed_rm = add_ids2dict(id_s, weed_rm)

# pre harvest seeding of cover crops (Vorerntesaat)
id_s = [21190101,
        21190102]
d_pre_harv_sowi = add_ids2dict(id_s, pre_harv_sowi)

# harvest/treatment of green manure
# dates
id_s = [21200101,
        21200102,
        21200103]
d_gm_date_eval = add_ids2dict(id_s, gm_date_eval)
# residues
id_s = [21200201,
        21200202,
        21200203]
d_gm_residues = add_ids2dict(id_s, gm_residues)



# Total input data ============================================================

# Collecting all biodiversity input data into a list of dataframes:
bd_input_collected = []
data_list = [
    ruderal_crop,
    drywall_crop,
    trail_crop,
    singletree_crop,
    hist_tree_crop,
    nulldict_soilcover,
    d_fertilisation_freq,
    d_fertilisation_dt,
    d_fert_intensity,
    d_dict_fert_norm,
    d_fertilisation_type,
    d_fert_tech,
    dict_freq_single,
    dict_clean_cut,
    d_herb_mgmt_freq,
    d_herb_mgmt_dates,
    d_amount_hrb_eval,
    hrb_type,
    weed_mechanic,
    weed_thermic,
    d_fungicide_freq,
    d_fungicide_dates,
    d_amount_fun_eval,
    dict_rod_reg,
    d_dict_mollusc,
    d_insecticide_freq,
    d_insecticide_dates,
    d_amount_ins_eval,
    ins_type,
    d_grazing_dt,
    d_grazing_dt2,
    d_grazing_intensity,
    d_animal_category_grazing,
    d_pasture_maint,
    nulldict_pasture_cuttech,
    d_past_maint_dates,
    d_cuts,
    d_cut_intensity,
    d_rarecut,
    d_cutting_g7_dt,
    d_cutting_g9_dt,
    d_cuttech,
    d_balingtech,
    d_depth,
    d_soil_dates,
    d_pgr,
    d_irrigation,
    d_harv_g3_dt,
    d_harv_residues,
    d_hedgecut,
    d_depth_planting,
    d_dates_planting,
    d_weed_rm,
    d_pre_harv_sowi,
    d_gm_date_eval,
    d_gm_residues
    ]

# create a dict with all rows per crop (specify crop_ids as columns)
# keys from the special case assessment
columns = [1.1,2.1,3.1,4.1,5.1]
columns.extend(list(crop_ids))
# sort the list of crop_ids
columns.sort()
dest = {key:{} for key in columns}
for a in data_list:
    for b in a.items():
        dest[b[0]].update(b[1])
# exchange the option ID in order to reflect the correct habitat type-II and
# get a new dict:
dest_new = {}
for key in dest:
    if type(key) == int:
        # for vegetables, differentiate between open-field (standard, as in
        # SALCAtables_crops) and greenhouse cultivation
        if c_bd_vege_grho_bool != {} and c_bd_vege_grho_bool[key] == True and crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
            new_id = crop_bdcategories[key] * 1000000 - 10000000 # id's for greenhouse
        else:
            new_id = crop_bdcategories[key] * 1000000
        old_id = 21000000
        dest_new[key] = {}
        for element, value in dest[key].items():
            if round(element,-6) == old_id:
                dest_new[key][element-old_id+new_id] = value
            else:
                dest_new[key][element] = value
    else:
        dest_new[key] = dest[key]


# %% handling of special crops ================================================

# Crops that are not evaluated for biodiversity (see SALCAtables_crops) get
# dropped from the dict: crops without assessment have the bdcategory = 0 in
# SALCAtables_crops.
dropped_crops = {}
replaced_crops = {}
vegetable_crops_control = {}
for key in dest:
    if type(key) == int:
        if crop_bdcategories[key] == 0:
            del dest_new[key]
            if key+0.5 in dest_new.keys():
                del dest_new[key+0.5]
            dropped_crops[key] = crop_names[key]
        # for orchard and vineyard crops, the general assessment is dropped
        # from salcabd_farm (done here) and replaced by the assessment from
        # salcabd_horti (done below):
        if crop_bdcategories[key] in [30, 70]:
            del dest_new[key]
            replaced_crops[key] = crop_names[key]
        # list vegetable crops to check whether their assessment is complete or
        # whether some part is missing (vegetables are evaluated mainly in
        # salcabd_farm but also partly in salcabd_horti)
        if crop_bdcategories[key] >= 40 and crop_bdcategories[key] < 70:
            vegetable_crops_control[key] = crop_names[key]
        
assessed_crops = dict(crop_names.items() ^ dropped_crops.items())

# integration of salcabd_horti
if hasattr(inp, 'f_bd_horti_output') and inp.f_bd_horti_output is not None:
    # load salcabd_horti results
    f_bd_horti = js.loads(inp.f_bd_horti_output)
    for dictionary in f_bd_horti:
        f_bd_horti[dictionary] = dict((int(key), value) for (key, value) in f_bd_horti[dictionary].items())
    f_bd_horti = dict((float(key), value) for (key, value) in f_bd_horti.items())
    
    # ensure that all orchard and vineyard crops dropped from the standard
    # evaluation (replaced_crops) are actually present in the salcabd_horti
    # results
    for key in replaced_crops.keys():
        if key not in set([int(key) for key in f_bd_horti.keys()]):
            w.warn("Missing crops during exchange between general and horticultural assessment!")
            stderr.flush()
            logging.info(replaced_crops[key])

    # combine the evaluation results for vegetables from both salcabd_farm and
    # salcabd_horti
    vegetable_crops2combine = [key for key in crop_bdcategories if crop_bdcategories[key] >= 40 and crop_bdcategories[key] < 70]
    for crop in vegetable_crops2combine:
        # update with the measure IDs assessed in salcabd_horti
        dest_new[crop].update(f_bd_horti[crop])

    # create the final dataframes with the input values for biodiversity
    # evaluation from salcabd_farm and salcabd_horti:
    df_total_bd_evaluation = pd.DataFrame.from_dict(dest_new)
    df_total_bd_evaluation.fillna(False, inplace = True)
    df_bd_horti_evaluation = pd.DataFrame.from_dict(f_bd_horti)
    df_bd_horti_evaluation.fillna(False, inplace = True)
    
    # combine bd_evaluation and bd_horti_evaluation
    df_total_bd_evaluation = pd.concat([df_total_bd_evaluation, df_bd_horti_evaluation])
    df_total_bd_evaluation.fillna(False, inplace = True)
elif replaced_crops != {}:
    w.warn('')
    w.warn('Horticultural crops are present in the farm evaluated, but no horticultural module was used in the calculation!')
    w.warn('')
    w.warn('Therefore, these crops are missing their SALCA-BD evaluation: %s')
    w.warn(replaced_crops)
    w.warn('')
    stderr.flush()
elif vegetable_crops_control != {}:
    w.warn('')
    w.warn('Vegetable crops are only partly evaluated, because no horticultural module was used in the calculation!')
    w.warn('')
    stderr.flush()
else:
    # create the final dataframes with the input values for biodiversity
    # evaluation in case of absence of the horticultural module
    df_total_bd_evaluation = pd.DataFrame.from_dict(dest_new)
    df_total_bd_evaluation.fillna(False, inplace = True)


# %% gathering the meta data ==================================================

## mapping the metainformation:
index = [
    "field_name",
    "field_id",
    "field_area",
    "field_border_area",
    "year",
    "culture_name",
    "culture_id",
    "scenario",
    "duration",
    "measures"]

meta_info_clist = {k: [] for k in index}
colnames = []
# special case assessment
speccase_area = {1.1: ruderal_eval_area,
                 2.1: drywall_area,
                 3.1: trail_area,
                 4.1: singletree_area,
                 5.1: hist_tree_area}
speccase_names = {1.1: "ruderal area",
                 2.1: "drywalls",
                 3.1: "trails",
                 4.1: "single trees",
                 5.1: "high stem trees"}
for key in [1.1,2.1,3.1,4.1,5.1]:
    meta_info_clist["field_name"].append(str(key))
    # every crop is assessed with its own field
    meta_info_clist["field_id"].append(speccase_names[key])
    # area of special case assessments (already in m2)
    meta_info_clist["field_area"].append(speccase_area[key])
    # SALCA-BD can assess the impact of field borders as well. However, here
    # they are not taken into consideration, therefore always = 0
    meta_info_clist["field_border_area"].append(0)
    meta_info_clist["year"].append(str(eval_year))
    meta_info_clist["culture_name"].append(str(key))
    meta_info_clist["culture_id"].append(speccase_names[key])
    meta_info_clist["scenario"].append('S1')
    meta_info_clist["duration"].append(speccase_duration)
    meta_info_clist["measures"].append("Massnahmen")
    colnames.append(key)
# assessment of crops and soil cover
crop_keys = list(crop_ids)
crop_keys.sort()
for key in crop_keys:
    # exclude crops without biodiversity assessment
    if key not in dropped_crops.keys():
        if key not in replaced_crops.keys():
            meta_info_clist["field_name"].append(str(key))
            # every crop is assessed with its own field
            meta_info_clist["field_id"].append(crop_names[key])
            # convert field area to m2
            meta_info_clist["field_area"].append(crop_area_ha[key]*10000)
            # SALCA-BD can assess the impact of field borders as well. However,
            # here they are not taken into consideration, therefore always = 0
            meta_info_clist["field_border_area"].append(0)
            meta_info_clist["year"].append(str(eval_year))
            meta_info_clist["culture_name"].append(str(key))
            meta_info_clist["culture_id"].append(crop_names[key])
            meta_info_clist["scenario"].append('S1')
            meta_info_clist["duration"].append(crop_duration_m[key])
            meta_info_clist["measures"].append("Massnahmen")
            colnames.append(key)
        else:
            horti_keys = [x for x in f_bd_horti.keys() if x > key and x < key+1]
            for element in horti_keys:
                meta_info_clist["field_name"].append(str(element))
                # every crop is assessed with its own field
                meta_info_clist["field_id"].append(crop_names[key])
                # convert field area to m2
                meta_info_clist["field_area"].append(crop_area_ha[key]*10000) 
                # SALCA-BD can assess the impact of field borders as well.
                # However, here they are not taken into consideration,
                # therefore always = 0
                meta_info_clist["field_border_area"].append(0)
                meta_info_clist["year"].append(str(eval_year))
                meta_info_clist["culture_name"].append(str(key))
                meta_info_clist["culture_id"].append(crop_names[key])
                meta_info_clist["scenario"].append('S1')
                meta_info_clist["duration"].append(crop_duration_m[key])
                meta_info_clist["measures"].append("Massnahmen")
                colnames.append(element)

# meta information dataframe:
meta_info_df = pd.DataFrame.from_dict(meta_info_clist, orient = 'index', columns = colnames)


# %% result calculation =======================================================

if ctx.farm.crops != {}:
    
    betrieb = salcabd.import_production_inventory_salca(meta_info_df, df_total_bd_evaluation, ctx.farm.inventory_id, control_table = None)
    betrieb.validate(ct = None)

    # farm result
    # get all results as dataframes and lists:
    r1_df, r2_list, r2_meta, r3_df, r4_df, nnrot_and_nnder = betrieb._calculate_for_export(ct = salcabd.get_default_control_table(), consider_zero_values = False)
    r2_tot_df = pd.concat(r2_list)


# %% output ===================================================================

if ctx.farm.crops == {}:
    logging.info('')
    logging.info('SALCA-BD not assessed:')
    logging.info('No crops were modeled on the farm')
else:
    logging.info('SALCA-BD successful')
    logging.info('')
    logging.info('Crops assessed:')
    logging.info(assessed_crops)
    logging.info('Crops without assessment:')
    logging.info(dropped_crops)
    logging.info('')
    logging.info('Result R4 for Export:')
    logging.info('')
    logging.info(r4_df.to_string())
    logging.info('')
    
    # save the results dataframes as text to the output
    out.f_bdiv_r1_df = js.dumps(r1_df.to_dict('split'), ensure_ascii=False)
    out.f_bdiv_r2_df = js.dumps(r2_tot_df.to_dict('split'), ensure_ascii=False)
    out.f_bdiv_r3_df = js.dumps(r3_df.to_dict('split'), ensure_ascii=False)
    out.f_bdiv_r4_df = js.dumps(r4_df.to_dict('split'), ensure_ascii=False)
    


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
