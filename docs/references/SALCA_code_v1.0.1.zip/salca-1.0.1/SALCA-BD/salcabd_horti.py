# -*- coding: utf-8 -*-
"""
File name: salcabd_horti.py
Created on Wed Feb 28 10:13:21 2024

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script assesses the impact of horticultural crops on biodiversity

Calculation level:
    Farm (entity comprising all fields, crops and animal groups)
"""

# %% import modules ===========================================================

import datetime as dt
import json as js
import logging
from importlib import reload
from pathlib import Path

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAmapping-BD_horticulture_viticulture'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes ===========================================================

class PppEvent_horti:
    """
    Class for the plant protection events on a crop. Contains the data needed
    to translate the management practices that occured on a crop into the
    corresponding true/false list of the SALCA-BD management level III.

    Input-Parameters
    ----------
    date : str, format: 'yyyy-mm-dd'
        Date the plant protection event occurred.
    products : list of str
        List of the names of applied plant protection products (PPP).
    amounts : list of float
        List of the applied amounts of products.
    perc_treated_area : float
        Value for the percentage of the crop area that has been treated during
        that event.
    row_interrow : str
        String that determines if an event has been applied to the rows or the
        interrows or both.
    type_fungicide : str
        String of the type of fungicide that has been applied in the event.
    type_insecticide : str
        String of the type of insecticide that has been applied in the event.
    type_bactericide : str
        String of the type of bactericide that has been applied in the event.
    crop_index : int
        Index of the crop on which the event occurred.
        
    Further Parameters
    ----------
    type : list of str
        List of the types of plant protection products.
    """
    def __init__(self, date, products, amounts, perc_treated_area, row_interrow, type_fungicide, type_insecticide, type_bactericide, crop_index):
        self.date = date
        self.products = [x for x in products if x]
        self.amounts = [x for x in amounts if x is not None]
        self.type = []
        self.area_treated_perc = perc_treated_area
        self.row_interrow = row_interrow
        self.type_fungicide = type_fungicide
        self.type_insecticide = type_insecticide
        self.type_bactericide = type_bactericide
        self.crop_index = crop_index
        self.mollusc = []
    
    def get_type(self):
        self.type = []
        olca_types = [tab_ppp.loc[tab_ppp['NameEN'] == x,"OLCA-Pest_type"].item() for x in self.products]
        for olca_type in olca_types:
            if olca_type in ["Fun", "Ins"]:
                self.type.append(olca_type)
            # acaricides are assessed under the category insecticides
            elif olca_type == "Ac/Mi":
                self.type.append("Ins")
            else:
                if olca_type in ["Hrb-pre", "Hrb-post"]:
                    self.type.append("Hrb")
                else:
                    self.type.append("unknown")
        return "Pesticide types have been determined!"
        
    def eval_mollusc(self):
        mollusc = ['ppp_metaldehyde', 'ppp_ferric_phosphate', 'ppp_ferric_pyrophosphate']
        self.mollusc = [True for x in self.products if x in mollusc]
        return "Molluscicide application has been evaluated!"


# %% define functions =========================================================

def load_intensity_table(table):
    path = Path(".") / "salcabd" / "pkg_resources" / "prep_tables" / table
    df_table = pd.read_csv(path,
                      sep=None,
                      header=0,
                      encoding='utf-8-sig',
                      engine='python')
    return df_table
# functions to gather input data:
def add_ids2dict_prep(ids, d_dict):
    result = {key: d_dict[i] for i,key in enumerate(ids)}
    return result
def add_ids2dict(id_s, the_dict):
    result = {k: add_ids2dict_prep(id_s, v) for k,v in the_dict.items()}
    return result

def eval_frequency(dates_list, crop_cat = 30):
    """
    Translates a list of event dates into the correct true/false list
    corresponding to the categories of the SALCA-BD management level III:
    Frequency.

    Parameter
    ----------
    dates_list : list
        List of the event dates to be evaluated.
    """
    if crop_cat == 70:
        freq_cats = {'a':1,'b':3,'c':5,'d':7}
    elif crop_cat == 'ppp_fun':
        freq_cats = {'a':0,'b':1,'c':6,'d':11,'e':16}
    elif crop_cat == 'ppp_ins':
        freq_cats = {'a':0,'b':1,'c':2,'d':3}
    else:
        freq_cats = {'a':0,'b':1,'c':3,'d':5}
    c_freq = len(dates_list)
    categories = [index for index,value in enumerate(freq_cats.values()) if c_freq >= value]

    category = [False] * len(freq_cats)
    if categories != []:
        category[max(categories)] = True
    return category

def eval_date(dates_list, date_category):
    """
    Translates a list of event dates into the correct true/false list
    corresponding to the categories of the SALCA-BD management level III: Date.

    Parameters
    ----------
    dates_list : list
        List of the event dates to be evaluated.
    date_category : string
        To determine for which of the three groups of date categories in
        SALCA-BD the evaluation shall be carried out.
    """
    if date_category == '3groups':
        date_cats = {'a':[1,2,3,4,5],'b':[6,7,8],'c':[9,10,11,12]}
        category = [False] * 3
    elif date_category == '3groups_march':
        date_cats = {'a':[3,4,5,6,7],'b':[8,9,10],'c':[11,12,1,2]}
        category = [False] * 3
    elif date_category == '4groups_season':
        date_cats = {'a':[12,1,2],'b':[9,10,11],'c':[3,4,5],'d':[6,7,8]}
        category = [False] * 4
    elif date_category == '4groups_season_spring':
        date_cats = {'a':[3,4,5],'b':[6,7,8],'c':[9,10,11],'d':[12,1,2]}
        category = [False] * 4
    else:
        if date_category == '9groups':
            date_cats = {'a':[11,12,1,2],'b':[3],'c':[4],'d':[5],'e':[6],'f':[7],'g':[8],'h':[9],'i':[10]}
            category = [False] * 9
        else:
            if date_category == '7groups':
                date_cats = {'a':[12,1,2,3,4,5],'b':[6],'c':[7],'d':[8],'e':[9],'f':[10],'g':[11]}
                category = [False] * 7
            else:
                logging.debug("Error: Wrong date_category! Choose between 3groups, 7groups or 9groups.")
    
    dates_list_months = [dt.datetime.strptime(x, '%Y-%m-%d').month for x in dates_list]
    # check where in the date_cats the months from the event dates match
    cat = [[key for key, value in date_cats.items() if x in value] for x in dates_list_months]
    cat = [item for sublist in cat for item in sublist]
    cat = set(cat)
    
    index = [list(date_cats.keys()).index(x) for x in cat]
    for i in index:
        category[i] = True
    return category

def eval_fert_types(fert_types):
    """
    Maps and converts the fertiliser types into the correct true/false list
    corresponding to the fertiliser categories of the SALCA-BD management level III.

    Parameter
    ----------
    fert_types : set
        Set of the fertiliser types used on the crop.
    """
    # Attention: The first two numbers (=21) determine the crop in SALCA-BD.
    fert_cats = {'slurry':21020501,
                 'fresh manure':21020502,
                 'compost':21020503,
                 'biosolids':21020504,
                 'ammonium salpetre':21020505,
                 'ammonium salpetre lime':21020506,
                 'salpetre lime':21020507,
                 'ammonium sulfate':21020508,
                 'Harnstoff':21020509,
                 'nitrogen lime':21020510,
                 'triple superphosphate':21020511,
                 'superphosphate':21020512,
                 'diammonphosphate':21020513,
                 'potassium salt 60%':21020514,
                 'potassium chloride with magnesium salts 40%':21020515,
                 'specific more-nutrient fertilizer':21020516,
                 'potassium sulfate':21020517,
                 'potassium nitrate':21020518,
                 'magnesium sulfate':21020519,
                 'Thomasmeal 17%':21020520,
                 'Thomaskali':21020521,
                 'Others':21020522}
    fertlist_bd = []
    
    for item in fert_types:
        if item == 'liquid_farm_manure':
            fertlist_bd.append(21020501)
        elif item == 'solid_farm_manure':
            fertlist_bd.append(21020502)
        elif item in tab_manu["NameEN"].values:
            fertlist_bd.append(int(tab_manu.loc[tab_manu['NameEN'] == item,"SALCA-BD_mapping"].item()))
        elif item in fert_cats.values():
            fertlist_bd.append(item)
        else:
            raise ValueError(f"Could not map Fertiliser = {item}")
    fertdict = fert_cats.copy()
    # set true for the used fertiliser categories, false for unused
    for key, val in fertdict.items():
        if val in fertlist_bd:
            fertdict[key] = True
        else:
            fertdict[key] = False
    return list(fertdict.values())

def eval_fert_tech(fert_incorp):
    """
    Translates the list of fertiliser incorporation event data into the correct
    true/false list corresponding to the fertiliser technique categories of the
    SALCA-BD management level III.
    
    "Incorporation" is true if solid manure is incorporated at least once
    (indicated by a positive value for the number of hours of incorporation
    after manure application). "No incorporation" is true if no incorporation
    hours are indicated or if -1 (no incorporation) is indicated at least once.
    In SALCA-BD, incorporation and no incorporation can occur in parallel 
    on a specific crop.

    Parameter
    ----------
    fert_incorp : list of int
        List of times in hours after which fertilisers are incorporated
        following application.
    """
    category = [False, False]
    if any(n >= 0 for n in fert_incorp) and fert_incorp != []:
        category[0] = True
    if any(n < 0 for n in fert_incorp) or fert_incorp == []:
        category[1] = True
    return category

def append_date2type(dict_res, event):
    """
    Append an event.date to a result dict with the event.crop_index as keys.
    Output is a dict with all crop_id's as keys and a list of event dates as
    values. Used for for the assessment of applying PPP.
    """
    if event.crop_index not in dict_res.keys():
        dict_res[event.crop_index] = [event.date]
    else:
        dict_res[event.crop_index].append(event.date)
    return dict_res

def eval_fert_norm_orch(dict_intensity_norm):
    categories = {32050501:0.7499,
                  32050502:1,
                  32050503:float('inf')}
    vector = {}
    for key in dict_intensity_norm:
        result = min([index for index,value in categories.items() if dict_intensity_norm[key] <= value])
        vector[key] = [False] * 3
        index = [ix for ix,val in enumerate(categories.keys()) if val == result]
        vector[key][index[0]] = True
    return vector

def eval_ppp_amount_horti(dict_amount_area, ppp_type):
    categories_hrb = {301:0.25,
                      302:0.5,
                      303:0.75,
                      304:1}
    categories_fun_ins = {201:0.25,
                      202:0.5,
                      203:0.75,
                      204:1}
    categories_bact = {34160201:0.25,
                       34160202:0.5,
                       34160203:0.75,
                       34160204:1}
    categories = dict(hrb = categories_hrb, fun = categories_fun_ins, ins = categories_fun_ins, bact = categories_bact)
    result = min([index for index,value in categories[ppp_type].items() if dict_amount_area <= value])
    vector = [False] * len(categories[ppp_type])
    index = [ix for ix,val in enumerate(categories[ppp_type].keys()) if val == result]
    vector[index[0]] = True
    vector_dict = dict(zip(categories[ppp_type], vector))
    return vector_dict

def id_completion(outer_dict, base_id, crop_bdcategories):
    '''
    Add a value (base_id) to the IDs of the measures inside the crop dict
    '''    
    data = {
        outer_k: {
            inner_k + base_id[crop_bdcategories[outer_k]]: inner_v
            for inner_k, inner_v in outer_v.items()
        } 
        for outer_k, outer_v in outer_dict.items()
    }
    return data

# %% inputs ===================================================================

# load table for manure
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                         columns=js.loads(inp.tab_manu)['columns'],
                         index=js.loads(inp.tab_manu)['index']
                         )
# load table for PPP
tab_ppp = pd.DataFrame(data=js.loads(inp.tab_ppp)['data'],
                         columns=js.loads(inp.tab_ppp)['columns'],
                         index=js.loads(inp.tab_ppp)['index']
                         )
# load crop table
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )
# load table for machinery
tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                         columns=js.loads(inp.tab_mach)['columns'],
                         index=js.loads(inp.tab_mach)['index']
                         )
# load animal table
tab_ls = pd.DataFrame(data=js.loads(inp.tab_ls)['data'],
                         columns=js.loads(inp.tab_ls)['columns'],
                         index=js.loads(inp.tab_ls)['index']
                         )
# load intensity tables
df_fert = load_intensity_table('tab_intensity_fertilisation.txt')
df_grazing = load_intensity_table('tab_intensity_stocking_density.txt')
df_harvestcut = load_intensity_table('tab_intensity_cuts.txt')

# information from the farm level:
# year of the assessment:
eval_year = dt.datetime.strptime(inp.f_end_evaluation, '%Y-%m-%d').year
# list of machine combinations by ID:
maco_list = inp.get_events('treatment_maco_event')
if maco_list != []:
    mc_dict = pd.DataFrame(maco_list).set_index("f_maco_id")
    mc_dict.drop(columns=['event_context'], inplace=True)
    mc_dict = mc_dict.applymap(lambda a: a[4:])
else:
    mc_dict = pd.DataFrame(maco_list)
# salcabd farm-level variables:
ruderal_area = inp.f_ruderal_ha
len_drywalls = inp.f_len_drywalls_m
len_trails = inp.f_len_trails_m
nbr_single_trees = inp.f_singl_tree_nbr
nbr_hist_trees = inp.f_hist_tree_nbr
# altitude: needed to define the intensity levels for grassland fertilisation
# and havesting
if hasattr(inp, 'f_altitude') and inp.f_altitude is not None:
    farm_altitude = inp.f_altitude
else:
    heights = {'001 Tal':500, '002 Huegel':900, '003 Berg':1300}
    farm_altitude = heights[inp.f_region]
# information from the field level:
if ctx.farm.fields == {}:
    total_kgN_crop = []
else:
    # total kg nitrogen applied in all crops:
    total_kgN_list = []
    for string in inp.fi_total_kgN_crop:
        total_kgN_list.append(js.loads(string))
    total_kgN_crop = {key: val for d in total_kgN_list for key, val in d.items()}


# crop management information from SALCAprep_crop:
c_salcaprep = []
# dicts for all crops:
c_fertilisation_dates = {}
c_fert_types = {}
c_fert_incorp = {}
c_fert_row = {}
c_ppp = {}
c_soil = {}
c_sowi = {}
c_harv = {}
c_harv_sepr = {}
c_maint = {}
c_irri = {}
c_grazing = {}
pre_harv_sowi = {}
c_hare_inco_bool = {}
c_rodent_regulation = {}
total_farm_area = 0
crop_area_ha = {}
crop_duration_m = {}
# load c_salcaprep if there are crops on the farm:
if ctx.farm.crops != {}:
    for i in inp.c_salcaprep:
        c_salcaprep.append(js.loads(i))
for j in c_salcaprep:
    # total_farm_area = sum of the crop areas (for the assessment of ruderal_area)
    total_farm_area += (j['c_areatime']/j['c_duration_years'])
    crop_area_ha[j['crop_id']] = j['c_areatime']/j['c_duration_years']
    # crop duration:
    dt_start = dt.datetime.strptime(j['c_start'], '%Y-%m-%d')
    dt_end   = dt.datetime.strptime(j['c_end'], '%Y-%m-%d')
    crop_duration_m[j['crop_id']] = 12 * (dt_end.year - dt_start.year) +\
                                        (dt_end.month - dt_start.month)
    # fertilisation:
    subset_id = [index for index,value in enumerate(j['tr_fert']['MC']) if value != 'fertilizer_multiplication']    
    datelist = [j['tr_fert']['date'][i] for i in subset_id]
    datelist.extend(j['tr_manure_l']['date'])
    datelist.extend(j['tr_manure_s']['date'])
    c_fertilisation_dates[j['crop_id']] = datelist
    c_fert_types[j['crop_id']] = list([j['tr_fert']['salcabd_type'][i] for i in subset_id])\
                                + list(j['tr_manure_l']['variable'])\
                                + list(j['tr_manure_s']['variable'])
    c_fert_row[j['crop_id']] = [j['tr_fert']['row_interrow'][i] for i in subset_id]
    c_fert_row[j['crop_id']].extend(j['tr_manure_l']['row_interrow'])
    c_fert_row[j['crop_id']].extend(j['tr_manure_s']['row_interrow'])
    c_fert_incorp[j['crop_id']] = j['tr_manure_s']['incorporation']  # fertiliser incorporation
    c_ppp[j['crop_id']] = j['tr_ppp']  # plant protection
    c_harv[j['crop_id']] = j['tr_harv']  # harvest of main products
    c_harv_sepr[j['crop_id']] = j['tr_harv_sepr']  # harvest of secondary products
    c_soil[j['crop_id']] = j['tr_soil']  # soil treatment
    c_sowi[j['crop_id']] = j['tr_sowi']  # seeding treatment
    c_maint[j['crop_id']] = j['tr_maint']  # maintenance treatment
    c_irri[j['crop_id']] = j['tr_irri']  # irrigation events
    c_grazing[j['crop_id']] = j['tr_grazing']  # grazing events
    pre_harv_sowi[j['crop_id']] = j['c_sowi_pre_harv']  # pre-harvest sowing
    c_hare_inco_bool[j['crop_id']] = j['c_hare_inco_bool']  # incorporation of crop residues
    c_rodent_regulation[j['crop_id']] = j['c_rodent_regulation']  # rodent regulation


# %% new input BD =============================================================

# crop management information from SALCAprep_crop_bd:
c_salcaprep_bd = []
# load c_salcaprep_bd if there are crops on the farm:
if ctx.farm.crops != {}:
    for i in inp.c_salcaprep_bd:
        c_salcaprep_bd.append(js.loads(i))

c_cover = {}
c_fences = {}
c_insect_traps = {}
c_rodents = {}
c_beneficials = {}
c_structures = {}
c_molluscs = {}
c_drift_red_equip = {}
c_drift_red_tech = {}
c_wood_leaves = {}
c_auxi_prod = {}
c_greening = {}
c_weed_cover = {}
c_foliage_thinning = {}
c_fruit_thinning = {}
c_tree_shaping = {}
c_wood_cuts = {}
c_frost_equip = {}
c_vine_lifting = {}
c_vine_trimming = {}
c_bd_frost_coats = {}
c_bd_mice_fence_orch = {}
c_bd_mice_fence_root = {}
c_bd_repellents = {}
c_bd_alternance_interrow = {}
c_bd_disbudding = {}
c_bd_suckering_trunk = {}
c_bd_suckering_head = {}
c_bd_suckering_manual = {}
c_bd_suckering_chemical = {}
c_bd_suckering_mechanical = {}
c_bd_vege_grho_bool = {}

for j in c_salcaprep_bd:
    c_cover[j['crop_id']] = j['c_cover_nets_tents']
    c_fences[j['crop_id']] = j['c_fences_scaffolds']
    c_insect_traps[j['crop_id']] = j['c_ppp_insect_traps']
    c_rodents[j['crop_id']] = j['c_ppp_rodents']
    c_beneficials[j['crop_id']] = j['c_ppp_beneficials']
    c_structures[j['crop_id']] = j['c_ppp_beneficials_structures']
    c_molluscs[j['crop_id']] = j['c_ppp_molluscs']
    c_drift_red_equip[j['crop_id']] = j['c_ppp_drift_red_equip']
    c_drift_red_tech[j['crop_id']] = j['c_ppp_drift_red_tech']
    c_wood_leaves[j['crop_id']] = j['c_maint_wood_leaves']
    c_auxi_prod[j['crop_id']] = j['c_maint_auxi_prod']
    c_greening[j['crop_id']] = j['c_ppp_greening']
    c_weed_cover[j['crop_id']] = j['c_ppp_weed_cover']
    c_foliage_thinning[j['crop_id']] = j['c_foliage_thinning']
    c_fruit_thinning[j['crop_id']] = j['c_fruit_thinning']
    c_tree_shaping[j['crop_id']] = j['c_tree_shaping']
    c_wood_cuts[j['crop_id']] = j['c_wood_cuts']
    c_frost_equip[j['crop_id']] = j['c_frost_equip']
    c_vine_lifting[j['crop_id']] = j['c_vine_lifting']
    c_vine_trimming[j['crop_id']] = j['c_vine_trimming']
    c_bd_frost_coats[j['crop_id']] = j['c_bd_frost_coats']
    c_bd_mice_fence_orch[j['crop_id']] = j['c_bd_mice_fence_orch']
    c_bd_mice_fence_root[j['crop_id']] = j['c_bd_mice_fence_root']
    c_bd_repellents[j['crop_id']] = j['c_bd_repellents']
    c_bd_alternance_interrow[j['crop_id']] = j['c_bd_alternance_interrow']
    c_bd_disbudding[j['crop_id']] = j['c_bd_disbudding']
    c_bd_suckering_trunk[j['crop_id']] = j['c_bd_suckering_trunk']
    c_bd_suckering_head[j['crop_id']] = j['c_bd_suckering_head']
    c_bd_suckering_manual[j['crop_id']] = j['c_bd_suckering_manual']
    c_bd_suckering_chemical[j['crop_id']] = j['c_bd_suckering_chemical']
    c_bd_suckering_mechanical[j['crop_id']] = j['c_bd_suckering_mechanical']
    c_bd_vege_grho_bool[j['crop_id']] = j['c_bd_vege_grho_bool']


# %% ID determination =========================================================

# list of crops:
crops = ctx.farm.crops
crop_ids = ctx.farm.crops.keys()
crop_names = {x:ctx.farm.crops[x].crop_definition_name for x in ctx.farm.crops}
# get salcabd crop categories for all crops on the farm
crop_bdcategories = {}
for key in crops:
    crop_bdcategories[key] = tab_crops.loc[tab_crops['NameEN'] == crops[key][2],"SALCA_BD_cropid"].values[0]
# list of fields and crops:
df_crop_and_field = pd.DataFrame({"fields": [], "crops": []})
for field_id in ctx.farm.fields:
    for crop_id in ctx.farm.fields[field_id].crops:
        new_row = [field_id, crop_id]
        df_crop_and_field.loc[len(df_crop_and_field)] = new_row


# %% calculations of general variables for horticultural crops ================

# The SALCA-BD assessment of horticultural crops differs from the assessment of
# arable crops or grassland even in the common traits like fertilisation, plant
# protection or harvest. Therefore, the assessment in salcabd_farm.py is
# repeated here. The result from here will replace the results in salcabd_farm
# in the case of horticultural crops.

# fertilisation ===============================================================
# dict with the category values for fertilisation frequency
fertilisation_freq_r = {}
fertilisation_freq_ir = {}
# fertilisation dates
fertilisation_dt_r = {}
fertilisation_dt_ir = {}
category='3groups_march'
for key in c_fertilisation_dates:
    # assessment for orchards
    if crop_bdcategories[key] == 30:
        fert_dates_r = []
        fert_dates_ir = []
        # distribute the fert_dates between row and interrow according to c_fert_row
        for i, element in enumerate(c_fertilisation_dates[key]):
            row_def = c_fert_row[key][i]
            if row_def == 'row' or row_def == 'both' or row_def == 'none':
                fert_dates_r.append(element)
            if row_def == "interrow" or row_def == 'both':
                fert_dates_ir.append(element)
        fertilisation_freq_r[key] = eval_frequency(fert_dates_r)
        fertilisation_freq_ir[key] = eval_frequency(fert_dates_ir)
        fertilisation_dt_r[key] = eval_date(fert_dates_r, category)
        fertilisation_dt_ir[key] = eval_date(fert_dates_ir, category)
# add IDs
ids_r = [32050401,
         32050402,
         32050403,
         32050404]
d_fertilisation_freq_r = add_ids2dict(ids_r, fertilisation_freq_r)
ids_ir = [33090401,
          33090402,
          33090403,
          33090404]
d_fertilisation_freq_ir = add_ids2dict(ids_ir, fertilisation_freq_ir)
ids_r = [32050701,
         32050702,
         32050703]
d_fertilisation_dt_r = add_ids2dict(ids_r, fertilisation_dt_r)
ids_ir = [33090701,
          33090702,
          33090703]
d_fertilisation_dt_ir = add_ids2dict(ids_ir, fertilisation_dt_ir)
# Assess the fertilisation frequency variable for vineyards and add the result:
# Even though SALCA-BD provides assessment options for fertilisation every 2-5
# years, we currently only differentiate between no fertilisation and
# fertilisation (assuming fertilisation every year). Furthermore, for
# fertilisation quantity vineyard (area) we set a constant standard value of
# "e. 81-100", since we currently do not ask for the % of fertilised area.
d_fertilisation_quan = {}  # fertilisation quantity vineyard (area)
for j in c_salcaprep:
    crop = j['crop_id']
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        d_fertilisation_freq_r[crop] = {71040201: False, 71040202: False,
                                        71040203: False, 71040204: False,
                                        71040205: False, 71040206: False}
        d_fertilisation_quan[crop] = {}
        if c_fertilisation_dates[crop] == []:
            d_fertilisation_freq_r[crop][71040201] = True
            d_fertilisation_quan[crop][71040305] = False
        else:
            d_fertilisation_freq_r[crop][71040202] = True
            d_fertilisation_quan[crop][71040305] = True
        # fertilisation dates
        category='4groups_season'
        fertilisation_dt_r[crop] = eval_date(c_fertilisation_dates[crop], category)
        ids_r = [71040501,
                 71040502,
                 71040503,
                 71040504]
        d_fertilisation_dt_r[crop] = add_ids2dict(ids_r, {crop:fertilisation_dt_r[crop]})[crop]

# fertilisation quantity in orchards (in % of the Swiss fertilisation norm)
crop_names_orch = {k:crop_names[k] for k, v in crop_bdcategories.items() if v == 30}  # get crop names from all orchard crops on the farm
# get the norm values from SALCAtables_crops
df_norm_fert = tab_crops.loc[tab_crops['NameEN'].isin(crop_names_orch.values()),['NameEN','Normertrag','Norm-N']]
# extract the norm values into a dict per crop_id (over the names of the crops)
fert_norm = {key: df_norm_fert.loc[df_norm_fert['NameEN'] == crop_names_orch[key],'Norm-N'].values[0] for key in crop_names_orch}
# divide the amount of nitrogen fertilisation through the norm values
fert_intensity_norm = {key: (total_kgN_crop[str(key)]/fert_norm[key] if fert_norm[key] != 0 else 0) for key in fert_norm}
# evaluate into the true/false vector
dict_fert_norm_r = eval_fert_norm_orch(fert_intensity_norm)
# corrections for zero-option (no fertilisation)
for crop in d_fertilisation_freq_r:
    if 32050401 in d_fertilisation_freq_r[crop]:
        if d_fertilisation_freq_r[crop][32050401] == True:
            dict_fert_norm_r[crop] = [False, False, False]
id_s = [32050501,
        32050502,
        32050503]
d_fert_norm_r = add_ids2dict(id_s, dict_fert_norm_r)
# inter-row fertilisation quantity: is kept constant on option b. 75-100% 
d_fert_norm_ir = {}
for crop in d_fertilisation_freq_ir:
    if d_fertilisation_freq_ir[crop][33090401] == False:  # zero-option assurance
        d_fert_norm_ir[crop] = {33090502: True}
    else:
        d_fert_norm_ir[crop] = {33090502: False}

# fertilisation types
fertilisation_type_r = {}
fertilisation_type_ir = {}
d_fertilisation_type_r = {}
d_fertilisation_type_ir = {}
fert_type_vine = {}
for key in c_fert_types:
    # assessment for orchards
    if crop_bdcategories[key] == 30:
        fertilisation_type_r[key] = []
        fertilisation_type_ir[key] = []
        for i, element in enumerate(c_fert_types[key]):
            row_def = c_fert_row[key][i]
            if row_def == 'row' or row_def == 'both' or row_def == 'none':
                fertilisation_type_r[key].append(element)
            if row_def == "interrow" or row_def == 'both':
                fertilisation_type_ir[key].append(element)
        d_fertilisation_type_r[key] = eval_fert_types(fertilisation_type_r[key])
        d_fertilisation_type_ir[key] = eval_fert_types(fertilisation_type_ir[key])
    # assessment for vineyards
    if crop_bdcategories[key] == 70:
        fert_type_vine[key] = {71040101: False, 71040102: False, 71040103: False, 71040104: False}
        if d_fertilisation_freq_r[key][71040201] == False:  # zero-option must be false
            for item in c_fert_types[key]:
                if item == 'liquid_farm_manure':
                    fert_type_vine[key][71040103] = True
                elif item == 'solid_farm_manure':
                    fert_type_vine[key][71040103] = True
                elif item in tab_manu["NameEN"].values:
                    fert_type_vine[key][71040103] = True
                else:
                    fert_type_vine[key][71040104] = True
            # All organic manure is of mixed animal and vegetal origin, since
            # there is straw in it. Of the current organic fertilisers, compost
            # might be the only potential exception, but even compost can't be
            # assured to be of pure vegetal origin. Therefore we only
            # differentiate between organic and mineral fertiliser.
# fertilisation type IDs
id_s = list(range(301,323))
ids_r = [x+32050000 for x in id_s]
ids_ir = [x+33090000 for x in id_s]
d_fertilisation_type_r = add_ids2dict(ids_r, d_fertilisation_type_r)
d_fertilisation_type_ir = add_ids2dict(ids_ir, d_fertilisation_type_ir)

# fertilisation technique/incorporation
fert_tech_r = {}
fert_tech_ir = {}
d_fert_tech_r = {}
d_fert_tech_ir = {}
for key in c_fert_incorp:
    # assessment for orchards
    if crop_bdcategories[key] == 30:
        fert_tech_r[key] = []
        fert_tech_ir[key] = []
        for i, element in enumerate(c_fert_incorp[key]):
            row_def = c_fert_row[key][i]
            if row_def == 'row' or row_def == 'both' or row_def == 'none':
                fert_tech_r[key].append(element)
            if row_def == "interrow" or row_def == 'both':
                fert_tech_ir[key].append(element)
        d_fert_tech_r[key] = eval_fert_tech(fert_tech_r[key])
        d_fert_tech_ir[key] = eval_fert_tech(fert_tech_ir[key])
        ids_r = [32050601, 32050602]
        ids_ir = [33090601, 33090602]
        d_fert_tech_r[key] = add_ids2dict(ids_r, {key:d_fert_tech_r[key]})[key]
        d_fert_tech_ir[key] = add_ids2dict(ids_ir, {key:d_fert_tech_ir[key]})[key]
    # assessment for vineyards
    if crop_bdcategories[key] == 70:
        d_fert_tech_r[key] = eval_fert_tech(c_fert_incorp[key])
        ids_r = [71040401, 71040402]
        d_fert_tech_r[key] = add_ids2dict(ids_r, {key:d_fert_tech_r[key]})[key]
        
# zero-option assurance:
# corrections for zero-option (no fertilisation)
for crop in d_fertilisation_freq_r:
    if 32050401 in d_fertilisation_freq_r[crop]:
        if d_fertilisation_freq_r[crop][32050401] == True:
            d_fert_tech_r[crop] = {32050601: False, 32050602: False}
for crop in d_fertilisation_freq_ir:
    if 33090401 in d_fertilisation_freq_ir[crop]:
        if d_fertilisation_freq_ir[crop][33090401] == True:
            d_fert_tech_ir[crop] = {33090601: False, 33090602: False}
    if 71040201 in d_fertilisation_freq_ir[crop]:
        if d_fertilisation_freq_ir[crop][71040201] == True:
            d_fert_tech_r[crop] = {71040401: False, 71040402: False}


# %% calculations: harvest ====================================================

harv_dt = {}
harv_type = {}
for crop in c_harv:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        # harvest date
        category='3groups_march'
        id_s = [34130201,34130202,34130203]
        harv_dt[crop] = eval_date(c_harv[crop]['date'], category)
        harv_dt[crop] = add_ids2dict(id_s, {crop:harv_dt[crop]})[crop]
        # harvest type
        harv_type[crop] = {34130101:False, 34130102:False, 34130103: False}
        if '002_mechanically' in c_harv[crop]['harv_type']:
            harv_type[crop][34130102] = True
        elif '003_harvestnets' in c_harv[crop]['harv_type']:
            harv_type[crop][34130103] = True
        elif '001_manually' in c_harv[crop]['harv_type']:
            harv_type[crop][34130101] = True
        # if none of those conditions are true, no harvest ist considered and
        # all options are false.
    
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        # harvest date: not relevant
        # harvest type
        harv_type[crop] = {74010101:False, 74010102:False, 74010103: False}
        if '001_manually' in c_harv[crop]['harv_type']:
            harv_type[crop][74010101] = True
        if '002_mechanically' in c_harv[crop]['harv_type']:
            harv_type[crop][74010102] = True
        # option 3 is the zero-option (no harvest) and is true if nothing else
        # is true:
        if harv_type[crop] == {74010101:False, 74010102:False, 74010103: False}:
            harv_type[crop][74010103] = True


# %% calculations: plant protection: greening: grazing ========================

grazing_r = {}
grazing_ir = {}
for crop in c_grazing:
    if c_grazing[crop]['date'] != []:  # a grazing event exists
        intersect_grazing_r =list(set(['row','both']) & set(c_greening[crop]["row_interrow"]))
        intersect_grazing_ir =list(set(['interrow','both','none']) & set(c_greening[crop]["row_interrow"]))
        # assessment for orchards
        if crop_bdcategories[crop] == 30:
            if intersect_grazing_r != []:  # row is grazed
                grazing_r[crop] = {32060201: True, 32060202: False}
            else:
                grazing_r[crop] = {32060201: False, 32060202: True}
            if intersect_grazing_ir != []:  # interrow is grazed
                grazing_ir[crop] = {33100201: True, 33100202: False}
            else:
                grazing_ir[crop] = {33100201: False, 33100202: True}
        # assessment for vineyards
        if crop_bdcategories[crop] == 70:
            if intersect_grazing_r != []:  # row is grazed
                grazing_r[crop] = {72030201: True, 72030202: False}
            else:
                grazing_r[crop] = {72030201: False, 72030202: True}
            if intersect_grazing_ir != []:  # interrow is grazed
                grazing_ir[crop] = {73030201: True, 73030202: False}
            else:
                grazing_ir[crop] = {73030201: False, 73030202: True}
    else:
        # assessment for orchards
        if crop_bdcategories[crop] == 30:
            grazing_r[crop] = {32060201: False, 32060202: True}
            grazing_ir[crop] = {33100201: False, 33100202: True}
        # assessment for vineyards
        if crop_bdcategories[crop] == 70:
            grazing_r[crop] = {72030201: False, 72030202: True}
            grazing_ir[crop] = {73030201: False, 73030202: True}


# %% calculations: plant protection: greening: number of cuts and mowing
#    technique ================================================================

green_cuts = {}
green_cuts_tech_map = {21100601:2,  # bar mower
                       21100602:3,  # rotary mower
                       21100603:4,  # rotary mower with conditioner
                       21140202:4,  # mulching
                       32060506:6,  # roller
                       32060507:7,  # tine harrow
                       21110102:7,  # no-till soil cultivation < 10cm
                       21110103:7,  # no-till soil cultivation > 10cm
                       21110104:7   # soil cultivation with tillage
}
green_cuts_tech_r = {}
green_cuts_tech_ir = {}
orch_green_cuts_tech_r = {}
orch_green_cuts_tech_ir = {}
vine_green_cuts_tech_r = {}
vine_green_cuts_tech_ir = {}
green_cuts_number_r = {}
green_cuts_number_ir = {}
# get the information about cuts, mulching and soil treatments
for crop in c_harv_sepr:
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] in [30, 70]:
        green_cuts[crop] = {'MC':[], 'date':[], 'row_interrow':[]}
        green_cuts[crop]['MC'].extend(c_harv_sepr[crop]['MC'])
        green_cuts[crop]['date'].extend(c_harv_sepr[crop]['date'])
        green_cuts[crop]['row_interrow'].extend(['interrow']*len(c_harv_sepr[crop]['date']))
        # since c_harv_sepr has no row_interrow assessment, it is considered to
        # always apply for inter-row and never for row as a standard.
for crop in c_maint:
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] in [30, 70]:
        # create the empty dict per crop if not already done
        if crop not in green_cuts:
            green_cuts[crop] = {'MC':[], 'date':[], 'row_interrow':[]}
        green_cuts[crop]['MC'].extend(c_maint[crop]['MC'])
        green_cuts[crop]['date'].extend(c_maint[crop]['date'])
        green_cuts[crop]['row_interrow'].extend(c_maint[crop]['row_interrow'])
for crop in c_soil:
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] in [30, 70]:
        # create the empty dict per crop if not already done
        if crop not in green_cuts:
            green_cuts[crop] = {'MC':[], 'date':[], 'row_interrow':[]}
        green_cuts[crop]['MC'].extend(c_soil[crop]['MC'])
        green_cuts[crop]['date'].extend(c_soil[crop]['date'])
        green_cuts[crop]['row_interrow'].extend(c_soil[crop]['row_interrow'])
# gather bd_category for the machinery involved in order to define the applied
# measures
for crop in green_cuts:
    green_cuts[crop]['bd_category'] = []
    for maco_id in green_cuts[crop]['MC']:
        if maco_id in mc_dict.index:
            machinery = mc_dict.loc[maco_id,].tolist()
            bd_cats = tab_mach[tab_mach["PythonName"].isin(machinery)]["SALCA-BD_mapping"].tolist()
            bd_cat  = [x for x in bd_cats if str(x) != 'nan']
            green_cuts[crop]['bd_category'].append(bd_cat)
    # iterate over each date and define the applied mowing techniques for row
    # and interrow by mapping the bd_category from SALCAtables_machinery to the
    # measure_baseids of the mowing techniques assessment
    # also: count the number of cuts/disturbances for row and interrow
    green_cuts_tech_r[crop] = []
    green_cuts_tech_ir[crop] = []
    green_cuts_number_r[crop] = 0
    green_cuts_number_ir[crop] = 0
    for i, date in enumerate(green_cuts[crop]['date']):
        if green_cuts[crop]['row_interrow'][i] in ['row','both']:
            green_cuts_tech_r[crop].extend([green_cuts_tech_map[x] for x in green_cuts[crop]['bd_category'][i]])
            green_cuts_number_r[crop] += 1
        else:
            green_cuts_tech_ir[crop].extend([green_cuts_tech_map[x] for x in green_cuts[crop]['bd_category'][i]])
            green_cuts_number_ir[crop] += 1
    green_cuts_tech_r[crop] = list(set(green_cuts_tech_r[crop]))
    green_cuts_tech_ir[crop] = list(set(green_cuts_tech_ir[crop]))
    # convert the results into the measures dict
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        # row:
        if green_cuts_number_r[crop] >=7:
            green_cuts_number_r[crop] = {32060101:False, 32060102:False, 32060103:False, 32060104:True}
        elif green_cuts_number_r[crop] >=4:
            green_cuts_number_r[crop] = {32060101:False, 32060102:False, 32060103:True, 32060104:False}
        elif green_cuts_number_r[crop] >=1:
            green_cuts_number_r[crop] = {32060101:False, 32060102:True, 32060103:False, 32060104:False}
        else:
            green_cuts_number_r[crop] = {32060101:True, 32060102:False, 32060103:False, 32060104:False}
        # interrow:
        if green_cuts_number_ir[crop] >=7:
            green_cuts_number_ir[crop] = {33100101:False, 33100102:False, 33100103:False, 33100104:True}
        elif green_cuts_number_ir[crop] >=4:
            green_cuts_number_ir[crop] = {33100101:False, 33100102:False, 33100103:True, 33100104:False}
        elif green_cuts_number_ir[crop] >=1:
            green_cuts_number_ir[crop] = {33100101:False, 33100102:True, 33100103:False, 33100104:False}
        else:
            green_cuts_number_ir[crop] = {33100101:True, 33100102:False, 33100103:False, 33100104:False}
        # mowing technique in rows:
        if green_cuts_tech_r[crop] == []:
            orch_green_cuts_tech_r[crop] = {32060501:True, 32060502:False, 32060503:False, 32060504:False, 32060505:False, 32060506:False, 32060507:False}
        else:
            orch_green_cuts_tech_r[crop] = {32060501:False, 32060502:False, 32060503:False, 32060504:False, 32060505:False, 32060506:False, 32060507:False}
            ids = [sum(x) for x in zip(green_cuts_tech_r[crop], [32060500]*len(green_cuts_tech_r[crop]))]
            for value in ids:
                orch_green_cuts_tech_r[crop][value] = True
            # zero-option when there are no true values in the dict
            if any(orch_green_cuts_tech_r[crop].values()) == False:
                orch_green_cuts_tech_r[crop][32060501] = True
        # mowing technique in interrows:
        if green_cuts_tech_ir[crop] == []:
            orch_green_cuts_tech_ir[crop] = {33100601:True, 33100602:False, 33100603:False, 33100604:False, 33100605:False, 33100606:False, 33100607:False}
        else:
            orch_green_cuts_tech_ir[crop] = {33100601:False, 33100602:False, 33100603:False, 33100604:False, 33100605:False, 33100606:False, 33100607:False}
            ids = [sum(x) for x in zip(green_cuts_tech_ir[crop], [33100600]*len(green_cuts_tech_ir[crop]))]
            for value in ids:
                orch_green_cuts_tech_ir[crop][value] = True
            # zero-option when there are no true values in the dict
            if any(orch_green_cuts_tech_ir[crop].values()) == False:
                orch_green_cuts_tech_ir[crop][33100601] = True
            
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        # row:
        if green_cuts_number_r[crop] >=5:
            green_cuts_number_r[crop] = {72030101:False, 72030102:False, 72030103:True}
        elif green_cuts_number_r[crop] >=3:
            green_cuts_number_r[crop] = {72030101:False, 72030102:True, 72030103:False}
        elif green_cuts_number_r[crop] >=1:
            green_cuts_number_r[crop] = {72030101:True, 72030102:False, 72030103:False}
        else:
            green_cuts_number_r[crop] = {72030101:False, 72030102:False, 72030103:False}
        # interrow:
        if green_cuts_number_ir[crop] >=5:
            green_cuts_number_ir[crop] = {73030101:False, 73030102:False, 73030103:True}
        elif green_cuts_number_ir[crop] >=3:
            green_cuts_number_ir[crop] = {73030101:False, 73030102:True, 73030103:False}
        elif green_cuts_number_ir[crop] >=1:
            green_cuts_number_ir[crop] = {73030101:True, 73030102:False, 73030103:False}
        else:
            green_cuts_number_ir[crop] = {73030101:False, 73030102:False, 73030103:False}
        # mowing tech in rows:
        if green_cuts_tech_r[crop] == []:
            vine_green_cuts_tech_r[crop] = {72030501:True, 72030502:False, 72030503:False, 72030504:False, 72030505:False, 72030506:False, 72030507:False}
        else:
            vine_green_cuts_tech_r[crop] = {72030501:False, 72030502:False, 72030503:False, 72030504:False, 72030505:False, 72030506:False, 72030507:False}
            ids = [sum(x) for x in zip(green_cuts_tech_r[crop], [72030500]*len(green_cuts_tech_r[crop]))]
            for value in ids:
                vine_green_cuts_tech_r[crop][value] = True
            # zero-option when there are no true values in the dict
            if any(vine_green_cuts_tech_r[crop].values()) == False:
                vine_green_cuts_tech_r[crop][72030501] = True
        # mowing technique in interrows:
        if green_cuts_tech_ir[crop] == []:
            vine_green_cuts_tech_ir[crop] = {73030601:True, 73030602:False, 73030603:False, 73030604:False, 73030605:False, 73030606:False, 73030607:False}
        else:
            vine_green_cuts_tech_ir[crop] = {73030601:False, 73030602:False, 73030603:False, 73030604:False, 73030605:False, 73030606:False, 73030607:False}
            ids = [sum(x) for x in zip(green_cuts_tech_ir[crop], [73030600]*len(green_cuts_tech_ir[crop]))]
            for value in ids:
                vine_green_cuts_tech_ir[crop][value] = True
            # zero-option when there are no true values in the dict
            if any(vine_green_cuts_tech_ir[crop].values()) == False:
                vine_green_cuts_tech_ir[crop][73030601] = True

# %% calculations: plant protection: soil management ==========================

weed_ctrl_freq_r = {}
weed_ctrl_freq_ir = {}
weed_ctrl_dateeval_r = {}
weed_ctrl_dateeval_ir = {}
weed_mechanic_r = {}
weed_mechanic_ir = {}
weed_thermic_r = {}
weed_thermic_ir = {}
weed_manual_r = {}
weed_manual_ir = {}
weed_electric_r = {}
weed_electric_ir = {}
weed_ctrl_dates_r = {}
weed_ctrl_dates_ir = {}

# orchards: assess the maintenance treatment events that are used for weed
# control
for crop in c_maint:
    if crop_bdcategories[crop] == 30:
        weed_mechanic_r[crop]  = {32070501 : False, 32070502 : False, 32070503 : False, 32070504 : False, 32070505 : False, 32070506 : False}
        weed_mechanic_ir[crop] = {33110501 : False, 33110502 : False, 33110503 : False, 33110504 : False, 33110505 : False, 33110506 : False}
        weed_thermic_r[crop]  = {32070601 : False, 32070602 : False}
        weed_thermic_ir[crop] = {33110601 : False, 33110602 : False}
        weed_manual_r[crop]  = {32070401 : False, 32070402 : False}
        weed_manual_ir[crop] = {33110401 : False, 33110402 : False}
        weed_ctrl_dates_r[crop] = []
        weed_ctrl_dates_ir[crop] = []
        
        for i, value in enumerate(c_maint[crop]['variable']):
            if c_maint[crop]['row_interrow'][i] in ['row','both']:  # row
                if value == '004_mulching':  # f. mulcher (cut or flail)
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_r[crop][32070506] = True
                if value == '001_hoeing' or value == '002_weeding':  # b. no-till < 10 cm
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_r[crop][32070502] = True
                if value == '010_sandwich_system':  # e. sandwich system
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_r[crop][32070505] = True
                    
                if value == '009_manual_weeding':  # Type_WeedCtrl: manual
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_manual_r[crop][32070401] = True
                if value == '005_burning_weed':  # Type_WeedCtrl: thermic
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_thermic_r[crop][32070601] = True
                    
            if c_maint[crop]['row_interrow'][i] in ['interrow','both','none']:  # interrow
                if value == '004_mulching':  # f. mulcher (cut or flail)
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_ir[crop][33110506] = True
                if value == '001_hoeing' or value == '002_weeding':  # b. no-till < 10 cm
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_ir[crop][33110502] = True
                if value == '010_sandwich_system':  # e. sandwich system
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_ir[crop][33110505] = True
                
                if value == '009_manual_weeding':  # Type_WeedCtrl: manual
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_manual_ir[crop][33110401] = True
                if value == '005_burning_weed':  # Type_WeedCtrl: thermic
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_thermic_ir[crop][33110601] = True
                    
# orchards: assess the soil treatment events as a means for weed control
for crop in c_soil:
    if crop_bdcategories[crop] == 30:
        if crop not in weed_mechanic_r and crop not in weed_mechanic_ir:
            # if there was no c_maint for a crop, the following dicts and lists
            # are not yet defined
            weed_mechanic_r[crop]  = {32070501 : False, 32070502 : False, 32070503 : False, 32070504 : False, 32070505 : False, 32070506 : False}
            weed_mechanic_ir[crop] = {33110501 : False, 33110502 : False, 33110503 : False, 33110504 : False, 33110505 : False, 33110506 : False}
        if crop not in weed_ctrl_dates_r and crop not in weed_ctrl_dates_ir:
            weed_ctrl_dates_r[crop] = []
            weed_ctrl_dates_ir[crop] = []
            
        for i, value in enumerate(c_soil[crop]['row_interrow']):
            # gather bd_category for the machinery involved in order to define
            # the soil treatment
            bd_cat = []  # reset bd_cat
            maco_id = c_soil[crop]['MC'][i]
            if maco_id in mc_dict.index:
                machinery = mc_dict.loc[maco_id,].tolist()
                bd_cats = tab_mach[tab_mach["PythonName"].isin(machinery)]["SALCA-BD_mapping"].tolist()
                bd_cat  = [x for x in bd_cats if str(x) != 'nan']
            
            if value in ['row','both']:  # row
                weed_ctrl_dates_r[crop].append(c_soil[crop]['date'][i])
                if bd_cat != []:
                    if 21110102 in bd_cat:  # b. no-till < 10 cm
                        weed_mechanic_r[crop][32070502] = True
                    if 21110103 in bd_cat:  # c. no-till > 10 cm
                        weed_mechanic_r[crop][32070503] = True
                    if 21110104 in bd_cat:  # d. ploughing
                        weed_mechanic_r[crop][32070504] = True
                else:
                    # soil treatments without known application tech are
                    # considered as shallow
                    weed_mechanic_r[crop][32070502] = True  # no-till < 10 cm
            if value in ['interrow','both','none']:  # interrow
                weed_ctrl_dates_ir[crop].append(c_soil[crop]['date'][i])
                if bd_cat != []:
                    if 21110102 in bd_cat:  # b. no-till < 10 cm
                        weed_mechanic_ir[crop][33110502] = True
                    if 21110103 in bd_cat:  # c. no-till > 10 cm
                        weed_mechanic_ir[crop][33110503] = True
                    if 21110104 in bd_cat:  # d. ploughing
                        weed_mechanic_ir[crop][33110504] = True
                else:
                    # soil treatments without known application tech are
                    # considered as shallow
                    weed_mechanic_ir[crop][33110502] = True  # b. no-till < 10 cm

# orchards: evaluate frequency and dates for weed control (mechanic, manual,
# and thermic)
for crop in weed_ctrl_dates_r:
    if crop_bdcategories[crop] == 30:
        # frequency evaluation
        values = eval_frequency(weed_ctrl_dates_r[crop])
        ids = [32070101, 32070102, 32070103, 32070104]
        weed_ctrl_freq_r[crop] = dict(zip(ids, values))
        # date evaluation
        values = eval_date(weed_ctrl_dates_r[crop], '3groups_march')
        ids = [32070201, 32070202, 32070203]
        weed_ctrl_dateeval_r[crop] = dict(zip(ids, values))
for crop in weed_ctrl_dates_ir:
    if crop_bdcategories[crop] == 30:
        # frequency evaluation
        values = eval_frequency(weed_ctrl_dates_ir[crop])
        ids = [33110101, 33110102, 33110103, 33110104]
        weed_ctrl_freq_ir[crop] = dict(zip(ids, values))
        # date evaluation
        values = eval_date(weed_ctrl_dates_ir[crop], '3groups_march')
        ids = [33110201, 33110202, 33110203]
        weed_ctrl_dateeval_ir[crop] = dict(zip(ids, values))

# orchards and vineyards: ensure zero-options for manual, thermic and mechanic
# weed control: see further below, after vineyards

# vineyards: assess the maintenance treatment events that are used for weed
# control
for crop in c_maint:
    if crop_bdcategories[crop] == 70:
        weed_manual_r[crop]  = {72040301 : False, 72040302 : False}
        weed_manual_ir[crop] = {73040301 : False, 73040302 : False}
        weed_thermic_r[crop]  = {72040501 : False, 72040502 : False}
        weed_thermic_ir[crop] = {73040501 : False, 73040502 : False}
        weed_electric_r[crop]  = {72040601 : False, 72040602 : False}
        weed_electric_ir[crop] = {73040601 : False, 73040602 : False}
        weed_mechanic_r[crop]  = {72040401 : False, 72040402 : False, 72040403 : False, 72040404 : False}
        weed_mechanic_ir[crop] = {73040401 : False, 73040402 : False, 73040403 : False, 73040404 : False}
        weed_ctrl_dates_r[crop] = []
        weed_ctrl_dates_ir[crop] = []

        for i, value in enumerate(c_maint[crop]['variable']):
            if c_maint[crop]['row_interrow'][i] in ['row','both']:  # row
                if value == '009_manual_weeding':  # Type_WeedCtrl: manual
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_manual_r[crop][72040301] = True
                if value == '005_burning_weed':  # Type_WeedCtrl: thermic
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_thermic_r[crop][72040501] = True
                if value == '011_electric_weedcontrol':  # Type_WeedCtrl: electric
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_electric_r[crop][72040601] = True
                    
                if value == '001_hoeing' or value == '002_weeding':  # b. no-till < 10 cm
                    weed_ctrl_dates_r[crop].append(c_maint[crop]['date'][i])
                    weed_electric_r[crop][72040402] = True
                    
            if c_maint[crop]['row_interrow'][i] in ['interrow','both','none']:  # interrow
                if value == '009_manual_weeding':  # Type_WeedCtrl: manual
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_manual_ir[crop][73040301] = True
                if value == '005_burning_weed':  # Type_WeedCtrl: thermic
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_thermic_ir[crop][73040501] = True
                if value == '011_electric_weedcontrol':  # Type_WeedCtrl: electric
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_electric_ir[crop][73040601] = True
                
                if value == '001_hoeing' or value == '002_weeding':  # b. no-till < 10 cm
                    weed_ctrl_dates_ir[crop].append(c_maint[crop]['date'][i])
                    weed_mechanic_ir[crop][73040402] = True
                    
# vineyards: assess the soil treatment events as a means for weed control
for crop in c_soil:
    if crop_bdcategories[crop] == 70:
        if crop not in weed_mechanic_r and crop not in weed_mechanic_ir:
            # if there was no c_maint for a crop, the following dicts and lists
            # are not yet defined
            weed_mechanic_r[crop]  = {72040401 : False, 72040402 : False, 72040403 : False, 72040404 : False}
            weed_mechanic_ir[crop] = {73040401 : False, 73040402 : False, 73040403 : False, 73040404 : False}
        
        if crop not in weed_ctrl_dates_r and crop not in weed_ctrl_dates_ir:
            weed_ctrl_dates_r[crop] = []
            weed_ctrl_dates_ir[crop] = []
            
        for i, value in enumerate(c_soil[crop]['row_interrow']):
            # gather bd_category for the machinery involved in order to define
            # the soil treatment
            bd_cat = []  # reset bd_cat
            maco_id = c_soil[crop]['MC'][i]
            if maco_id in mc_dict.index:
                machinery = mc_dict.loc[maco_id,].tolist()
                bd_cats = tab_mach[tab_mach["PythonName"].isin(machinery)]["SALCA-BD_mapping"].tolist()
                bd_cat  = [x for x in bd_cats if str(x) != 'nan']
            
            if value in ['row','both']:  # row
                weed_ctrl_dates_r[crop].append(c_soil[crop]['date'][i])
                if bd_cat != []:
                    if 21110102 in bd_cat:  # b. no-till < 10 cm
                        weed_mechanic_r[crop][72040402] = True
                    if 21110103 in bd_cat:  # c. no-till > 10 cm
                        weed_mechanic_r[crop][72040403] = True
                    if 21110104 in bd_cat:  # d. ploughing
                        weed_mechanic_r[crop][72040404] = True
                else:
                    # soil treatments without known application tech are
                    # considered as shallow
                    weed_mechanic_r[crop][72040402] = True  # b. no-till < 10 cm
            if value in ['interrow','both','none']:  # interrow
                weed_ctrl_dates_ir[crop].append(c_soil[crop]['date'][i])
                if bd_cat != []:
                    if 21110102 in bd_cat:  # b. no-till < 10 cm
                        weed_mechanic_ir[crop][73040402] = True
                    if 21110103 in bd_cat:  # c. no-till > 10 cm
                        weed_mechanic_ir[crop][73040403] = True
                    if 21110104 in bd_cat:  # d. ploughing
                        weed_mechanic_ir[crop][73040404] = True
                else:
                    # soil treatments without known application tech are
                    # considered as shallow
                    weed_mechanic_ir[crop][73040402] = True  # b. no-till < 10 cm

# vineyards: evaluate frequency and dates for weed control (mechanic, manual,
# and thermic)
for crop in weed_ctrl_dates_r:
    if crop_bdcategories[crop] == 70:
        # frequency evaluation
        values = eval_frequency(weed_ctrl_dates_r[crop], crop_cat = 70)
        ids = [72040101, 72040102, 72040103, 72040104]
        weed_ctrl_freq_r[crop] = dict(zip(ids, values))
        # date evaluation
        values = eval_date(weed_ctrl_dates_r[crop], '4groups_season_spring')
        ids = [72040201, 72040202, 72040203, 72040204]
        weed_ctrl_dateeval_r[crop] = dict(zip(ids, values))
for crop in weed_ctrl_dates_ir:
    if crop_bdcategories[crop] == 70:
        # frequency evaluation
        values = eval_frequency(weed_ctrl_dates_ir[crop], crop_cat = 70)
        ids = [73040101, 73040102, 73040103, 73040104]
        weed_ctrl_freq_ir[crop] = dict(zip(ids, values))
        # date evaluation
        values = eval_date(weed_ctrl_dates_ir[crop], '4groups_season_spring')
        ids = [73040201, 73040202, 73040203, 73040204]
        weed_ctrl_dateeval_ir[crop] = dict(zip(ids, values))

# orchards and vineyards: ensure zero-options for manual, thermic, electric and
# mechanic weed control
for crop in weed_mechanic_r.keys():
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        if True not in weed_mechanic_r[crop].values():
            weed_mechanic_r[crop][32070501] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        if True not in weed_mechanic_r[crop].values():
            weed_mechanic_r[crop][72040401] = True
for crop in weed_mechanic_ir:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        if True not in weed_mechanic_ir[crop].values():
            weed_mechanic_ir[crop][33110501] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if True not in weed_mechanic_ir[crop].values():
            weed_mechanic_ir[crop][73040401] = True
    
for crop in weed_manual_r:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        if weed_manual_r[crop][32070401] == False:
            weed_manual_r[crop][32070402] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_manual_r[crop][72040301] == False:
            weed_manual_r[crop][72040302] = True
for crop in weed_manual_ir:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        if weed_manual_ir[crop][33110401] == False:
            weed_manual_ir[crop][33110402] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_manual_ir[crop][73040301] == False:
            weed_manual_ir[crop][73040302] = True

for crop in weed_thermic_r:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        if weed_thermic_r[crop][32070601] == False:
            weed_thermic_r[crop][32070602] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_thermic_r[crop][72040501] == False:
            weed_thermic_r[crop][72040502] = True
for crop in weed_thermic_ir:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        if weed_thermic_ir[crop][33110601] == False:
            weed_thermic_ir[crop][33110602] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_thermic_ir[crop][73040501] == False:
            weed_thermic_ir[crop][73040502] = True

for crop in weed_electric_r:
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_electric_r[crop][72040601] == False:
            weed_electric_r[crop][72040602] = True
for crop in weed_electric_ir:
    # assessment for vineyards
    if crop_bdcategories[crop] == 70: 
        if weed_electric_ir[crop][73040601] == False:
            weed_electric_ir[crop][73040602] = True

# %% plant protection: chemical weed control ==================================
# for herbicides, interrow application is defined as the standard case if not
# specified (# row-interrow)
# PPP = plant protection product
ppp_event = []
for crop in c_ppp:
    if crop_bdcategories[crop] in [30, 70]:
        for i, element in enumerate(c_ppp[crop]["date"]):
            # add the PPP treatment events and their data as objects to an
            # event list:
            ppp_event.append(PppEvent_horti(c_ppp[crop]["date"][i],
                                      c_ppp[crop]["variable"][i],
                                      c_ppp[crop]["amount_kg"][i],
                                      c_ppp[crop]["area_treated_perc"][i],
                                      c_ppp[crop]["row_interrow"][i],
                                      c_ppp[crop]["type_fungicide"][i],
                                      c_ppp[crop]["type_insecticide"][i],
                                      c_ppp[crop]["type_bactericide"][i],
                                      crop))
# execute Class functions to determine additional info
[x.get_type() for x in ppp_event]
[x.eval_mollusc() for x in ppp_event]

hrb_date_result_r = {}
hrb_date_result_ir = {}
amount_area_r = {}
amount_area_ir = {}
freq_single_r = {crop : [] for crop in c_ppp if crop_bdcategories[crop] in [30, 70]}
freq_single_ir = {crop : [] for crop in c_ppp if crop_bdcategories[crop] in [30, 70]}
# preparation: get a PPP dict in the correct form:
for event in ppp_event:
    if event.row_interrow in ['row', 'both']:
        # amount row:
        if event.crop_index not in amount_area_r.keys():
            amount_area_r[event.crop_index] = [event.area_treated_perc]
        else:
            amount_area_r[event.crop_index].append(event.area_treated_perc)
    else:
        # amount interrow:
        if event.crop_index not in amount_area_ir.keys():
            amount_area_ir[event.crop_index] = [event.area_treated_perc]
        else:
            amount_area_ir[event.crop_index].append(event.area_treated_perc)
    if event.area_treated_perc < 0.01:
        for tp in event.type:
            if tp in ['Hrb']:
                # spot treatment / single-plant application for herbicides:
                if event.row_interrow in ['row', 'both']:
                    freq_single_r[event.crop_index].append(tp)
                else:
                    freq_single_ir[event.crop_index].append(tp)
    # dates:
    if "Hrb" in set(event.type):
        if event.row_interrow in ['row', 'both']:
            hrb_date_result_r = append_date2type(hrb_date_result_r, event)
        else:
            hrb_date_result_ir = append_date2type(hrb_date_result_ir, event)

# frequency
herb_freq_r = {}
herb_freq_ir = {}
for crop in c_ppp:
    if crop_bdcategories[crop] in [30, 70]:
        # herbicides in rows:
        if crop in hrb_date_result_r.keys():
            values = eval_frequency(hrb_date_result_r[crop])
        else:
            values = [True, False, False, False]
        ids = [101, 102, 103, 104]
        herb_freq_r[crop] = dict(zip(ids, values))
        # herbicides in interrows:
        if crop in hrb_date_result_ir.keys():
            values = eval_frequency(hrb_date_result_ir[crop])
        else:
            values = [True, False, False, False]
        ids = [101, 102, 103, 104]
        herb_freq_ir[crop] = dict(zip(ids, values))
# dates and quantity (area)
herb_dates_r = {}
herb_dates_ir = {}
amount_hrb_eval_r = {}
amount_hrb_eval_ir = {}
for crop in hrb_date_result_r:
    # evaluate dates of herbicide application for rows
    if crop_bdcategories[crop] == 30:
        values = eval_date(hrb_date_result_r[crop], '3groups_march')
        ids = [501, 502, 503]
        herb_dates_r[crop] = dict(zip(ids, values))
    if crop_bdcategories[crop] == 70:
        values = eval_date(hrb_date_result_r[crop], '4groups_season_spring')
        ids = [501, 502, 503, 504]
        herb_dates_r[crop] = dict(zip(ids, values))
    # evaluate area of herbicide application for rows
    if crop in amount_area_r.keys():
        amount_hrb_eval_r[crop] = eval_ppp_amount_horti(np.mean(amount_area_r[crop]), 'hrb')
for crop in hrb_date_result_ir:
    # evaluate dates of herbicide application for interrows
    if crop_bdcategories[crop] == 30:
        values = eval_date(hrb_date_result_ir[crop], '3groups_march')
        ids = [501, 502, 503]
        herb_dates_ir[crop] = dict(zip(ids, values))
    if crop_bdcategories[crop] == 70:
        values = eval_date(hrb_date_result_ir[crop], '4groups_season_spring')
        ids = [501, 502, 503, 504]
        herb_dates_ir[crop] = dict(zip(ids, values))
    # evaluate area of herbicide application for interrows
    if crop in amount_area_ir.keys():
        amount_hrb_eval_ir[crop] = eval_ppp_amount_horti(np.mean(amount_area_ir[crop]), 'hrb')
# spot treatment / single-plant application
dict_freq_single_r = {}
dict_freq_single_ir = {}
for key in freq_single_r:
    if 'Hrb' in freq_single_r[key]:
        dict_freq_single_r[key] = {201: True, 202: False}
    elif key in hrb_date_result_r.keys():
        dict_freq_single_r[key] = {201: False, 202: True}
    else:
        # "No" for spot treatment / single-plant application is a zero-option as well
        dict_freq_single_r[key] = {201: False, 202: True}
for key in freq_single_ir:
    if 'Hrb' in freq_single_ir[key]:
        dict_freq_single_ir[key] = {201: True, 202: False}
    elif key in hrb_date_result_ir.keys():
        dict_freq_single_ir[key] = {201: False, 202: True}
    else:
        # "No" for spot treatment / single-plant application is a zero-option as well
        dict_freq_single_ir[key] = {201: False, 202: True}

# herbicide type
hrb_type_r = {crop : {401 : False, 402 : False} for crop in c_ppp if crop_bdcategories[crop] in [30, 70]}
hrb_type_ir = {crop : {401 : False, 402 : False} for crop in c_ppp if crop_bdcategories[crop] in [30, 70]}
# When there is no information about the pesticides being selective or
# non-selective, non-selective is implemented as standard value for herbicide
# and insecticides application.
for event in ppp_event:
    if crop_bdcategories[event.crop_index] in [30, 70]:
        if 'Hrb' in event.type:
            if event.row_interrow in ['row', 'both']:
                hrb_type_r[event.crop_index][402] = True
            else:
                hrb_type_ir[event.crop_index][402] = True
## ID completion:
base_id_r = {30:32080000, 70:72050000}
base_id_ir = {30:33120000, 70:73050000}
herb_freq_r =           id_completion(herb_freq_r, base_id_r, crop_bdcategories)
dict_freq_single_r =    id_completion(dict_freq_single_r, base_id_r, crop_bdcategories)
amount_hrb_eval_r =     id_completion(amount_hrb_eval_r, base_id_r, crop_bdcategories)
hrb_type_r =            id_completion(hrb_type_r, base_id_r, crop_bdcategories)
herb_dates_r =          id_completion(herb_dates_r, base_id_r, crop_bdcategories)

herb_freq_ir =          id_completion(herb_freq_ir, base_id_ir, crop_bdcategories)
dict_freq_single_ir =   id_completion(dict_freq_single_ir, base_id_ir, crop_bdcategories)
amount_hrb_eval_ir =    id_completion(amount_hrb_eval_ir, base_id_ir, crop_bdcategories)
hrb_type_ir =           id_completion(hrb_type_ir, base_id_ir, crop_bdcategories)
herb_dates_ir =         id_completion(herb_dates_ir, base_id_ir, crop_bdcategories)


# %% calculations: plant protection: bactericides, fungicides, insecticides ===

fun_date_result = {}
ins_date_result = {}
bact_date_result = {}
fun_type = {}
ins_type = {}
bact_type = {}
amount_area = {}

# evaluate type and collect data:
for event in ppp_event:
    if crop_bdcategories[event.crop_index] in [30, 70]:
        # collecting amounts:
        if event.crop_index not in amount_area.keys():
            amount_area[event.crop_index] = [event.area_treated_perc]
        else:
            amount_area[event.crop_index].append(event.area_treated_perc)
        # collecting dates:
        if "Fun" in set(event.type):
            fun_date_result = append_date2type(fun_date_result, event)
        if "Ins" in set(event.type):
            ins_date_result = append_date2type(ins_date_result, event)
        if crop_bdcategories[event.crop_index] == 30:
            if event.type_bactericide != '001_none':
                bact_date_result = append_date2type(bact_date_result, event)
        # assessing type:
        crop = event.crop_index
        if "Fun" in set(event.type):
            fun_type[crop] = {301: False, 302: False, 303: False}
            if event.type_fungicide == '002_copper':
                fun_type[crop][301] = True
            if event.type_fungicide == '003_sulfur':
                fun_type[crop][302] = True
            if event.type_fungicide == '004_other':
                fun_type[crop][303] = True
        if "Ins" in set(event.type):
            ins_type[crop] = {301: False, 302: False, 303: False, 304: False}
            if event.type_insecticide == '001_selective':
                ins_type[crop][301] = True
            if event.type_insecticide == '002_broad':
                ins_type[crop][302] = True
            if event.type_insecticide == '003_hiselect':
                ins_type[crop][303] = True
            if event.type_insecticide == '004_unknown':
                ins_type[crop][304] = True
        if crop_bdcategories[crop] == 30:
            bact_type[crop] = {34160301: False, 34160302: False, 34160303: False, 34160304: False}
            if event.type_bactericide == '002_antibiotic':
                bact_type[crop][34160301] = True
            if event.type_bactericide == '003_micro_organism':
                bact_type[crop][34160302] = True
            if event.type_bactericide == '004_mineral':
                bact_type[crop][34160303] = True
            if event.type_bactericide == '005_phytoregulator':
                bact_type[crop][34160304] = True
# ID completion:
base_id_fun = {30:34170000, 70:74030000}
base_id_ins = {30:34180000, 70:74040000}
fun_type = id_completion(fun_type, base_id_fun, crop_bdcategories)
ins_type = id_completion(ins_type, base_id_ins, crop_bdcategories)

# evaluation of frequency (different for orchards and vineyards):
fungicide_freq = {}
insecticide_freq = {}
bactericide_freq = {}
for key in crop_ids:
    # assessment for orchards
    if crop_bdcategories[key] == 30:
        # fungicides:
        if key in fun_date_result.keys():
            fungicide_freq[key] = eval_frequency(fun_date_result[key])
        else:
            fungicide_freq[key] = [True, False, False, False]
        # insecticides:
        if key in ins_date_result.keys():
            insecticide_freq[key] = eval_frequency(ins_date_result[key])
        else:
            insecticide_freq[key] = [True, False, False, False]
        # bactericides:
        if key in bact_date_result.keys():
            bactericide_freq[key] = eval_frequency(bact_date_result[key])
        else:
            bactericide_freq[key] = [True, False, False, False]
        # ID addition:
        ids = [34170101, 34170102, 34170103, 34170104]
        fungicide_freq[key] = dict(zip(ids, fungicide_freq[key]))
        ids = [34180101, 34180102, 34180103, 34180104]
        insecticide_freq[key] = dict(zip(ids, insecticide_freq[key]))
        ids = [34160101, 34160102, 34160103, 34160104]
        bactericide_freq[key] = dict(zip(ids, bactericide_freq[key]))
    # assessment for vineyards
    if crop_bdcategories[key] == 70:
        # fungicides:
        if key in fun_date_result.keys():
            fungicide_freq[key] = eval_frequency(fun_date_result[key], crop_cat = 'ppp_fun')
        else:
            fungicide_freq[key] = [True, False, False, False, False]
        # insecticides:
        if key in ins_date_result.keys():
            insecticide_freq[key] = eval_frequency(ins_date_result[key], crop_cat = 'ppp_ins')
        else:
            insecticide_freq[key] = [True, False, False, False]
        # ID addition:
        ids = [74030101, 74030102, 74030103, 74030104, 74030105]
        fungicide_freq[key] = dict(zip(ids, fungicide_freq[key]))
        ids = [74040101, 74040102, 74040103, 74040104]
        insecticide_freq[key] = dict(zip(ids, insecticide_freq[key]))

# evaluation of dates
category='3groups_march'
fungicide_dates = {}
insecticide_dates = {}
bactericide_dates = {}
for key in fun_date_result.keys():
    fungicide_dates[key] = eval_date(fun_date_result[key], category)
for key in ins_date_result.keys():
    insecticide_dates[key] = eval_date(ins_date_result[key], category)
for key in bact_date_result.keys():
    bactericide_dates[key] = eval_date(bact_date_result[key], category)

# dates of fungicide application
id_s = [34170401,
        34170402,
        34170403]
d_fungicide_dates = add_ids2dict(id_s, fungicide_dates)
# dates of insecticide application
id_s = [34180401,
        34180402,
        34180403]
d_insecticide_dates = add_ids2dict(id_s, insecticide_dates)
# dates of bactericide application
id_s = [34160401,
        34160402,
        34160403]
d_bactericide_dates = add_ids2dict(id_s, bactericide_dates)
# reset IDs from orchard to vineyard IDs
for key in crop_ids:
    # assessment for vineyards
    if crop_bdcategories[key] == 70:
        if key in d_fungicide_dates.keys():
            ids = [74030401, 74030402, 74030403]
            d_fungicide_dates[key] = add_ids2dict(ids, {key:list(d_fungicide_dates[key].values())})[key]
        if key in d_insecticide_dates.keys():
            ids = [74040401, 74040402, 74040403]
            d_insecticide_dates[key] = add_ids2dict(ids, {key:list(d_fungicide_dates[key].values())})[key]

# evaluation of quantity (area)
amount_fun_eval = {}
amount_ins_eval = {}
amount_bact_eval = {}
for key in fun_date_result:
    if key in amount_area.keys():
        amount_fun_eval[key] = eval_ppp_amount_horti(np.mean(amount_area[key]), 'fun')
for key in ins_date_result:
    if key in amount_area.keys():
        amount_ins_eval[key] = eval_ppp_amount_horti(np.mean(amount_area[key]), 'ins')
for key in bact_date_result:
    if key in amount_area.keys():
        amount_bact_eval[key] = eval_ppp_amount_horti(np.mean(amount_area[key]), 'bact')
# ID completion:
base_id_fun = {30:34170000, 70:74030000}
base_id_ins = {30:34180000, 70:74040000}
amount_fun_eval = id_completion(amount_fun_eval, base_id_fun, crop_bdcategories)
amount_ins_eval = id_completion(amount_ins_eval, base_id_ins, crop_bdcategories)

# ensure zero-option (for fungicides and insecticides)
for key in fungicide_freq:
    zero_option_id = base_id_fun[crop_bdcategories[key]] + 101
    if fungicide_freq[key][zero_option_id] == True:
        d_fungicide_dates[key] = {k: False for k, value in d_fungicide_dates[key].items()}
        amount_fun_eval[key] = {k: False for k, value in amount_fun_eval[key].items()}
        fun_type[key] = {k: False for k, value in fun_type[key].items()}
for key in insecticide_freq:
    zero_option_id = base_id_ins[crop_bdcategories[key]] + 101
    if insecticide_freq[key][zero_option_id] == True:
        d_insecticide_dates[key] = {k: False for k, value in d_insecticide_dates[key].items()}
        amount_ins_eval[key] = {k: False for k, value in amount_ins_eval[key].items()}
        ins_type[key] = {k: False for k, value in ins_type[key].items()}


# %% calculations specific to vegetables ======================================


# Vegetables are similar to arable crops, therefore most of their assessment is
# done in salcabd_farm. Further below, the following topics are assessed for
# vegetables:

# Plant protection: rodent regulation
# Plant protection: beneficials and favorisation structures
# Soil management: cover for weed control


# %% calculations specific to orchards and vineyards
#    (including a few calculations for vegetables) ============================

# variables:
frost_coats = {}
mice_fence_orch = {}
mice_fence_root = {}
repellents = {}
alternance_interrow = {}
disbudding_suckering = {}

for j in c_salcaprep:
    crop = j['crop_id']
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        # coats for frost protection
        if c_bd_frost_coats[crop] == True:
            frost_coats[crop] = {31040101: True, 31040102: False}
        else:
            frost_coats[crop] = {31040101: False, 31040102: True}
        # mice fences
        if c_bd_mice_fence_orch[crop] == True:
            mice_fence_orch[crop] = {31040401: True, 31040402: False}
        else:
            mice_fence_orch[crop] = {31040401: False, 31040402: True}
        if c_bd_mice_fence_root[crop] == True:
            mice_fence_root[crop] = {31040501: True, 31040502: False}
        else:
            mice_fence_root[crop] = {31040501: False, 31040502: True}
    # repellents against bird damage / game bite
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        if c_bd_repellents[crop] == True:
            repellents[crop] = {31040701: True, 31040702: False}
        else:
            repellents[crop] = {31040701: False, 31040702: True}
    if crop_bdcategories[crop] == 70:  # assessment for vineyards
        if c_bd_repellents[crop] == True:
            repellents[crop] = {71030501: True, 71030502: False}
        else:
            repellents[crop] = {71030501: False, 71030502: True}
    # greening: alternance of inter-rows
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        if c_bd_alternance_interrow[crop] == True:
            alternance_interrow[crop] = {33100501: True, 33100502: False}
        else:
            alternance_interrow[crop] = {33100501: False, 33100502: True}
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        if c_bd_alternance_interrow[crop] == True:
            alternance_interrow[crop] = {73030501: True, 73030502: False}
        else:
            alternance_interrow[crop] = {73030501: False, 73030502: True}
    # disbudding and suckering:
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        disbudding_suckering[crop] = {74050101: False, 74050102: False,
                                      74050201: False, 74050202: False,
                                      74050301: False, 74050302: False, 74050303: False}
        # disbudding
        if c_bd_disbudding[crop] == True:
            disbudding_suckering[crop][74050101] = True
            disbudding_suckering[crop][74050102] = False
        elif c_bd_disbudding[crop] == False:
            disbudding_suckering[crop][74050101] = False
            disbudding_suckering[crop][74050102] = True
        else:
            disbudding_suckering[crop][74050101] = False
            disbudding_suckering[crop][74050102] = False
        # suckering, duplication
        if c_bd_suckering_trunk[crop] == True:
            disbudding_suckering[crop][74050201] = True
        if c_bd_suckering_head[crop] == True:
            disbudding_suckering[crop][74050202] = True
        if c_bd_suckering_manual[crop] == True:
            disbudding_suckering[crop][74050301] = True
        if c_bd_suckering_chemical[crop] == True:
            disbudding_suckering[crop][74050302] = True
        if c_bd_suckering_mechanical[crop] == True:
            disbudding_suckering[crop][74050303] = True


# %% assessment of events: irrigation =========================================

# Irrigation assessment for orchards and vineyards.
# Irrigation for vegetables is assessed in salcabd_farm in the same way as
# arable crops.

irrigation_type = {}
irrigation_area = {}
irrigation_duration = {}
irrigation_type_r = {}
irrigation_type_ir = {}
irrigation_area_r = {}
irrigation_area_ir = {}
irrigation_duration_r = {}
irrigation_duration_ir = {}

for crop in c_irri:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        irrigation_type[crop] = {31010201: False, 31010202: False, 31010203: False, 31010204: False, 31010205: False}
        if '001_sprinkler' in c_irri[crop]['type']:
            if '003_below_crop' in c_irri[crop]['type_detail']:
                irrigation_type[crop][31010204] = True
            if '002_above_crop' in c_irri[crop]['type_detail'] or '001_nosprinkler' in c_irri[crop]['type_detail']:
                irrigation_type[crop][31010203] = True
                
        if '002_drip' in c_irri[crop]['type']:
            irrigation_type[crop][31010202] = True
        if '003_surface' in c_irri[crop]['type']:
            irrigation_type[crop][31010205] = True
        if c_irri[crop]['type'] == []:
            irrigation_type[crop][31010201] = True
        # quantity (area)
        irrigation_area[crop] = {31010101: False, 31010102: False, 31010103: False, 31010104: False}
        # quantity only needs assessment if the zero-option is false
        if irrigation_type[crop][31010201] == False:
            # in case of multiple events with different areas, the biggest area
            # will be assessed.
            if '004_under100' in c_irri[crop]['area_perc']:
                irrigation_area[crop][31010104] = True
            elif '003_under75' in c_irri[crop]['area_perc']:
                irrigation_area[crop][31010103] = True
            elif '002_under50' in c_irri[crop]['area_perc']:
                irrigation_area[crop][31010102] = True
            else:
                irrigation_area[crop][31010101] = True
        # duration
        irrigation_duration[crop] = {31010301: False, 31010302: False, 31010303: False, 
                                     31010304: False, 31010305: False, 31010306: False}
        # duration only needs assessment if the zero-option is false
        if irrigation_type[crop][31010201] == False:
            # in case of multiple events with different durations, priority is
            # given here in the code:
            if '006_when_needed' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010306] = True
            elif '005_year' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010305] = True
            elif '004_vege_period' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010304] = True
            elif '003_6months' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010303] = True
            elif '002_3months' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010302] = True
            elif '001_1month' in c_irri[crop]['duration']:
                irrigation_duration[crop][31010301] = True
            else:
                raise ValueError(f"No value found in irrigation_duration assessment for crop number: {crop}")
                
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        irrigation_type_r[crop] = {72010201: False, 72010202: False, 72010203: False, 72010204: False}
        irrigation_type_ir[crop] = {73010201: False, 73010202: False, 73010203: False, 73010204: False}
        irrigation_area_r[crop] = {72010101: False, 72010102: False, 72010103: False, 72010104: False}
        irrigation_area_ir[crop] = {73010101: False, 73010102: False, 73010103: False, 73010104: False}
        irrigation_duration_r[crop] = {72010301: False}
        irrigation_duration_ir[crop] = {73010301: False}
        
        area_perc_mapping = {'001_under25':10101,'002_under50':10102,'003_under75':10103,'004_under100':10104}
        type_mapping = {'001_sprinkler':10202,'002_drip':10203,'003_surface':10204}
        
        if c_irri[crop]['type'] == []:  # no irrigation event on the crop
            irrigation_type_r[crop][72010201] = True
            irrigation_type_ir[crop][73010201] = True
        else:
            area_value_r = 0
            area_value_ir = 0
            for i, element in enumerate(c_irri[crop]["row_interrow"]):
                if element == 'row' or element == 'both' or element == 'none':                
                    type_value = c_irri[crop]['type'][i]
                    irrigation_type_r[crop][72000000+type_mapping[type_value]] = True
                    
                    # ensure single value for quantity
                    if c_irri[crop]['area_perc'][i] > area_value_r:
                        area_value_r = c_irri[crop]['area_perc'][i]
                    
                    irrigation_duration_r[crop][72010301] = True
                if element == "interrow" or element == 'both':
                    type_value = c_irri[crop]['type'][i]
                    irrigation_type_ir[crop][73000000+type_mapping[type_value]] = True
                    
                    # ensure single value for quantity
                    if c_irri[crop]['area_perc'][i] > area_value_ir:
                        area_value_ir = c_irri[crop]['area_perc'][i]
                    
                    irrigation_duration_ir[crop][73010301] = True
            irrigation_area_r[crop][72000000+area_perc_mapping[area_value_r]] = True
            irrigation_area_ir[crop][73000000+area_perc_mapping[area_value_ir]] = True

# %% assessment of sustaining materials =======================================

# nets and tents
net_mesh_size = {}
cover_dimension = {}
cover_duration = {}

for crop in c_cover:
    if crop_bdcategories[crop] == 30:  # assessment for orchards
        # mesh sizes present
        net_mesh_size[crop] = {31020101: False, 31020102: False, 31020103: False, 31020104: False, 31020105: False, 31020106: False}
        if '002_closed' in c_cover[crop]['c_01_mesh_size']:
            net_mesh_size[crop][31020102] = True
        if '003_2x2' in c_cover[crop]['c_01_mesh_size']:
            net_mesh_size[crop][31020103] = True
        if '004_10x10' in c_cover[crop]['c_01_mesh_size']:
            net_mesh_size[crop][31020104] = True
        if '005_25x25' in c_cover[crop]['c_01_mesh_size']:
            net_mesh_size[crop][31020105] = True
        if '006_over25x25' in c_cover[crop]['c_01_mesh_size']:
            net_mesh_size[crop][31020106] = True
        # zero-option: if all options are still False, then there are no nets
        # or tents, therefore the zero-option is True
        if True not in net_mesh_size[crop].values():
            net_mesh_size[crop][31020101] = True
        # dimensions of covers: Priority is given in the following order (no
        # multiple choice)
        if '004_side' in c_cover[crop]['c_02_cover_dimension']:
            cover_dimension[crop] = {31020201: False, 31020202: False, 31020203: False, 31020204: True}
        elif '003_top' in c_cover[crop]['c_02_cover_dimension']:
            cover_dimension[crop] = {31020201: False, 31020202: False, 31020203: True, 31020204: False}
        elif '002_row' in c_cover[crop]['c_02_cover_dimension']:
            cover_dimension[crop] = {31020201: False, 31020202: True, 31020203: False, 31020204: False}
        elif '001_tree' in c_cover[crop]['c_02_cover_dimension']:
            cover_dimension[crop] = {31020201: True, 31020202: False, 31020203: False, 31020204: False}
        else:
            cover_dimension[crop] = {31020201: False, 31020202: False, 31020203: False, 31020204: False}
        # duration of covers:
        cover_duration[crop] = {31020301: False, 31020302: False, 31020303: False, 31020304: False, 31020305: False, 31020306: False}
        if '001_1month' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020301] = True
        if '002_3months' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020302] = True
        if '003_6months' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020303] = True
        if '004_vege_period' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020304] = True
        if '005_year' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020305] = True
        if '006_when_needed' in c_cover[crop]['c_03_cover_duration']:
            cover_duration[crop][31020306] = True
    
# fences/scaffolds/supports
fence_material = {}
sheats = {}

for crop in c_fences:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        # fence material
        fence_material[crop] = {31020401: False, 31020402: False, 31020403: False, 31020404: False, 31020405: False, 31020406: False, 31020407: False}
        if '002_concrete' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020402] = True
        if '003_chrome' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020403] = True
        if '004_zinc' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020404] = True
        if '005_wood_impregnated' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020405] = True
        if '006_wood_taroiled' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020406] = True
        if '007_wood_untreated' in c_fences[crop]['c_01_material']:
            fence_material[crop][31020407] = True
        # zero-option: if all options are still False, then there are no
        # fences, therefore the zero-option is True
        if True not in fence_material[crop].values():
            fence_material[crop][31020401] = True
        
        # sheats
        if True in c_fences[crop]['c_02_sheaths']:
            sheats[crop] = {31020501: True, 31020502: False}
        else:
            sheats[crop] = {31020501: False, 31020502: True}

    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        # fence material in vineyards is only differentiated by the material,
        # not by the coating/impregnation
        fence_material[crop] = {71010101: False, 71010102: False, 71010103: False, 71010104: False}
        if '002_concrete' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010102] = True
        if '003_chrome' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010103] = True
        if '004_zinc' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010103] = True
        if '005_wood_impregnated' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010104] = True
        if '006_wood_taroiled' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010104] = True
        if '007_wood_untreated' in c_fences[crop]['c_01_material']:
            fence_material[crop][71010104] = True
        # zero-option: if all options are still False, then there are no
        # fences, therefore the zero-option is True
        if True not in fence_material[crop].values():
            fence_material[crop][71010101] = True


# %% assessment of events: plant protection: regulation of herbivores =========

# plant protection: insect traps
insect_traps = {}
for crop in c_insect_traps:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        insect_traps[crop] = {31030101: False, 31030102: False, 31030103: False, 31030104: False, 31030105: False}
        if '002_pheromones' in c_insect_traps[crop]:
            insect_traps[crop][31030102] = True
        if '003_alcohol' in c_insect_traps[crop]:
            insect_traps[crop][31030103] = True
        if '004_bait' in c_insect_traps[crop]:
            insect_traps[crop][31030104] = True
        if '005_glue' in c_insect_traps[crop]:
            insect_traps[crop][31030105] = True
        # zero-option:
        if True not in insect_traps[crop].values():
            insect_traps[crop][31030101] = True
    
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        insect_traps[crop] = {71030101: False, 71030102: False}
        if '002_pheromones' in c_insect_traps[crop]:
            insect_traps[crop][71030102] = True
        # zero-option:
        if True not in insect_traps[crop].values():
            insect_traps[crop][71030101] = True

# plant protection: rodent regulation
rodent_control = {}
for crop in c_rodents:
    # assessment for orchards
    if crop_bdcategories[crop] == 30: 
        rodent_control[crop] = {31030201: False, 31030202: False, 31030203: False, 31030204: False, 31030205: False, 31030206: False}
        if '002_traps' in c_rodents[crop]:
            rodent_control[crop][31030202] = True
        if '005_predators' in c_rodents[crop]:
            rodent_control[crop][31030203] = True
        if '004_gazing' in c_rodents[crop]:
            rodent_control[crop][31030204] = True
        if '003_bait' in c_rodents[crop]:
            rodent_control[crop][31030205] = True
        if '006_birth_control' in c_rodents[crop]:
            rodent_control[crop][31030206] = True
        # zero-option:
        if True not in rodent_control[crop].values():
            rodent_control[crop][31030201] = True
    # assessment for vegetables
    if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
        # ensure proper ID depending on the vegetable category and the type of
        # cultivation (open-field or greenhouse)
        if c_bd_vege_grho_bool[crop] == True:
            measure_baseid = int(crop_bdcategories[crop] * 1000000 - 10000000)
        else:
            measure_baseid = int(crop_bdcategories[crop] * 1000000)
        rodent_control[crop] = {measure_baseid + 50101: False, measure_baseid + 50102: False, 
                                measure_baseid + 50103: False, measure_baseid + 50104: False}
        if '002_traps' in c_rodents[crop]:
            rodent_control[crop][measure_baseid + 50102] = True
        if '003_bait' in c_rodents[crop]:
            rodent_control[crop][measure_baseid + 50103] = True
        if '004_gazing' in c_rodents[crop]:
            rodent_control[crop][measure_baseid + 50104] = True
        # zero-option:
        if True not in rodent_control[crop].values():
            rodent_control[crop][measure_baseid + 50101] = True

# plant protection: beneficials and favorisation structures
beneficials = {}
for crop in c_beneficials:
    # clean setup:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        beneficials[crop] = {31030301: False, 31030302: False, 31030303: False}
    # assessment for vegetables
    if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
        # ensure proper ID depending on the vegetable category and the type of
        # cultivation (open-field or greenhouse)
        if c_bd_vege_grho_bool[crop] == True:
            measure_baseid = int(crop_bdcategories[crop] * 1000000 - 10000000)
        else:
            measure_baseid = int(crop_bdcategories[crop] * 1000000)
        beneficials[crop] = {measure_baseid + 30101: False, measure_baseid + 30102: False, measure_baseid + 30103: False}
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        beneficials[crop] = {71020201: False, 71020202: False, 71020203: False}
    # choices:
    if '002_predators' in c_beneficials[crop]:
        # assessment for orchards
        if crop_bdcategories[crop] == 30:
            beneficials[crop][31030302] = True
        # assessment for vegetables
        if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
            beneficials[crop][measure_baseid + 30102] = True
        # assessment for vineyards
        if crop_bdcategories[crop] == 70:
            beneficials[crop][71020202] = True
    if '003_parasitoids' in c_beneficials[crop]:
        # assessment for orchards
        if crop_bdcategories[crop] == 30:
            beneficials[crop][31030303] = True
        # assessment for vegetables
        if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
            beneficials[crop][measure_baseid + 30103] = True
        # assessment for vineyards
        if crop_bdcategories[crop] == 70:
            beneficials[crop][71020203] = True
    # zero-option:
    if crop_bdcategories[crop] == 30 and \
    True not in beneficials[crop].values():
        beneficials[crop][31030301] = True
    if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70 and \
    True not in beneficials[crop].values():
        beneficials[crop][measure_baseid + 30101] = True
    if crop_bdcategories[crop] == 70 and \
    True not in beneficials[crop].values():
        beneficials[crop][71020201] = True
structures = {}
for crop in c_structures:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        structures[crop] = {31040601: False, 31040602: False, 31040603: False, 31040604: False, 31040605: False, 31040606: False, 31040607: False}
        if '002_heterogene' in c_structures[crop]:
            structures[crop][31040602] = True
        if '003_isolated' in c_structures[crop]:
            structures[crop][31040603] = True
        if '004_perches' in c_structures[crop]:
            structures[crop][31040604] = True
        if '005_nesting_aids' in c_structures[crop]:
            structures[crop][31040605] = True
        if '006_small' in c_structures[crop]:
            structures[crop][31040606] = True
        if '007_big' in c_structures[crop]:
            structures[crop][31040607] = True
        # zero-option:
        if True not in structures[crop].values():
            structures[crop][31040601] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        structures[crop] = {71030401: False, 71030402: False, 71030403: False, 71030404: False, 71030405: False, 71030406: False, 71030407: False}
        if '002_heterogene' in c_structures[crop]:
            structures[crop][71030402] = True
        if '003_isolated' in c_structures[crop]:
            structures[crop][71030403] = True
        if '004_perches' in c_structures[crop]:
            structures[crop][71030404] = True
        if '005_nesting_aids' in c_structures[crop]:
            structures[crop][71030405] = True
        if '006_small' in c_structures[crop]:
            structures[crop][71030406] = True
        if '007_big' in c_structures[crop]:
            structures[crop][71030407] = True
        # zero-option:
        if True not in structures[crop].values():
            structures[crop][71030401] = True

# plant protection: mollusc regulation
# yes/no assessment of molluscicides for other crop categories is done in
# salcabd_farm.py based on the PPP events.
mollusc_control = {}
for crop in c_molluscs:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        mollusc_control[crop] = {31030401: False, 31030402: False, 31030403: False, 31030404: False}
        if '002_traps' in c_molluscs[crop]:
            mollusc_control[crop][31030402] = True
        if '003_predators' in c_molluscs[crop]:
            mollusc_control[crop][31030403] = True
        if '004_pellets' in c_molluscs[crop]:
            mollusc_control[crop][31030404] = True
        # zero-option:
        if True not in mollusc_control[crop].values():
            mollusc_control[crop][31030401] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        mollusc_control[crop] = {71020301: False, 71020302: False, 71020303: False}
        if '002_traps' in c_molluscs[crop]:
            mollusc_control[crop][71020303] = True
        if '003_predators' in c_molluscs[crop]:
            mollusc_control[crop][71020303] = True
        if '004_pellets' in c_molluscs[crop]:
            mollusc_control[crop][71020302] = True
        # zero-option:
        if True not in mollusc_control[crop].values():
            mollusc_control[crop][71020301] = True

# plant protection: measures for drift reduction

# equipment
drift_red_equip = {}
for crop in c_drift_red_equip:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        drift_red_equip[crop] = {31040201: False, 31040202: False, 31040203: False, 31040204: False}
        if '002_hailnet' in c_drift_red_equip[crop]:
            drift_red_equip[crop][31040202] = True
        if '003_hedge' in c_drift_red_equip[crop]:
            drift_red_equip[crop][31040203] = True
        if '004_verticalnet' in c_drift_red_equip[crop]:
            drift_red_equip[crop][31040204] = True
        # zero-option:
        if True not in drift_red_equip[crop].values():
            drift_red_equip[crop][31040201] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        drift_red_equip[crop] = {71030201: False, 71030202: False, 71030203: False}
        if '002_hailnet' in c_drift_red_equip[crop]:
            drift_red_equip[crop][71030202] = True
        if '003_hedge' in c_drift_red_equip[crop]:
            drift_red_equip[crop][71030203] = True
        # zero-option:
        if True not in drift_red_equip[crop].values():
            drift_red_equip[crop][71030201] = True

# application techniques
drift_red_tech = {}
for crop in c_drift_red_tech:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        drift_red_tech[crop] = {31040301: False, 31040302: False, 31040303: False, 31040304: False, 31040305: False}
        if '002_nozzles' in c_drift_red_tech[crop]:
            drift_red_tech[crop][31040302] = True
        if '003_devices_other' in c_drift_red_tech[crop]:
            drift_red_tech[crop][31040303] = True
        if '004_tunnel_sprayer' in c_drift_red_tech[crop]:
            drift_red_tech[crop][31040304] = True
        if '005_margin_rows' in c_drift_red_tech[crop]:
            drift_red_tech[crop][31040305] = True
        # zero-option:
        if True not in drift_red_tech[crop].values():
            drift_red_tech[crop][31040301] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        drift_red_tech[crop] = {71030301: False, 71030302: False, 71030303: False, 71030304: False, 71030305: False, 71030306: False}
        if '002_nozzles' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030302] = True
        if '003_devices_other' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030303] = True
        if '004_tunnel_sprayer' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030304] = True
        if '005_margin_rows' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030305] = True
        if '006_untreated_area' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030305] = True
        if '007_regulation' in c_drift_red_tech[crop]:
            drift_red_tech[crop][71030306] = True
        # zero-option:
        if True not in drift_red_tech[crop].values():
            drift_red_tech[crop][71030301] = True
            
# %% assessment of soil management: handling of wood cuts and dead leaves =====

wood_leaves_r = {}
wood_leaves_ir = {}

for crop in c_wood_leaves:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        wood_leaves_r[crop] = {32050101: False, 32050102: False, 32050103: False, 32050104: False}
        wood_leaves_ir[crop] = {33090101: False, 33090102: False, 33090103: False, 33090104: False}
        measure_baseid_r = 32050000
        measure_baseid_ir = 33090000
        woodtreat_mapping = {'001_elimination':101,'002_wood_mulching':102,'003_leaf_mulching':103,
                             '004_wood_burning':101,'005_wood_grinding':102,'006_leaving_in_place':104}  # burning and grinding are mapped accordingly
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        wood_leaves_r[crop] = {72020101: False, 72020102: False, 72020103: False}
        wood_leaves_ir[crop] = {73020101: False, 73020102: False, 73020103: False}
        measure_baseid_r = 72020000
        measure_baseid_ir = 73020000
        woodtreat_mapping = {'001_elimination':101,'002_wood_mulching':103,'003_leaf_mulching':0,
                             '004_wood_burning':102,'005_wood_grinding':103,'006_leaving_in_place':0} 
        # mulching is considered similar to grinding // leaf mulching and
        # leaving in place have no assessment value (= all false)
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        for i, element in enumerate(c_wood_leaves[crop]["row_interrow"]):
            value = c_wood_leaves[crop]['c_02_wood_leaves'][i]
            if element == 'row' or element == 'both' or element == 'none':                
                if woodtreat_mapping[value] != 0:
                    wood_leaves_r[crop][measure_baseid_r+woodtreat_mapping[value]] = True
            if element == "interrow" or element == 'both':
                if woodtreat_mapping[value] != 0:
                    wood_leaves_ir[crop][measure_baseid_ir+woodtreat_mapping[value]] = True

# soil management: auxiliary agents

auxi_prod_r = {}
auxi_prod_ir = {}
for crop in c_auxi_prod:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        auxi_prod_r[crop] = {32050201: False, 32050202: False, 32050203: False, 32050204: False, 32050205: False, 32050206: False}
        auxi_prod_ir[crop] = {33090201: False, 33090202: False, 33090203: False, 33090204: False, 33090205: False, 33090206: False}
        measure_baseid_r = 32050000
        measure_baseid_ir = 33090000
        auxi_mapping = {'001_algae':201,'002_foliar_fert':202,'003_soil_adjuvants':203,
                             '004_manure':204,'005_micro_organism':205,'006_plant_adjuvants':206}
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        auxi_prod_r[crop] = {72020201: False, 72020202: False, 72020203: False, 72020204: False}
        auxi_prod_ir[crop] = {73020201: False, 73020202: False, 73020203: False, 73020204: False}
        measure_baseid_r = 72020000
        measure_baseid_ir = 73020000
        auxi_mapping = {'001_algae':201,'002_foliar_fert':202,'003_soil_adjuvants':203,
                             '004_manure':204,'005_micro_organism':0,'006_plant_adjuvants':0}
        # micro-organisms and plant adjuvants are only assessed for orchards    
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        for i, element in enumerate(c_auxi_prod[crop]["row_interrow"]):
            value = c_auxi_prod[crop]['c_02_auxi_prod'][i]
            if element == 'row' or element == 'both' or element == 'none':                
                if auxi_mapping[value] != 0:
                    auxi_prod_r[crop][measure_baseid_r+auxi_mapping[value]] = True
            if element == "interrow" or element == 'both':
                if auxi_mapping[value] != 0:
                    auxi_prod_ir[crop][measure_baseid_ir+auxi_mapping[value]] = True

# %% assessmet of plant protection: greening ==================================

greening_type_r = {}
greening_type_ir = {}
green_type_mapping = {'001_none':1,'002_natural':2,'003_local':3,
                     '004_floral':4,'005_allelopathic':5,'006_green_manure':6}
greening_duration_r = {}
greening_duration_ir = {}
green_seeding_mapping = {'001_none':401,'002_annually':402,'003_multiannual':403}
green_seeding_r = {}
green_seeding_ir = {}
green_orchdate_mapping = {'001_spring':1,'002_summer':12,'003_fall':2,'004_winter':3}
green_vinedate_mapping = {'001_spring':1,'002_summer':2,'003_fall':3,'004_winter':4}
green_date_r = {}
green_date_ir = {}

for crop in c_greening:
    # greening type
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        greening_type_r[crop] = {32060601: False, 32060602: False, 32060603: False, 32060604: False, 32060605: False, 32060606: False}
        greening_type_ir[crop] = {33100701: False, 33100702: False, 33100703: False, 33100704: False, 33100705: False, 33100706: False}
        measure_baseid_r = 32060600
        measure_baseid_ir = 33100700
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        greening_type_r[crop] = {72030601: False, 72030602: False, 72030603: False, 72030604: False, 72030605: False, 72030606: False}
        greening_type_ir[crop] = {73030701: False, 73030702: False, 73030703: False, 73030704: False, 73030705: False, 73030706: False}
        measure_baseid_r = 72030600
        measure_baseid_ir = 73030700
    # for greening type, only one choice is allowed
    occurrence_count_r = 0
    occurrence_count_ir = 0
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            value = c_greening[crop]['c_02_green_type'][i]
            if (element == 'row' or element == 'both' or element == 'none') and occurrence_count_r == 0:                
                greening_type_r[crop][measure_baseid_r+green_type_mapping[value]] = True
                occurrence_count_r += 1
            if (element == "interrow" or element == 'both') and occurrence_count_ir == 0:
                greening_type_ir[crop][measure_baseid_ir+green_type_mapping[value]] = True
                occurrence_count_ir += 1
        # zero-option: if all options are still False, then there is no
        # greening, therefore the zero-option is True
        if True not in greening_type_r[crop].values():
            greening_type_r[crop][measure_baseid_r+1] = True
        if True not in greening_type_ir[crop].values():
            greening_type_ir[crop][measure_baseid_ir+1] = True

    # greening duration/season
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        greening_duration_r[crop] = {32060301: False, 32060302: False, 32060303: False}
        greening_duration_ir[crop] = {33100301: False, 33100302: False, 33100303: False}
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            if (element == 'row' or element == 'both' or element == 'none'):
                if '001_allyear' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_r[crop][32060301] = True
                if '002_winteronly' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_r[crop][32060302] = True
                if '003_summeronly' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_r[crop][32060303] = True
            if (element == "interrow" or element == 'both'):
                if '001_allyear' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_ir[crop][33100301] = True
                if '002_winteronly' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_ir[crop][33100302] = True
                if '003_summeronly' in c_greening[crop]['c_03_green_duration'][i]:
                    greening_duration_ir[crop][33100303] = True
        # zero-option: if all options are still False, a choice is missing and
        # default is set to 001_allyear
        if True not in greening_duration_r[crop].values():
            greening_duration_r[crop][32060301] = True
        if True not in greening_duration_ir[crop].values():
            greening_duration_ir[crop][33100301] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        greening_duration_r[crop] = {72030301: False, 72030302: False, 72030303: False, 72030304: False}
        greening_duration_ir[crop] = {73030301: False, 73030302: False, 73030303: False, 73030304: False}
        # Although orchards and vineyards differ in their assessment, we used
        # the same choices in the events and mapped the choice "summer only" to
        # spring and summer and the choice "winter only" to autumn and winter
        # for vineyards.
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            if (element == 'row' or element == 'both' or element == 'none'):
                if '001_allyear' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_r[crop][72030301] = True
                    greening_duration_r[crop][72030302] = True
                    greening_duration_r[crop][72030303] = True
                    greening_duration_r[crop][72030304] = True
                if '002_winteronly' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_r[crop][72030303] = True
                    greening_duration_r[crop][72030304] = True
                if '003_summeronly' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_r[crop][72030301] = True
                    greening_duration_r[crop][72030302] = True
            if (element == "interrow" or element == 'both'):
                if '001_allyear' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_ir[crop][73030301] = True
                    greening_duration_ir[crop][73030302] = True
                    greening_duration_ir[crop][73030303] = True
                    greening_duration_ir[crop][73030304] = True
                if '002_winteronly' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_ir[crop][73030303] = True
                    greening_duration_ir[crop][73030304] = True
                if '003_summeronly' in c_greening[crop]['c_03_green_duration']:
                    greening_duration_ir[crop][73030301] = True
                    greening_duration_ir[crop][73030302] = True
    
    # greening: seeding
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        green_seeding_r[crop] = {32060401: False, 32060402: False, 32060403: False}
        green_seeding_ir[crop] = {33100401: False, 33100402: False, 33100403: False}
        measure_baseid_r = 32060000
        measure_baseid_ir = 33100000
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        green_seeding_r[crop] = {72030401: False, 72030402: False, 72030403: False}
        green_seeding_ir[crop] = {73030401: False, 73030402: False, 73030403: False}
        measure_baseid_r = 72030000
        measure_baseid_ir = 73030000
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            value = c_greening[crop]['c_04_green_seeding'][i]
            if (element == 'row' or element == 'both' or element == 'none'):
                green_seeding_r[crop][measure_baseid_r+green_seeding_mapping[value]] = True
            if (element == "interrow" or element == 'both'):
                green_seeding_ir[crop][measure_baseid_ir+green_seeding_mapping[value]] = True
        # zero-option: if all options are still False, there is no seeding
        # (= 001_none is True)
        if True not in green_seeding_r[crop].values():
            green_seeding_r[crop][measure_baseid_r+401] = True
        if True not in green_seeding_ir[crop].values():
            green_seeding_ir[crop][measure_baseid_ir+401] = True
        # no multiple choice allowed: priority is given to
        # 002_annually > 003_multiannual > 001_none
        # row
        if green_seeding_r[crop][measure_baseid_r+402] == True:
            green_seeding_r[crop][measure_baseid_r+401] = False
            green_seeding_r[crop][measure_baseid_r+403] = False
        elif green_seeding_r[crop][measure_baseid_r+403] == True:
            green_seeding_r[crop][measure_baseid_r+401] = False
        # interrow
        if green_seeding_ir[crop][measure_baseid_ir+402] == True:
            green_seeding_ir[crop][measure_baseid_ir+401] = False
            green_seeding_ir[crop][measure_baseid_ir+403] = False
        elif green_seeding_ir[crop][measure_baseid_ir+403] == True:
            green_seeding_ir[crop][measure_baseid_ir+401] = False
    
    # greening date
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        green_date_r[crop] = {32060701: False, 32060702: False, 32060703: False}
        green_date_ir[crop] = {33100801: False, 33100802: False, 33100803: False}
        measure_baseid_r = 32060700
        measure_baseid_ir = 33100800
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            value = c_greening[crop]['c_03_date_season'][i]
            if value != '':
                for number in str(green_orchdate_mapping[value]):  # treating the double mapping of '002_summer'
                    if (element == 'row' or element == 'both' or element == 'none'):
                        green_date_r[crop][measure_baseid_r+int(number)] = True
                    if (element == "interrow" or element == 'both'):
                        green_date_ir[crop][measure_baseid_ir+int(number)] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        green_date_r[crop] = {72030701: False, 72030702: False, 72030703: False, 72030704: False}
        green_date_ir[crop] = {73030801: False, 73030802: False, 73030803: False, 73030804: False}
        measure_baseid_r = 72030700
        measure_baseid_ir = 73030800
        for i, element in enumerate(c_greening[crop]["row_interrow"]):
            value = c_greening[crop]['c_03_date_season'][i]
            if value != '':
                if (element == 'row' or element == 'both' or element == 'none'):
                    green_date_r[crop][measure_baseid_r+green_vinedate_mapping[value]] = True
                if (element == "interrow" or element == 'both'):
                    green_date_ir[crop][measure_baseid_ir+green_vinedate_mapping[value]] = True

# %% assessment of soil management: cover for weed control ====================
weed_cover_r = {}
weed_cover_ir = {}
weed_cover_mapping = {'001_none':301,'002_mulch':302,'003_fleece':303}
for crop in c_weed_cover:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        weed_cover_r[crop] = {32070301: False, 32070302: False, 32070303: False}
        weed_cover_ir[crop] = {33110301: False, 33110302: False, 33110303: False}
        measure_baseid_r = 32070000
        measure_baseid_ir = 33110000
        for i, element in enumerate(c_weed_cover[crop]["row_interrow"]):
            value = c_weed_cover[crop]['c_02_weed_cover'][i]
            if value != '':
                if (element == 'row' or element == 'both' or element == 'none'):
                    weed_cover_r[crop][measure_baseid_r+weed_cover_mapping[value]] = True
                if (element == "interrow" or element == 'both'):
                    weed_cover_ir[crop][measure_baseid_ir+weed_cover_mapping[value]] = True
        # zero-option: if all options are still False, then there is no weed
        # cover, therefore the zero-option is True
        if True not in weed_cover_r[crop].values():
            weed_cover_r[crop][measure_baseid_r+301] = True
        if True not in weed_cover_ir[crop].values():
            weed_cover_ir[crop][measure_baseid_ir+301] = True
    # assessment for vegetables
    if crop_bdcategories[crop] >= 50 and crop_bdcategories[crop] < 70:
        # ensure proper ID depending on the vegetable category and the type of
        # cultivation (open-field or greenhouse)
        if c_bd_vege_grho_bool[crop] == True:
            measure_baseid = int(crop_bdcategories[crop] * 1000000 - 10000000)
        else:
            measure_baseid = int(crop_bdcategories[crop] * 1000000)
        weed_cover_r[crop] = {measure_baseid + 30901: False, measure_baseid + 30902: False, measure_baseid + 30903: False}
        # weed_cover_ir[crop]: for vegetables there is no differentiation
        # between row and interrow assessment
        if '001_none' in c_weed_cover[crop]['c_02_weed_cover']:
            weed_cover_r[crop][measure_baseid + 30901] = True
        if '002_mulch' in c_weed_cover[crop]['c_02_weed_cover']:
            weed_cover_r[crop][measure_baseid + 30902] = True
        if '003_fleece' in c_weed_cover[crop]['c_02_weed_cover']:
            weed_cover_r[crop][measure_baseid + 30903] = True

# %% assessment of canopy management ==========================================

# canopy management: foliage thinning
thinning_date_mapping = {'001_jan': 34140203, '002_feb': 34140203, '003_mar': 34140201,
                         '004_apr': 34140201, '005_mai': 34140201, '006_jun': 34140201,
                         '007_jul': 34140201, '008_aug': 34140202, '009_sep': 34140202,
                         '010_oct': 34140202, '011_nov': 34140203, '012_dec': 34140203}
thinning_type = {}
thinning_date = {}
measure_baseid = {30: 34140000, 70: 74020000}
for crop in c_foliage_thinning:
    # type
    # assessment for orchards and vineyards
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        thinning_type[crop] = {measure_baseid[crop_bdcategories[crop]]+101: False, 
                         measure_baseid[crop_bdcategories[crop]]+102: False, 
                         measure_baseid[crop_bdcategories[crop]]+103: False, 
                         measure_baseid[crop_bdcategories[crop]]+104: False, 
                         measure_baseid[crop_bdcategories[crop]]+105: False, 
                         measure_baseid[crop_bdcategories[crop]]+106: False, 
                         measure_baseid[crop_bdcategories[crop]]+107: False}
    
        if '002_manually' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+102] = True
        if '003_airpressure' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+103] = True
        if '004_ripping' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+104] = True
        if '005_aspiration' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+105] = True
        if '006_thermic' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+106] = True
        if '007_grazing' in c_foliage_thinning[crop]['c_01_thinning_type']:
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+107] = True
        # zero-option: if all options are still False, then there is no foliage
        # thinning, therefore the zero-option is True
        if True not in thinning_type[crop].values():
            thinning_type[crop][measure_baseid[crop_bdcategories[crop]]+101] = True
    
    # date
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        thinning_date[crop] = {measure_baseid[crop_bdcategories[crop]]+201: False, 
                        measure_baseid[crop_bdcategories[crop]]+202: False, 
                        measure_baseid[crop_bdcategories[crop]]+203: False}
        
        values = c_foliage_thinning[crop]['c_03_date_month']
        for value in values:
            thinning_date[crop][thinning_date_mapping[value]] = True

# canopy management: fruit thinning
fr_thinning_date = {}
fr_thinning_type = {}

for crop in c_fruit_thinning:
    # date
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        fr_thinning_date[crop] = {34140901: False, 34140902: False, 34140903: False}
        values = c_fruit_thinning[crop]['c_03_date_month']
        for value in values:
            date_id = thinning_date_mapping[value]+700
            if date_id not in fr_thinning_date[crop]:
                raise ValueError("ID-Error in fr_thinning_date: The following ID does not match the predefined dicts: " + str(date_id))
            fr_thinning_date[crop][date_id] = True
    # type
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        fr_thinning_type[crop] = {34140601: False, 34140602: False, 34140603: False,
                                  34140701: False, 34140702: False, 34140703: False,
                                  34140704: False, 34140705: False, 34140706: False,
                                  34140707: False, 34140708: False, 34140709: False,
                                  34140710: False, 34140711: False, 34140712: False,
                                  34140801: False, 34140802: False, 34140803: False}
        if '002_mechanic' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140602] = True
        if '003_shading' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140603] = True
        if '007_regulator_ba' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140701] = True
        if '008_regulator_ete' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140702] = True
        if '009_regulator_gib' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140703] = True
        if '010_regulator_naa' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140704] = True
        if '011_regulator_naam' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140705] = True
        if '012_manure_ats' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140706] = True
        if '013_manure_k2o_vinasse' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140707] = True
        if '014_manure_no3_vinasse' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140708] = True
        if '015_fungi' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140709] = True
        if '016_herbi' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140710] = True
        if '017_insecti_broad' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140711] = True
        if '018_insecti_selective' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140712] = True
        if '004_wiping' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140801] = True
        if '005_spurpruning' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140802] = True
        if '006_manual_selection' in c_fruit_thinning[crop]['c_01_fr_thinning_type']:
            fr_thinning_type[crop][34140803] = True
        # zero-option: if no other values are true, then no fruit thinning needs to be True
        if True not in fr_thinning_type[crop].values():
            fr_thinning_type[crop][34140601] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        fr_thinning_type[crop] = {74020401: False, 74020402: False, 74020403: False}
        if '002_chemical' in c_fruit_thinning[crop]['c_02_vine_thinning_type']:
            fr_thinning_type[crop][74020402] = True
        if '003_manual' in c_fruit_thinning[crop]['c_02_vine_thinning_type']:
            fr_thinning_type[crop][74020403] = True
        # zero-option: if chemical or manual are not true, then no fruit thinning needs to be True
        if True not in fr_thinning_type[crop].values():
            fr_thinning_type[crop][74020401] = True

# canopy management: shaping of trees
tree_pruning = {}
tree_education_system = {}
tree_shaping_date = {}

for crop in c_tree_shaping:
    measure_baseid = {30: 34140300, 70: 74020200}
    # pruning
    if crop_bdcategories[crop] == 30 or crop_bdcategories[crop] == 70:
        tree_pruning[crop] = {measure_baseid[crop_bdcategories[crop]] + 1: False, 
                              measure_baseid[crop_bdcategories[crop]] + 2: True}
        if True in c_tree_shaping[crop]['c_01_pruning_bool']:
            tree_pruning[crop] = {measure_baseid[crop_bdcategories[crop]] + 1: True, 
                                  measure_baseid[crop_bdcategories[crop]] + 2: False}
        else:
            if False in c_tree_shaping[crop]['c_01_pruning_bool']:
                tree_pruning[crop] = {measure_baseid[crop_bdcategories[crop]] + 1: False, 
                                      measure_baseid[crop_bdcategories[crop]] + 2: True}
    # education system
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        tree_education_system[crop] = {34140401: False, 34140402: False}
        if '001_airy' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][34140401] = True
        elif '002_dense' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][34140402] = True
        else:
            False
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        tree_education_system[crop] = {74020301: False, 74020302: False, 74020303: False,
                                       74020304: False, 74020305: False}
        if '001_gobelet' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][74020301] = True
        elif '002_cordon' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][74020302] = True
        elif '003_guyot' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][74020303] = True
        elif '004_Lyre' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][74020304] = True
        elif '005_precision' in c_tree_shaping[crop]['c_02_education_system_orch']:
            tree_education_system[crop][74020305] = True

    # date
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        tree_shaping_date[crop] = {34140501: False, 34140502: False, 34140503: False}
        values = c_tree_shaping[crop]['c_03_date_month']
        for value in values:
            date_id = thinning_date_mapping[value]+300
            if date_id not in tree_shaping_date[crop]:
                raise ValueError("ID-Error in tree_shaping_date: The following ID does not match the predefined dicts: " + str(date_id))
            tree_shaping_date[crop][date_id] = True

# canopy management: cutting of wood
woodcut_type = {}
woodcut_woundtrea = {}
woodcut_date = {}
for crop in c_wood_cuts:
    # assessment for orchards
    if crop_bdcategories[crop] == 30:
        # type
        woodcut_type[crop] = {34150101: False, 34150102: False, 34150103: False, 34150104: False}
        if '004_both' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][34150104] = True
        elif '003_mechanical' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][34150103] = True
        elif '002_manually' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][34150102] = True
        else:
            woodcut_type[crop][34150101] = True
        # wound treatment
        woodcut_woundtrea[crop] = {34150201: False, 34150202: True}  # zero-option is true
        if True in c_wood_cuts[crop]['c_02_wound_bool']:
            woodcut_woundtrea[crop][34150201] = True
            woodcut_woundtrea[crop][34150202] = False
        woodcut_date[crop] = {34150301: False, 34150302: False, 34150303: False}
        values = c_wood_cuts[crop]['c_03_date_month']
        for value in values:
            date_id = thinning_date_mapping[value]+10100
            if date_id not in woodcut_date[crop]:
                raise ValueError("ID-Error in woodcut_date: The following ID does not match the predefined dicts: " + str(date_id))
            woodcut_date[crop][date_id] = True
    # assessment for vineyards
    if crop_bdcategories[crop] == 70:
        # type
        woodcut_type[crop] = {74020501: False, 74020502: False, 74020503: False, 74020504: False}
        if '004_both' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][74020504] = True
        elif '003_mechanical' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][74020503] = True
        elif '002_manually' in c_wood_cuts[crop]['c_01_woodcut_type']:
            woodcut_type[crop][74020502] = True
        else:
            woodcut_type[crop][74020501] = True          
        # wound treatment
        woodcut_woundtrea[crop] = {74020601: False, 74020602: True}  # zero-option is true
        if True in c_wood_cuts[crop]['c_02_wound_bool']:
            woodcut_woundtrea[crop][74020601] = True
            woodcut_woundtrea[crop][74020602] = False

# canopy management: lifting (levage/relevage)
vine_lifting_type = {}
vine_lifting_freq = {}
for crop in c_vine_lifting:
    # assessment for vineyards only
    if crop_bdcategories[crop] == 70:
        # type
        vine_lifting_type[crop] = {74050401: False, 74050402: False, 74050403: False}
        if '003_mechanical' in c_vine_lifting[crop]['c_01_lifting_type']:
            vine_lifting_type[crop][74050403] = True
        elif '002_manual' in c_vine_lifting[crop]['c_01_lifting_type']:
            vine_lifting_type[crop][74050402] = True
        else:
            vine_lifting_type[crop][74050401] = True
        # frequency
        vine_lifting_freq[crop] = {74050501: False, 74050502: False, 74050503: False, 74050504: False}
        if '3' in c_vine_lifting[crop]['c_02_lifting_rate']:
            vine_lifting_freq[crop][74050504] = True
        elif '2' in c_vine_lifting[crop]['c_02_lifting_rate']:
            vine_lifting_freq[crop][74050503] = True
        elif '1' in c_vine_lifting[crop]['c_02_lifting_rate']:
            vine_lifting_freq[crop][74050502] = True
        else:
            # zero-option (otherwise this option in combination with the zero-
            # option of lifting_type makes no sense)
            vine_lifting_freq[crop][74050501] = True 

# canopy management: trimming/topping
vine_trimming_type = {}
vine_trimming_freq = {}
for crop in c_vine_trimming:
    # assessment for vineyards only
    if crop_bdcategories[crop] == 70:
        # type
        vine_trimming_type[crop] = {74050601: False, 74050602: False, 74050603: False}
        if '003_mechanical' in c_vine_trimming[crop]['c_01_trimming_type']:
            vine_trimming_type[crop][74050603] = True
        elif '002_manual' in c_vine_trimming[crop]['c_01_trimming_type']:
            vine_trimming_type[crop][74050602] = True
        else:
            vine_trimming_type[crop][74050601] = True
        # frequency
        vine_trimming_freq[crop] = {74050701: False, 74050702: False, 74050703: False, 74050704: False}
        if '3' in c_vine_trimming[crop]['c_02_trimming_rate']:
            vine_trimming_freq[crop][74050704] = True
        elif '2' in c_vine_trimming[crop]['c_02_trimming_rate']:
            vine_trimming_freq[crop][74050703] = True
        elif '1' in c_vine_trimming[crop]['c_02_trimming_rate']:
            vine_trimming_freq[crop][74050702] = True
        else:
            # zero-option (otherwise this option in combination with the zero-
            # option of lifting_type makes no sense)
            vine_trimming_freq[crop][74050701] = True 

# %% assessment of preventative plant protection: reduction of frost damage ===

frost_equip = {}
for crop in c_frost_equip:
    # assessment for vineyards only
    if crop_bdcategories[crop] == 70:
        frost_equip[crop] = {71030101: False, 71030102: False, 71030103: False,
                             71030104: False, 71030105: False, 71030106: False,
                             71030107: False, 71030108: False}
        if '002_strawfire' in c_frost_equip[crop]:
            frost_equip[crop][71030102] = True
        if '003_paraffin_candles' in c_frost_equip[crop]:
            frost_equip[crop][71030103] = True
        if '004_oil_lamps' in c_frost_equip[crop]:
            frost_equip[crop][71030104] = True
        if '005_antifreeze_tower' in c_frost_equip[crop]:
            frost_equip[crop][71030105] = True
        if '006_aspersion' in c_frost_equip[crop]:
            frost_equip[crop][71030106] = True
        if '007_helicopter' in c_frost_equip[crop]:
            frost_equip[crop][71030107] = True
        if '008_late_pruning' in c_frost_equip[crop]:
            frost_equip[crop][71030108] = True
        # zero-option: if all options are still False, then there is no frost
        # equipment used, therefore the zero-option is True
        if True not in frost_equip[crop].values():
            frost_equip[crop][71030101] = True



# %% gathering input data & meta data =========================================

# collect all biodiversity input data in a list of dataframes:
horti_data_list = [
    d_fertilisation_freq_r,
    d_fertilisation_freq_ir,
    d_fertilisation_dt_r,
    d_fertilisation_dt_ir,
    d_fert_norm_r,          # fertilisation quantity orchard (area)
    d_fert_norm_ir,         # fertilisation quantity orchard (area)
    d_fertilisation_quan,   # fertilisation quantity vineyard (area)
    d_fertilisation_type_r,
    d_fertilisation_type_ir,
    fert_type_vine,
    d_fert_tech_r,
    d_fert_tech_ir,
    harv_dt,
    harv_type,
    grazing_r,
    grazing_ir,
    orch_green_cuts_tech_r,
    orch_green_cuts_tech_ir,
    vine_green_cuts_tech_r,
    vine_green_cuts_tech_ir,
    green_cuts_number_r,
    green_cuts_number_ir,
    weed_ctrl_freq_r,
    weed_ctrl_freq_ir,
    weed_ctrl_dateeval_r,
    weed_ctrl_dateeval_ir,
    weed_mechanic_r,
    weed_mechanic_ir,
    weed_thermic_r,
    weed_thermic_ir,
    weed_manual_r,
    weed_manual_ir,
    weed_electric_r,
    weed_electric_ir,
    herb_freq_r,
    herb_freq_ir,
    herb_dates_r,
    herb_dates_ir,
    amount_hrb_eval_r,
    amount_hrb_eval_ir,
    dict_freq_single_r,
    dict_freq_single_ir,
    hrb_type_r,
    hrb_type_ir,
    fungicide_freq,
    insecticide_freq,
    bactericide_freq,
    d_fungicide_dates,
    d_insecticide_dates,
    d_bactericide_dates,
    amount_fun_eval,
    amount_ins_eval,
    amount_bact_eval,
    fun_type,
    ins_type,
    bact_type,
    irrigation_type,
    irrigation_area,
    irrigation_duration,
    irrigation_type_r,
    irrigation_type_ir,
    irrigation_area_r,
    irrigation_area_ir,
    irrigation_duration_r,
    irrigation_duration_ir,
    net_mesh_size,
    cover_dimension,
    cover_duration,
    fence_material,
    sheats,
    insect_traps,
    rodent_control,
    beneficials,
    mollusc_control,
    frost_coats,
    frost_equip,
    drift_red_equip,
    drift_red_tech,
    mice_fence_orch,
    mice_fence_root,
    structures,
    repellents,
    wood_leaves_r,
    wood_leaves_ir,
    auxi_prod_r,
    auxi_prod_ir,
    greening_type_r,
    greening_type_ir,
    greening_duration_r,
    greening_duration_ir,
    alternance_interrow,
    green_seeding_r,
    green_seeding_ir,
    green_date_r,
    green_date_ir,
    weed_cover_r,
    weed_cover_ir,
    thinning_type,
    thinning_date,
    tree_pruning,
    tree_education_system,
    tree_shaping_date,
    fr_thinning_type,
    fr_thinning_date,
    woodcut_type,
    woodcut_woundtrea,
    woodcut_date,
    disbudding_suckering,
    vine_lifting_type,
    vine_lifting_freq,
    vine_trimming_type,
    vine_trimming_freq
    ]

# create a dict with all rows per crop:
bd_horti_dest = {}
for a in horti_data_list:
    if a != {}:
        for b in a.items():
            if len(set([int(key/1000000) for key in b[1]])) == 1:
                if all([(int(key) > 31000000 and int(key) < 35000000) or
                        (int(key) > 71000000 and int(key) < 75000000) for key in b[1]]):
                    addendum = int(list(b[1].keys())[0]/1000000)/100
                    if float(b[0])+addendum in bd_horti_dest.keys():
                        bd_horti_dest[float(b[0])+addendum].update(b[1])
                    else:
                        bd_horti_dest[float(b[0])+addendum] = b[1]
                else:
                    if float(b[0]) in bd_horti_dest.keys():
                        bd_horti_dest[float(b[0])].update(b[1])
                    else:
                        bd_horti_dest[float(b[0])] = b[1]
            else:
                raise ValueError("Please check module code and control table: Measure ID's do not match in Habitat Type II: " + str(b))


# %% output ===================================================================

out.f_bd_horti_output = js.dumps(bd_horti_dest)


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
