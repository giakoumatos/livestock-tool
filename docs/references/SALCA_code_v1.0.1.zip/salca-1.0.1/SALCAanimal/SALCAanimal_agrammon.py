# -*- coding: utf-8 -*-
"""
File name: SALCAanimal_agrammon.py
Created on Thu Jun 27 10:51:55 2019

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script calculates correction factors for NH3 emissions that are used 
    in SALCAanimal.

Calculation level:
    Farm

Related scripts: SALCAanimal_ls.py, SALCAanimal_farm.py, SALCAfield_field.py
"""

# %% import modules and starting sequence =====================================
import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAanimal_agrammon'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define functions =========================================================
def read_pars(path):
    """ read CSV file with parameters """
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab

# %% load table ===============================================================
# load the table SALCAanimal_pars from csv file
tab_pars = read_pars('SALCAanimal_pars.csv')

# load table with correction factors for infrastructure and manure management
tab_CF_building = pd.read_csv('agrammon_infrastructure.csv',
                              header=6,
                              sep=';'
                              )
tab_CF_manu = pd.read_csv('agrammon_manure_management.csv',
                          header=6,
                          sep=';'
                          )

# set up a table to assign applied manure to the manure application techniques
df_tech = pd.DataFrame({'technic': ['not specified', 'trailing hose',
                                    'drill', 'deep injection',
                                    'trailing shoe', 'broadcaster'],
                        'python_name': ['000 pract0', '001 pract1',
                                        '002 pract2', '003 pract3',
                                        '004 pract4', '005 pract5'],
                        # setup for determining the relative use of each
                        # technique
                        'amount': [0, 0, 0, 0, 0, 0]})

# CFs for incorporation of solid manure
incorp_time_other = tab_CF_manu['Incorporation time manure cattle pigs'].dropna(
).values[::-1]
incorp_time_cf_other = tab_CF_manu['CF Incorporation time manure cattle pigs'].dropna(
).values[::-1]
incorp_time_poul = tab_CF_manu['Incorporation time manure poultry'].dropna(
).values[::-1]
incorp_time_cf_poul = tab_CF_manu['CF Incorporation time manure poultry'].dropna(
).values[::-1]

# %% load input data ==========================================================

if ctx.farm.livestocks == {}:  # no livestocks on farm
    # pasture input
    # list of mean daily hours spent on pasture, number from livestock
    pasture_duration = []
    ls_head = 0
else:
    pasture_duration = inp.ls_past_h
    ls_head = inp.ls_head


# housing input
# infrastructure for cattle. list from event
cattle_infrastructure = [value['f_catt_03_infr']
                         for value in inp.get_events('cattle_infrastructure')]
# infrastructure for pigs. list from event
pigs_infrastructure = [value['f_pigs_03_infr']
                       for value in inp.get_events('pigs_infrastructure')]
# system for air cleaning for pig housing, str from enum
f_pigs_airc = [value['f_pigs_04_aircl']
               for value in inp.get_events('pigs_infrastructure')]
# system for air cleaning for poultry housing, str from enum
poultry_air_cleaner = [value['f_poul_03_aircl']
                       for value in inp.get_events('poul_infrastructure')]
# poultry drinking system. str from enum
poultry_drinking_system = [value['f_poul_04_drink']
                           for value in inp.get_events('poul_infrastructure')]
# dropping removal frequency for hens. str from enum
dropping_removal_frequ = inp.f_dropping_removal_freq

# number of places per infrastructure to weigh the CFs
cattle_infr_places = [value['f_catt_02_infr_places']
                         for value in inp.get_events('cattle_infrastructure')]
cattle_infr_m2 = [value['f_catt_02_infr_m2']
                         for value in inp.get_events('cattle_infrastructure')]
pigs_infr_places = [value['f_pigs_02_infr_places']
                       for value in inp.get_events('pigs_infrastructure')]
pigs_infr_m2 = [value['f_pigs_02_infr_m2']
                       for value in inp.get_events('pigs_infrastructure')]
poul_infr_places = [value['f_poul_02_infr_places']
                       for value in inp.get_events('poul_infrastructure')]

# convert m2 to places if there is only m2 given in case of deep litter
cattle_m2perplace = tab_pars['Value']['cattle_m2perplace']
pigs_m2perplace = tab_pars['Value']['pigs_m2perplace']
for index, i in enumerate(cattle_infr_places):
    if i is None:
        cattle_infr_places[index] = cattle_infr_m2[index]/cattle_m2perplace
for index, i in enumerate(pigs_infr_places):
    if i is None:
        pigs_infr_places[index] = pigs_infr_m2[index]/pigs_m2perplace

# yard input
# list of yard types from event
yard_type = [value['f_yard_01_type'] for value in inp.get_events('building_yard')]
yard_size = [value['f_yard_02_m2'] for value in inp.get_events('building_yard')]


# manure storage input
# list of liquid manure storage systems, from event
key_manstor_l = [value['f_lman_02_stor_vari']
                 for value in inp.get_events('key_manstor_l')]
size_m3_manstor_l = [value['f_lman_03_m3']
                 for value in inp.get_events('key_manstor_l')]
# list of solid manure storage systems, from event
key_manstor_s = [value['f_sman_01_stor_vari']
                 for value in inp.get_events('key_manstor_s')]
size_m2_manstor_s = [value['f_sman_02_m2']
                 for value in inp.get_events('key_manstor_s')]

# Slurry additions frequency. str from enum
slurry_freq = inp.f_lman_freq  

# Manure application input
# frequency of manure application on warm days, str form enum
application_warm_freq = inp.f_sman_freq

# %% liquid manure application ================================================

# setup
l_appl_evening = 0  # correction for manure application in the evening
l_appl_deep_inject = 0  # fraction of slurry applied by deep injection
l_amount_total_m3 = 0  # total amount of slurry applied, [m3]

# There is no c_salcaprep when only livestock but no crop is modelled.
# Without crop modelling, there is no manure application to derive a CF from.
if hasattr(inp, 'c_salcaprep') and inp.c_salcaprep is not None:
    # cycle the input from salcaprep_crop for the different crops
    for c_salcaprep in inp.c_salcaprep:
        # load the stored dictionary for the current crop
        c_salcaprep = js.loads(c_salcaprep)
        # extract the subdirectory for the slurry application
        manure_l = c_salcaprep['tr_manure_l']
        # iterate through the different slurry applications
        for i in np.arange(len(manure_l['date'])):
            # extract the date, convert to dt.datetime
            date = dt.datetime.strptime(manure_l['date'][i], '%Y-%m-%d')
            # extract the amount of the slurry application
            amount = manure_l['amount_m3'][i]
            # add the amount to the total amount of applied slurry
            l_amount_total_m3 += amount
            # extract the practice of slurry application
            tech = manure_l['practice'][i]
            # enter the amount applied with the given
            # practice to the tech dataframe
            df_tech.loc[df_tech['python_name'] == tech, 'amount'] += amount
            # information whether the application was made in the evening
            evening = manure_l['evening'][i]
            if evening == 1:  # if application in the evening
                # add the amount for evening, multiply by correction factor
                l_appl_evening += amount * tab_pars['Value']['corr_appl_evening']
            else:  # no correction for application in the evening
                l_appl_evening += amount * 1

if l_amount_total_m3 > 0:
    # divide by the total amount to finish weights
    l_appl_evening = l_appl_evening / l_amount_total_m3

    # extract the amounts applied with the different techniques
    # divide by total amount of slurry applied to calculate fractions
    l_appl_standard = df_tech.loc[df_tech['technic'] == 'not specified',
                                  'amount'].values[0] / l_amount_total_m3
    l_appl_broadcaster = df_tech.loc[df_tech['technic'] == 'broadcaster',
                                     'amount'].values[0] / l_amount_total_m3
    l_appl_drill = df_tech.loc[df_tech['technic'] == 'drill',
                               'amount'].values[0] / l_amount_total_m3
    l_appl_trailing_hos = df_tech.loc[df_tech['technic'] == 'trailing hose',
                                      'amount'].values[0] / l_amount_total_m3
    l_appl_trailing_shoe = df_tech.loc[df_tech['technic'] == 'trailing shoe',
                                       'amount'].values[0] / l_amount_total_m3
    l_appl_deep_inject = df_tech.loc[df_tech['technic'] == 'deep injection',
                                     'amount'].values[0] / l_amount_total_m3
else:  # avoid division by 0
    l_appl_evening = 0
    l_appl_standard = 0
    l_appl_broadcaster = 0
    l_appl_drill = 0
    l_appl_trailing_hos = 0
    l_appl_trailing_shoe = 0
    l_appl_deep_inject = 0

# calculate the weighted cf for the application techniques
l_appl_tech = (l_appl_broadcaster*1.00
             + l_appl_drill*tab_pars['Value']['corr_appl_drill']
             + l_appl_trailing_hos*tab_pars['Value']['corr_appl_trailing_hos']
             + l_appl_trailing_shoe*tab_pars['Value']['corr_appl_trailing_shoe']
             + l_appl_deep_inject*tab_pars['Value']['corr_appl_deep_inject'])
if l_appl_tech == 0:
    l_appl_tech = 1
if l_appl_evening == 0:
    l_appl_evening = 1

# derive the correction factor [%] for the frequency of slurry applied
# on warm days. Correction factor /100 to convert % to fraction
l_appl_warm = tab_CF_manu.loc[tab_CF_manu['Frequency manure application on warm days']
                              == application_warm_freq, 'CF manure application on warm days'
                              ].values[0]/100

# calculate the product of the correction factors
# for a total cf for slurry application
cf_man_appl_l = (l_appl_tech
               * l_appl_evening
               * l_appl_warm
                 )

# %% solid manure application =================================================
# Is calculated directly in SALCAfield_field (see cf_manu_frac)

# %% manure storage ===========================================================
# list of the cfs for solid and liquid manure storage [%/100]
infrastructure_s = []
infrastructure_l = []

# iterate through solid manure storage systems
for index, i in enumerate(key_manstor_s):
    # extract the cf and append it to the list, convert % to fraction
    infrastructure_s.append(tab_CF_building.loc[tab_CF_building['Name'] == i,
                                                'CF'].values[0]/100 
                                                * size_m2_manstor_s[index]
                                                /sum(size_m2_manstor_s))
# iterate through slurry storage
for index, i in enumerate(key_manstor_l):
    # extract the cf and append it to the list, convert % to fraction
    infrastructure_l.append(tab_CF_building['CF']
                           [tab_CF_building['Name'] == i].values[0]/100 
                           * size_m3_manstor_l[index]/sum(size_m3_manstor_l))
# default 1.0 for no entry
if key_manstor_l == []:
    infrastructure_l.append(1.0)
if key_manstor_s == []:
    infrastructure_s.append(1.0)
# extract the cf for the frequency of slurry stirring, convert % to fraction
cf_slurry_stirring = tab_CF_manu.loc[tab_CF_manu['Frequency manure stirring']
                                     == slurry_freq, 'CF manure stirring'
                                     ].values[0]/100
# calculate the combined cf for slurry and
# solid manure storage as product [%/100]
cf_man_stor_s = np.sum(infrastructure_s)
cf_man_stor_l = np.sum(infrastructure_l)*cf_slurry_stirring

# %%  housing pasture and yard ================================================
# setup
# list of cf for housing for cattle and pigs
cf_housing_cattle = 0
cf_housing_pigs = 0
cf_housing_pigs_air = 0
cf_housing_poultry_1 = 0
cf_housing_poultry_2 = 0
# go through the different entries of cattle housing
for index, i in enumerate(cattle_infrastructure):
    nbr_places = cattle_infr_places[index]
    # extract the cf and append it to the list, convert % to fraction
    cf_housing_cattle += tab_CF_building['CF'][tab_CF_building['Name']
                                               == i].values[0]/100 * nbr_places
if cf_housing_cattle == 0:
    cf_housing_cattle = 1
else:
    cf_housing_cattle = cf_housing_cattle / sum(cattle_infr_places)
# go through the different entries of pig housing
for index, i in enumerate(pigs_infrastructure):
    nbr_places = pigs_infr_places[index]
    # extract the cf and append it to the list
    cf_housing_pigs += tab_CF_building['CF'][tab_CF_building['Name']
                                             == i].values[0]/100 * nbr_places
if cf_housing_pigs == 0:
    cf_housing_pigs = 1
else:
    cf_housing_pigs = cf_housing_pigs / sum(pigs_infr_places)
# extract the cf for air cleaning, convert % to fraction
for index, i in enumerate(f_pigs_airc):
    nbr_places = pigs_infr_places[index]
    cf_housing_pigs_air += tab_CF_building['CF'][tab_CF_building['Name']
                                                 == i
                                                 ].values[0]/100 * nbr_places
if cf_housing_pigs_air == 0:
    cf_housing_pigs_air = 1
else:
    cf_housing_pigs_air = cf_housing_pigs_air / sum(pigs_infr_places)

# calculate the product of the cfs.
cf_housing_pigs = cf_housing_pigs * cf_housing_pigs_air

# extract the cf for air cleaning for poultry housing. convert % to fraction
for index, i in enumerate(poultry_air_cleaner):
    nbr_places = poul_infr_places[index]
    cf_housing_poultry_1 += tab_CF_building['CF'][tab_CF_building['Name']
                                                  == i
                                                  ].values[0]/100 * nbr_places
if cf_housing_poultry_1 == 0:
    cf_housing_poultry_1 = 1
else:
    cf_housing_poultry_1 = cf_housing_poultry_1 / sum(poul_infr_places)
# extract the cf for the poultry drinking system. convert % to fraction
for index, i in enumerate(poultry_drinking_system):
    nbr_places = poul_infr_places[index]
    cf_housing_poultry_2 += tab_CF_building['CF'][tab_CF_building['Name']
                                                  == i
                                                  ].values[0]/100 * nbr_places
if cf_housing_poultry_2 == 0:
    cf_housing_poultry_2 = 1
else:
    cf_housing_poultry_2 = cf_housing_poultry_2 / sum(poul_infr_places)

# extract the cf for the poultry dropping removal frequency, convert % to fraction
cf_housing_poultry_3 = tab_CF_manu['CF dropping removal'][tab_CF_manu['Frequency dropping removal']
                                                          == dropping_removal_frequ
                                                          ].values[0]/100
cf_housing_poultry = (cf_housing_poultry_1
                    * cf_housing_poultry_2
                    * cf_housing_poultry_3)

# list of cf for pasture
# map pasture duration to the respective class
cf_past = []
for index, i in enumerate(pasture_duration):  # Unit: h
    if i == 0:
        pasture_duration_c = 'not_on_pasture'
    elif i < 5:
        pasture_duration_c = 'duration_001'
    elif i <= 12:
        pasture_duration_c = 'duration_002'
    elif i <= 22:
        pasture_duration_c = 'duration_003'
    elif i < 24:
        pasture_duration_c = 'duration_004'
    else:
        pasture_duration_c = 'all_day'
    # cf for time on pasture. convert % to fraction
    cf_past.append(tab_CF_manu.loc[tab_CF_manu['time on pasture']
                                   == pasture_duration_c, 
                                   'CF time on pasture'].values[0]/100
                                   * ls_head[index]/sum(ls_head))
# calculate the product of the cfs.
cf_housing = (cf_housing_cattle
            * cf_housing_pigs
            * cf_housing_poultry
            * np.sum(cf_past)
              )
cf_past = np.sum(cf_past)

# list of cf for yard, % converted to fraction
cf_yard = []
for index, i in enumerate(yard_type):
    cf_yard.append(tab_CF_building['CF']
                  [tab_CF_building['Name'] == i].values[0]/100 
                  * yard_size[index]/sum(yard_size))
# calculate the product of the cfs.
cf_yard = np.sum(np.array(cf_yard))

# %% output ===================================================================
# create a dictionary with the output
c_agrammon = {
    'Correction factor NH3 housing': cf_housing,
    'Correction factor NH3 yard': cf_yard,
    'Correction factor NH3 liquid manure storage': cf_man_stor_l,
    'Correction factor NH3 solid manure storage': cf_man_stor_s,
    'Correction factor NH3 pasture': cf_past,  # currently not used
    'Correction factor NH3 liquid manure applied': cf_man_appl_l,
    # CF for solid manure applied is calculated directly in SALCAfield_field
}
# dump to string and return to the database
out.f_agrammon = js.dumps(c_agrammon)

logging.info('')
logging.info('Agrammon correction factors (f_agrammon):')
for key, value in c_agrammon.items():
        logging.info("{} = {}".format(key, value))
logging.info('**********************************')

# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
