# -*- coding: utf-8 -*-
"""
File name: SALCAanimal_farm.py
Created on Mon Jan  6 08:23:33 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script summarises the emissions from livestock per animal group 
    from SALCAanimal_ls.py at farm level as part of SALCAanimal.

Calculation level:
    Farm

Related scripts: SALCAanimal_agrammon.py, SALCAanimal_ls.py
"""

# %% import modules and starting sequence =====================================
import datetime as dt
import json as js
import copy
import logging
from importlib import reload

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.INFO)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAanimal_farm'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes ===========================================================

# %% define functions =========================================================
def read_pars(path):
    """ read CSV file with parameters """
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab


def get_value(col, manure_type):
    """
    Extract a single value from the manure table.

    Keyword arguments:
    col: Name of the column with the target value in the manure table.
    manure_type: Specifies the column of the target value in the manure table.
    """
    value = tab_manure[col][tab_manure['NameEN'] == manure_type].values[0]
    return value


def get_hm_cont(metal, manure_type):
    ''' reads the HM content for manure_type and metal (the column header)
        HM_mapping: map manure type to HM table '''
    if manure_type == '':
        hm_content = 0.0
    else:
        hm_mapping = tab_manure['HM_mapping'][tab_manure['NameEN'] == manure_type].values[0]
        dm_content = tab_hm['DM_content'][tab_hm['NameEN'] == hm_mapping].values[0]
        hm_content = tab_hm[metal][tab_hm['NameEN'] == hm_mapping].values[0]*dm_content
    return hm_content

def unpack_dc(dc):
    ''' Unpack a dataframe, which was dumped into a string.
        input: the string containing the dataframe
        this includes information about index and column names. '''
    import pandas as pd
    import json as js
    return pd.DataFrame(data=js.loads(dc)['data'],
                        columns=js.loads(dc)['columns'],
                        index=js.loads(dc)['index'])


def non0(value):
    """ avoid division by zero. Returns 1 for value=0 """
    if value == 0:
        non_zero_value = 1
    else:
        non_zero_value = value
    return non_zero_value


# %% input ====================================================================
metals = ['Cd', 'Cu', 'Zn', 'Pb', 'Ni', 'Cr', 'Hg']  # list of HMs
treatments = []

# There are no c_salcaprep and no treatments when only livestock but no crop is modelled:
if hasattr(inp, 'c_salcaprep') and inp.c_salcaprep is not None:
    for i in inp.c_salcaprep:
        treatments.append(js.loads(i))

# load HM in manure
if ctx.farm.livestocks == {}:  # no livestock on farm
    num_ls = 0
    salcaanimal_manure = [{}]*0
else:
    num_ls = len(inp.ls_animal_manu_prep)  # number of livestock groups
    salcaanimal_manure = [{}]*len(inp.ls_animal_manu_prep)
    for i in range(len(inp.ls_animal_manu_prep)):
        salcaanimal_manure[i] = js.loads(inp.ls_animal_manu_prep[i])

# turn the list of dicts into a dict of lists
manure_HM_liq = {}
manure_HM_sol = {}
liquid = 0  # index for liquid manure
solid  = 1  # index for solid manure
for metal in metals:
    hm_list = [0.0]*num_ls  # initialize list
    for ls in range(num_ls):
        hm_list[ls] = salcaanimal_manure[ls]['hm'][liquid][metal]
        logging.debug('HM in liquid manure:')
        logging.debug(f'ls= {ls}, metal= {metal}, hm_list= {hm_list}')
    manure_HM_liq[metal] = hm_list
    hm_list = [0.0]*num_ls  # initialize
    for ls in range(num_ls):
        hm_list[ls] = salcaanimal_manure[ls]['hm'][solid][metal]
        logging.debug('HM in solid manure:')
        logging.debug(f'ls= {ls}, metal= {metal}, hm_list= {hm_list}')
    manure_HM_sol[metal] = hm_list

# manure imported from other farms is counted as an input to the balance
m_import = {
    # dictionary with lists of values. Each position in the list
    # represents information about one manure type.
    'manure_type': [value['f_01_sman_vari'] for value
                    in inp.get_events('import_manure_s')],
    'slurry_type': [value['f_01_lman_vari'] for value
                    in inp.get_events('import_manure_l')],
    # Units: m3 for liquid manure, t for solid manure
    'f_02_impo_t': [value['f_02_impo_t'] for value
                    in inp.get_events('import_manure_s')],
    'f_02_imp_dilu_m3': [value['f_02_impo_m3'] for value
                         in inp.get_events('import_manure_l')],

    # 1 for solid manure, fraction of liquid manure on total volume
    'f_03_manu_dilu_perc': [value['f_03_manu_dilu_perc'] for value
                            in inp.get_events('import_manure_l')]
}

m_export = {
    # only total amounts for liquid [m2] and solid [t] manure.
    'lman_expo_m3': np.sum([value['f_02_impo_m3'] for value
                            in inp.get_events('export_manure_l')]),
    'sman_expo_t': np.sum([value['f_02_expo_t'] for value
                           in inp.get_events('export_manure_s')])
}

m_spreading = {
    # only total amounts for liquid [m2] and solid [t] manure.
    'sman_spreading_t': 0,
    'lman_spreading_m3': 0
}

for dc in treatments:
    for index, manure_type in enumerate(dc['tr_manure_l']['variable']):
        if manure_type == 'liquid_farm_manure':
            m_spreading['lman_spreading_m3'] += np.sum(dc['tr_manure_l']['amount_m3'][index])
    for index, manure_type in enumerate(dc['tr_manure_s']['variable']):
        if manure_type == 'solid_farm_manure':
            m_spreading['sman_spreading_t'] += np.sum(dc['tr_manure_s']['amount_t'][index])


# no livestock on farm
if ctx.farm.livestocks == {}:
    m_production = {
        # from SALCAanimal_livestock
        # mapping animal type --> manure types
        'animal_type': [],
        # kg N after storage
        'production_sman_kgN': [],
        'production_lman_kgN': [],
        # kg P2O5
        'production_sman_kgP2O5': [],
        'production_lman_kgP2O5': [],
        # kg K2O
        'production_sman_kgK2O': [],
        'production_lman_kgK2O': [],
        # kg NH4-N
        'production_sman_kgNH4_N': [],
        'production_lman_kgNH4_N': [],
        # kg OS
        'production_sman_kgOS': [],
        'production_lman_kgOS': []
    }
    for metal in metals:
        m_production['production_sman_'+metal] = []
        m_production['production_lman_'+metal] = []
else:
    m_production = {
        # from SALCAanimal_livestock
        # mapping animal type --> manure types
        'animal_type': [ctx.farm.livestocks[i].livestock_definition_name
                        for i in ctx.farm.livestocks.keys()],
        # kg N after storage
        'production_sman_kgN': inp.ls_sman_kgN,
        'production_lman_kgN': inp.ls_lman_kgN,
        # kg P2O5
        'production_sman_kgP2O5': inp.ls_sman_kgP2O5,
        'production_lman_kgP2O5': inp.ls_lman_kgP2O5,
        # kg K2O
        'production_sman_kgK2O': inp.ls_sman_kgK2O,
        'production_lman_kgK2O': inp.ls_lman_kgK2O,
        # kg NH4-N
        'production_sman_kgNH4_N': inp.ls_sman_kgNH4_N,
        'production_lman_kgNH4_N': inp.ls_lman_kgNH4_N,
        # kg OS
        'production_sman_kgOS': inp.ls_sman_kgOS,
        'production_lman_kgOS': inp.ls_lman_kgOS,
    }
    for metal in metals:
        m_production['production_sman_mg'+metal] = manure_HM_sol[metal]
        m_production['production_lman_mg'+metal] = manure_HM_liq[metal]
        
# enum selection of NH3 model. 1=EMEP/EEA or 2=Agrammon
f_model_NH3 = inp.f_model_NH3

# %% tables ===================================================================
# load the table SALCAanimal_pars from csv file
tab_pars = read_pars('SALCAanimal_pars.csv')
# load the livestock table from SALCAtables.
tab_ls = unpack_dc(inp.tab_ls)
# load the manure table from SALCAtables.
tab_manure = unpack_dc(inp.tab_manu)
# HM contents
tab_hm = unpack_dc(inp.tab_hm)

# table for EF NH3 manure spreading (average values)
# manure class according to SALCAtables_manu and the manure types described there.
# Animal categories from SALCAtables_ls are more detailed than the listed manure types.
# where no value: sheep, goats, horses like cattle; all poultry like laying hens
# unassigned as average of all values
if f_model_NH3 == 'EMEP/EEA':
    tab_EF_NH3 = pd.DataFrame({'manure class': ['Cattle', 'Pigs',
                                                'Sheep and goats',
                                                'Horses', 'Poultry',
                                                'Unassigned'],
                               'EF_solid': [0.68, 0.45, 0.9, 0.9, 0.47, 0.62],
                               'EF_liquid': [0.55, 0.35, 0.55, 0.55, 0.69, 0.51]})
elif f_model_NH3 == 'Agrammon':
    tab_EF_NH3 = pd.DataFrame({'manure class': ['Cattle', 'Pigs',
                                                'Sheep and goats',
                                                'Horses', 'Poultry',
                                                'Unassigned'],
                               'EF_solid': [0.8, 0.6, 0.7, 0.7, 0.4, 0.6],
                               'EF_liquid': [0.5, 0.35, 0.5, 0.5, 0.4, 0.43]})

# %% calculations =============================================================
# The added livestock categories need to be changed to its parent
# category for the calculations here in SALCAanimal
for i,animal_type in enumerate(m_production['animal_type']):
    if 'livestock_cattle_other_' in animal_type:
        m_production['animal_type'][i] = 'livestock_cattle_other'
    elif animal_type == 'livestock_pigs_piglets':
        m_production['animal_type'][i] = 'livestock_pigs_breeding'

# assign manure classes for imported manure
m_import['manure_class_s'] = []
for manure_type in m_import['manure_type']:
    m_import['manure_class_s'].append(get_value('Module', manure_type))
m_import['manure_class_l'] = []
for slurry_type in m_import['slurry_type']:
    m_import['manure_class_l'].append(get_value('Module', slurry_type))

# calculate undiluted imported slurry
m_import['f_02_impo_m3'] = []
for i, dilution in enumerate(m_import['f_03_manu_dilu_perc']):
    m_import['f_02_impo_m3'] = (
        np.array(m_import['f_02_imp_dilu_m3']) * dilution)

# calculate imported kg N, kg NH4-N, P2O5, K2O, OS per t or per m3
# solid manure
m_import['sman_kgNpt'] = []
m_import['sman_kgNH4_Npt'] = []
m_import['sman_kgP2O5pt'] = []
m_import['sman_kgK2Opt'] = []
m_import['sman_kgOSpt'] = []
for metal in metals:
    m_import['sman_mg'+metal+'pkg'] = []

for manure_type in m_import['manure_type']:
    m_import['sman_kgNpt'].append(get_value('AM: N after storage',   manure_type))
    m_import['sman_kgNH4_Npt'].append(get_value('AM: kg NH4-N/unit', manure_type))
    m_import['sman_kgP2O5pt'].append(get_value('AM: P2O5',           manure_type))
    m_import['sman_kgK2Opt'].append(get_value('AM: K2O',             manure_type))
    m_import['sman_kgOSpt'].append(get_value('AM: OS',               manure_type))
    for metal in metals:  # HM contents per kg (fresh mass)
        m_import['sman_mg'+metal+'pkg'].append(get_hm_cont(metal+'_content', manure_type))

# liquid manure
m_import['lman_kgNpm3'] = []
m_import['lman_kgNH4_Npm3'] = []
m_import['lman_kgP2O5pm3'] = []
m_import['lman_kgK2Opm3'] = []
m_import['lman_kgOSpm3'] = []
for metal in metals:
    m_import['lman_mg'+metal+'pkg'] = []

for slurry_type in m_import['slurry_type']:
    m_import['lman_kgNpm3'].append(get_value('AM: N after storage', slurry_type))
    m_import['lman_kgNH4_Npm3'].append(get_value('AM: kg NH4-N/unit', slurry_type))
    m_import['lman_kgP2O5pm3'].append(get_value('AM: P2O5', slurry_type))
    m_import['lman_kgK2Opm3'].append(get_value('AM: K2O', slurry_type))
    m_import['lman_kgOSpm3'].append(get_value('AM: OS', slurry_type))
    for metal in metals:
        m_import['lman_mg'+metal+'pkg'].append(get_hm_cont(metal+'_content', slurry_type))

# assign manure classes for produced manure
m_production['manure_class_s'] = []
m_production['manure_class_l'] = []
for i in m_production['animal_type']:
    sman_type = tab_ls.loc[tab_ls['NameEN'] == i,
                              'Manure solid'].values[0]
    sman_class = tab_manure.loc[tab_manure['NameEN'] == sman_type,
                              'Module'].values[0]
    lman_type = tab_ls.loc[tab_ls['NameEN'] == i,
                              'Manure liquid'].values[0]
    lman_class = tab_manure.loc[tab_manure['NameEN'] == lman_type,
                              'Module'].values[0]
    m_production['manure_class_s'].append(sman_class)
    m_production['manure_class_l'].append(lman_class)
    del sman_type, lman_type, sman_class, lman_class


null_dc = {
    # dictionary with default values and without manure type
    'f_02_impo_t': 0,
    'sman_kgN': 0,
    'sman_kgNH4_N': 0,
    'sman_kgP2O5': 0,
    'sman_kgK2O': 0,
    'sman_kgOS': 0,
    'production_sman_kgN': 0,
    'production_sman_kgP2O5': 0,
    'production_sman_kgK2O': 0,
    'production_sman_kgNH4_N': 0,
    'production_sman_kgOS': 0,
    'f_02_impo_m3': 0,
    'lman_kgN': 0,
    'lman_kgNH4_N': 0,
    'lman_kgP2O5': 0,
    'lman_kgK2O': 0,
    'lman_kgOS': 0,
    'production_lman_kgN': 0,
    'production_lman_kgP2O5': 0,
    'production_lman_kgK2O': 0,
    'production_lman_kgNH4_N': 0,
    'production_lman_kgOS': 0
}
for metal in metals:  # add HM variables
    null_dc['sman_mg'+metal] = 0
    null_dc['lman_mg'+metal] = 0
    null_dc['production_sman_mg'+metal] = 0
    null_dc['production_lman_mg'+metal] = 0


# List of all manure types in the table.
ls_manure_classes = set(tab_manure['Module'].values)

manure_data = {}
for manure_class in ls_manure_classes:
    manure_data[manure_class] = copy.deepcopy(null_dc)
    manure_data[manure_class]['manure_class'] = manure_class


# assign imported inputs to manure data
for i, manure_class in enumerate(m_import['manure_class_s']):
    manure_data[manure_class]['f_02_impo_t'] += m_import[
        'f_02_impo_t'][i]
    manure_data[manure_class]['sman_kgN'] += m_import[
        'f_02_impo_t'][i]*m_import['sman_kgNpt'][i]
    manure_data[manure_class]['sman_kgNH4_N'] += m_import[
        'f_02_impo_t'][i]*m_import['sman_kgNH4_Npt'][i]
    manure_data[manure_class]['sman_kgP2O5'] += m_import[
        'f_02_impo_t'][i]*m_import['sman_kgP2O5pt'][i]
    manure_data[manure_class]['sman_kgK2O'] += m_import[
        'f_02_impo_t'][i]*m_import['sman_kgK2Opt'][i]
    manure_data[manure_class]['sman_kgOS'] += m_import[
        'f_02_impo_t'][i]*m_import['sman_kgOSpt'][i]
    for metal in metals:  # HMs in mg. Convert from kg to t
        manure_data[manure_class]['sman_mg'+metal] += m_import[
        'f_02_impo_t'][i]*m_import['sman_mg'+metal+'pkg'][i]*1000

for i, manure_class in enumerate(m_import['manure_class_l']):
    manure_data[manure_class]['f_02_impo_m3'] += m_import[
        'f_02_impo_m3'][i]
    manure_data[manure_class]['lman_kgN'] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_kgNpm3'][i]
    manure_data[manure_class]['lman_kgNH4_N'] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_kgNH4_Npm3'][i]
    manure_data[manure_class]['lman_kgP2O5'] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_kgP2O5pm3'][i]
    manure_data[manure_class]['lman_kgK2O'] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_kgK2Opm3'][i]
    manure_data[manure_class]['lman_kgOS'] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_kgOSpm3'][i]
    for metal in metals:  # HMs in mg. Convert from kg to m3
        manure_data[manure_class]['lman_mg'+metal] += m_import[
        'f_02_impo_m3'][i]*m_import['lman_mg'+metal+'pkg'][i]*1000

# assign produced inputs to manure data
for i, manure_class in enumerate(m_production['manure_class_s']):
    manure_data[manure_class]['production_sman_kgN'] += m_production[
                              'production_sman_kgN'][i]
    manure_data[manure_class]['production_lman_kgN'] += m_production[
                              'production_lman_kgN'][i]
    manure_data[manure_class]['production_sman_kgNH4_N'] += m_production[
                              'production_sman_kgNH4_N'][i]
    manure_data[manure_class]['production_lman_kgNH4_N'] += m_production[
                              'production_lman_kgNH4_N'][i]
    manure_data[manure_class]['production_sman_kgP2O5'] += m_production[
                              'production_sman_kgP2O5'][i]
    manure_data[manure_class]['production_lman_kgP2O5'] += m_production[
                              'production_lman_kgP2O5'][i]
    manure_data[manure_class]['production_sman_kgK2O'] += m_production[
                              'production_sman_kgK2O'][i]
    manure_data[manure_class]['production_lman_kgK2O'] += m_production[
                              'production_lman_kgK2O'][i]
    manure_data[manure_class]['production_sman_kgOS'] += m_production[
                              'production_sman_kgOS'][i]
    manure_data[manure_class]['production_lman_kgOS'] += m_production[
                              'production_lman_kgOS'][i]
    for metal in metals:  # HMs in mg
        manure_data[manure_class]['production_sman_mg'+metal] += m_production[
        'production_sman_mg'+metal][i]
        manure_data[manure_class]['production_lman_mg'+metal] += m_production[
        'production_lman_mg'+metal][i]

# proportion of liquid, solid and total manure for individual manure classes

# %% Total manure =============================================================
manure_total = {}
manure_total['sman_expo_t'] = m_export['sman_expo_t']
manure_total['sman_spreading_t'] = m_spreading['sman_spreading_t']
manure_total['sman_output_t'] = (m_export['sman_expo_t']
                                 + m_spreading['sman_spreading_t'])
manure_total['sman_output_kgN'] = 0
manure_total['sman_output_kgNH4_N'] = 0
manure_total['sman_output_kgP2O5'] = 0
manure_total['sman_output_kgK2O'] = 0
manure_total['sman_output_kgOS'] = 0
manure_total['lman_expo_m3'] = m_export['lman_expo_m3']
manure_total['lman_spreading_m3'] = m_spreading['lman_spreading_m3']
manure_total['lman_output_m3'] = (m_export['lman_expo_m3']
                                  + m_spreading['lman_spreading_m3'])
manure_total['lman_output_kgN'] = 0
manure_total['lman_output_kgNH4_N'] = 0
manure_total['lman_output_kgP2O5'] = 0
manure_total['lman_output_kgK2O'] = 0
manure_total['lman_output_kgOS'] = 0

for metal in metals:  # HMs in mg
    manure_total['sman_output_mg'+metal] = 0
    manure_total['lman_output_mg'+metal] = 0

# calculate the total N after storage, NH4-N, P2O5, K2O [kg], HMs [mg]
for manure_class in ls_manure_classes:
    manure_total['sman_output_kgN'] += (manure_data[manure_class]['production_sman_kgN']
                                      + manure_data[manure_class]['sman_kgN'])
    manure_total['lman_output_kgN'] += (manure_data[manure_class]['production_lman_kgN']
                                      + manure_data[manure_class]['lman_kgN'])
    manure_total['sman_output_kgNH4_N'] += (manure_data[manure_class]['production_sman_kgNH4_N']
                                          + manure_data[manure_class]['sman_kgNH4_N'])
    manure_total['lman_output_kgNH4_N'] += (manure_data[manure_class]['production_lman_kgNH4_N']
                                          + manure_data[manure_class]['lman_kgNH4_N'])
    manure_total['sman_output_kgP2O5'] += (manure_data[manure_class]['production_sman_kgP2O5']
                                         + manure_data[manure_class]['sman_kgP2O5'])
    manure_total['lman_output_kgP2O5'] += (manure_data[manure_class]['production_lman_kgP2O5']
                                         + manure_data[manure_class]['lman_kgP2O5'])
    manure_total['sman_output_kgK2O'] += (manure_data[manure_class]['production_sman_kgK2O']
                                        + manure_data[manure_class]['sman_kgK2O'])
    manure_total['lman_output_kgK2O'] += (manure_data[manure_class]['production_lman_kgK2O']
                                        + manure_data[manure_class]['lman_kgK2O'])
    manure_total['sman_output_kgOS'] += (manure_data[manure_class]['production_sman_kgOS']
                                        + manure_data[manure_class]['sman_kgOS'])
    manure_total['lman_output_kgOS'] += (manure_data[manure_class]['production_lman_kgOS']
                                        + manure_data[manure_class]['lman_kgOS'])
    for metal in metals:  # HMs Unit: mg
        manure_total['sman_output_mg'+metal] += \
                                    (manure_data[manure_class]['production_sman_mg'+metal]
                                   + manure_data[manure_class]['sman_mg'+metal])
        manure_total['lman_output_mg'+metal] += \
                                    (manure_data[manure_class]['production_lman_mg'+metal]
                                   + manure_data[manure_class]['lman_mg'+metal])

# calculate the contents after storage for N, NH4-N, P2O5, K2O (kg/t, kg/m3), HMs [mg/t]
for manure_class in ls_manure_classes:
    if manure_total['sman_output_t'] > 0:
        manure_total['sman_kgNpt'] = (manure_total['sman_output_kgN']
                                      / manure_total['sman_output_t'])
        manure_total['sman_kgNH4_Npt'] = (manure_total['sman_output_kgNH4_N']
                                          / manure_total['sman_output_t'])
        manure_total['sman_kgP2O5pt'] = (manure_total['sman_output_kgP2O5']
                                         / manure_total['sman_output_t'])
        manure_total['sman_kgK2Opt'] = (manure_total['sman_output_kgK2O']
                                        / manure_total['sman_output_t'])
        manure_total['sman_kgOSpt'] = (manure_total['sman_output_kgOS']
                                        / manure_total['sman_output_t'])
        for metal in metals:  # HMs in mg
            manure_total['sman_mg'+metal+'pkg'] = \
                                        (manure_total['sman_output_mg'+metal]
                                       /(manure_total['sman_output_t']*1000))
                                        # convert from t to kg
    else:
        manure_total['sman_kgNpt'] = 0
        manure_total['sman_kgNH4_Npt'] = 0
        manure_total['sman_kgP2O5pt'] = 0
        manure_total['sman_kgK2Opt'] = 0
        manure_total['sman_kgOSpt'] = 0
        for metal in metals:  # HMs Unit: mg
            manure_total['sman_mg'+metal+'pkg'] = 0

    if manure_total['lman_output_m3'] > 0:
        manure_total['lman_kgNpm3'] = (manure_total['lman_output_kgN']
                                       / manure_total['lman_output_m3'])
        manure_total['lman_kgNH4_Npm3'] = (manure_total['lman_output_kgNH4_N']
                                           / manure_total['lman_output_m3'])
        manure_total['lman_kgP2O5pm3'] = (manure_total['lman_output_kgP2O5']
                                          / manure_total['lman_output_m3'])
        manure_total['lman_kgK2Opm3'] = (manure_total['lman_output_kgK2O']
                                         / manure_total['lman_output_m3'])
        manure_total['lman_kgOSpm3'] = (manure_total['lman_output_kgOS']
                                         / manure_total['lman_output_m3'])
        for metal in metals:  # HMs Unit: mg
            manure_total['lman_mg'+metal+'pkg'] = \
                                        (manure_total['lman_output_mg'+metal]
                                       /(manure_total['lman_output_m3']*1000))
    else:
        manure_total['lman_kgNpm3'] = 0
        manure_total['lman_kgNH4_Npm3'] = 0
        manure_total['lman_kgP2O5pm3'] = 0
        manure_total['lman_kgK2Opm3'] = 0
        manure_total['lman_kgOSpm3'] = 0
        for metal in metals:  # HMs in mg
            manure_total['lman_mg'+metal+'pkg'] = 0

keys = ('sman_kgNpt', 'sman_kgNH4_Npt', 'sman_kgP2O5pt', 'sman_kgK2Opt', 'sman_kgOSpt',
        'lman_kgNpm3', 'lman_kgNH4_Npm3', 'lman_kgP2O5pm3', 'lman_kgK2Opm3', 'lman_kgOSpm3')
nutrient_content = {k: manure_total[k] for k in keys}
logging.info('Nutrient contents of all farm manure: %s', nutrient_content)
logging.info('')

# write HM contents to dict
manu_HM_cont = {}
for metal in metals:
    # convert from mg/kg to mg/t. The HM balance is calculated in mg
    # negative values are set to 0 here. Negative HM contents in manure make no sense
    # and are presumably the result of an erroneous balance.
    manu_HM_cont['sman_mg'+metal+'pt']  = max(0, manure_total['sman_mg'+metal+'pkg']*1000)
    manu_HM_cont['lman_mg'+metal+'pm3'] = max(0, manure_total['lman_mg'+metal+'pkg']*1000)

logging.info('Heavy metal contents of all farm manure (manu_HM_cont)= %s', manu_HM_cont)
logging.info('')

# calculate the exported N after storage, NH4-N, P2O5, K2O [kg], HMs [mg]
for manure_class in ls_manure_classes:
    manure_total['exported_Nstor_s'] = (manure_total['sman_expo_t']
                                        * manure_total['sman_kgNpt'])
    manure_total['exported_Nstor_l'] = (manure_total['lman_expo_m3']
                                        * manure_total['lman_kgNpm3'])
    manure_total['exported_nh4n_s'] = (manure_total['sman_expo_t']
                                       * manure_total['sman_kgNH4_Npt'])
    manure_total['exported_nh4n_l'] = (manure_total['lman_expo_m3']
                                       * manure_total['lman_kgNH4_Npm3'])
    manure_total['exported_p2o5_s'] = (manure_total['sman_expo_t']
                                       * manure_total['sman_kgP2O5pt'])
    manure_total['exported_p2o5_l'] = (manure_total['lman_expo_m3']
                                       * manure_total['lman_kgP2O5pm3'])
    manure_total['exported_k2o_s'] = (manure_total['sman_expo_t']
                                      * manure_total['sman_kgK2Opt'])
    manure_total['exported_k2o_l'] = (manure_total['lman_expo_m3']
                                      * manure_total['lman_kgK2Opm3'])
    manure_total['exported_OS_s'] = (manure_total['sman_expo_t']
                                       * manure_total['sman_kgOSpt'])
    manure_total['exported_OS_l'] = (manure_total['lman_expo_m3']
                                       * manure_total['lman_kgOSpm3'])
    for metal in metals:  # HMs Unit: mg. *1000 convert t to kg
        manure_total['exported_mg'+metal+'_s'] = (manure_total['sman_expo_t']
                                       * manure_total['sman_mg'+metal+'pkg']*1000)
        manure_total['exported_mg'+metal+'_l'] = (manure_total['lman_expo_m3']
                                       * manure_total['lman_mg'+metal+'pkg']*1000)

# calculate the spread N after storage, NH4-N, P2O5, K2O (kg), HMs [mg]
for manure_class in ls_manure_classes:
    manure_total['spread_Nstor_s'] = (manure_total['sman_spreading_t']
                                      * manure_total['sman_kgNpt'])
    manure_total['spread_Nstor_l'] = (manure_total['lman_spreading_m3']
                                      * manure_total['lman_kgNpm3'])
    manure_total['spread_nh4n_s'] = (manure_total['sman_spreading_t']
                                     * manure_total['sman_kgNH4_Npt'])
    manure_total['spread_nh4n_l'] = (manure_total['lman_spreading_m3']
                                     * manure_total['lman_kgNH4_Npm3'])
    manure_total['spread_p2o5_s'] = (manure_total['sman_spreading_t']
                                     * manure_total['sman_kgP2O5pt'])
    manure_total['spread_p2o5_l'] = (manure_total['lman_spreading_m3']
                                     * manure_total['lman_kgP2O5pm3'])
    manure_total['spread_k2o_s'] = (manure_total['sman_spreading_t']
                                    * manure_total['sman_kgK2Opt'])
    manure_total['spread_k2o_l'] = (manure_total['lman_spreading_m3']
                                    * manure_total['lman_kgK2Opm3'])
    manure_total['spread_OS_s'] = (manure_total['sman_spreading_t']
                                    * manure_total['sman_kgOSpt'])
    manure_total['spread_OS_l'] = (manure_total['lman_spreading_m3']
                                    * manure_total['lman_kgOSpm3'])
    for metal in metals:  # HMs Unit: mg. *1000 convert t to kg
        manure_total['spread_mg'+metal+'_s'] = (manure_total['sman_spreading_t']
                                     * manure_total['lman_mg'+metal+'pkg']*1000)
        manure_total['spread_mg'+metal+'_l'] = (manure_total['lman_spreading_m3']
                                     * manure_total['sman_mg'+metal+'pkg']*1000)


# %% proportion of liquid, solid and total manure for individual ==============
# manure classes, relative to NH4-N
# avoid division by zero
for manure_class in ls_manure_classes:
    # (import kg NH4-N (manure class)
    # + production kg NH4-N (manure class))
    # / kg NH4-N from manure output total
    manure_data[manure_class]['lman_frac_NH4_N'] = (
        (manure_data[manure_class]['lman_kgNH4_N']
         + manure_data[manure_class]['production_lman_kgNH4_N'])
        / non0(manure_total['lman_output_kgNH4_N']))
    manure_data[manure_class]['sman_frac_NH4_N'] = (
        (manure_data[manure_class]['sman_kgNH4_N']
         + manure_data[manure_class]['production_sman_kgNH4_N'])
        / non0(manure_total['sman_output_kgNH4_N']))
    manure_data[manure_class]['total_man_frac_NH4_N'] = (
        (manure_data[manure_class]['sman_kgNH4_N']
         + manure_data[manure_class]['production_sman_kgNH4_N']
         + manure_data[manure_class]['lman_kgNH4_N']
         + manure_data[manure_class]['production_lman_kgNH4_N'])
        / non0(manure_total['sman_output_kgNH4_N'] + manure_total['lman_output_kgNH4_N']))


# %% EF NH3 ===================================================================
# setup for the emission factors, weighted mean by animal class
EF_nh3_l = 0
EF_nh3_s = 0
for manure_class in ls_manure_classes:
    EF_nh3_l += (manure_data[manure_class]['lman_frac_NH4_N']
                 * tab_EF_NH3.loc[tab_EF_NH3['manure class'] == manure_class,
                                  'EF_liquid']
                 * tab_pars['Value']['reduction_liquid']).values[0]
    EF_nh3_s += (manure_data[manure_class]['sman_frac_NH4_N']
                 * tab_EF_NH3.loc[tab_EF_NH3['manure class'] == manure_class,
                                  'EF_solid']
                 * tab_pars['Value']['reduction_solid']).values[0]

# %% NH4-N per animal class in solid manure ===================================
# need to split up due to different EFs
cattle_kgNH4_N = 0
pigs_kgNH4_N = 0
poul_kgNH4_N = 0
others_kgNH4_N = 0

for manure_type in manure_data.keys():
    if manure_type in ['total_l', 'total_s']:
        continue
    # (production kg NH4-N (animal class)
    # + import kg NH4-N (animal class)) /
    # kg NH4-N total from this manure type.
    if manure_data[manure_type]['manure_class'] == 'Cattle':
        cattle_kgNH4_N += manure_data[manure_type]['production_sman_kgNH4_N'] + \
            manure_data[manure_type]['sman_kgNH4_N']
    elif manure_data[manure_type]['manure_class'] == 'Pigs':
        pigs_kgNH4_N += manure_data[manure_type]['production_sman_kgNH4_N'] + \
            manure_data[manure_type]['sman_kgNH4_N']
    elif manure_data[manure_type]['manure_class'] == 'Poultry':
        poul_kgNH4_N += manure_data[manure_type]['production_sman_kgNH4_N'] + \
            manure_data[manure_type]['sman_kgNH4_N']
    else:
        others_kgNH4_N += manure_data[manure_type]['production_sman_kgNH4_N'] + \
            manure_data[manure_type]['sman_kgNH4_N']
sum_kgNH4_N = cattle_kgNH4_N + pigs_kgNH4_N + poul_kgNH4_N + others_kgNH4_N


# %% output ===================================================================
# Manure summary
if sum_kgNH4_N == 0:
    out.f_sman_NH4N_from_cattle_perc = 0
    out.f_sman_NH4N_from_pigs_perc = 0
    out.f_sman_NH4N_from_poul_perc = 0
    out.f_sman_NH4N_from_others_perc = 0
else:
    out.f_sman_NH4N_from_cattle_perc = cattle_kgNH4_N/sum_kgNH4_N
    out.f_sman_NH4N_from_pigs_perc = pigs_kgNH4_N/sum_kgNH4_N
    out.f_sman_NH4N_from_poul_perc = poul_kgNH4_N/sum_kgNH4_N
    out.f_sman_NH4N_from_others_perc = others_kgNH4_N/sum_kgNH4_N

out.f_lman_kgNpm3 = manure_total['lman_kgNpm3']
out.f_sman_kgNpt = manure_total['sman_kgNpt']

out.f_lman_kgTANpm3 = manure_total['lman_kgNH4_Npm3']
out.f_sman_kgTANpt = manure_total['sman_kgNH4_Npt']

out.f_lman_kgP2O5pm3 = manure_total['lman_kgP2O5pm3']
out.f_sman_kgP2O5pt = manure_total['sman_kgP2O5pt']

out.f_lman_kgK2Opm3 = manure_total['lman_kgK2Opm3']
out.f_sman_kgK2Opt = manure_total['sman_kgK2Opt']

out.f_lman_kgOSpm3 = manure_total['lman_kgOSpm3']
out.f_sman_kgOSpt = manure_total['sman_kgOSpt']

out.f_manu_HM_cont = js.dumps(manu_HM_cont)

out.f_ef_lman_frac = EF_nh3_l
out.f_ef_sman_frac = EF_nh3_s

out.f_lman_spreading_m3 = manure_total['lman_spreading_m3']
out.f_sman_spreading_t = manure_total['sman_spreading_t']

# Print spread manure amounts
logging.info('Spread amounts of liquid farm manure (whole farm)= %s m3', manure_total['lman_spreading_m3'])
logging.info('Spread amounts of solid farm manure (whole farm)= %s t', manure_total['sman_spreading_t'])
logging.info('')

# %% end sequence, print timestamp and duration

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)