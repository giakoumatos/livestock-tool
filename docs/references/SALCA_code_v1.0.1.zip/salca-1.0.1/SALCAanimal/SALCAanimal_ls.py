# -*- coding: utf-8 -*-
"""
File name: SALCAanimal_ls.py
Created on Wed Nov 27 10:41:04 2019

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script calculates emissions from livestock per animal group 
    as part of SALCAanimal.

Calculation level:
    Livestock

Related scripts: SALCAanimal_agrammon.py, SALCAanimal_farm.py
"""

# %% import modules and starting sequence =====================================
import datetime as dt
import json as js
import logging
import warnings as w
from importlib import reload
from sys import stderr

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAanimal_ls'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('livestock')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define classes ===========================================================

class AnimalGroup:
    # class to describe the characteristics of the covered animal type based
    # on the input parameters from the dictionary dc.

    def __init__(self, dc):
        self.__dc = dc  # copy of the dictonary for backup
        # animal type, python name of livestock category
        self.animal_type = dc['animal_type']
        # average annual ls_head
        self.ls_head = dc['ls_head']  # [heads]
        # animals sold and purchased
        self.live_weight_sold_kg = dc['live_weight_sold_kg']  # [kg]
        self.live_weight_purchase_kg = dc['live_weight_purchase_kg']  # [kg]
        # dry matter intake in the period
        self.feed_kgDM = dc['feed_kgDM']  # [kg]
        # gross energy from feeding
        self.feed_MJ = dc['feed_MJ']  # [MJ]
        # nitrogen from animal feed
        self.feed_kgN = dc['feed_kgN'] # [kg N]
        # phosphor from animal feed
        self.feed_kgP = dc['feed_kgP']  # [kg P]
        # potassium cfrom animal feed
        self.feed_kgK = dc['feed_kgK']  # [kg K]
        # HM in feed
        self.feed_mgHM = dc['feed_mgHM']  # HM in feed [mg]
        # feed digestibility [fraction]
        self.feed_digestibility_frac = dc['feed_digestibility_frac']
        # ash from animal feed
        self.feed_ash_kg = dc['feed_ash_kg']  # [kg]
        # raw fibre from animal feed
        self.feed_raw_fibre_kg = dc['feed_raw_fibre_kg']  # [kg]
        # NfE from animal feed
        self.feed_NfE_kg = dc['feed_NfE_kg']  # [kg]
        # raw lipid from animal feed
        self.feed_raw_lipid_kg = dc['feed_raw_lipid_kg']  # [kg]
        # self.feed_intake_grazing = dc['feed_intake_grazing']
        self.ls_grazing_N_perc = dc['ls_grazing_N_perc']
        # straw use
        self.ls_straw_use_kg = dc['ls_straw_use_kg']  # [kg]
        # live weight gain
        self.live_weight_gain = dc['live_weight_gain']  # [kg LW]
        # information about housing specifications according to animal class
        # different for cattle, pigs and poultry. otherwise 0
        self.ls_housing_frac = dc['ls_housing_frac']  # fraction
        # days per year in yard
        self.ls_yard_d = dc['ls_yard_d']  # days
        # hours in yard per day
        self.ls_yard_h = dc['ls_yard_h']  # hours/day
        # nuber of days grazing per year
        self.ls_past_d = dc['ls_past_d']  # days
        # number of hours grazing per day
        self.ls_past_h = dc['ls_past_h']  # hours/day
        # number of days grazing in march, april, may
        self.ls_past_mar_may_d = dc['ls_past_mar_may_d']  # days
        # number of days grazing in june, july, august
        self.ls_past_jun_aug_d = dc['ls_past_jun_aug_d']  # days
        # number of days grazing in september, october, november
        self.ls_past_sep_nov_d = dc['ls_past_sep_nov_d']  # days
        # number of days grazing in december, january, february
        self.ls_past_dec_feb_d = dc['ls_past_dec_feb_d']  # days
        # proportion N in liquid manure, [%/100]
        self.ls_lman_N_frac = dc['ls_lman_N_perc']  # fraction
        # sold cow milk
        self.sold_cow_milk_kg = dc['sold_cow_milk_kg']  # kg
        # sold sheep milk
        self.sold_sheep_milk_kg = dc['sold_sheep_milk_kg']  # kg
        # sold sheep wool
        self.sold_sheep_wool_kg = dc['sold_sheep_wool_kg']  # kg
        # sold goat milk
        self.sold_goat_milk_kg = dc['sold_goat_milk_kg']  # kg
        # sold horse milk
        self.sold_horse_milk_kg = dc['sold_horse_milk_kg']  # kg
        # sold eggs
        self.sold_eggs_kg = dc['sold_eggs_kg']  # kg


# %% define functions =========================================================
def read_pars(path): 
    """ read CSV file with parameters from path """
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab

def read_table(path): 
    """ read CSV file with a table from path """
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    # in all tables start at line 7, i.e. skip 6 lines (header)
    return tab


def get_value(table, col, name):
    """ return a value from a table, match on col 'Name' """
    try:
        value = table[col][table['NameEN'] == name].values[0]
    except:
        value = table[col][table['Name'] == name].values[0]
    return value


def get_value_n(tab_n, col, name):
    """ return a value from a table, match on col 'livestock' """
    value = tab_n[col][tab_n['Livestock'] == name].values
    return value


def get_hm_cont(tab_hm, tab_ls, metal, name):
    """ get the hm content from tab_hm
        for metal
        by looking up the flow name (hm_mapping) from table tab_ls
        get HM_mapping from tab_ls """
    hm_mapping = tab_ls.loc[tab_ls['NameEN'] == name]['HM_mapping'].values[0]
    # get hm_content from tab_hm
    hm_content = tab_hm.loc[tab_hm['NameEN'] == hm_mapping][metal+'_content'].values[0]
    return hm_content


def unpack_dc(dc):
    """ Unpack a dataframe, which was dumped into a string.
        input: the string containing the dataframe
        this includes information about index and column names. """
    import pandas as pd
    import json as js
    return pd.DataFrame(data=js.loads(dc)['data'],
                        columns=js.loads(dc)['columns'],
                        index=js.loads(dc)['index'])


def non0(value):
    """ avoid division by zero. Returns 1 for value=0 """
    if value == 0:
        non_zero_value = 1
    else:
        non_zero_value = value
    return non_zero_value


def feed_info(key, ls_feed_type, ls_feed_DM_kg, tab_feed):
    ''' calculates the weighted digestibility resp. the weighted 
        nutrient amounts extract for all feedstuffs:
        key: keyword --> column header of the requested parameter
        ls_feed_type: list of all feedstuff types (roughage+suppl.feed)
        ls_feed_DM_kg: list of DM amounts for all feedstuffs (roughage+suppl.feed)
        tab_feed: table with nutrient contents of feedstuffs
    '''
    output = 0.0
    for i, feed_type in enumerate(ls_feed_type):
        # for digestibility (in %) return the weighted average of
        # digestibility of the used feed types.
        if key == 'AM: digestibility cattle' or key == 'AM: digestibility pigs':
            digest_value = tab_feed.loc[tab_feed['NameEN']
                                             == feed_type][key].values[0]
            if digest_value == 'na':
                digestibility = 0.0  # if 'na', set to 0
            else:
                digestibility = float(digest_value)
            output += digestibility/100 * ls_feed_DM_kg[i]/non0(sum(ls_feed_DM_kg))
        else:
            # if anything but digestibility is concerned,
            # calculate the total nutrient intake:
            nutrient_content = float(tab_feed.loc[tab_feed['NameEN']
                                             == feed_type][key].values[0])
            # add to the output in kg of the concerned content
            output += nutrient_content * ls_feed_DM_kg[i]
    return output

def get_hm(metal, ls_feed_type, ls_feed_DM_kg, tab_feed, tab_hm):
    """ Calculate the HM flows by looking up the HM content and multiplying it
        by the dry mass """
    hm_flow = 0.0  # the flow of 'metal'
    # get HM_mapping
    for i, feed_type in enumerate(ls_feed_type):
        # get the name of the hm flow
        hm_mapping = tab_feed.loc[tab_feed['NameEN'] == feed_type]['HM_mapping'].values[0]
        # get the hm content [mg]
        hm_content = tab_hm.loc[tab_hm['NameEN'] == hm_mapping][metal].values[0]
        # calculate the hm flow
        hm_flow += ls_feed_DM_kg[i] * hm_content
    return hm_flow

def replace_none_in_list(in_list):
    """ replace all None values in a list with 0. """
    import copy
    # make a copy of the list
    out_list = copy.deepcopy(in_list)
    for i, element in enumerate(in_list):
        if element == None:
            out_list[i] = 0
    return out_list


# %% input for preparation ====================================================
logging.info("Start time of preparation part %s", dt.datetime.now(tz=None))

# python name of the animal type
animal_type = ctx.livestock.livestock_definition_name
animal_name = ctx.livestock.livestock_name
animal_id = ctx.livestock.livestock_id

# load input from SALCAprep_farm
f_salcaprep = js.loads(inp.f_salcaprep)
# mean annual temperature [°C]
f_temp_annual_degC = f_salcaprep['mean_temperature']
# enum selection of NH3 model. 1=EMEP/EEA or 2=Agrammon
f_model_NH3 = inp.f_model_NH3
# Model for CH4 emissions from enteric fermentation of dairy cows:
# IPCC, Kirchgessner (enum selection)
f_model_CH4 = inp.f_model_CH4
# Methane emission correction factor for mitigation measure modelling and sensitivity analysis
cf_ch4_animal = inp.ls_cf_digest_CH4

# duration of assessment period:
ls_duration = dt.datetime.strptime(inp.f_end_evaluation, '%Y-%m-%d') -\
dt.datetime.strptime(inp.f_start_evaluation, '%Y-%m-%d')

# number of animals
ls_head = inp.ls_head
# LW gain/loss in the assessment period [kg]
ls_gain_kg = inp.ls_gain_kg
# weight of imported animals (list)
ls_impo_kg = [variable['ls_02_impo_kg']
              for variable in inp.get_events('ls_import_livestock')]
# weight of exported animals (list)
ls_expo_kg = [variable['ls_02_expo_kg']
              for variable in inp.get_events('ls_export_livestock')]
# python names of used animal roughage feed types (list)
ls_rough_type = [variable['ls_01_rofe_type']
                for variable in inp.get_events('ls_feedstuff_r')]
# amounts of used animal roughage feed, (list) [kg]
ls_rough_amount_kg = [variable['ls_02_amts_kg']
                     for variable in inp.get_events('ls_feedstuff_r')]
# python names of used animal supplementary feed types (list)
ls_suppl_type = [variable['ls_01_sufe_type']
                for variable in inp.get_events('ls_feedstuff_s')]
# amounts of used animal supplementary feed (list) [kg]
ls_suppl_amount_kg = [variable['ls_02_amfs_kg']
                     for variable in inp.get_events('ls_feedstuff_s')]
# python names of exported animal product types (list)
ls_expo_anpr_vari = [variable['ls_01_anpr_vari']
                     for variable in inp.get_events('ls_export_animal_p')]
""" depending on the selected product, only weight (eggs, wool) or
    volume (all types of milk) is used for the particular instance
    of the event. """
# amounts of exported animal product, kg (list)
ls_expo_anpr_kg = [variable['ls_02_anpr_kg']
                   for variable in inp.get_events('ls_export_animal_p')]
# straw use in the period [kg]
ls_straw_use_kg = inp.ls_straw_use_kg
# number of days in the yard [day]
ls_yard_d = inp.ls_yard_d
# mean daily number of hours in yard [h/day]
ls_yard_h = inp.ls_yard_h
# mean daily number of hours on pasture [h/day]
ls_past_h = inp.ls_past_h
# number of days on pasture, march - may [day]
ls_past_mar_may_d = inp.ls_past_mar_may_d
# number of days on pasture, june - august [day]
ls_past_jun_aug_d = inp.ls_past_jun_aug_d
# number of days on pasture, september - november [day]
ls_past_sep_nov_d = inp.ls_past_sep_nov_d
# number of days on pasture, december - february [day]
ls_past_dec_feb_d = inp.ls_past_dec_feb_d
# relative N content of feed from grazing 
# compared to the average N content of the whole year [%/100]
ls_grazing_N_perc = inp.ls_grazing_N_perc
# relative N content in liquid manure [%/100]
ls_lman_N_perc = inp.ls_lman_N_perc
# relative amount of cattle in yard/on litter [%/100]
ls_housing_cattle_perc = inp.ls_housing_cattle_perc
# relative amount of fattening pigs in yard/on litter [%/100]
ls_housing_pigs_perc = inp.ls_housing_pigs_perc
# relative amount of poultry with manure belt with drying [%/100]
ls_housing_poul_perc = inp.ls_housing_poul_perc
# relative amount of liquid manure with biogas production [%/100]
f_lman_digester_perc = inp.f_lman_digester_perc
# relative amount of solid manure with composting [%/100]
f_sman_compost_perc = inp.f_sman_compost_perc
# Correction factor manure storage, CH4 [%/100]
f_cf_manu_stor_CH4 = inp.f_cf_manu_stor_CH4
# relative amount of liquid manure with natural crust [%/100]
f_manu_crust_perc = inp.f_manu_crust_perc
# relative amount of liquid manure with pit storage [%/100]
f_pit_stor_perc = inp.f_pit_stor_perc

# %% read tables ==============================================================
# table for animal fodder
tab_feed = unpack_dc(inp.tab_feed)
# livestock table
tab_ls = unpack_dc(inp.tab_ls)
# HM contents. Needed for preparation and calculation.
tab_hm = unpack_dc(inp.tab_hm)
# load the table for animal products. Milk, wool,... Needed for preparation and calculation.
tab_anpr = unpack_dc(inp.tab_anpr)


# load the parameter file SALCAanimal_pars from csv file
tab_pars = read_pars('SALCAanimal_pars.csv')

# load the table with EFs on pasture from csv file
tab_pasture_N = read_table('Pasture_N.csv').set_index('Variable')

# load EFs for NH3 from csv file
if f_model_NH3 == 'EMEP/EEA':
    tab_nh3 = read_table('EF_NH3_EEA.csv')
elif f_model_NH3 == 'Agrammon':
    tab_nh3 = read_table('EF_NH3_Agrammon.csv')
tab_nh3.fillna(0, inplace=True)

# load EFs for N2O from csv file
tab_n2o = read_table('EF_N2O.csv')
tab_n2o.fillna(0, inplace=True)

# %% calculation of preparation ===============================================
# The added livestock categories need to be changed to their parent categories
if 'livestock_cattle_other_' in animal_type:
    animal_type = 'livestock_cattle_other'
elif animal_type == 'livestock_pigs_piglets':
    animal_type = 'livestock_pigs_breeding'

# number of days on the pasture for the whole year [day]
ls_past_d =   (ls_past_dec_feb_d
             + ls_past_mar_may_d
             + ls_past_jun_aug_d
             + ls_past_sep_nov_d)

# replace None values in lists with 0
ls_expo_kg = replace_none_in_list(ls_expo_kg)
ls_impo_kg = replace_none_in_list(ls_impo_kg)
# mass of imported animals of the current livestock type [kg]
live_weight_purchase_kg = sum(ls_impo_kg)
# mass of exported animals of the current livestock type [kg]
live_weight_sold_kg = sum(ls_expo_kg)

# Calculate the feed amounts and average nutrient contents
# derive list with DM contents
ls_DM_content_r = [0.0]*len(ls_rough_type)  # define list with required length
for i, feed_type in enumerate(ls_rough_type):
    ls_DM_content_r[i] = 1.0  # for roughage, values are given in dry matter
    
ls_DM_content_s = [0.0]*len(ls_suppl_type)
for i, feed_type in enumerate(ls_suppl_type):
    # for suppl. feed, values are given in fresh matter (FM). Get DM content
    ls_DM_content_s[i] = tab_feed.loc[tab_feed['NameEN'] == feed_type]['DM_content'].values[0]
    
ls_DM_contents = ls_DM_content_r + ls_DM_content_s  # join the two lists
ls_feed_type = ls_rough_type + ls_suppl_type  # join the two lists
total_amount_kg = ls_rough_amount_kg + ls_suppl_amount_kg  # list of raw feed amounts

# list of feed DM input
ls_feed_DM_kg = [0.0]*len(ls_feed_type)
for i, feed_type in enumerate(ls_feed_type):
    ls_feed_DM_kg[i] = total_amount_kg[i] * ls_DM_contents[i]

# sum of dry mass of the used animal feed [kg DM]
feed_kgDM = sum(ls_feed_DM_kg)
# gross energy intake [MJ]
feed_MJ = feed_info('AM: gross energy', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# N intake [kg N]
feed_kgN = feed_info('AM: nitrogen content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# P intake [kg P]
feed_kgP = feed_info('AM: phosphorus content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# K intake [kg K]
feed_kgK = feed_info('AM: potassium content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# average digestibility of the used animal feed for cattle
# (weighted average) [%/100]
feed_digestibility_cattle_frac = feed_info('AM: digestibility cattle', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# average digestibility of the used animal feed for non-cattle
# (weighted average) [%/100]
feed_digestibility_others_frac = feed_info('AM: digestibility pigs', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# ash intake [kg ash]
feed_ash_kg = feed_info('AM: ash content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# raw fibre intake [kg]
feed_raw_fibre_kg = feed_info('AM: raw fibre content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# NfE intake [kg nfe]
feed_NfE_kg = feed_info('AM: NfE content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)
# raw lipid intake [kg]
feed_raw_lipid_kg = feed_info('AM: raw lipid content', ls_feed_type,
                      ls_feed_DM_kg, tab_feed)

# get HM flows of feed into dict feed_mgHM
metals = ['Cd', 'Cu', 'Zn', 'Pb', 'Ni', 'Cr', 'Hg']
feed_mgHM = {}
for metal in metals:
    feed_mgHM[metal] = get_hm(metal+'_content', ls_feed_type, \
                              ls_feed_DM_kg, tab_feed, tab_hm)

# empty table for animal products
df_product = pd.DataFrame({'product': ['001 Cow milk', '004 Horse milk',
                                       '006 Eggs', '002 Sheep milk',
                                       '005 Sheep wool', '003 Goat milk'],
                           'amount kg': [0, 0, 0, 0, 0, 0]})
# add the exported animal products to the prepared table
for i, product in enumerate(ls_expo_anpr_vari):
    amount_kg = ls_expo_anpr_kg[i]
    df_product.loc[df_product['product'] == product,
                   'amount kg'] += amount_kg

# amount of sold products [kg]
sold_cow_milk_kg = df_product.loc[df_product['product'] == '001 Cow milk',
                                  'amount kg'].values[0]
sold_horse_milk_kg = df_product.loc[df_product['product'] == '004 Horse milk',
                                    'amount kg'].values[0]
sold_eggs_kg = df_product.loc[df_product['product'] == '006 Eggs',
                              'amount kg'].values[0]
sold_sheep_milk_kg = df_product.loc[df_product['product'] == '002 Sheep milk',
                                    'amount kg'].values[0]
sold_sheep_wool_kg = df_product.loc[df_product['product'] == '005 Sheep wool',
                                    'amount kg'].values[0]
sold_goat_milk_kg = df_product.loc[df_product['product'] == '003 Goat milk',
                                   'amount kg'].values[0]

# animal group in SALCAanimal
animal_group = tab_ls.loc[tab_ls['NameEN'] == animal_type,
                          'Name SALCAanimal'].values[0]
# Assign parameters according to the animal group
if animal_group in ['Dairy cows', 'Other cattle', 'Dairy cows, tied housing']:
    ls_housing_perc = ls_housing_cattle_perc
    feed_digestibility_frac = feed_digestibility_cattle_frac
elif animal_group in ['Sheep', 'Goats', 'Horses (and mules, asses)', 'Other ruminants']:
    ls_housing_perc = 0
    feed_digestibility_frac = feed_digestibility_cattle_frac
elif animal_group in ['Fattening pigs', 'Sows']:
    ls_housing_perc = ls_housing_pigs_perc
    feed_digestibility_frac = feed_digestibility_others_frac
elif animal_group in ['Laying hens', 'Broilers', 'Turkeys', 'Ducks', 'Geese']:
    ls_housing_perc = ls_housing_poul_perc
    feed_digestibility_frac = feed_digestibility_others_frac
else:  # Other non-ruminants
    ls_housing_perc = 0
    feed_digestibility_frac = feed_digestibility_others_frac

# ls_housing_perc is already a fraction
ls_housing_frac = ls_housing_perc

# %% output of preparation part ===============================================

salcaanimal_prep = {
    'f_model_NH3': f_model_NH3,
    'f_model_CH4': f_model_CH4,
    'ls_duration_days': ls_duration.days,
    'annual_temp': f_temp_annual_degC,
    'animal_type': animal_type,
    'animal_id': animal_id,
    'ls_head': ls_head,
    'live_weight_purchase_kg': live_weight_purchase_kg,
    'live_weight_sold_kg': live_weight_sold_kg,
    'live_weight_gain': ls_gain_kg,
    'feed_kgDM': feed_kgDM,
    'feed_MJ': feed_MJ,
    'feed_kgN': feed_kgN,
    'feed_kgP': feed_kgP,
    'feed_kgK': feed_kgK,
    'feed_mgHM': feed_mgHM,
    'feed_digestibility_frac': feed_digestibility_frac,
    'feed_ash_kg': feed_ash_kg,
    'feed_raw_fibre_kg': feed_raw_fibre_kg,
    'feed_NfE_kg': feed_NfE_kg,
    'feed_raw_lipid_kg': feed_raw_lipid_kg,
    'ls_grazing_N_perc': ls_grazing_N_perc,
    'ls_straw_use_kg': ls_straw_use_kg,
    'ls_yard_d': ls_yard_d,
    'ls_yard_h': ls_yard_h,
    'ls_past_d': ls_past_d,
    'ls_past_h': ls_past_h,
    'ls_past_mar_may_d': ls_past_mar_may_d,
    'ls_past_jun_aug_d': ls_past_jun_aug_d,
    'ls_past_sep_nov_d': ls_past_sep_nov_d,
    'ls_past_dec_feb_d': ls_past_dec_feb_d,
    'sold_cow_milk_kg': sold_cow_milk_kg,
    'sold_horse_milk_kg': sold_horse_milk_kg,
    'sold_eggs_kg': sold_eggs_kg,
    'sold_sheep_milk_kg': sold_sheep_milk_kg,
    'sold_sheep_wool_kg': sold_sheep_wool_kg,
    'sold_goat_milk_kg': sold_goat_milk_kg,
    'ls_housing_frac': ls_housing_frac,
    'ls_lman_N_perc': ls_lman_N_perc,
    'f_manu_crust_perc': f_manu_crust_perc,
    'f_pit_stor_perc': f_pit_stor_perc,
    'f_lman_digester_perc': f_lman_digester_perc,
    'f_sman_compost_perc': f_sman_compost_perc,
    'f_cf_manu_stor_CH4': f_cf_manu_stor_CH4
}

for key in salcaanimal_prep:
    if type(salcaanimal_prep[key]) == np.int64:
        salcaanimal_prep[key] = float(salcaanimal_prep[key])

logging.info('salcaanimal_prep: %s', salcaanimal_prep)
logging.info("End time of preparation part %s", dt.datetime.now(tz=None))

# %% input of calculation =====================================================
logging.info("Start time of calculation part %s", dt.datetime.now(tz=None))
# mean annual temperature [°C]
in_mean_annual_temp = salcaanimal_prep['annual_temp']
# enum selection of NH3 model. 1=EMEP/EEA or 2=Agrammon
f_model_NH3 = salcaanimal_prep['f_model_NH3']
# Model for CH4 emissions from enteric fermentation of dairy cows:
# 1=IPCC, 2=Kirchgessner (enum selection)
f_model_CH4 = salcaanimal_prep['f_model_CH4']

dc = {
    'animal_type': salcaanimal_prep['animal_type'],
    'ls_head': salcaanimal_prep['ls_head'],
    'live_weight_purchase_kg': salcaanimal_prep['live_weight_purchase_kg'],
    'live_weight_sold_kg': salcaanimal_prep['live_weight_sold_kg'],
    'live_weight_gain': salcaanimal_prep['live_weight_gain'],
    'feed_kgDM': salcaanimal_prep['feed_kgDM'],
    'feed_MJ': salcaanimal_prep['feed_MJ'],
    'feed_kgN': salcaanimal_prep['feed_kgN'],
    'feed_kgP': salcaanimal_prep['feed_kgP'],
    'feed_kgK': salcaanimal_prep['feed_kgK'],
    'feed_mgHM': salcaanimal_prep['feed_mgHM'],
    'feed_digestibility_frac': salcaanimal_prep['feed_digestibility_frac'],
    'feed_ash_kg': salcaanimal_prep['feed_ash_kg'],
    'feed_raw_fibre_kg': salcaanimal_prep['feed_raw_fibre_kg'],
    'feed_NfE_kg': salcaanimal_prep['feed_NfE_kg'],
    'feed_raw_lipid_kg': salcaanimal_prep['feed_raw_lipid_kg'],
    'ls_grazing_N_perc': salcaanimal_prep['ls_grazing_N_perc'],
    'ls_straw_use_kg': salcaanimal_prep['ls_straw_use_kg'],
    'ls_yard_d': salcaanimal_prep['ls_yard_d'],
    'ls_yard_h': salcaanimal_prep['ls_yard_h'],
    'ls_past_d': salcaanimal_prep['ls_past_d'],
    'ls_past_h': salcaanimal_prep['ls_past_h'],
    'ls_past_mar_may_d': salcaanimal_prep['ls_past_mar_may_d'],
    'ls_past_jun_aug_d': salcaanimal_prep['ls_past_jun_aug_d'],
    'ls_past_sep_nov_d': salcaanimal_prep['ls_past_sep_nov_d'],
    'ls_past_dec_feb_d': salcaanimal_prep['ls_past_dec_feb_d'],
    'sold_cow_milk_kg': salcaanimal_prep['sold_cow_milk_kg'],
    'sold_horse_milk_kg': salcaanimal_prep['sold_horse_milk_kg'],
    'sold_eggs_kg': salcaanimal_prep['sold_eggs_kg'],
    'sold_sheep_milk_kg': salcaanimal_prep['sold_sheep_milk_kg'],
    'sold_sheep_wool_kg': salcaanimal_prep['sold_sheep_wool_kg'],
    'sold_goat_milk_kg': salcaanimal_prep['sold_goat_milk_kg'],
    'ls_housing_frac': salcaanimal_prep['ls_housing_frac'],
    'ls_lman_N_perc': salcaanimal_prep['ls_lman_N_perc']
}

# derive information from infrastructure
infrastructure = {
    # fraction of manure storage covered by a liquid crust
    'f_manu_crust_perc': salcaanimal_prep['f_manu_crust_perc'],
    # fraction of manure stored in pit storage
    'f_pit_stor_perc': salcaanimal_prep['f_pit_stor_perc'],
    # fraction of liquid manure with anaerobic digester
    'f_lman_digester_perc': salcaanimal_prep['f_lman_digester_perc'],
    # fraction of solid manure with composting
    'f_sman_compost_perc': salcaanimal_prep['f_sman_compost_perc'],
    # correction factor CH4 for manure storage
    'f_cf_manu_stor_CH4': salcaanimal_prep['f_cf_manu_stor_CH4']
}
# load results from SALCAanimal_agrammon
c_agrammon = js.loads(inp.f_agrammon)


# %% Setup ====================================================================

# load the information about the animals into the class structure
animal = AnimalGroup(dc)
# extract the type of animal class
animal.animal_class = get_value(tab_ls, 'Name SALCAanimal',
                                animal.animal_type
                                )
# derive the type of liquid and solid manure produced by the animal class
manure_type_liq = get_value(tab_ls, 'Manure liquid',
                            animal.animal_type
                            )
manure_type_sol = get_value(tab_ls, 'Manure solid',
                            animal.animal_type
                            )
# Differentiate between Dairy cows loose housing and Dairy cows tied housing.
if (animal.animal_class == 'Dairy cows') and (animal.ls_housing_frac == 0):
    animal.animal_class = 'Dairy cows, tied housing'
# processing of NfE, raw lipids, raw fibre only for dairy cows
if animal.animal_class not in ['Dairy cows', 'Dairy cows, tied housing']:
    animal.feed_NfE_kg = 0
    animal.feed_raw_lipid_kg = 0
    animal.feed_raw_fibre_kg = 0


# %% Calculation ==============================================================

# %% Nutrient Balance =========================================================
# Gross energy intake
animal.intake_energy = animal.feed_MJ  # [MJ]
# N intake
animal.intake_N = animal.feed_kgN  # [kg N]
# P intake
animal.intake_P = animal.feed_kgP  # [kg P]
# K intake
animal.intake_K = animal.feed_kgK  # [kg K]
# HM intake
metals = ['Cd', 'Cu', 'Zn', 'Pb', 'Ni', 'Cr', 'Hg']  # list of metals
animal.intake_HM = {}
for metal in metals:
    animal.intake_HM[metal] = animal.feed_mgHM[metal]  #[mg]

# Nutrient contents of imported and exported animals
animal.animal_content_N = get_value(tab_ls, 'N_content',
                                    animal.animal_type)  # [kg N/kg LW]
animal.animal_content_P = get_value(tab_ls, 'P_content',
                                    animal.animal_type)  # [kg P/kg LW]
animal.animal_content_K = get_value(tab_ls, 'K_content',
                                    animal.animal_type)  # [kg K/kg LW]
animal.animal_content_HM = {}
straw_content_HM = {}
for metal in metals:  # HM contents [mg] of animals and straw
    animal.animal_content_HM[metal] = get_hm_cont(tab_hm, tab_ls, metal, animal.animal_type)
    # take 'wheat straw' as proxy for straw
    straw_content_HM[metal] = tab_hm.loc[tab_hm['NameEN'] \
                            == 'wheat straw'][metal+'_content'].values[0]

# Purchased animals N, P, K, HM
animal.purchased_animal_N = (animal.live_weight_purchase_kg
                             * animal.animal_content_N)  # [kg N]
animal.purchased_animal_P = (animal.live_weight_purchase_kg
                             * animal.animal_content_P)  # [kg P]
animal.purchased_animal_K = (animal.live_weight_purchase_kg
                             * animal.animal_content_K)  # [kg K]
animal.purchased_animal_HM = {}
for metal in metals:  # HM flows
    animal.purchased_animal_HM[metal] = (animal.live_weight_purchase_kg
                                       * animal.animal_content_HM[metal])  # [mg HM]
# exported animals
animal.sold_animal_N = animal.live_weight_sold_kg * animal.animal_content_N  # [kg N]
animal.sold_animal_P = animal.live_weight_sold_kg * animal.animal_content_P  # [kg P]
animal.sold_animal_K = animal.live_weight_sold_kg * animal.animal_content_K  # [kg K]
animal.sold_animal_HM = {}
for metal in metals:  # HM flows
    animal.sold_animal_HM[metal] = (animal.live_weight_sold_kg
                                  * animal.animal_content_HM[metal])  # [mg HM]
# Live weight gain [kg N/P/K/HM]
animal.growth_animal_N = animal.live_weight_gain * animal.animal_content_N
animal.growth_animal_P = animal.live_weight_gain * animal.animal_content_P
animal.growth_animal_K = animal.live_weight_gain * animal.animal_content_K
animal.growth_animal_HM = {}
for metal in metals:
    animal.growth_animal_HM[metal] = (animal.live_weight_gain
                                  * animal.animal_content_HM[metal])

# exported products [kg N/P/K]
animal.nutrient_cow_milk = np.array([
    get_value(tab_anpr, 'N content',
              '001 Cow milk')*animal.sold_cow_milk_kg,
    get_value(tab_anpr, 'P content',
              '001 Cow milk')*animal.sold_cow_milk_kg,
    get_value(tab_anpr, 'K content',
              '001 Cow milk')*animal.sold_cow_milk_kg
])
animal.nutrient_sheep_milk = np.array([
    get_value(tab_anpr, 'N content',
              '002 Sheep milk')*animal.sold_sheep_milk_kg,
    get_value(tab_anpr, 'P content',
              '002 Sheep milk')*animal.sold_sheep_milk_kg,
    get_value(tab_anpr, 'K content',
              '002 Sheep milk')*animal.sold_sheep_milk_kg
])
animal.nutrient_goat_milk = np.array([
    get_value(tab_anpr, 'N content',
              '003 Goat milk')*animal.sold_goat_milk_kg,
    get_value(tab_anpr, 'P content',
              '003 Goat milk')*animal.sold_goat_milk_kg,
    get_value(tab_anpr, 'K content',
              '003 Goat milk')*animal.sold_goat_milk_kg
])
animal.nutrient_horse_milk = np.array([
    get_value(tab_anpr, 'N content',
              '004 Horse milk')*animal.sold_horse_milk_kg,
    get_value(tab_anpr, 'P content',
              '004 Horse milk')*animal.sold_horse_milk_kg,
    get_value(tab_anpr, 'K content',
              '004 Horse milk')*animal.sold_horse_milk_kg
])
animal.nutrient_sheep_wool = np.array([
    get_value(tab_anpr, 'N content',
              '005 Sheep wool')*animal.sold_sheep_wool_kg,
    get_value(tab_anpr, 'P content',
              '005 Sheep wool')*animal.sold_sheep_wool_kg,
    get_value(tab_anpr, 'K content',
              '005 Sheep wool')*animal.sold_sheep_wool_kg
])
animal.nutrient_eggs = np.array([
    get_value(tab_anpr, 'N content',
              '006 Eggs')*animal.sold_eggs_kg,
    get_value(tab_anpr, 'P content',
              '006 Eggs')*animal.sold_eggs_kg,
    get_value(tab_anpr, 'K content',
              '006 Eggs')*animal.sold_eggs_kg
])

# exported products [mg HM]
animal.HM_cow_milk = {}  # initialize dicts
animal.HM_sheep_milk = {}
animal.HM_goat_milk = {}
animal.HM_horse_milk = {}
animal.HM_sheep_wool = {}
animal.HM_eggs = {}
for metal in metals:
    animal.HM_cow_milk[metal]   = (get_hm_cont(tab_hm, tab_anpr, metal, '001 Cow milk')
                                   * animal.sold_cow_milk_kg)
    animal.HM_sheep_milk[metal] = (get_hm_cont(tab_hm, tab_anpr, metal, '002 Sheep milk')
                                   * animal.sold_sheep_milk_kg)
    animal.HM_goat_milk[metal]  = (get_hm_cont(tab_hm, tab_anpr, metal, '003 Goat milk')
                                   * animal.sold_goat_milk_kg)
    animal.HM_horse_milk[metal] = (get_hm_cont(tab_hm, tab_anpr, metal, '004 Horse milk')
                                   * animal.sold_horse_milk_kg)
    animal.HM_sheep_wool[metal] = (get_hm_cont(tab_hm, tab_anpr, metal, '005 Sheep wool')
                                   * animal.sold_sheep_wool_kg)
    animal.HM_eggs[metal]       = (get_hm_cont(tab_hm, tab_anpr, metal, '006 Eggs')
                                   * animal.sold_eggs_kg)

# Fraction of time spent on pasture
animal._past_frac = (animal.ls_past_d/365 * animal.ls_past_h/24)
# Fraction of time spent in yard
animal._yard_frac = (animal.ls_yard_d/365 * animal.ls_yard_h/24)

# Fraction of days with grazing
animal._grazing_frac_days = animal.ls_past_d/365

# nutrients exported: animal sales+growth+products.
# Growth is considered as export, growth can be negative
animal.exported_N = (animal.sold_animal_N
                     + animal.growth_animal_N
                     + animal.nutrient_cow_milk[0]
                     + animal.nutrient_sheep_milk[0]
                     + animal.nutrient_goat_milk[0]
                     + animal.nutrient_horse_milk[0]
                     + animal.nutrient_sheep_wool[0]
                     + animal.nutrient_eggs[0]
                     )  # kg N
animal.exported_P = (animal.sold_animal_P
                     + animal.growth_animal_P
                     + animal.nutrient_cow_milk[1]
                     + animal.nutrient_sheep_milk[1]
                     + animal.nutrient_goat_milk[1]
                     + animal.nutrient_horse_milk[1]
                     + animal.nutrient_sheep_wool[1]
                     + animal.nutrient_eggs[1]
                     )  # kg P
animal.exported_K = (animal.sold_animal_K
                     + animal.growth_animal_K
                     + animal.nutrient_cow_milk[2]
                     + animal.nutrient_sheep_milk[2]
                     + animal.nutrient_goat_milk[2]
                     + animal.nutrient_horse_milk[2]
                     + animal.nutrient_sheep_wool[2]
                     + animal.nutrient_eggs[2]
                     )  # kg K
animal.exported_HM = {}
for metal in metals:  # HM flows [mg]
    animal.exported_HM[metal] = \
                     ( animal.sold_animal_HM[metal]
                     + animal.growth_animal_HM[metal]
                     + animal.HM_cow_milk[metal]
                     + animal.HM_sheep_milk[metal]
                     + animal.HM_goat_milk[metal]
                     + animal.HM_horse_milk[metal]
                     + animal.HM_sheep_wool[metal]
                     + animal.HM_eggs[metal]
                     )
# Nutrient excreted: intake + purchased animals - exports
animal.excreted_N = (animal.intake_N
                     + animal.purchased_animal_N
                     - animal.exported_N
                     )  # kg N
animal.excreted_P = (animal.intake_P
                     + animal.purchased_animal_P
                     - animal.exported_P
                     )  # kg P
animal.excreted_K = (animal.intake_K
                     + animal.purchased_animal_K
                     - animal.exported_K
                     )  # kg K
animal.excreted_HM = {}
for metal in metals:  # HM flows [mg], only excretion in housing and yard, DMI on pasture subtracted
    animal.excreted_HM[metal] = \
                     ( animal.intake_HM[metal] * (1-animal._past_frac)
                     + animal.purchased_animal_HM[metal]
                     - animal.exported_HM[metal]
                     )

# %% housing ==================================================================
# Correction factor NH3 for housing emissions on grazing days
if animal.ls_past_h < 5:
    nh3_temp = 1.1 - 1
elif animal.ls_past_h < 12:
    nh3_temp = 1.4 - 1
elif animal.ls_past_h < 22:
    nh3_temp = 2 - 1
elif animal.ls_past_h < 24:
    nh3_temp = 2.5 - 1
else:  # animal.ls_past_h = 24
    nh3_temp = 1 - 1
# temporal weight eventually by fraction on evaluated days
# correction factor for both agrammon and EMEP/EEA
animal.corr_nh3_hous = nh3_temp * animal._grazing_frac_days+1

# %% manure management ========================================================
# fraction of time spent on Pasture/Range/Paddock/Dry lot
animal._ms_past_drylot = animal._yard_frac + animal._past_frac
# Fraction of organic substance in liquid manure storage total
animal._ms_os_in_liq = ((1 - animal._ms_past_drylot)
                        * animal.ls_lman_N_frac
                        * min(1, tab_pars['Value']['corr_OS_cattle']))
# Fraction of organic substance in solid manure storage total.
animal._ms_os_in_solid = 1 - animal._ms_past_drylot - animal._ms_os_in_liq

if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Other cattle',
                           'Fattening pigs', 'Sows'
                           ]:
    # fraction in solid manure storage
    animal._ms_solid_stor = ((1-animal.ls_housing_frac)  #tied/conventional housing
                             * animal._ms_os_in_solid
                             * (1-infrastructure['f_sman_compost_perc']))
    # fraction in pit storage (liquid)
    animal._ms_pit_stor = (animal._ms_os_in_liq
                           * (1-infrastructure['f_lman_digester_perc']))
    # fraction in anaerobic digester (liquid)
    animal._ms_anaer_digest = (animal._ms_os_in_liq
                                     * infrastructure['f_lman_digester_perc'])
    # fraction in deep bedding (solid manure storage)
    animal._ms_deep_bedding = (animal._ms_os_in_solid
                               * animal.ls_housing_frac)
    # fraction of composting (solid)
    animal._ms_composting = (infrastructure['f_sman_compost_perc']
                             * animal._ms_os_in_solid
                             * (1-animal.ls_housing_frac))
else:  # no liquid manure assumed for these animal classes
    # fraction in solid manure storage
    animal._ms_solid_stor = (animal._ms_os_in_solid
                             * (1-infrastructure['f_sman_compost_perc']))
    # fraction in pit storage (liquid)
    animal._ms_pit_stor = 0
    # fraction in anaerobic digester (liquid)
    animal._ms_anaer_digest = 0
    # fraction in deep bedding (solid manure storage)
    animal._ms_deep_bedding = 0
    # fraction of composting (solid)
    animal._ms_composting = (infrastructure['f_sman_compost_perc']
                             * animal._ms_os_in_solid)

if animal.animal_class in ['Laying hens,',
                           'Poultry', 'Broilers', 'Ducks', 'Geese']:
    # fraction of solid manure storage for poultry
    animal._ms_poultry = animal._ms_os_in_solid - animal._ms_composting
    # fraction in solid manure storage (non-poultry)
    animal._ms_solid_stor = 0
else:
    # fraction of solid manure storage for poultry
    animal._ms_poultry = 0

# sum of all fractions of pathways in organic substance
animal._ms_total = (animal._ms_past_drylot
                    + animal._ms_solid_stor
                    + animal._ms_pit_stor
                    + animal._ms_anaer_digest
                    + animal._ms_deep_bedding
                    + animal._ms_composting
                    + animal._ms_poultry)
# should add to 1
if animal._ms_total != 1:
    # otherwise: print warning
    w.warn('Manure system does not add up to 1')
    stderr.flush()
    logging.info("Sum of all manure systems: %d", animal._ms_total)
    logging.info("animal._ms_past_drylot: %d", animal._ms_past_drylot)
    logging.info("animal._ms_solid_stor: %d", animal._ms_solid_stor)
    logging.info("animal._ms_pit_stor: %d", animal._ms_pit_stor)
    logging.info("animal._ms_anaer_digest: %d", animal._ms_anaer_digest)
    logging.info("animal._ms_deep_bedding: %d", animal._ms_deep_bedding)
    logging.info("animal._ms_composting: %d", animal._ms_composting)
    logging.info("animal._ms_poultry: %d", animal._ms_poultry)

animal.f_cf_manu_stor_CH4 = infrastructure['f_cf_manu_stor_CH4']

# additional calculations manure
infrastructure['liq_manure_without_crust'] = (
    1 - infrastructure['f_manu_crust_perc']
    - infrastructure['f_pit_stor_perc']
    - infrastructure['f_lman_digester_perc']
)
infrastructure['solid_storage'] = max([0, 1
                                       - animal.ls_housing_frac
                                       - infrastructure['f_sman_compost_perc']
                                       ])

# %% CH4 emissions ===========================================================
# Methane conversion factor Ym []
animal.table_ch4_factor_Ym = get_value(tab_ls,
                                       'CH4 Ym',
                                       animal.animal_type
                                       )
# IPCC 2019, Tier 2 method, Table 10.12, p. 10.48, Ym factor
if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing']:
    # check digestibility and raw fibre content to assign CH4 conversion
    # factor Ym for dairy cows
    if animal.feed_digestibility_frac >= 0.7:
        if animal.feed_raw_fibre_kg < 0.35:
            animal.table_ch4_factor_Ym = 0.057
        else:
            animal.table_ch4_factor_Ym = 0.06
    elif animal.feed_digestibility_frac >= 0.62:
        animal.table_ch4_factor_Ym = 0.063
    else:
        animal.table_ch4_factor_Ym = 0.065
elif animal.animal_class == 'Other cattle':
    # check digestibility and raw fibre content to assign Methane conversion
    # factor Ym for other cattle
    if animal.feed_digestibility_frac >= 0.75:
        animal.table_ch4_factor_Ym = 0.03
    elif animal.feed_digestibility_frac >= 0.72:
        animal.table_ch4_factor_Ym = 0.04
    elif animal.feed_digestibility_frac >= 0.62:
        animal.table_ch4_factor_Ym = 0.063
    else:
        animal.table_ch4_factor_Ym = 0.07

# Maximum methane producing capacity B0 [m3 CH4/kg VS]
animal._ch4_b0 = get_value(tab_ls, 'B0', animal.animal_type)
# UE*GE, given as fraction (0.02 or 0.04)
animal._ch4_ue_ge = float(get_value(tab_ls, '(UE*GE)', animal.animal_type))
# CH4 emissions from enteric fermentation, Kirchgessner (2004), only for
# dairy cows
if (animal.ls_head > 0) and (animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing']):
    # Only for positive populations of Dairy Cows
    # Feed intake [kg DM/cow/year]
    animal.feed_per_animal = animal.feed_kgDM / non0(animal.ls_head)
    # base [kg CH4/year]
    animal._ch4_kirchgessner_base = tab_pars['Value']['ch4_kirchgessner_base']
else:
    animal.feed_per_animal = 0  # [kg DM/head/year]
    animal._ch4_kirchgessner_base = 0

animal.ch4_vol_solids = (animal.intake_energy
                      * (1 - animal.feed_digestibility_frac + animal._ch4_ue_ge)
                      * (1 - animal.feed_ash_kg/non0(animal.feed_kgDM))
                         / non0(tab_pars['Value']['gec_dm'])
                        )  # kg VS/year, VS=Volatile solids excretion (org. matter in manure)

animal.ch4_em_IPPC = (animal.feed_MJ
                      * animal.table_ch4_factor_Ym
                      / non0(tab_pars['Value']['ch4_ec'])
                      )  # [kg CH4/year], CH4 emissions

animal._crude_protein = animal.feed_kgN * tab_pars['Value']['n2protein']  # kg protein
# Parameters for Kirchgessner formula, conversion to kg/cow/day
animal._crude_protein_kgpd = animal._crude_protein/(animal.ls_head*365)
animal._raw_fibre_kgpd = animal.feed_raw_fibre_kg/(animal.ls_head*365)
animal._NfE_kgpd = animal.feed_NfE_kg/(animal.ls_head*365)
animal._raw_lipid_kgpd = animal.feed_raw_lipid_kg/(animal.ls_head*365)

animal.ch4_em_kirchgessner_1 = (animal._ch4_kirchgessner_base
                                + (tab_pars['Value']['ch4_kirchgessner_protein']
                                   * animal._crude_protein_kgpd
                                   + tab_pars['Value']['ch4_kirchgessner_fibre']
                                   * animal._raw_fibre_kgpd
                                   + tab_pars['Value']['ch4_kirchgessner_nfe']
                                   * animal._NfE_kgpd
                                   - tab_pars['Value']['ch4_kirchgessner_lipid']
                                   * animal._raw_lipid_kgpd)
                                ) * 365 / 1000  # kg CH4/cow/year
animal.ch4_em_kirchgessner_2 = (animal.ch4_em_kirchgessner_1
                                * animal.ls_head
                                )  # kg CH4/year, total CH4 emissions
animal.ch4_em_used = animal.ch4_em_IPPC  # [kg CH4/year]
# alternative model for dairy cows
if ((animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing'])
        and (f_model_CH4 == 'Kirchgessner')):
    # alternative model for dairy cows
    animal.ch4_em_used = animal.ch4_em_kirchgessner_2  # [kg CH4/year]
# CH4 emissions from manure management [kg CH4/year]
animal.ch4_em_man_mag = (animal.ch4_vol_solids
                         * (animal._ch4_b0*tab_pars['Value']['ch4_dens'])
                         * (animal._ms_past_drylot
                            * tab_pars['Value']['ch4_mcf_drylot']
                            + animal._ms_solid_stor
                            * tab_pars['Value']['ch4_mcf_solid_stor']
                            + animal._ms_pit_stor
                            * tab_pars['Value']['ch4_mcf_pit_stor']
                            + animal._ms_anaer_digest
                            * tab_pars['Value']['ch4_mcf_digest']
                            + animal._ms_deep_bedding
                            * tab_pars['Value']['ch4_mcf_bedding']
                            + animal._ms_composting
                            * tab_pars['Value']['ch4_mcf_composting']
                            + animal._ms_poultry
                            * tab_pars['Value']['ch4_mcf_poultry']
                            )
                         * animal.f_cf_manu_stor_CH4
                         )
# Modification of animal methane emissions by a correction factor 
# for mitigation measure modelling and sensitivity analysis
if cf_ch4_animal != 1:
    logging.info('Correction factor for animal CH4 emissions has been applied!')
    logging.info(f'Animal category: \"{animal_type}\", named: \"{animal_name}\"')
    logging.info('animal CH4 emission before correction: %d',animal.ch4_em_used)
animal.ch4_em_used = animal.ch4_em_used * cf_ch4_animal
if cf_ch4_animal != 1:
    logging.info('animal CH4 emission after correction: %d',animal.ch4_em_used)
# CH4 emissions total
ch4_total = animal.ch4_em_used + animal.ch4_em_man_mag   # [kg CH4/year]
# Calculate OS in manure for soil quality
# C in manure excreted (before losses) [kg C]
c_man1 = animal.ch4_vol_solids * tab_pars['Value']['c_cont_man']
# C in manure after storage (subtract losses by CH4 and CO2) [kg C]
c_man2 = c_man1 - animal.ch4_em_man_mag/tab_pars['Value']['c2ch4'] \
    - animal.ch4_vol_solids*tab_pars['Value']['ef_co2_man']/tab_pars['Value']['c2co2']
# OS in manure [kg OS]
os_man = c_man2/tab_pars['Value']['c_cont_man']

# %% N emissions ==============================================================
# All N emissions are calculated as kg N.
# The conversion to NH3, N2O, NOx, NO3 is done in the Output section at the end

# %% distribution of excreted nutrients & total excretion =====================
# Proportion N in solid manure
animal._sman_N_frac = 1 - animal.ls_lman_N_frac
# proportion liquid manure storage (corrected for pasture)
animal._man_l_stor_frac1 = (animal.ls_lman_N_frac
                            * (1-animal._past_frac))
# proportion liquid manure storage (corrected for pasture and yard)
animal._man_l_stor_frac2 = (animal.ls_lman_N_frac
                            * (1-animal._past_frac
                               - animal._yard_frac))
# proportion solid manure storage (corrected for pasture)
animal._man_s_stor_frac1 = (animal._sman_N_frac
                            * (1-animal._past_frac))
# proportion solid manure storage (corrected for pasture and yard)
animal._man_s_stor_frac2 = (animal._sman_N_frac
                            * (1-animal._past_frac
                               - animal._yard_frac))
# N content of feed during whole year [kg N/kg DM]
animal.feed_nc_total = animal.feed_kgN/non0(animal.feed_kgDM)
# for cattle
if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Other cattle'
                           ]:

    # Correction for N content feed on pasture [kg N/kg DM]
    animal.feed_nc_past = animal.feed_nc_total * animal.ls_grazing_N_perc
    # Correction for N content feed in housing and yard [kg N/kg DM]
    # avoid division by 0
    if ((1-animal._past_frac) * animal.feed_nc_total) == 0:
        animal.feed_nc_yard_housing = 0
    else:
        animal.feed_nc_yard_housing = (animal.feed_nc_total
                                       * (1-animal._past_frac
                                          * animal.ls_grazing_N_perc)
                                       / (1-animal._past_frac)
                                       )

    # proportion N excreted as urine/dung whole year / on pasture / in yard
    # feed_nc multiplied by 100 to convert from fraction to %
    animal._n_excret_year_liq = min([70, max([30, animal.feed_nc_total * 100
                                              * tab_pars['Value']['n_nc2prop1']
                                              - tab_pars['Value']['n_nc2prop2']
                                              ])])/100
    animal._n_excret_year_sol = 1 - animal._n_excret_year_liq
    # proportion N excreted as urine/dung on pasture
    animal._n_excret_past_liq = min([70, max([30, animal.feed_nc_past * 100
                                              * tab_pars['Value']['n_nc2prop1']
                                              - tab_pars['Value']['n_nc2prop2']
                                              ])])/100
    animal._n_excret_past_sol = 1 - animal._n_excret_past_liq
    # proportion N excreted as urine/dung in housing and yard
    animal._n_excret_housing_yard_liq = min(
        [70, max([30, (animal.feed_nc_yard_housing * 100
                       * tab_pars['Value']['n_nc2prop1']
                       - tab_pars['Value']['n_nc2prop2']
                       )])])/100
    animal._n_excret_housing_yard_sol = 1 - animal._n_excret_housing_yard_liq
    # N excreted on pasture
    animal._nex_past = (animal.excreted_N * animal._past_frac
                        * animal.ls_grazing_N_perc)
    # N excreted in yard
    rel_nc_yard_housing = animal.feed_nc_yard_housing / \
        non0(animal.feed_nc_total)
    animal._nex_yard = (animal.excreted_N * animal._yard_frac
                        * rel_nc_yard_housing)
    # liquid excretion
    # N excreted per manure type
    animal._le_N = (animal._man_l_stor_frac2
                    * animal.excreted_N
                    * rel_nc_yard_housing)
    # solid excretion (dung)
    # N excreted per manure type
    animal._se_N = (animal._man_s_stor_frac2
                    * animal.excreted_N
                    * rel_nc_yard_housing)

# for all other animal classes than cattle
else:
    # N excreted on pasture
    animal._nex_past = (animal._past_frac * animal.excreted_N)
    # N excreted in yard
    animal._nex_yard = (animal._yard_frac * animal.excreted_N)
    # liquid excretion
    # N excreted per manure type
    animal._le_N = (animal._man_l_stor_frac2
                    * animal.excreted_N)
    # solid excretion (dung)
    # N excreted per manure type
    animal._se_N = (animal._man_s_stor_frac2
                    * animal.excreted_N)
# Check N balance
animal.check_N = (animal.excreted_N
                  - animal._nex_past
                  - animal._nex_yard
                  - animal._le_N
                  - animal._se_N)
animal.check_N_relative = (animal._past_frac
                           + animal._yard_frac
                           + animal._man_l_stor_frac2
                           + animal._man_s_stor_frac2
                           )
if (abs(animal.check_N) > 1e-12) or (animal.check_N_relative != 1):
    w.warn('N out of balance (check N != 0)')
    stderr.flush()
    logging.info('animal.check_N_relative= %d', animal.check_N_relative)


# %% Straw input ==============================================================
animal._se_straw_HM_in = {}
animal._le_straw_HM_in = {}
if animal._sman_N_frac > 0:  # if there is solid manure, straw goes to solid manure
    animal._se_straw_N_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_N']
    animal._se_straw_P_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_P']
    animal._se_straw_K_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_K']
    animal._se_straw_OS_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_OS']
    animal._le_straw_N_in = 0.0
    animal._le_straw_P_in = 0.0
    animal._le_straw_K_in = 0.0
    animal._le_straw_OS_in = 0.0
    for metal in metals:  # straw HM input [mg]
        animal._se_straw_HM_in[metal] = animal.ls_straw_use_kg * straw_content_HM[metal]
        animal._le_straw_HM_in[metal] = 0.0
else:  # if there is no solid manure, straw goes to liquid manure
    animal._se_straw_N_in = 0.0
    animal._se_straw_P_in = 0.0
    animal._se_straw_K_in = 0.0
    animal._se_straw_OS_in = 0.0
    animal._le_straw_N_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_N']
    animal._le_straw_P_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_P']
    animal._le_straw_K_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_K']
    animal._le_straw_OS_in = animal.ls_straw_use_kg * tab_pars['Value']['straw_OS']
    for metal in metals:  # straw HM input [mg]
        animal._se_straw_HM_in[metal] = 0.0
        animal._le_straw_HM_in[metal] = animal.ls_straw_use_kg * straw_content_HM[metal]

# %% TAN ======================================================================
if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Calf', 'Other cattle'
                           ]:
    # Assumes 100% of urine N and 20% of dung N (Kirchmann & Witter, 1989) being soluble :
    frac_TAN_liq = (animal._n_excret_year_liq
                    + 0.2*animal._n_excret_year_sol)
    frac_TAN_sol = frac_TAN_liq
else:
    frac_TAN_liq = get_value_n(tab_nh3,
                               'proportion of TAN',
                               animal.animal_class)[0]
    frac_TAN_sol = get_value_n(tab_nh3,
                               'proportion of TAN',
                               animal.animal_class)[-1]

if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Calf', 'Other cattle',
                           'Fattening pigs', 'Sows',
                           'Laying hens'
                           ]:
    frac_TAN = frac_TAN_liq
else:
    frac_TAN = frac_TAN_sol

# %% N mineralisation / immobilisation of N in manure =========================
if f_model_NH3 == 'EMEP/EEA':
    mineralisation_liq = tab_pars['Value']['min_liq_EEA']
    immobilisation_sol = min([1, max([0, (tab_pars['Value']['imm_sol_EEA']*animal.ls_straw_use_kg
                                          / non0(animal._se_N*frac_TAN_sol))])])
elif f_model_NH3 == 'Agrammon':
    mineralisation_liq = tab_pars['Value']['min_liq_Agr']
    immobilisation_sol = tab_pars['Value']['imm_sol_Agr']


# %% EF N2O from manure store =================================================
key_pit_stor = 'Pit storage below animal confinements'
ef_e_air_kgN2O_man_stor_list = get_value_n(tab_n2o, 'Without natural crust',
                                           animal.animal_class)
if len(ef_e_air_kgN2O_man_stor_list) == 2:
    ef_e_air_kgN2O_man_stor_liq = (infrastructure['f_manu_crust_perc']
                                   * get_value_n(tab_n2o, 'With natural crust',
                                                 animal.animal_class)[0]
                                   + infrastructure['f_pit_stor_perc']
                                   * get_value_n(tab_n2o,
                                                 key_pit_stor,
                                                 animal.animal_class)[0]
                                   + (1 - infrastructure['f_manu_crust_perc']
                                      - get_value_n(tab_n2o,
                                                    key_pit_stor,
                                                    animal.animal_class)[0])
                                   * get_value_n(tab_n2o, 'With natural crust',
                                                 animal.animal_class)[0]
                                   )  # EF manure storage used, liquid [kg N2O-N/kg TAN]
    ef_e_air_kgN2O_man_stor_sol = ef_e_air_kgN2O_man_stor_list[1]
else:
    ef_e_air_kgN2O_man_stor_sol = ef_e_air_kgN2O_man_stor_list[0]
    ef_e_air_kgN2O_man_stor_liq = 0  # no entry for liquid manure

# %% N emissions on pasture =====================================================
# NOx emission
e_nox_past = (animal._nex_past * tab_pars['Value']['nox_past'])
if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Other cattle']:
    # NH3 emission depends on the season
    e_nh3_past = (animal._nex_past
                  * animal._n_excret_past_liq
                  * (animal.ls_past_mar_may_d* tab_pasture_N['Spring (III-V)']['pasture_nh3_urine']
                  + animal.ls_past_jun_aug_d*tab_pasture_N['Summer (VI-VIII)']['pasture_nh3_urine']
                  + animal.ls_past_sep_nov_d*tab_pasture_N['Autummn (IX-XI)']['pasture_nh3_urine']
                  + animal.ls_past_dec_feb_d*tab_pasture_N['Winter (XII-II)']['pasture_nh3_urine'])/365
                  )
    e_n2o_past = (animal._nex_past
                  * (animal._n_excret_past_liq
                     * get_value_n(tab_n2o, 'EF grazing',
                                   animal.animal_class)[0]  # for urine
                     + animal._n_excret_past_sol
                     * get_value_n(tab_n2o, 'EF grazing',
                                   animal.animal_class)[1]  # for dung
                     )
                  )
    n_deposition_past = max([0, (animal._nex_past
                                 - e_nh3_past
                                 - e_nox_past
                                 - e_n2o_past
                                 )])
    n_deposition_past_liq = (n_deposition_past
                             * animal._n_excret_past_liq)
    n_deposition_past_sol = (n_deposition_past
                             - n_deposition_past_liq)

    # NO3 emissiom depends on the season
    e_no3_past = (n_deposition_past_liq
                  * (animal.ls_past_mar_may_d*tab_pasture_N['Spring (III-V)']['pasture_no3_urine']
                  + animal.ls_past_jun_aug_d*tab_pasture_N['Summer (VI-VIII)']['pasture_no3_urine']
                  + animal.ls_past_sep_nov_d*tab_pasture_N['Autummn (IX-XI)']['pasture_no3_urine']
                  + animal.ls_past_dec_feb_d*tab_pasture_N['Winter (XII-II)']['pasture_no3_urine'])/365
                  + n_deposition_past_sol
                  * (animal.ls_past_mar_may_d*tab_pasture_N['Spring (III-V)']['pasture_no3_dung']
                  + animal.ls_past_jun_aug_d*tab_pasture_N['Summer (VI-VIII)']['pasture_no3_dung']
                  + animal.ls_past_sep_nov_d*tab_pasture_N['Autummn (IX-XI)']['pasture_no3_dung']
                  + animal.ls_past_dec_feb_d*tab_pasture_N['Winter (XII-II)']['pasture_no3_dung'])/365
                  )
elif animal.animal_class in ['Fattening pigs', 'Sows']:
    e_nh3_past = (animal._nex_past
                  * frac_TAN
                  * get_value_n(tab_nh3, 'EF grazing/outdoor',
                                animal.animal_class)[1]
                  )
    e_n2o_past = (animal._nex_past
                  * get_value_n(tab_n2o, 'EF grazing',
                                animal.animal_class)[0]
                  )

    n_deposition_past = max([0, (animal._nex_past
                                 - e_nh3_past
                                 - e_nox_past
                                 - e_n2o_past
                                 )])
    n_deposition_past_liq = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    n_deposition_past_sol = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    e_no3_past = n_deposition_past_liq * tab_pars['Value']['no3_pigs']
elif animal.animal_class == 'Laying hens':
    e_nh3_past = (animal._nex_past
                  * frac_TAN
                  * get_value_n(tab_nh3, 'EF grazing/outdoor',
                                animal.animal_class)[1]
                  )
    e_n2o_past = (animal._nex_past
                  * get_value_n(tab_n2o, 'EF grazing',
                                animal.animal_class)[0]
                  )

    n_deposition_past = max([0, (animal._nex_past
                                 - e_nh3_past
                                 - e_nox_past
                                 - e_n2o_past
                                 )])
    n_deposition_past_liq = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    n_deposition_past_sol = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    e_no3_past = n_deposition_past_liq * tab_pasture_N['Mean']['pasture_no3_urine']
else:  # all others than cattle, pigs and laying hens
    e_nh3_past = (animal._nex_past
                  * frac_TAN
                  * get_value_n(tab_nh3, 'EF grazing/outdoor',
                                animal.animal_class)[0]
                  )
    e_n2o_past = (animal._nex_past
                  * get_value_n(tab_n2o, 'EF grazing',
                                animal.animal_class)[0]
                  )
    n_deposition_past = max([0, (animal._nex_past
                                 - e_nh3_past
                                 - e_nox_past
                                 - e_n2o_past
                                 )])
    n_deposition_past_liq = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    n_deposition_past_sol = max([0, (animal._nex_past*frac_TAN
                                     - e_nh3_past
                                     - e_nox_past
                                     - e_n2o_past
                                     )])
    e_no3_past = n_deposition_past_liq * tab_pasture_N['Mean']['pasture_no3_urine']

n_past_check = (animal._nex_past
                - e_nh3_past
                - e_nox_past
                - e_n2o_past
                - n_deposition_past)
if (abs(n_past_check) > 1e-12):
    w.warn('N emissions on pasture out of balance (check N != 0)')
    stderr.flush()


# %%  Emissions in yard =======================================================
e_nh3_yard = (animal._nex_yard
              * frac_TAN
              * get_value_n(tab_nh3, 'EF yard', animal.animal_class)[0]
              * c_agrammon['Correction factor NH3 yard']
              )
e_nox_yard = animal._nex_yard * tab_pars['Value']['nox_past']

if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Other cattle']:
    # different EFs for liquid and solid manure
    e_n2o_yard = animal._nex_yard * (animal._n_excret_housing_yard_liq
                                     * get_value_n(tab_n2o, 'EF grazing',
                                                   animal.animal_class)[0]
                                     + animal._n_excret_past_sol
                                     * get_value_n(tab_n2o, 'EF grazing',
                                                   animal.animal_class)[1]
                                     )
else: # same for all other animal categories
    e_n2o_yard = animal._nex_yard * get_value_n(tab_n2o, 'EF grazing',
                                                animal.animal_class)[0]

n_deposition_yard = max([0, (animal._nex_yard
                             - e_nh3_yard
                             - e_nox_yard
                             - e_n2o_yard
                             )])
n_TAN_yard = max([0, (animal._nex_yard
                      * frac_TAN
                      - e_nh3_yard
                      - e_nox_yard
                      - e_n2o_yard
                      )])
n_yard_check = (animal._nex_yard
                - e_nh3_yard
                - e_nox_yard
                - e_n2o_yard
                - n_deposition_yard
                )

if (abs(n_past_check) > 1e-12):
    w.warn('N emissions on yard out of balance (check N != 0)')
    stderr.flush()

# %% emissions in housing, manure =============================================
# Emission in housing
ef_housing_list = get_value_n(tab_nh3, 'EF housing',
                              animal.animal_class)  # get EFs

e_nh3_housing_liq = (animal._le_N
                     * frac_TAN
                     * ef_housing_list[0]
                     * c_agrammon['Correction factor NH3 housing']
                     * animal.corr_nh3_hous
                     )
e_nh3_housing_sol = (animal._se_N
                     * frac_TAN
                     * ef_housing_list[-1]
                     * c_agrammon['Correction factor NH3 housing']
                     * animal.corr_nh3_hous
                     )

# N immobilisation in solid manure, 0 for liq
n_immobilisation_sol = max([0, (animal._se_N
                                * frac_TAN_sol-e_nh3_housing_liq)
                                * immobilisation_sol])


# N entering manure store
Nstor_liq = max([animal._le_N
                 + animal._le_straw_N_in
                 - e_nh3_housing_liq
                 + n_deposition_yard*animal.ls_lman_N_frac,
                 0])
Nstor_sol = max([animal._se_N
                 + animal._se_straw_N_in
                 - e_nh3_housing_sol
                 + n_deposition_yard*animal._sman_N_frac,
                 0])
tanstor_liq_1 = max([animal._le_N
                     * frac_TAN_liq
                     - e_nh3_housing_liq
                     + n_TAN_yard*animal.ls_lman_N_frac,
                     0])
tanstor_sol_1 = max([animal._se_N
                     * frac_TAN_sol
                     - e_nh3_housing_sol
                     + n_TAN_yard*animal._sman_N_frac,
                     0])
n_mineralisation_liq_man = (Nstor_liq - tanstor_liq_1) * mineralisation_liq
tanstor_liq_2 = tanstor_liq_1 + n_mineralisation_liq_man
tanstor_sol_2 = tanstor_sol_1 - n_immobilisation_sol

# emission from manure store
key_cf_nh3_liqman_stor = 'Correction factor NH3 liquid manure storage'
e_nh3_manstor_liq = (tanstor_liq_2
                     * get_value_n(tab_nh3, 'EF storage',
                                   animal.animal_class)[0]
                     * c_agrammon[key_cf_nh3_liqman_stor]
                     )
key_cf_nh3_solman_stor = 'Correction factor NH3 solid manure storage'
e_nh3_manstor_sol = (tanstor_sol_2
                     * get_value_n(tab_nh3, 'EF storage',
                                   animal.animal_class)[-1]
                     * c_agrammon[key_cf_nh3_solman_stor]
                     )
e_nox_manstor_liq = tanstor_liq_2 * tab_pars['Value']['nox_manstor_liq']
e_nox_manstor_sol = tanstor_sol_2 * tab_pars['Value']['nox_manstor_sol']
e_n2o_manstor_liq = tanstor_liq_2 * ef_e_air_kgN2O_man_stor_liq
e_n2o_manstor_sol = tanstor_sol_2 * ef_e_air_kgN2O_man_stor_sol
e_n2_manstor_liq = tanstor_liq_2 * tab_pars['Value']['n2_manstor_liq']
e_n2_manstor_sol = tanstor_sol_2 * tab_pars['Value']['n2_manstor_sol']
e_nman_liq = max([Nstor_liq
                  - e_nh3_manstor_liq
                  - e_nox_manstor_liq
                  - e_n2o_manstor_liq
                  - e_n2_manstor_liq, 0])
e_nman_sol = max([Nstor_sol
                  - e_nh3_manstor_sol
                  - e_nox_manstor_sol
                  - e_n2o_manstor_sol
                  - e_n2_manstor_sol, 0])
e_TANman_liq = max([tanstor_liq_2
                    - e_nh3_manstor_liq
                    - e_nox_manstor_liq
                    - e_n2o_manstor_liq
                    - e_n2_manstor_liq, 0])
e_TANman_sol = max([tanstor_sol_2
                    - e_nh3_manstor_sol
                    - e_nox_manstor_sol
                    - e_n2o_manstor_sol
                    - e_n2_manstor_sol, 0])
check_n_manstor_liq = (Nstor_liq
                       - e_nh3_manstor_liq
                       - e_nox_manstor_liq
                       - e_n2o_manstor_liq
                       - e_n2_manstor_liq
                       - e_nman_liq)
check_n_manstor_sol = (Nstor_sol
                       - e_nh3_manstor_sol
                       - e_nox_manstor_sol
                       - e_n2o_manstor_sol
                       - e_n2_manstor_sol
                       - e_nman_sol)
# P, K and OS are not distributed between liquid and solid in the same proportions
# The distribution is therefore corrected by corr_P/K/OS_...
if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                           'Other cattle', 'Sheep', 'Goats', 'Other ruminants', 'Horses (and mules, asses)']:
    manure_P_liq = (animal.excreted_P*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_P_cattle'])
                    + animal._le_straw_P_in)
    manure_P_sol = (animal.excreted_P*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_P_cattle']))
                    + animal._se_straw_P_in)
    manure_K_liq = (animal.excreted_K*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_K_cattle'])
                    + animal._le_straw_K_in)
    manure_K_sol = (animal.excreted_K*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_K_cattle']))
                    + animal._se_straw_K_in)
    manure_OS_liq = (os_man*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_OS_cattle'])
                    + animal._le_straw_OS_in)
    manure_OS_sol = (os_man*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_OS_cattle']))
                    + animal._se_straw_OS_in)
else:  # other than ruminants or horses
    manure_P_liq = (animal.excreted_P*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_P_pigs'])
                    + animal._le_straw_P_in)
    manure_P_sol = (animal.excreted_P*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_P_pigs']))
                    + animal._se_straw_P_in)
    manure_K_liq = (animal.excreted_K*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_K_pigs'])
                    + animal._le_straw_K_in)
    manure_K_sol = (animal.excreted_K*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_K_pigs']))
                    + animal._se_straw_K_in)
    manure_OS_liq = (os_man*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_OS_pigs'])
                    + animal._le_straw_OS_in)
    manure_OS_sol = (os_man*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_OS_pigs']))
                    + animal._se_straw_OS_in)

# convert to P2O5 or K2O
manure_P2O5_liq = manure_P_liq * tab_pars['Value']['p2p205']
manure_P2O5_sol = manure_P_sol * tab_pars['Value']['p2p205']
manure_K2O_liq = manure_K_liq * tab_pars['Value']['k2k20']
manure_K2O_sol = manure_K_sol * tab_pars['Value']['k2k20']

manure_HM_liq = {}
manure_HM_sol = {}
for metal in metals:  # HM flows [mg]
    if animal.animal_class in ['Dairy cows', 'Dairy cows, tied housing',
                               'Other cattle', 'Sheep', 'Goats', 'Other ruminants', 'Horses (and mules, asses)']:
        manure_HM_liq[metal] = \
                         (animal.excreted_HM[metal]*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_OS_cattle'])
                         + animal._le_straw_HM_in[metal])
        manure_HM_sol[metal] = \
                         (animal.excreted_HM[metal]*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_OS_cattle']))
                         + animal._se_straw_HM_in[metal])
    else:
        manure_HM_liq[metal] = \
                         (animal.excreted_HM[metal]*min(1, animal._man_l_stor_frac1*tab_pars['Value']['corr_OS_pigs'])
                         + animal._le_straw_HM_in[metal])
        manure_HM_sol[metal] = \
                         (animal.excreted_HM[metal]*min(1, animal._man_s_stor_frac1*(1-tab_pars['Value']['corr_OS_pigs']))
                         + animal._se_straw_HM_in[metal])

# %% Emission summary =========================================================

e_nh3_total = (e_nh3_housing_liq
               + e_nh3_housing_sol
               + e_nh3_yard
               + e_nh3_past
               + e_nh3_manstor_liq
               + e_nh3_manstor_sol
               )


e_nox_total = (e_nox_yard
               + e_nox_past
               + e_nox_manstor_liq
               + e_nox_manstor_sol
               )


e_n2o_housing_indirect_liq = e_nh3_housing_liq * tab_pars['Value']['ef_e_air_kgN2O_indir_1']
e_n2o_housing_indirect_sol = e_nh3_housing_sol * tab_pars['Value']['ef_e_air_kgN2O_indir_1']
e_n2o_yard_indirect = (e_nh3_yard + e_nox_yard) * tab_pars['Value']['ef_e_air_kgN2O_indir_1']
e_n2o_past_indirect = ((e_nh3_past + e_nox_past)*tab_pars['Value']['ef_e_air_kgN2O_indir_1']
                       + e_no3_past * tab_pars['Value']['ef_e_air_kgN2O_indir_2'])
e_n2o_manstor_indirect_liq = (e_nh3_manstor_liq + e_nox_manstor_liq) \
    * tab_pars['Value']['ef_e_air_kgN2O_indir_1']
e_n2o_manstor_indirect_sol = (e_nh3_manstor_sol + e_nox_manstor_sol) \
    * tab_pars['Value']['ef_e_air_kgN2O_indir_1']
e_n2o_housing_total = e_n2o_housing_indirect_liq + e_n2o_housing_indirect_sol
e_n2o_yard_total = e_n2o_yard + e_n2o_yard_indirect
e_n2o_past_total = e_n2o_past + e_n2o_past_indirect
e_n2o_manstor_total = (e_n2o_manstor_liq
                       + e_n2o_manstor_indirect_liq
                       + e_n2o_manstor_sol
                       + e_n2o_manstor_indirect_sol
                       )
e_n2o_total = (e_n2o_housing_total
               + e_n2o_yard_total
               + e_n2o_past_total
               + e_n2o_manstor_total)

e_n2_total = e_n2_manstor_liq + e_n2_manstor_sol

# %% N balance ================================================================
b_input_N_manure_liq = animal.excreted_N + animal._le_straw_N_in
b_input_N_manure_sol = animal._se_straw_N_in
b_emission_N_manure = (e_nh3_total
                       + e_nox_total
                       + e_n2o_yard
                       + e_n2o_past
                       + e_n2o_manstor_liq
                       + e_n2o_manstor_sol
                       + e_n2_manstor_liq
                       + e_n2_manstor_sol
                       )
b_input_animal_class = b_input_N_manure_liq + b_input_N_manure_sol
b_emission_animal_class = b_emission_N_manure
b_remaining_manure = e_nman_liq + e_nman_sol
b_N_balance = (b_input_animal_class
               - b_emission_animal_class
               - b_remaining_manure
               - n_deposition_past
               )


# %% Output ===================================================================
out.ls_animal_prep = js.dumps(salcaanimal_prep)
out.ls_lman_kgN = e_nman_liq
out.ls_sman_kgN = e_nman_sol
out.ls_lman_kgNH4_N = e_TANman_liq
out.ls_sman_kgNH4_N = e_TANman_sol
out.ls_lman_kgP2O5 = manure_P2O5_liq
out.ls_sman_kgP2O5 = manure_P2O5_sol
out.ls_lman_kgK2O = manure_K2O_liq
out.ls_sman_kgK2O = manure_K2O_sol
out.ls_lman_kgOS = manure_OS_liq
out.ls_sman_kgOS = manure_OS_sol
out.ls_lman_mgHM = js.dumps(manure_HM_liq)  # dict with HMs
out.ls_sman_mgHM = js.dumps(manure_HM_sol)  # dict with HMs
salcaanimal_manure = {'n': [e_nman_liq, e_nman_sol],
                      'nh4n': [e_TANman_liq, e_TANman_sol],
                      'p205': [manure_P2O5_liq, manure_P2O5_sol],
                      'k2o':  [manure_K2O_liq, manure_K2O_sol],
                      'hm':   [manure_HM_liq, manure_HM_sol],
                      'manure_type': [manure_type_liq, manure_type_sol],
                      'production_dilution': [1, 1]
                      }
out.ls_animal_manu_prep = js.dumps(salcaanimal_manure)

out.ls_e_air_kgNH3 = e_nh3_total * tab_pars['Value']['conv_nh3']
out.ls_e_air_kgCH4 = ch4_total
out.ls_e_air_kgNOX = e_nox_total * tab_pars['Value']['conv_nox']
out.ls_e_air_kgN2O = e_n2o_total * tab_pars['Value']['conv_n2o']
out.ls_e_kgNO3 = e_no3_past * tab_pars['Value']['conv_no3']

logging.info('salcaanimal_manure= %s', salcaanimal_manure)

# Overview animal emissions:
salcaanimal_emissions = {
    'animal_type': animal_type,
    'animal_name': animal_name,
    'animal_id': animal_id,
    'ch4_enteric': animal.ch4_em_used,   # [kg CH4/year]
    'ch4_man_mag': animal.ch4_em_man_mag,   # [kg CH4/year]
    'ch4_total': ch4_total,  # [kg CH4/year]
    'nh3_housing_liq': e_nh3_housing_liq * tab_pars['Value']['conv_nh3'],
    'nh3_housing_sol': e_nh3_housing_sol * tab_pars['Value']['conv_nh3'],
    'nh3_yard': e_nh3_yard * tab_pars['Value']['conv_nh3'],
    'nh3_pasture': e_nh3_past * tab_pars['Value']['conv_nh3'],
    'nh3_manstor_liq': e_nh3_manstor_liq * tab_pars['Value']['conv_nh3'],
    'nh3_manstor_sol': e_nh3_manstor_sol * tab_pars['Value']['conv_nh3'],
    'nh3_total': e_nh3_total * tab_pars['Value']['conv_nh3'],
    'nox_yard': e_nox_yard * tab_pars['Value']['conv_nox'],
    'nox_pasture': e_nox_past * tab_pars['Value']['conv_nox'],
    'nox_manstor_liq': e_nox_manstor_liq * tab_pars['Value']['conv_nox'],
    'nox_manstor_sol': e_nox_manstor_sol * tab_pars['Value']['conv_nox'],
    'nox_total': e_nox_total * tab_pars['Value']['conv_nox'],
    'n2o_housing': e_n2o_housing_total * tab_pars['Value']['conv_n2o'],
    'n2o_yard': e_n2o_yard_total * tab_pars['Value']['conv_n2o'],
    'n2o_pasture': e_n2o_past_total * tab_pars['Value']['conv_n2o'],
    'n2o_manstor': e_n2o_manstor_total * tab_pars['Value']['conv_n2o'],
    'n2o_total': e_n2o_total * tab_pars['Value']['conv_n2o'],
    'n2_manstor_liq': e_n2_manstor_liq,
    'n2_manstor_sol': e_n2_manstor_sol,
    'n2_total': e_n2_total,
    'no3_pasture': e_no3_past * tab_pars['Value']['conv_no3']
    }
out.ls_animal_emissions = js.dumps(salcaanimal_emissions)

logging.info('')
logging.info('Emission Summary:')
for item, amount in salcaanimal_emissions.items():
    logging.info("{} = {} kg".format(item, amount))
logging.info('**********************************')

# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
