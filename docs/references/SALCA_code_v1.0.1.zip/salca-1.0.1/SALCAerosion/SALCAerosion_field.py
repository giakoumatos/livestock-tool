# -*- coding: utf-8 -*-
"""
File name: SALCAerosion_field.py
Created on Mon Jun  8 09:35:11 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script estimates annual soil loss from areal and linear soil erosion.

Calculation level:
    Field (delimited piece of land that can have one or more crops)

Related scripts: SALCAphosphor.py, SALCAheavymetal_crop.py,
                 SALCAsoilquality_crop.py, SALCAsoilquality_farm.py
    It provides input for these scripts.
"""

# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.INFO)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAerosion field'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('field')  # for running in SALCAfuture
inp, out = ctx.bind()

logging.info('Modul run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define functions =========================================================


def is_number(s):
    """Check if s is a number."""
    try:
        float(s)
        return True
    except ValueError:
        return False


def removeDuplicates(listofElements):
    """Create a list of unique elements."""
    uniqueList = []
    for elem in listofElements:
        if elem not in uniqueList:
            uniqueList.append(elem)
    return uniqueList


def read_table(path, index = False):
    """Read a CSV file."""
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    if index != False:
        tab = tab.set_index(index)
    return tab


def CvalueStepI_fu(Dataframe, CondRowValue, CondColValue):
    """Retrieve the value in the correct row and column according to
    the computation of the C-factor, step 1.
    """
    rownr = np.argmax(Dataframe.index <= CondRowValue)
    logging.debug("The row number to be selected from the Table is %s.", rownr)
    logging.debug("cond=\n %s", Dataframe.columns.astype(np.float64) > CondColValue)
    colnr = np.argmax(np.array(Dataframe.columns, dtype = np.float64) > CondColValue)
    logging.debug("The col number to be selected from the Table is %s.", colnr)
    res = Dataframe.iloc[rownr, colnr]
    logging.debug("The resulting CvalueStepI is %s.", res)
    return res


def searchintervals(interval_boundaries, value, boundaries='left-closed'):
    """Find the interval from a list of intervals that includes the value v.

    @param interval_boundaries: List of the interval boundaries
    @param value: The value
    @param boundaries: 'left-closed'*, 'left-open', 'right-closed', 'right-open'
                        For boundaries 0 & 100 the intervals are
                            - left-closed: [0, 100) & [100, inf)
                            - left-open: (0, 100] & (100, inf]
                            - right-closed: (inf, 0] & (0, 100]
                            - right-open: (inf, 0) & [0, 100)
    @return: The position of the interval within the list of intervals
    @raise ValueError: The value lies outside of the specified intervals
    """
    if boundaries == 'left-closed' or boundaries == 'right-open':
        side = 'right'
    else:
        side = 'left'
    index = np.searchsorted(interval_boundaries, value, side)
    if 'left' in boundaries:
        index -= 1
    if index < 0 or index >= len(interval_boundaries):
        raise ValueError('{} is not included in the intervals with the \
                         {} boundaries {}'.format(value, boundaries,
                                                  list(interval_boundaries)))
    return index


# %% input for preparation part ===============================================

logging.info('Starting time of preparation part: %s', dt.datetime.now(tz=None))

in_crop_code = []  # names of the crops on the field
in_crop_id = []  # crop IDs of the crops on the field
field = ctx.field[2]
for crop in sorted(field.values()):
    in_crop_code.append(crop[2])
    in_crop_id.append(crop[0])
fi_fia_ha = inp.fi_fia_ha  # area of the field [ha]
f_region_eros = inp.f_region_eros  # region, as needed in SALCAerosion

fi_soil_type = inp.fi_soil_type  # soil type on the field

fi_soil_kgpm3 = inp.fi_soil_kgpm3  # soil density [kg/m3]
# flow distance runoff [m] (0, if unknown)
fi_terrain_flow_dist_m = inp.fi_terrain_flow_dist_m
fi_slope_frac = inp.fi_slope_perc  # hill slope [%]
# presence of erosion gullies (0 or 1)
fi_eros_gully_bool = inp.fi_eros_gully_bool
# frequency of erosion gullies (enum)
fi_eros_gully_freq = inp.fi_eros_gully_freq
fi_eros_gully_cm = inp.fi_eros_gully_cm  # depth of erosion gullies [cm]
# shape of erosion gullies (enum)
fi_eros_gully_shape = inp.fi_eros_gully_shape
# single or several erosion gullies (singular: True, several: False)
fi_eros_gully_amount_bool = inp.fi_eros_gully_amount_bool

c_salcaprep_str = inp.c_salcaprep  # load information from salcaprep_crop
f_salcaprep = js.loads(inp.f_salcaprep)  # load information from SALCAprep_farm
# dictionary with crop types and the fraction of their presence in the
# crop rotation across the farm []
f_crop_rotation = f_salcaprep['f_crop_rotation']
# percentage of permanent culture and sowing with reduced tillage in the
# crop rotation [%]
f_protective_sowi = f_salcaprep['f_protective_sowi']

f_summercrop_group_1 = f_salcaprep['f_summercrop_group_1']
f_summercrop_group_2 = f_salcaprep['f_summercrop_group_2']

# %% calculation for preparation ==============================================

open_arable_areatime_sum = 0  # area*time of open arable areas on the field
areatime_sum = 0  # area*time of all areas on the field
for i, str_crop in enumerate(c_salcaprep_str):
    c_salcaprep = js.loads(str_crop)
    crop_type = in_crop_code[i]
    areatime_sum += c_salcaprep['c_areatime']
    # check for open arable area (permaculture == 0)
    if c_salcaprep['c_eros_permaculture'] == 0:
        open_arable_areatime_sum += c_salcaprep['c_areatime']
fi_oaa_frac = open_arable_areatime_sum/areatime_sum
fi_oaa_ha = fi_fia_ha * fi_oaa_frac  # area of open arable areas on the field

# %% output of preparation ====================================================

fi_eros_prep = {
    'in_crop_code': in_crop_code,
    'fi_fia_ha': fi_fia_ha,
    'fi_oaa_ha': fi_oaa_ha,
    'fi_oaa_frac': fi_oaa_frac,
    'f_region_eros': f_region_eros,
    'fi_soil_type': fi_soil_type,
    'fi_soil_kgpm3': fi_soil_kgpm3,
    'fi_terrain_flow_dist_m': fi_terrain_flow_dist_m,
    'fi_slope_gradient': fi_slope_frac,
    'fi_eros_gully_bool': fi_eros_gully_bool,
    'fi_eros_gully_freq': fi_eros_gully_freq,
    'fi_eros_gully_cm': fi_eros_gully_cm,
    'fi_eros_gully_shape': fi_eros_gully_shape,
    'fi_eros_gully_amount_bool': fi_eros_gully_amount_bool,
    'f_protective_sowi': f_protective_sowi,
    'f_crop_rotation': f_crop_rotation,
    'f_summercrop_group_1': f_summercrop_group_1,
    'f_summercrop_group_2': f_summercrop_group_2
}
logging.info('End time of preparation part: %s', dt.datetime.now(tz=None))

# %% input ====================================================================

logging.info('Starting time of calculation part: %s', dt.datetime.now(tz=None))

# start date of the evaluation of the farm
start_evaluation = dt.datetime.strptime(inp.f_start_evaluation, '%Y-%m-%d')
# end date of the evaluation of the farm
end_evaluation = dt.datetime.strptime(inp.f_end_evaluation, '%Y-%m-%d')

# soil type on the field: sand, loam, silt or clay
fi_soil_type = fi_eros_prep['fi_soil_type']
# region, as needed in SALCAerosion: 1, 2a, 2b, 3 or 4
f_region_eros = fi_eros_prep['f_region_eros']
fi_soil_kgpm3 = fi_eros_prep['fi_soil_kgpm3']  # soil density [kg/m3]
fi_slope_gradient = fi_eros_prep['fi_slope_gradient']  # hill slope [%]
# flow distance runoff [m]
fi_terrain_flow_dist_m = fi_eros_prep['fi_terrain_flow_dist_m']
# area of the open arable land on the field [ha]
fi_oaa_ha = fi_eros_prep['fi_oaa_ha']
fi_fia_ha = fi_eros_prep['fi_fia_ha']  # area of the field [ha]
# presence of erosion gullies (0 or 1)
fi_eros_gully_bool = fi_eros_prep['fi_eros_gully_bool']
# depth of erosion gullies [cm]
fi_eros_gully_cm = fi_eros_prep['fi_eros_gully_cm']
# frequency of erosion gullies (enum)
fi_eros_gully_freq = fi_eros_prep['fi_eros_gully_freq']
# single or several erosion gullies (singular: 0, several: 1)
fi_eros_gully_amount_bool = fi_eros_prep['fi_eros_gully_amount_bool']
# shape of erosion gullies (enum):
# 1 = predominantly as wide as they are deep; 2 = wider than deep
fi_eros_gully_shape = fi_eros_prep['fi_eros_gully_shape']

in_crop_code = fi_eros_prep['in_crop_code']  # names of the crops on the field

# fraction of winter grain in crop rotation on the farm
f_crop_rotation_winter_grain = fi_eros_prep['f_crop_rotation'][
    'winter_grain_rapeseed']
# fraction of ley fallow in crop rotation on the farm
f_crop_rotation_ley_fallow = fi_eros_prep['f_crop_rotation'][
    'ley_fallow']
# fraction of catch crop in crop rotation on the farm
f_crop_rotation_catch_crop = fi_eros_prep['f_crop_rotation'][
    'catch_crop']
# fraction of fieldgrown vegetable in crop rotation on the farm
f_crop_rotation_vegetable = fi_eros_prep['f_crop_rotation'][
    'vegetables']
# fraction of maize in crop rotation on the farm
f_crop_rotation_maize = fi_eros_prep['f_crop_rotation'][
    'maize']

# fraction of other crops (e.g. permanent crops) in crop rotation on the farm
f_crop_rotation_others = fi_eros_prep['f_crop_rotation'][
    'others']

# fraction of sowing with reduced plowing in crop rotation on the farm
f_crop_rotation_reduced_till = fi_eros_prep['f_protective_sowi']

logging.debug("")
logging.debug("fi_soil_type= %s", fi_soil_type)
logging.debug("fi_fia_ha (Field Area)= %s", fi_fia_ha)
logging.debug("fi_oaa_ha= %s", fi_oaa_ha)
logging.debug("fi_terrain_flow_dist_m= %s\n", fi_terrain_flow_dist_m)
logging.debug("    Crop rotation shares:")
logging.debug("f_crop_rotation_catch_crop (Percentage of catch crops in " \
              "crop rotation) [%%]= %s", f_crop_rotation_catch_crop*100)
logging.debug("f_crop_rotation_vegetable (Percentage of vegetables in " \
              "crop rotation) [%%]= %s", f_crop_rotation_vegetable*100)
logging.debug("f_crop_rotation_ley_fallow (Percentage of ley and fallow " \
              "[Kunstwiese u. Bunt-/Rotationsbrache] in crop rotation) [%%]= %s",
              f_crop_rotation_ley_fallow*100)
logging.debug("f_crop_rotation_maize (Percentage of maize in crop rotation) [%%]= %s",
              f_crop_rotation_maize*100)
logging.debug("f_crop_rotation_winter_grain (Percentage of winter grains and " \
              "rapeseed in crop rotation) [%%]= %s\n",
              f_crop_rotation_winter_grain*100)
logging.debug("    Remaining category as control:")
logging.debug("f_crop_rotation_others (Percentage of other crops [e.g. " \
              "permanent crops] in crop rotation) [%%]= %s\n",
              f_crop_rotation_others*100)
logging.debug("    Reduced tillage:")
logging.debug("f_crop_rotation_reduced_till (Percentage of " \
              "Mulch-/Streifen-/Direktsaat in crop rotation) [%%]= %s\n",
              f_crop_rotation_reduced_till*100)

# fraction of parcel from total arable area []
fi_oaa_frac = fi_eros_prep['fi_oaa_frac']
logging.debug("")
logging.debug("Fraction of open arable area on the field= %s\n", fi_oaa_frac)

f_summercrop_group_1 = fi_eros_prep['f_summercrop_group_1']
f_summercrop_group_2 = fi_eros_prep['f_summercrop_group_2']

# %% Tables ===================================================================


# select the table according to the region
regionMapping_pd = pd.DataFrame({
    'Region': ['1', '2a', '2b', '3', '4'],
    'Index': [0, 1, 2, 3, 4]
})
regnr = int(regionMapping_pd.Index[regionMapping_pd.Region
                                   == f_region_eros].iloc[0])

listTables = ['ErosionI', 'ErosionIIa', 'ErosionIIb',
              'ErosionIII', 'ErosionIV']

CValueStepI_df = read_table('./'+listTables[regnr]+'/CValueStepI.csv', 
                            index = 'Percentage of winter cereals and rapeseed')

CValuesII_df = read_table('./'+listTables[regnr]+'/CValueStepII.csv',
                          index = 'Variable')

LocationEffects_df = read_table('./'+listTables[regnr]+'/LocationEffects.csv',
                                index = ['soil_type', 'flow_path_length_2'])

Gullies_df = read_table('./'+listTables[regnr]+'/Gullies.csv', index = 'Variable')

Monokult_df = read_table('Monoculture.csv', index='Monocultures')

Fruchtfolgenfaktor_df= read_table('CFactor_no_corr.csv', index = 'Index')


dataSubtrahend = read_table('ProtSowing.csv', index = 'Region')
dataFracRedTill = read_table('FracRedTill.csv', index = 'Variable')

eros_contr_fi_manag = pd.DataFrame({
    "FracRedTill": dataFracRedTill.loc["FracRedTill"],
    "Subtrahend": dataSubtrahend.loc[f_region_eros].\
        reindex(dataFracRedTill.columns)
})

# %% Step 1 ===================================================================

# CValue depending on fractions of winter grains & rapeseed and
# ley & fallow in crop rotation
Step1_Cvalue = CvalueStepI_fu(CValueStepI_df,
                              f_crop_rotation_winter_grain,
                              f_crop_rotation_ley_fallow)

# %% Step 2 ===================================================================

# Get Step2_Cvalue from the erosion lookup table CValueStepII.csv depending on
# the two groups of summercrops that are present on the farm and the fraction
# of cash crops cultivated before those summercrops.

# Precondition: For some Step1_Cvalues, Step2_Cvalue is directly dependent
# on Step1_Cvalue
if Step1_Cvalue == "W" or is_number(Step1_Cvalue):
    Step2_Cvalue = "W"
else:
    if f_summercrop_group_1 == 0 and f_summercrop_group_2 == 0:
        # Wintercrops belong to neither of the groups.
        # Step2_Cvalue is not relevant for those crops.
        Step2_Cvalue = ""
    else:
        if f_summercrop_group_1 == 0:
            gru = "g2"
        elif f_summercrop_group_2 == 0:
            gru = "g1"
        else:
            gru = "g12"
        # retrieve only relevant part of table CValuesII_df, depending on
        # whether fracFarmCashCrop >50% or <=50%
        if f_crop_rotation_catch_crop > 0.5:
            variable = "culture_acc_"+ gru
        else:
            variable = "culture_af_"+ gru
        Step2_Cvalue = CValuesII_df[Step1_Cvalue][variable]

# %% Step 3 ===================================================================


# Cvalue for monocultures of maize or vegetables
if Step2_Cvalue == "W":
    if f_crop_rotation_maize == 1 \
            and f_crop_rotation_catch_crop < 0.5:
        Step3_Cvalue = Monokult_df.loc['maize only, with mostly fallow during winter', str(regnr)]
    elif f_crop_rotation_maize == 1 \
            and f_crop_rotation_catch_crop >= 0.5:
        Step3_Cvalue = Monokult_df.loc['maize only, with mostly catch crops', str(regnr)]
    elif f_crop_rotation_vegetable == 1 \
            and f_crop_rotation_catch_crop < 0.5:
        Step3_Cvalue = Monokult_df.loc['vegetables only, with mostly fallow during winter', str(regnr)]
    elif f_crop_rotation_vegetable == 1 \
            and f_crop_rotation_catch_crop >= 0.5:
        Step3_Cvalue = Monokult_df.loc['vegetables only, with mostly catch crops', str(regnr)]
    else:
        Step3_Cvalue = 0.0
else:
    Step3_Cvalue = 0

logging.debug("Step3_Cvalue= %s", Step3_Cvalue)

# %% Step 4 ===================================================================

if Step3_Cvalue == 0:
    Step4_Cvalue = Monokult_df.loc['Strawberries, perennial berries, Peas', str(regnr)]
else:
    Step4_Cvalue = 0
logging.debug("Step4_Cvalue= %s", Step4_Cvalue)

# %% Step 5 ===================================================================


su_leyFallow_winterGrain = f_crop_rotation_ley_fallow \
    + f_crop_rotation_winter_grain


if su_leyFallow_winterGrain == 1 and Step1_Cvalue in Fruchtfolgenfaktor_df.columns:
    Step5_Cvalue = Fruchtfolgenfaktor_df.loc[regnr,Step1_Cvalue]
else:
    Step5_Cvalue = 0

logging.debug("Step5_Cvalue= %s\n", Step5_Cvalue)

# C-factor without correction according to selected region (1, 2a, 2b, 3 or 4)

if Step5_Cvalue > 0:
    CvalueWithoutCorrReg = Step5_Cvalue
elif is_number(Step2_Cvalue):
    CvalueWithoutCorrReg = Step2_Cvalue
elif Step3_Cvalue != 0:
    CvalueWithoutCorrReg = Step3_Cvalue
else:
    CvalueWithoutCorrReg = Step4_Cvalue

logging.debug("CvalueWithoutCorrReg= %s", CvalueWithoutCorrReg)

# Correction of C-factor for gentle form of seed ("schonende Saat")

# data in the range [0,1]
criteria = eros_contr_fi_manag.FracRedTill <= f_crop_rotation_reduced_till
v1 = eros_contr_fi_manag.Subtrahend[criteria]
CorrectCFakRedTill = min(v1)
logging.debug("CorrectCFakRedTill= %s\n", CorrectCFakRedTill)

# C-factor effective according to the selected region (1, 2a, 2b, 3 or 4)

fi_eros_c = max(0.0,CvalueWithoutCorrReg+CorrectCFakRedTill)
logging.debug('fi_eros_c: %.3f\n', fi_eros_c)

# %% Location factor region ===================================================

logging.debug(listTables[regnr])

SlopesLimits = [0.02,0.06,0.11,0.16]  # thresholds for slopes

LocationEffects_reg = LocationEffects_df.loc[fi_soil_type]
logging.debug("LocationEffects_reg= %s", LocationEffects_reg)
logging.debug("LocationEffects_reg.index= %s", LocationEffects_reg.index)
logging.debug("fi_terrain_flow_dist_m= %s", fi_terrain_flow_dist_m)

# extract row value for the corresponding terrain flow distance
for val in LocationEffects_reg.index:
    if val <= fi_terrain_flow_dist_m:
        flow_dist_threshold = val
        logging.debug("flow_dist_threshold= %s", flow_dist_threshold)

# assign the correct slope column according to the slope level
if fi_slope_gradient >= SlopesLimits[0] and \
        fi_slope_gradient <= SlopesLimits[1]:
    colname = "slope1"
elif fi_slope_gradient > SlopesLimits[1] \
        and fi_slope_gradient <= SlopesLimits[2]:
    colname = "slope2"
elif fi_slope_gradient > SlopesLimits[2] \
        and fi_slope_gradient <= SlopesLimits[3]:
    colname = "slope3"
elif fi_slope_gradient > SlopesLimits[3]:
    colname = "slope4"
else:
    colname = "NA"
    fi_eros_s = 0

if colname != "NA":
    fi_eros_s = LocationEffects_reg.at[flow_dist_threshold, colname]
    logging.debug('fi_eros_s: %.3f\n', fi_eros_s)

# %% Parcel areal erosion =====================================================
# product of location factor and C-factor

# determine valid soil types
SoiltypeVal = LocationEffects_df.index.get_level_values("soil_type")
SoiltypeVal = list(SoiltypeVal)
SoiltypeVal = removeDuplicates(SoiltypeVal)
logging.debug("SoiltypeVal= %s\n", SoiltypeVal)

if fi_soil_type in SoiltypeVal and fi_eros_s != 0 \
        and fi_fia_ha > 0:
    fi_eros_areal_dtphapa = fi_eros_s*fi_eros_c
else:
    fi_eros_areal_dtphapa = 0

logging.debug('fi_eros_c: %.3f\n', fi_eros_c)
logging.debug('Risk of areal erosion: %.3f\n', fi_eros_areal_dtphapa)

# %% Parcel linear erosion ====================================================

# reduce table to 1 single row dependent on given parameters
# Attention: The table for region 1 (I) has a different structure than
# the tables for the other four erosion regions (2a, 2b, 3, 4)

logging.debug("f_region_eros= %s\n", f_region_eros)

# only calculate linear erosion if
# 1) there is data for erosion gullies and
# 2) erosion gullies occur
if not fi_eros_gully_bool \
        or int(fi_eros_gully_freq) == 0:
    fi_eros_linear_dtphapa = 0.0
else:
    if f_region_eros == '1':
        # extract value based on gully depth and amount
        if fi_eros_gully_cm < 15 and \
                not fi_eros_gully_amount_bool:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_l_15', ]
        elif fi_eros_gully_cm < 15 and \
                fi_eros_gully_amount_bool:  # several
            Gullies_df_Red = Gullies_df.loc['2_gully_l_15', ]
        elif fi_eros_gully_cm >= 15 and \
                not fi_eros_gully_amount_bool:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_m_15', ]
        elif fi_eros_gully_cm >= 15 and \
                fi_eros_gully_amount_bool:  # several
            Gullies_df_Red = Gullies_df.loc['2_gully_m_15', ]
        else:
            # for avoiding an error just assume a 'gentle' case
            Gullies_df_Red = Gullies_df.loc['1_gully_l_15', ]
    else:
        logging.debug("CaseRegion 2a, 2b, 3 or 4")
        if fi_eros_gully_cm < 15 \
                and not fi_eros_gully_amount_bool \
                and fi_eros_gully_shape == 1:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_l_15_s1', ]
        elif fi_eros_gully_cm < 15 \
                and not fi_eros_gully_amount_bool \
                and fi_eros_gully_shape == 2:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_l_15_s2', ]
        elif fi_eros_gully_cm >= 15 \
                and not fi_eros_gully_amount_bool \
                and fi_eros_gully_shape == 1:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_m_15_s1', ]
        elif fi_eros_gully_cm >= 15 \
                and not fi_eros_gully_amount_bool \
                and fi_eros_gully_shape == 2:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_m_15_s2', ]
        elif fi_eros_gully_cm > 25 \
                and not fi_eros_gully_amount_bool:  # single
            Gullies_df_Red = Gullies_df.loc['1_gully_m_25', ]
        elif fi_eros_gully_cm < 15 \
                and fi_eros_gully_amount_bool:  # several
            Gullies_df_Red = Gullies_df.loc['2_gully_l_15', ]
        elif fi_eros_gully_cm >= 15 \
                and fi_eros_gully_amount_bool:  # several
            Gullies_df_Red = Gullies_df.loc['2_gully_m_15', ]
        else:
            # for avoiding an error just assume a 'little critical' case
            Gullies_df_Red = Gullies_df.loc['1_gully_l_15_s1', ]

    logging.debug("Gullies_df_Red= \n%s\n", Gullies_df_Red)
    logging.debug("fi_eros_gully_freq= %s\n", fi_eros_gully_freq)

    # get the linear erosion amount from the table
    # +3 as table to the left includes columns with information on
    # number of gullies
    fi_eros_linear_dtphapa = Gullies_df_Red[fi_eros_gully_freq]

logging.debug("Risk of linear erosion= %s\n", fi_eros_linear_dtphapa)

# %% Parcel area-weighted erosion risk (areal + linear) =======================

# no case distinction necessary as areal and linear erosion are equal to
# 0.0 if no computation of areal or linear erosion was performed
fi_eros_dtphapa = fi_oaa_frac*(fi_eros_areal_dtphapa
                               + fi_eros_linear_dtphapa)

fi_eros_kgphapa = fi_eros_dtphapa*100.0  # unit conversion dt/ha -> kg/ha

logging.debug('Erosion risk, weighted: %.3f kg soil loss/ha*a\n', fi_eros_kgphapa)

# %% Average annual soil loss [mm/year] =======================================

# dt/ha -> kg/ha: *100
# kg/ha -> kg/m2: /10000
# (kg/m2)/(kg/m3) -> m
# m -> mm: *1000
# in combination: 100/10000*1000 = 10
if is_number(fi_eros_dtphapa):
    fi_eros_mmpa = fi_eros_dtphapa*10/(fi_soil_kgpm3)
else:
    fi_eros_mmpa = 0.0

logging.debug('Average soil loss: %.3f mm.\n', fi_eros_mmpa)

# consider field area and duration
duration = end_evaluation-start_evaluation
fi_eros_kg = fi_eros_kgphapa*fi_fia_ha*duration.days/365
fi_eros_mm = fi_eros_mmpa*duration.days/365

# %% output ===================================================================

output_res_df = pd.DataFrame.from_dict({
    'Fraction of open arable area on the field':
          [fi_oaa_frac],
    'Total average soil loss [mm/a]':
        [fi_eros_mmpa],
        'Total average soil loss [kg/ha*a]':
        [fi_eros_kgphapa],
        'Areal ("flächenhafte") erosion [kg/ha*a]':
        [fi_eros_areal_dtphapa],
        'Linear ("linienhafte") erosion [kg/ha*a]':
        [fi_eros_linear_dtphapa],
        'C-factor': [fi_eros_c],
        'S-factor': [fi_eros_s],
        'total erosion [kg]:': [fi_eros_kg],
        'total erosion [mm]': [fi_eros_mm]},
        orient = 'index', columns = ['Erosion Summary'])
logging.info('*********************************************************')
logging.info(output_res_df)
logging.info('')

# write output into the SALCAfuture database
out.fi_eros_mmpa = fi_eros_mmpa
# used in SALCAheavymetal and SALCAphosphor
out.fi_eros_kgphapa = fi_eros_kgphapa
out.fi_eros_areal_dtphapa = fi_eros_areal_dtphapa
out.fi_eros_linear_dtphapa = float(fi_eros_linear_dtphapa)
out.fi_eros_c = fi_eros_c
out.fi_eros_s = fi_eros_s
out.fi_eros_mm = fi_eros_mm
out.fi_eros_kg = fi_eros_kg

# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
