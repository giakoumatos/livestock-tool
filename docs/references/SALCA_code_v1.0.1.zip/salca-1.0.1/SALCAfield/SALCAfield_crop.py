# -*- coding: utf-8 -*-
"""
File name: SALCAfield_crop.py
Created on Mon Mar  4 15:56:59 2024

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script estimates CO2 and N2O emissions from land use change
    to the air at crop level

Calculation level:
    Crop

Related scripts: SALCAfield_field.py (emissions at field level), 
"""

# %% import modules ===========================================================

import datetime as dt
import json as js
import re
import logging
from importlib import reload

import pandas as pd
import math

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAfield_crop'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define factors ===========================================================

c_to_co2_conversion = 44/12
n_to_n2o_conversion = 44/28
delta_time = 20  # a change in C-stock will take 20 years to reach the new equilibrium

# %% define functions =========================================================
def get_bd_category(maco_id):
    """ 
    for a machinery combination, 
    get the bd_categories for the individual machinery (maco_id) 
    """
    if maco_id in mc_dict.index:
        machinery = mc_dict.loc[maco_id,].tolist()
        bd_category = tab_mach[tab_mach["PythonName"].isin(machinery)]["SALCA-BD_mapping"]
    else:
        bd_category = pd.Series(None, dtype = 'float64')
    return bd_category

def read_pars(path):  # read CSV file
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab

# %% input ====================================================================
# String input modifications:
# remove the number and underscore in front of the string
c_historic_landuse = re.sub(r'[0-9]*\_', '', inp.c_historic_landuse, count = 1) 
# replace underscore with space
c_historic_landuse = re.sub(r'\_', ' ', c_historic_landuse)
# change the first letter of the sentence to uppercase
c_historic_landuse = c_historic_landuse.capitalize()

# remove the number and underscore in front of the string
c_historic_management = re.sub(r'[0-9]*\_', '', inp.c_historic_management, count = 1) 
# change the first letter of the sentence to uppercase
c_historic_management = c_historic_management.capitalize()

# crop names
crop_name = ctx.crop[2]

c_salcaprep = js.loads(inp.c_salcaprep)
f_salcaprep = js.loads(inp.f_salcaprep)

f_climate_zone = inp.f_climate_zone
f_region = inp.f_region
fi_clay_frac = inp.fi_clay_frac
fi_humus_perc = inp.fi_humus_perc

# Has there been a change in land use on the area of the crop in the last 20 years
# (intensification, extensification, change from grassland to arable land or vice versa)?
if hasattr(inp, 'c_luc_bool') and inp.c_luc_bool is not None:
    c_luc_bool = inp.c_luc_bool
else:
    c_luc_bool = False  # no assessment if this variable is not yet in the data entry form.

# What type of land use did the area correspond to before this change?
if hasattr(inp, 'c_luc_ancientcrop') and inp.c_luc_ancientcrop is not None:
    c_luc_ancientcrop = inp.c_luc_ancientcrop
else:
    c_luc_ancientcrop = '001_unknown'  # if not specified in the data entry form, it is unknown which means no calculation done.
# Climate region according to WSL (www.wsl.ch, Jura, Mittelland, Voralpen, 
# Alpen feucht, Alpen trocken, Südlich der Alpen)
if hasattr(inp, 'f_climate_region_wsl') and inp.f_climate_region_wsl is not None:
    f_climate_region_wsl = inp.f_climate_region_wsl
    # if not specified in the data entry form and the calculation applies, it throws an error.
    # if the calculation does not apply, there is no need to specify and no error will be thrown.

# load coefficient table
tab_luc_coeff = pd.read_csv('Cseq_Grassland.csv',
                  sep=';',
                  header=0,
                  encoding='utf-8-sig')

tab_pars = read_pars('SALCAfield_pars.csv')
cn_ratio = tab_pars['Value']['cn_ratio']


# %% calculation of CO2 emissions based on landuse change on grassland (AGS KLIM research group)
if (inp.c_eval_cstock_change_bool == True and c_luc_bool == True 
    and fi_humus_perc < 0.3 and int(c_luc_ancientcrop[:3]) not in [1,2,9] 
    and c_salcaprep['c_eros_permaculture'] == 1):
    """ a C-stock change on grassland is calculated if:
        - we decide to include it in our assessments (inp.c_eval_cstock_change_bool)
        - we had a land use change in the last 20 years
        - the soil is a mineral soil (organic soils have a separate calculation 
          for C-stock changes, see SALCAfield_field)
        - the crop before the change was a grassland type as well 
          (arable land has a different calculation)
        - the crop itself is a permanent crop according to the definition 
          for erosion (exclude arable crops since the topic is grassland)
    """
# =============================================================================
    # convert crop name to match the column GRASS_FROM
    grass_from = re.sub(r"_\d\d_", "_00_", crop_name)
    grass_from = re.sub("_valley", "", grass_from)
    grass_from = re.sub("_hill", "", grass_from)
    grass_from = re.sub("_mountain", "", grass_from)
    grass_from = re.sub("_mountian", "", grass_from)
    # convert ancient crop to match the column GRASS_TO
    grass_to = '07_grassland_00_' + c_luc_ancientcrop[4:]
    
    # coefficient determination
    searchresults = tab_luc_coeff.loc[(
        (tab_luc_coeff['GRASS_FROM'] == grass_from) &
        (tab_luc_coeff['GRASS_TO'] == grass_to) &
        (tab_luc_coeff['Region'] == f_region) &
        (tab_luc_coeff['Klimazone'] == f_climate_region_wsl))]
    
    if len(searchresults) != 1:
        logging.info('**********************************')
        logging.info('Warning: No unambiguous entry found in the coefficient tables for landuse change on grassland.')
        logging.info('Number of entries found: %d',len(searchresults))
        logging.info('Crop: %s',crop_name)
        logging.info('**********************************')
        # In case no unambiguous entry was found in the table, the emission can't be calculated, therefore is zero.
        # This should be the case for permanent_crops that don't belong to the grasslands in the table Cseq_Grassland.csv.
        c_e_co2_soil2air_grass_kg = 0
    else:
        abschnitt = searchresults['Abschnitt'].values[0]
        amplitude = searchresults['Amplitude'].values[0]
        tau = searchresults['tau'].values[0]
        
        # equation: delta_soc = change in C-stock [t C/ha]
        delta_soc = abschnitt + amplitude*math.exp((-1*fi_clay_frac/tau))
        
        # CO2 emission from soil to air: positive means the soil is emitting CO2, negative means
        # the soil is binding CO2. Unit: [kg CO2/ha/yr]
        c_e_co2_soil2air_grass_kg = delta_soc / delta_time * c_to_co2_conversion * 1000 * -1
    
else:
    c_e_co2_soil2air_grass_kg = 0
    
# multiply with areatime to get the absolute emission [kg CO2/ha/yr -> kg CO2]
c_e_co2_landtransf_grass_kg = c_e_co2_soil2air_grass_kg * c_salcaprep['c_areatime']

# calculate the N2O emission using the C/N ratio [kg N2O/ha/yr]
c_e_n2o_soil2air_grass_kg = n_to_n2o_conversion \
    * c_e_co2_soil2air_grass_kg/(c_to_co2_conversion*cn_ratio)
c_e_n2o_landtransf_grass_kg = n_to_n2o_conversion \
    * c_e_co2_landtransf_grass_kg/(c_to_co2_conversion*cn_ratio)
logging.info('CO2 emissions LUC Grassland [kgCO2/ha/yr] = %d',c_e_co2_soil2air_grass_kg)
logging.info('N2O emissions LUC Grassland [kgN2O/ha/yr] = %d',c_e_n2o_soil2air_grass_kg)

# %% calculation for landuse change on arable land or between grassland and arable land (IPCC)
"""
  This C-stock change is calculated if we decide to include it in our assessments 
  (inp.c_eval_cstock_change_bool), the soil is a mineral soil and the 
  previous case of land use change on grassland did not apply 
  (which means that result is = 0) 
"""
if inp.c_eval_cstock_change_bool == True and fi_humus_perc < 0.3 and c_e_co2_landtransf_grass_kg == 0:
    """ inputs needed:
            f_salcaprep['mean_temperature']
            f_climate_zone
            f_climate_type
            fi_sand_frac
            fi_clay_frac
            c_salcaprep['c_eros_permaculture']
            f_quan_LU
            c_grazing
            lman/sman events, weight of machinery, number of animals
            irrigation, compost application/etc.
            tillage = c_salcaprep['c_protective_sowi'] / soil treatment assessment as in SALCA-BD (goal = differentiate tillage, reduced tillage, no-till)
            c_salcaprep['tr_harv_sepr']
            c_salcaprep['tr_fert']
            further c_salcaprep events
    """
    # table with stock change factors:
    tab_scf = pd.read_csv('Cstock_change_factors.csv', sep=';', header=6, encoding='utf-8-sig')
    # table with default reference soil organic C stocks SOCref for mineral soils
    tab_socref = pd.read_csv('SOCref_table.csv', sep=';', header=6, encoding='utf-8-sig')
    tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                             columns=js.loads(inp.tab_crops)['columns'],
                             index=js.loads(inp.tab_crops)['index']
                             )
    tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                             columns=js.loads(inp.tab_mach)['columns'],
                             index=js.loads(inp.tab_mach)['index']
                             )
    # load machine combinations present on the farm
    maco_list = inp.get_events('treatment_maco_event')
    mc_dict = pd.DataFrame(maco_list).set_index("f_maco_id")
    mc_dict.drop(columns=['event_context'], inplace=True)
    mc_dict = mc_dict.applymap(lambda a: a[4:])
    
    # determine the climate and moisture regime:
    climate_regime_str = inp.f_climate_zone_carbon  # Cool temperate = standard for CH, according to IPCC climate region map
    climate_regime = re.sub(r'[0-9]*\_', '', climate_regime_str, count = 1)  # remove the number and underscore in front of the string
    climate_regime = re.sub(r'\_', ' ', climate_regime)  # replace underscore with space
    climate_regime = climate_regime.title()  # change first letter of each word to uppercase
    if climate_regime == 'Polar':  # polar currently not implemented. Use boreal instead.
        climate_regime = 'Boreal'
    # moisture_regime according to the climate type variable:
    moisture_regime = "dry" if inp.f_climate_type == "001 dry" else "moist"  # moist = standard for CH, according to IPCC climate region map
    logging.info("Climate regime = %s", climate_regime)
    logging.info("Moisture regime = %s", moisture_regime)
    
    # stock change factor for land-use systems or sub-systems for a particular land-use (current crop):
    # mapping of land use from SALCAtables to the categories of the land-use category for the C-stock change factor
    # paddy rice not implemented (Keep in mind: paddy rice would only use the factor_landuse and not the factors factor_management and factor_org_input)!
    mapdict_landuse = {
    'Arable land': 'Long term cultivated',
    'Temporary grassland': 'Temporary set aside',
    'Permanent grassland intensive': 'Temporary set aside',
    'Permanent grassland extensive': 'Temporary set aside',
    'Vineyards': 'Perennial tree crop',
    'Fruit trees': 'Perennial tree crop',
    'Vegetables': 'Long term cultivated'
    }
    if '09_ecological' in crop_name:
        # set asides are distributed into 4 crops with their python name starting with 09_ecological
        landuse_level = 'Temporary set aside'
    else:
        # use the column land use from SALCAtables_crops to determine landuse_level
        landuse_key = tab_crops.loc[tab_crops['NameEN'] == crop_name, 'land use'].item()
        landuse_level = mapdict_landuse[landuse_key]
    
    factor_landuse = tab_scf.loc[(tab_scf['Factor value type'] == 'Land use (FLU)') & 
                                 (tab_scf['Level'] == landuse_level) &
                                 (tab_scf['Temperature regime'] == climate_regime) &
                                 (tab_scf['Moisture regime'] == moisture_regime),'IPCC defaults'].item()
    
    # stock change factor for management/tillage (current crop):
    # base factor: reduced tillage = everything else
    factor_tillage = 'Reduced'
    
    # full tillage = intensive soil treatment in SALCAtables_machinery:
    cat_till = []
    for index, value in enumerate(c_salcaprep['tr_soil']['date']):
        # SALCA-BD category
        bd_cat = get_bd_category(c_salcaprep['tr_soil']['MC'][index]).values
        cat_till.extend(bd_cat)
        # intensive soil treatment
        if c_salcaprep['tr_soil']['intense_trea'][index] == True:
            factor_tillage = 'Full'
    for index, value in enumerate(c_salcaprep['tr_sowi']['date']):
        # SALCA-BD category
        bd_cat = get_bd_category(c_salcaprep['tr_sowi']['MC'][index]).values
        cat_till.extend(bd_cat)
        # intensive soil treatment
        if c_salcaprep['tr_sowi']['intense_trea'][index] == True:
            factor_tillage = 'Full'
    for index, value in enumerate(c_salcaprep['tr_harv']['date']):
        # SALCA-BD category
        bd_cat = get_bd_category(c_salcaprep['tr_harv']['MC'][index]).values
        cat_till.extend(bd_cat)
        bd_cat = [get_bd_category(maco).values for maco in c_salcaprep['tr_harv']['MC_ff']]
        bd_cat = [x for xs in bd_cat for x in xs] # flatten the list
        cat_till.extend(bd_cat)
        # intensive soil treatment
        if c_salcaprep['tr_harv']['intense_trea'][index] == True:
            factor_tillage = 'Full'
    cat_till = [int(x) for x in cat_till if str(x) != 'nan']  # drop nan values
    cat_till = list(set(cat_till))  # drop duplicates
    # no-till = SALCA-BD category "keine Bodenbearbeitung" and/or no treatment_soil event, only sowing
    if factor_tillage == 'Reduced' and (21110101 in cat_till or c_salcaprep['tr_soil']['date'] == []):
        factor_tillage = 'No-till'
    
    if factor_tillage == 'Full':
        factor_management = tab_scf.loc[(tab_scf['Factor value type'] == 'Tillage (FMG)') & 
                                        (tab_scf['Level'] == factor_tillage),'IPCC defaults'].item()
    else:
        factor_management = tab_scf.loc[(tab_scf['Factor value type'] == 'Tillage (FMG)') & 
                                        (tab_scf['Level'] == factor_tillage) &
                                        (tab_scf['Temperature regime'] == climate_regime) &
                                        (tab_scf['Moisture regime'] == moisture_regime),'IPCC defaults'].item()
    
    # stock change factor for input of organic manure (current crop):
    # assessment questions:
    organic_amendmends = (True if c_salcaprep['tr_manure_l']['date'] != [] 
                          or c_salcaprep['tr_manure_s']['date'] != [] else False)
    low_residue_crop = (True if tab_crops.loc[tab_crops['NameEN'] == crop_name, 
                        'Type of residue crop'].item() != 'high' else False)
    """ Decide if there is bare fallow in the rotation:
        If the wintertime has a crop or plant cover, there is no bare soil in winter 
        and the other way around. --> check crop dates.
        We translate this to: If there are more than 2 months (= 60 days) 
        between the first soil treatment and the first sowing date,
        there is a bare fallow in the rotation. """
    if c_salcaprep['tr_soil']['date'] != [] and c_salcaprep['tr_sowi']['date'] != []:
        first_soil_treatment = min(c_salcaprep['tr_soil']['date'])
        first_sowing = min(c_salcaprep['tr_sowi']['date'])
        if dt.datetime.strptime(first_sowing, '%Y-%m-%d') - dt.datetime.strptime(first_soil_treatment, '%Y-%m-%d') >= dt.timedelta(days=60):
            rotation_with_bare_fallow = True
        else:
            rotation_with_bare_fallow = False
    else:
        rotation_with_bare_fallow = False
    # check presence of the id-number of the N fertilizers
    min_N_fert = True if any([int(x[0:3]) < 11 for x in c_salcaprep['tr_fert']['variable']]) else False 
    legume = True if tab_crops.loc[tab_crops['NameEN'] == crop_name, 'SALCA_BD_cropid'].item() == 23 else False
    # practices of enhancing residue production like using irrigation, cover crops or green manure,
    # vegetated fallows, high residue yielding crops, mixed crop/grass system (on at least 1/3 of the crop rotation)
    if c_salcaprep['tr_irri']['amount_m3'] != []:  # irrigated crop
        practice_c_enhanced_residues = True
    elif f_salcaprep['f_crop_rotation']['catch_crop']+f_salcaprep['f_crop_rotation']['ley_fallow'] >= 0.33:  # cover crops, green manure, ley or fallow in crop rotation
        practice_c_enhanced_residues = True
    elif low_residue_crop == False:  # high residue yielding crops
        practice_c_enhanced_residues = True
    else:
        practice_c_enhanced_residues = False
    # practice_c_increase: practices of organic amendmends, cover crops or green manure, mixed crop/grass system (on at least 1/3 of the crop rotation)
    # practice_c_increase = this means practice_c_enhanced_residues + organic_amendmends (both questions assessed)
    practice_c_increase = True if practice_c_enhanced_residues == True and organic_amendmends == True else False
    
    # decision tree:
    if c_salcaprep['tr_harv_sepr']['date'] !=[]:
        # crop residues are removed
        if organic_amendmends == True:
            input_level = 'Medium'
        else:
            input_level = 'Low'
    else:
        # crop residues left on the field
        if low_residue_crop == True or rotation_with_bare_fallow == True:
            if practice_c_increase == True:
                input_level = 'Medium'
            else:
                input_level = 'Low'
        elif min_N_fert == True or legume == True:
            if organic_amendmends == True:
                input_level = 'High with manure'
            elif practice_c_enhanced_residues == True:
                input_level = 'High without manure'
            else:
                input_level = 'Medium'
        else:
            if practice_c_enhanced_residues == True:
                input_level = 'Medium'
            else:
                input_level = 'Low'
    
    if input_level == 'Medium':
        factor_org_input = (tab_scf.loc[(tab_scf['Factor value type'] 
                                         == 'Input (FI)') & (tab_scf['Level'] 
                                         == input_level),'IPCC defaults'].item())
    else:
        factor_org_input = tab_scf.loc[(tab_scf['Factor value type'] == 'Input (FI)') & 
                                       (tab_scf['Level'] == input_level) &
                                       (tab_scf['Temperature regime'] == climate_regime) &
                                       (tab_scf['Moisture regime'] == moisture_regime),'IPCC defaults'].item()
    
    """ factor changes in last 20 years:
        carbon stock change: factor land use (FLU)
        what was the predominant land use in the last 20 years on this field?
            Descr: A change in land use leads to a different soil state over 
            a time period of around 20 years with a different
            carbon storage potential. Until the new equilibrium is reached, 
            carbon is either bound or released. Those positive or negative 
            emissions are assessed based on these questions about past cultivation 
            compared to the cultivation details of the current crop.
    """       
    factor_historic_landuse = tab_scf.loc[(tab_scf['Factor value type'] == 'Land use (FLU)') & 
                                 (tab_scf['Level'] == c_historic_landuse) &
                                 (tab_scf['Temperature regime'] == climate_regime) &
                                 (tab_scf['Moisture regime'] == moisture_regime),'IPCC defaults'].item()
    
    """ carbon stock change: factor tillage/management (FMG)
        what was the predominant tillage regime in the last 20 years on this field?
            Descr: A change in the tillage regime leads to a different soil state 
            over a time period of around 20 years with a different carbon storage 
            potential. Until the new equilibrium is reached, carbon is either 
            bound or released. Those positive or negative emissions are assessed 
            based on these questions about past cultivation compared to the 
            cultivation details of the current crop.
    """
    if c_historic_management == 'Full':
        factor_historic_management = tab_scf.loc[(tab_scf['Factor value type'] == 'Tillage (FMG)') & 
                                        (tab_scf['Level'] == c_historic_management),'IPCC defaults'].item()
    else:
        factor_historic_management = tab_scf.loc[(tab_scf['Factor value type'] == 'Tillage (FMG)') & 
                                        (tab_scf['Level'] == c_historic_management) &
                                        (tab_scf['Temperature regime'] == climate_regime) &
                                        (tab_scf['Moisture regime'] == moisture_regime),'IPCC defaults'].item()
    
    # carbon stock change: factor input (FI)
        # carbon stock change: What was the predominant cultivation practice 
        # in the last 20 years on this field? Were crop residues 
        # harvested/removed? (No = left on the field)
    c_historic_residues = inp.c_historic_residues
        # carbon stock change: Has practicing organic amendment been 
        # predominant in the last 20 years on this field?
    c_historic_amended_org = inp.c_historic_amended_org
        # carbon stock change: Were crops with low amounts of harvest residues 
        # the predominant crops grown in this field over the last 20 years 
        # (e.g. root crops, maize, oil crops, vegetables, etc.)?
    c_historic_low_residue_crop = inp.c_historic_low_residue_crop
        # carbon stock change: Did the crop rotation on this field include 
        # frequent bare fallow periods between crops in the last 20 years?
    c_historic_bare_fallow = inp.c_historic_bare_fallow
        # carbon stock change: Did the cultivation of this field during the 
        # last 20 years include mineral fertilizer application on a regular basis?
    c_historic_min_fert = inp.c_historic_min_fert
        # carbon stock change: Did the crop rotation on this field regularly 
        # include legume crops in the last 20 years?
    c_historic_legume = inp.c_historic_legume
        # carbon stock change: Did the predominant cultivation practices 
        # in the last 20 years include irrigation?
    c_historic_irrigation = inp.c_historic_irrigation
    """ carbon stock change: Did the crop rotation on this field include cover crops, 
        green manure crops, ley or vegetated fallow in the last 20 years?
        Descr: A change in the biomass input regime leads to a different 
        soil state over a time period of around 20 years with a different
        carbon storage potential. Until the new equilibrium is reached, 
        carbon is either bound or released. Those positive or negative 
        emissions are assessed based on these questions about past 
        cultivation compared to the cultivation details of the current crop.        
    """
            
    c_historic_biomass_input = inp.c_historic_biomass_input
    # practices of enhancing residue production like using irrigation, cover crops or green manure,
    # vegetated fallows, high residue yielding crops, mixed crop/grass system (on at least 1/3 of the crop rotation)
    if c_historic_irrigation == True:  # irrigated crop
        historic_practice_c_enhanced_residues = True
    elif c_historic_biomass_input == True:  # cover crops, green manure, ley or fallow in crop rotation
        historic_practice_c_enhanced_residues = True
    elif c_historic_low_residue_crop == False:  # high residue yielding crops
        historic_practice_c_enhanced_residues = True
    else:
        historic_practice_c_enhanced_residues = False
    # practice_c_increase: practices of organic amendmends, cover crops or green manure, mixed crop/grass system (on at least 1/3 of the crop rotation)
    # practice_c_increase = this means practice_c_enhanced_residues + organic_amendmends (both questions assessed)
    historic_practice_c_increase = True if historic_practice_c_enhanced_residues == True and c_historic_amended_org == True else False
    
    # decision tree:
    if c_historic_residues == True:
        # crop residues are removed
        if c_historic_amended_org == True:
            historic_input_level = 'Medium'
        else:
            historic_input_level = 'Low'
    else:
        # crop residues left on the field
        if c_historic_low_residue_crop == True or c_historic_bare_fallow == True:
            if historic_practice_c_increase == True:
                historic_input_level = 'Medium'
            else:
                historic_input_level = 'Low'
        elif c_historic_min_fert == True or c_historic_legume == True:
            if c_historic_amended_org == True:
                historic_input_level = 'High with manure'
            elif historic_practice_c_enhanced_residues == True:
                historic_input_level = 'High without manure'
            else:
                historic_input_level = 'Medium'
        else:
            if historic_practice_c_enhanced_residues == True:
                historic_input_level = 'Medium'
            else:
                historic_input_level = 'Low'
    
    if historic_input_level == 'Medium':
        factor_historic_org_input = tab_scf.loc[
                                   (tab_scf['Factor value type'] == 'Input (FI)') 
                                 & (tab_scf['Level'] == historic_input_level),
                                    'IPCC defaults'].item()
    else:
        factor_historic_org_input = tab_scf.loc[(tab_scf['Factor value type'] == 'Input (FI)') 
                                 & (tab_scf['Level'] == historic_input_level) 
                                 & (tab_scf['Temperature regime'] == climate_regime) 
                                 & (tab_scf['Moisture regime'] == moisture_regime),
                                   'IPCC defaults'].item()
    
    # Default reference soil organic C stocks SOCref [t C/ha]
    soc_ref = tab_socref.loc[(tab_socref['Temperature regime'] == climate_regime) 
                           & (tab_socref['Moisture regime'] == moisture_regime),
                             'HAC soils'].item()
    
    # equations: delta_soc = change in C-stock [t C/ha]
    soc_today = soc_ref * factor_landuse * factor_management * factor_org_input
    soc_past = soc_ref * factor_historic_landuse * factor_historic_management * factor_historic_org_input
    delta_soc = (soc_today - soc_past) / delta_time
    
    
    # CO2 emission from soil to air: positive means the soil is emitting CO2, negative means
    # the soil is binding CO2. Unit: [kg CO2/ha/yr]
    c_e_co2_soil2air_arable_kg = delta_soc * c_to_co2_conversion * 1000 * -1
    
    # Print an overview over the assessment:
    logging.info('**************************')
    logging.info('Calculation factors were as follows:')
    logging.info("factor_landuse = %s and factor_historic_landuse = %s", factor_landuse, factor_historic_landuse)
    logging.info("factor_management (tillage) = %s and factor_historic_management (tillage) = %s", factor_management, factor_historic_management)
    logging.info("factor_org_input = %s and factor_historic_org_input = %s", factor_org_input, factor_historic_org_input)
    logging.info('**************************')
    
else:
    c_e_co2_soil2air_arable_kg = 0
# multiply with areatime to get the absolute emission [kg CO2/ha/yr -> kg CO2]
c_e_co2_landtransf_arable_kg = c_e_co2_soil2air_arable_kg * c_salcaprep['c_areatime']
# calculate the N2O emission using the C/N ratio [kg N2O/ha/yr]
c_e_n2o_soil2air_arable_kg = n_to_n2o_conversion \
    * c_e_co2_soil2air_arable_kg/(c_to_co2_conversion*cn_ratio)
c_e_n2o_landtransf_arable_kg = n_to_n2o_conversion \
    * c_e_co2_landtransf_arable_kg/(c_to_co2_conversion*cn_ratio)
logging.info('**************************')
logging.info('CO2 emissions LUC cropland [kgCO2/ha/yr] = %d', c_e_co2_soil2air_arable_kg)
logging.info('N2O emissions LUC cropland [kgN2O/ha/yr] = %d', c_e_n2o_landtransf_arable_kg)
logging.info('**************************')


# %% output ===================================================================

out.c_e_landtransf_grass_kgCO2 = c_e_co2_landtransf_grass_kg
out.c_e_landtransf_arable_kgCO2 = c_e_co2_landtransf_arable_kg
out.c_e_landtransf_grass_kgN2O = c_e_n2o_landtransf_grass_kg
out.c_e_landtransf_arable_kgN2O = c_e_n2o_landtransf_arable_kg

# %% end sequence =============================================================
end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
