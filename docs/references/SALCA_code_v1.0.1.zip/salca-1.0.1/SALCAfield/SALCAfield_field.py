# -*- coding: utf-8 -*-
"""
File name: SALCAfield_field.py
Created on Wed Jan 22 15:28:34 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script estimates N and CO2 emissions to the air at field level
    N emissions include NH3, N2O, and NOx.
    It also calculates the land occupation and transformation.

Calculation level:
    Field

Related scripts: SALCAfield_crop.py (land use change emissions at crop level), 
                 SALCAanimal_farm.py (nutrient contents of manure)
"""


# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd
import numpy as np
import math

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAfield_field'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('field')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes ===========================================================

class Factors:
    # parameters used. Can be left here, as they are constants
    lman_density_tpm3 = 1  # t/m3

    # content of N, Ca, Mg of fertilisers, is 1 by definition, 
    # as the inputs are given in "pure" nutrients
    an_kgNpkg = 1
    urea_kgNpkg = 1
    uan_kgNpkg = 1
    map_dap_kgNpkg = 1
    anp_kgNpkg = 1
    can_kgNpkg = 1
    as_kgNpkg = 1
    nk_kgNpkg = 1
    mf_others_kgNpkg = 1
    lime_kgCapkg = 1  # [kg Ca/kg]
    carbonation_kgCapkg = 1
    algae_kgCapkg = 1
    mg_kgMgpkg = 1  # [kg Mg/kg]

# %% define functions =========================================================
def sum_areatime_by_code(c_areatime, c_area_code, ref):
    '''
    calculates the sum of land occupation and transformation by area_code.
    c_area_time: array of land occupation values
    c_area_code: array of land use type codes
    ref: the requested land use type code
    '''
    # setup
    sum_areatime = 0
    for i_crop in np.arange(len(c_areatime)):
        if c_area_code[i_crop] == ref:
            sum_areatime += c_areatime[i_crop]
    # convert from ha to m2:
    sum_areatime_m2 = sum_areatime * 10000
    return sum_areatime_m2

def read_pars(path):  # read CSV file
    """ read CSV file with parameters from path """
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab

def read_table(path):  # read CSV file
    """ read CSV file with a table from path """
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    # in all tables start at line 7, i.e. skip 6 lines (header)
    return tab

def extract_prep(c_salcaprep, label):
    """ extract information about crops for each crop in the field.
        label: list of keys, length 1 to 2 """
    output = []  # setup empty list
    if len(label) == 1:
        # if only one label is given in the list
        # iterate through the crops and append the entry of the given label
        # to the output
        for crop in c_salcaprep.values():
            output.append(crop[label[0]])
        return output
    elif len(label) == 2:
        # if two labels are given in a list, iterate through the crops and 
        # append the entry of the given labels to the output. 
        # The second label is usually used to extract specific
        # information about a treatment.
        for crop in c_salcaprep.values():
            output.append(crop[label[0]][label[1]])
        return output
    else:
        # if no list of 1 or 2 elements were given as label
        logging.info('The parameter "label" needs to be a list of 1 to 2 key \
              arguments.')


def unpack_dc(dc):
    """ Unpack a dataframe, which was dumped into a string.
        input: the string containing the dataframe
        this includes information about index and column names. """
    import pandas as pd
    import json as js
    return pd.DataFrame(data=js.loads(dc)['data'],
                        columns=js.loads(dc)['columns'],
                        index=js.loads(dc)['index'])

# %% input for preparation ====================================================

logging.info("Start time of preparation part: %s", dt.datetime.now(tz=None))

# %% tables ===================================================================
# load the manure table from SALCAtables.
tab_manu = unpack_dc(inp.tab_manu)
# load crops table
tab_crops = unpack_dc(inp.tab_crops)
# table for EF NH3 manure spreading from SALCAanimal_farm:
# Needed for directly to the field applied imported organic manure
tab_EF_NH3 = pd.DataFrame({'manure class': ['Cattle', 'Pigs',
                                            'Sheep and goats',
                                            'Horses', 'Poultry',
                                            'Unassigned'],
                           'EF_solid': [0.8, 0.6, 0.7, 0.7, 0.4, 0.64],
                           'EF_liquid': [0.5, 0.35, 0.42, 0.42, 0.4, 0.42]})

# %% load information from salcaprep_crop =====================================
# setup an empty dictionary
c_salcaprep = {}
# list of the different treatments in SALCAprep_crop
treatment_list = ['tr_manure_s', 'tr_sowi', 'tr_fert', 'tr_harv',
                  'tr_manure_l', 'tr_ppp', 'tr_soil', 'tr_harv_sepr']
# list of the different crops, returns the dev_crop_ids
crop_list = []
# iterate through the crops in the field and store their information in
# respective subfolders.
for i, crop_prep_str in enumerate(inp.c_salcaprep):
    # load the total information from SALCAprep abount the current crop
    crop_prep = js.loads(crop_prep_str)
    # extract and store the crop definition (Python name) from the salca
    # context
    crop_list.append(crop_prep['crop_id'])
    crop_prep['crop_definition_name'] = crop_prep['crop_name']
    # extract and store start- and end date of crop evaluation
    crop_prep['c_end'] = dt.datetime.strptime(crop_prep['c_end'], '%Y-%m-%d')
    crop_prep['c_start'] = dt.datetime.strptime(
        crop_prep['c_start'], '%Y-%m-%d')
    # iterate through the treatments
    for treatment in treatment_list:
        # extract the treatment dates in str
        treatment_dates = crop_prep[treatment]['date_dt']
        # empty the entry for the dates in dt.date
        crop_prep[treatment]['date_dt'] = []
        # convert the treatment dates to dt.date format
        for date in treatment_dates:
            crop_prep[treatment]['date_dt'].append(dt.datetime.strptime(date,
                                                                        '%Y-%m-%d'))
    # store the information about the crop in the c_salcaprep dictionary
    c_salcaprep[str(crop_prep['crop_id'])] = crop_prep

# load the information from SALCAprep_farm
f_salcaprep = js.loads(inp.f_salcaprep)

# area of the field, [ha]
fi_fia_ha = inp.fi_fia_ha

# pH on the soil
fi_pH = inp.fi_pH

# humus fraction (0.0 - 1) in soil
fi_humus_perc = inp.fi_humus_perc

# soil water level
fi_soil_water_level_m = inp.fi_soil_water_level_m

# fraction of the year * area per crop in the field [a*ha]
c_areatime = extract_prep(c_salcaprep, ['c_areatime'])
# list of the areas of the crops in the field [ha]
c_ca_ha = inp.c_ca_ha

# list of the previous harvest dates
# previous_harv_date = inp.c_prha_date (earlier than harv_date)
harv_date = extract_prep(c_salcaprep, ['tr_harv', 'date_dt'])

# extract the climatic data from salcaprep_farm, monthly data.
temp_mean_deg = f_salcaprep['temperature']  # [°C]
humidity_mean_perc = f_salcaprep['humidity']  # [%]
# load N/TAN content of slurry and manure from SALCAanimal_farm [kg N/m3, kg N/t]
f_lman_kgNpm3 = inp.f_lman_kgNpm3
f_sman_kgNpt = inp.f_sman_kgNpt
# content of soluble N in total N in slurry and manure
f_lman_kgTANpm3 = inp.f_lman_kgTANpm3  # [kg NH4-N / m3]
f_sman_kgTANpt = inp.f_sman_kgTANpt  # [kg NH4-N / t]

# load P2O5 and K2O content of slurry and manure from SALCAanimal_farm
f_lman_kgP2O5pm3 = inp.f_lman_kgP2O5pm3
f_sman_kgP2O5pt = inp.f_sman_kgP2O5pt
f_lman_kgK2Opm3 = inp.f_lman_kgK2Opm3
f_sman_kgK2Opt = inp.f_sman_kgK2Opt

# load NH4-N for cattle, pigs, poultry and others from SALCAanimal_farm
# [kg NH4-N]
f_sman_NH4N_from_cattle_frac = inp.f_sman_NH4N_from_cattle_perc
f_sman_NH4N_from_pigs_frac = inp.f_sman_NH4N_from_pigs_perc
f_sman_NH4N_from_poul_frac = inp.f_sman_NH4N_from_poul_perc
f_sman_NH4N_from_others_frac = inp.f_sman_NH4N_from_others_perc
# load efs for slurry and manure from SALCAanimal
f_ef_lman_frac = inp.f_ef_lman_frac  # kg NH3-N/kg TAN
f_ef_sman_frac = inp.f_ef_sman_frac  # kg NH3-N/kg TAN
# load start and end date of the evaluation
start_evaluation = inp.f_start_evaluation
end_evaluation = inp.f_end_evaluation

# input from agrammon
f_agrammon = js.loads(inp.f_agrammon)
cf_lman_appl_frac = f_agrammon[
    'Correction factor NH3 liquid manure applied']

# %% calculation of preparation ===============================================
# codes of land use type of crops in the field.
c_area_code = []  # setup empty list
""" table to map land use types to respective codes:
    1=Arable, 2=Grassland int., 3=Grassland ext., 4= Fruit trees, 5=Vineyards
"""
tab_area_code = read_table('Area_Code.csv')

# prepare monthly slurry/manure applied on field
monthly_lman_kgN = np.zeros(12)  # [m3/month]
monthly_sman_kgN = np.zeros(12)  # [t/month]
monthly_lman_kgTAN = np.zeros(12)  # [m3/month]
monthly_sman_kgTAN = np.zeros(12)  # [t/month]

# setup slurry/liquid manure
lman_month = []  # month of application of slurry
lman_amount_m3 = []  # amount applied [m3]
lman_kgN_month = []  # kgN per month from liquid manure
lman_kgTAN_month = []  # kgTAN per month from liquid manure
amount_lman_farm_m3 = 0
amount_lman_imported_m3 = 0
amount_sman_farm_t = 0
amount_sman_imported_t = 0
# setup solid manure
sman_month = []  # month of application of manure
sman_amount_t = []  # amount applied
time_s = []  # 0: not applied after 18.00, 1: applied after 18.00
sman_incorp_h = []  # incorporation time [h]
pract_s = []  # application practice
sman_kgN_month = []  # kgN per month from solid manure
sman_kgTAN_month = []  # kgTAN per month from solid manure

total_kgN_crop = {} # amount of N applied in kg for each crop
kgNpha = {} # calculated amount of N per ha for each crop
total_kgP2O5_crop = {} # amount of P2O5 applied in kg for each crop
total_kgK2O_crop = {} # amount of K2O applied in kg for each crop
for crop in crop_list:
    total_kgN_crop[str(crop)] = 0
    kgNpha[str(crop)] = 0
    total_kgP2O5_crop[str(crop)] = 0
    total_kgK2O_crop[str(crop)] = 0

# iterate through the different crops
for crop in crop_list:
    crop = str(crop)  # int -> str for the dictionary
    # extract the treatments for slurry and manure
    manure_l = c_salcaprep[crop]['tr_manure_l']
    manure_s = c_salcaprep[crop]['tr_manure_s']
    # extract the land use category for the current crop
    crop_area_code = tab_crops.loc[tab_crops['NameEN'] == c_salcaprep[crop]
                                   ['crop_definition_name'],
                                   'land use'].values[0]
    # check the code for the land use category in the table
    list_area_code = tab_area_code.loc[tab_area_code['Land use type']
                                       == crop_area_code].values[0][2:]
    # extract the correct code and append it to the list
    c_area_code.append(np.max(list_area_code))

    # iterate through the applications of slurry on the current crop
    for i in np.arange(len(manure_l['date'])):
        # extract the month of application
        lman_month.append(manure_l['date_dt'][i].month)
        # extract the applied amount [m3], corrected for dilution
        lman_amount_m3.append(manure_l['amount_m3'][i])
        # kgN and kgTAN per month from liquid manure: N_content from SALCAanimals
        # for farm_manure and from tab_manu for other organic manure
        if manure_l['variable'][i] == "liquid_farm_manure":
            n_content = f_lman_kgNpm3
            tan_content = f_lman_kgTANpm3
            p2o5_content = f_lman_kgP2O5pm3
            k2o_content = f_lman_kgK2Opm3
            amount_lman_farm_m3 += manure_l['amount_m3'][i]  #calculate total amount of liquid farm manure
        else:
            n_content = tab_manu['AM: N after storage'][tab_manu['NameEN'] == manure_l['variable'][i]].values[0]
            tan_content = tab_manu['AM: kg NH4-N/unit'][tab_manu['NameEN'] == manure_l['variable'][i]].values[0]
            p2o5_content = tab_manu['AM: P2O5'][tab_manu['NameEN'] == manure_l['variable'][i]].values[0]
            k2o_content = tab_manu['AM: K2O'][tab_manu['NameEN'] == manure_l['variable'][i]].values[0]
            amount_lman_imported_m3 += manure_l['amount_m3'][i]  # total amount of imported organic manure
            
        lman_kgN_month.append(manure_l['amount_m3'][i] * n_content)
        lman_kgTAN_month.append(manure_l['amount_m3'][i] * tan_content)
        # sum the total kg N applied on the crop (for SALCA-BD)
        total_kgN_crop[crop] += (manure_l['amount_m3'][i] * n_content)
        total_kgP2O5_crop[crop] += (manure_l['amount_m3'][i] * p2o5_content)
        total_kgK2O_crop[crop] += (manure_l['amount_m3'][i] * k2o_content)

    # iterate through the applications of manure on the current crop
    for i in np.arange(len(manure_s['date'])):
        sman_month.append(manure_s['date_dt'][i].month)  # month of application
        sman_amount_t.append(manure_s['amount_t'][i])  # applied amount [t]
        sman_incorp_h.append(manure_s['incorporation'][i])  # incorporation time [h]
        # kgN and kgTAN per month from solid manure: N_content from SALCAanimals
        # for farm_manure and from tab_manu for other organic manure
        if manure_s['variable'][i] == "solid_farm_manure":
            n_content = f_sman_kgNpt
            tan_content = f_sman_kgTANpt
            p2o5_content = f_sman_kgP2O5pt
            k2o_content = f_sman_kgK2Opt
            amount_sman_farm_t += manure_s['amount_t'][i]  #calculate total amount of solid farm manure
        else:
            n_content = tab_manu['AM: N after storage'][tab_manu['NameEN'] == manure_s['variable'][i]].values[0]
            tan_content = tab_manu['AM: kg NH4-N/unit'][tab_manu['NameEN'] == manure_s['variable'][i]].values[0]
            p2o5_content = tab_manu['AM: P2O5'][tab_manu['NameEN'] == manure_s['variable'][i]].values[0]
            k2o_content = tab_manu['AM: K2O'][tab_manu['NameEN'] == manure_s['variable'][i]].values[0]
            amount_sman_imported_t += manure_s['amount_t'][i]  # total amount of imported organic manure
        sman_kgN_month.append(manure_s['amount_t'][i] * n_content)
        sman_kgTAN_month.append(manure_s['amount_t'][i] * tan_content)
        # sum the total kg N applied on the crop (for SALCA-BD)
        total_kgN_crop[crop] += (manure_s['amount_t'][i] * n_content)
        total_kgP2O5_crop[crop] += (manure_s['amount_t'][i] * p2o5_content)
        total_kgK2O_crop[crop] += (manure_s['amount_t'][i] * k2o_content)

# for each slurry application
for i in np.arange(len(lman_month)):
    # add the applied amount of slurry [m3] to the corresponging month
    # corrected by -1 as jan is in position 0 on the array
    monthly_lman_kgN[lman_month[i]-1] += lman_kgN_month[i]
    monthly_lman_kgTAN[lman_month[i]-1] += lman_kgTAN_month[i]

# for each manure application
for i in np.arange(len(sman_month)):
    # add the applied amount of manure to the corresponging month
    # corrected by -1 as jan is in position 0 on the array
    monthly_sman_kgN[sman_month[i]-1] += sman_kgN_month[i]
    monthly_sman_kgTAN[sman_month[i]-1] += sman_kgTAN_month[i]
    # weight incorporation time by amount
    sman_incorp_h[i] *= sman_amount_t[i]//np.sum(sman_amount_t)

# combine incorporation time to a single value
sman_incorp_h = np.sum(sman_incorp_h)

# from treatment - fertilisers
# initialise the variables for the different fertilisers [kg]
an_kgN = 0                   # ammonium nitrate
urea_kgN = 0                 # urea
uan_kgN = 0                  # urea ammonium nitrate
map_dap_kgN = 0              # mono-ammonium-phosphate/di-ammonium-phosphate
anp_kgN = 0                  # ammonium nitrate phosphate
can_kgN = 0                  # calcium ammonium nitrate
as_kgN = 0                   # ammonium sulfate
nk_kgN = 0                   # NK-fertiliser
mf_others_kgN = 0            # other mineral fertiliser
lime_kgCa = 0                # lime (CaCO3)
carbonation_kgCa = 0         # carbonation lime (CaCO3), from sugar industry
algae_kgCa = 0               # lime (CaCO3) from algae
mg_kgMg = 0                  # magnesium (MgCO3)

# iterate through the different crops on the field 
# and sum up the applied fertiliser nutrients for the whole field
for crop in crop_list:
    # int -> str for the dictionary
    crop = str(crop)
    # extract the fertiliser treatments
    fertilisers = c_salcaprep[crop]['tr_fert']
    # iterate through the fertilisation treatments on the current crop
    for i in np.arange(len(fertilisers['date'])):
        # extract the name of the applied fertilisers
        fert_var = fertilisers['variable'][i]
        # if it matches with the template, add the applied amount to the
        # corresponding variable
        if fert_var in ['002 N Ammoniumnitrat']:
            an_kgN += fertilisers['amount_kg'][i]*Factors.an_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.an_kgNpkg
        elif fert_var in ['003 N Harnstoff']:
            urea_kgN += fertilisers['amount_kg'][i]*Factors.urea_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.urea_kgNpkg
        elif fert_var in ['004 N Harnstoff-AN']:
            uan_kgN += fertilisers['amount_kg'][i]*Factors.uan_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.uan_kgNpkg
        elif fert_var in ['005 N Monoammoniumphosphat',
                          '006 N Diammoniumphosphat']:
            map_dap_kgN += fertilisers['amount_kg'][i]*Factors.map_dap_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.map_dap_kgNpkg
        elif fert_var in ['007 N AN-Phosphat']:
            anp_kgN += fertilisers['amount_kg'][i]*Factors.anp_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.anp_kgNpkg
        elif fert_var in ['008 N Kalk-Ammoniumnitrat']:
            can_kgN += fertilisers['amount_kg'][i]*Factors.can_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.can_kgNpkg
        elif fert_var in ['009 N Ammoniumsulfat']:
            as_kgN += fertilisers['amount_kg'][i]*Factors.as_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.as_kgNpkg
        elif fert_var in ['010 N Kaliumnitrat']:
            nk_kgN += fertilisers['amount_kg'][i]*Factors.nk_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.nk_kgNpkg
        elif fert_var in ['011 N Ammoniak fluessig',
                          '001 N Mineralduenger unspezifiziert', ]:
            mf_others_kgN += fertilisers['amount_kg'][i]*Factors.mf_others_kgNpkg
            total_kgN_crop[crop] += fertilisers['amount_kg'][i]*Factors.mf_others_kgNpkg
        elif fert_var in ['025 Ca Kalk']:
            lime_kgCa += fertilisers['amount_kg'][i]*Factors.lime_kgCapkg
        elif fert_var in ['026 Ca Karbonationskalk']:
            carbonation_kgCa += fertilisers['amount_kg'][i] * \
                Factors.carbonation_kgCapkg
        elif fert_var in ['027 Ca Meeresalgenkalk']:
            algae_kgCa += fertilisers['amount_kg'][i]*Factors.algae_kgCapkg
        elif fert_var in ['028 Mg Magnesium']:
            mg_kgMg += fertilisers['amount_kg'][i]*Factors.mg_kgMgpkg
        elif fert_var in ['012 P Mineralduenger unspezifiziert', 
                          '013 P Triple-Superphos.', 
                          '014 P Superphosphat', 
                          '015 P Monoammoniumphosphat', 
                          '016 P Diammoniumphosphat', 
                          '017 P AN-Phosphat', 
                          '018 P Hyperphosphat', 
                          '019 P Thomasmehl']:
            total_kgP2O5_crop[crop] += fertilisers['amount_kg'][i]
        elif fert_var in ['020 K Mineralduenger unspezifiziert',
                          '021 K Kalisalz',
                          '022 K Kaliumsulfat',
                          '023 K Kaliumnitrat',
                          '024 K Patentkali']:
            total_kgK2O_crop[crop] += fertilisers['amount_kg'][i]

# total kg N applied on the crop (for SALCA-BD)
for crop in crop_list:
    crop = str(crop)
    kgNpha[crop] = total_kgN_crop[crop] / (c_salcaprep[crop]['c_areatime']/c_salcaprep[crop]['c_duration_years'])

logging.info('')
logging.info('Total kg N applied per crop on the field:')
logging.info(total_kgN_crop)
logging.info('Applied kgN/ha per crop on the field:')
logging.info(kgNpha)
logging.info('')

# from treatment - crop residues
# setup for the total N from crop residues [kg N] in the field
hres_kgN = 0  # hres for harvest residues
# iterate through the crops in the field
for j, crop in enumerate(crop_list):
    crop = str(crop)  # convert int -> str
    # extract the python name of the crop
    crop_name = c_salcaprep[crop]['crop_definition_name']
    # extract the harvest treatments
    harvest = c_salcaprep[crop]['tr_harv']
	# extract the harvest treatments of secondary products
    harvest_sepr = c_salcaprep[crop]['tr_harv_sepr']
    # harvest residues are present if no secondary products are harvested on
    # the crop. If secondary products are harvested at least once, it is assumed
	# that residues from all harvest events are exported from the field. The
	# date correlation between multiple events of harvest and harvest_sepr is
	# not checked for simplicity reasons.
    if harvest_sepr['date']==[]:
        # for all harvest treatments, if there are crop hres_kg/ha, their amount
        # per area and N content is extracted from the table and multiplied by the
        # area of the crop.
        for i in np.arange(len(harvest['date'])):
            # N content of the crop hres_kg/ha
            # [kg N/kg] (table values in kg N/t -> /1000)
            hres_kgNpkg = tab_crops.loc[tab_crops['NameEN'] == crop_name,
                                        'N Content harvest residues'].values[0]/1000
            # crop hres_kg/ha per area [kg/ha]
            hres_kgpha = float(tab_crops.loc[tab_crops['NameEN'] == crop_name,
                                             'SQ Optional Above Ground Crop Residues'
                                             ].values[0])
            if math.isnan(hres_kgpha):  # to correct if no value given in tab_crops
                hres_kgpha = 0.0
            hres_kgN += hres_kgNpkg*hres_kgpha*c_ca_ha[j]  # [kg N]
        # print to the module log:
        logging.info("Harvest residues are left on the field for crop: %s", crop_name)
        logging.info('hres_kgN= %s', str(hres_kgN))
    else:
        logging.info("Secondary products are harvested. No harvest residues left on"+\
              " the field for crop: %s", crop_name)


# %% output of preparation ====================================================

# prepare output dictionary
fi_field_prep = {
    'sman_incorp_h': sman_incorp_h,
    'fi_humus_perc' : fi_humus_perc,
    'fi_soil_water_level_m' : fi_soil_water_level_m,
    'fi_fia_ha': fi_fia_ha,  # > 0
    'fi_pH': fi_pH,
    # codes of land use type of crops in the field.
    'c_area_code': c_area_code,
    # fraction of the year * area per crop in the field
    'c_areatime': c_areatime,
    # list of the areas of the crops in the field
    'c_ca_ha': c_ca_ha,
    'start_evaluation': start_evaluation,
    'end_evaluation': end_evaluation,
    # 'harv_date': harv_date,
    'hres_kgN': hres_kgN,
    'temp_mean_deg': temp_mean_deg,
    'humidity_mean_perc': humidity_mean_perc,
    'f_lman_kgNpm3': f_lman_kgNpm3,
    'f_sman_kgNpt': f_sman_kgNpt,
    'f_lman_kgTANpm3': f_lman_kgTANpm3,
    'f_sman_kgTANpt': f_sman_kgTANpt,
    'f_sman_NH4N_from_cattle_frac': f_sman_NH4N_from_cattle_frac,
    'f_sman_NH4N_from_pigs_frac': f_sman_NH4N_from_pigs_frac,
    'f_sman_NH4N_from_poul_frac': f_sman_NH4N_from_poul_frac,
    'f_sman_NH4N_from_others_frac': f_sman_NH4N_from_others_frac,
    'f_ef_lman_frac': f_ef_lman_frac,
    'cf_lman_appl_frac': cf_lman_appl_frac,
    'f_ef_sman_frac': f_ef_sman_frac,
    #correction factor for solid manure application is directly calculated here
    'monthly_lman_kgN': list(monthly_lman_kgN),
    'monthly_lman_kgTAN': list(monthly_lman_kgTAN),
    'monthly_sman_kgN': list(monthly_sman_kgN),
    'monthly_sman_kgTAN': list(monthly_sman_kgTAN),
    'an_kgN': an_kgN,
    'urea_kgN': urea_kgN,
    'uan_kgN': uan_kgN,
    'map_dap_kgN': map_dap_kgN,
    'anp_kgN': anp_kgN,
    'can_kgN': can_kgN,
    'as_kgN': as_kgN,
    'nk_kgN': nk_kgN,
    'mf_others_kgN': mf_others_kgN,
    'lime_kgCa': lime_kgCa,
    'carbonation_kgCa': carbonation_kgCa,
    'algae_kgCa': algae_kgCa,
    'mg_kgMg': mg_kgMg
}
logging.info("End time of preparation part: %s", dt.datetime.now(tz=None))

# %% input of calculation =====================================================
logging.info("Start time of calculation part: %s", dt.datetime.now(tz=None))
# Load parameters, emission factors and correction factors:
# load input from NH3 Mineral Fertilisers table
nh3_mineral_fertilisers = read_table('NH3_Mineral_Fertilisers.csv').set_index('Variable')
# load input from Incorp_time_cf table
incorp_time_cf = read_table('Incorp_Time_CF.csv').set_index('Variable')
# load input from SALCAfield tables
tab_pars = read_pars('SALCAfield_pars.csv')
# mineral fertiliser and crop hres_kg/ha, kg N2O-N/kg N, IPCC 2019
ef_1_kgN20_NpkgN= tab_pars['Value']['ef_1_kgN20_NpkgN']  # for min. N fertiliser, slurry and crop residues [kg N2O-N/kg N]
ef_2_kgN20_NpkgN= tab_pars['Value']['ef_2_kgN20_NpkgN']  # for solid manure und org. fert. [kg N2O-N/kg N]
# ef for induced N2O from NO3 and NOx calculated in SALCAnitrate
ef_4_kgN20_NpkgN = tab_pars['Value']['ef_4_kgN20_NpkgN']  # N2O from NH3 & NOx [kg N2O-N/kg N]
ef_5_kgN20_NpkgN = tab_pars['Value']['ef_5_kgN20_NpkgN']  # N2O from NO3 [kg N2O-N/kg N]
# kg NOx-N/kg N excreted
ef_6_kgNOx_NpkgN = tab_pars['Value']['ef_6_kgNOx_NpkgN']
# Correction factors for N2O emissions depending on the application rate
n2o_cf1 = tab_pars['Value']['n2o_cf1']
n2o_cf2 = tab_pars['Value']['n2o_cf2']
n2o_cf3 = tab_pars['Value']['n2o_cf3']
# amounts of CO2 per fertiliser
urea_kgCO2pkgN = tab_pars['Value']['urea_kgCO2pkgN']  # [kg CO2/kg N]
lime_kgCO2pkgCaCO3 = tab_pars['Value']['lime_kgCO2pkgCaCO3']  # [kg CO2/kg CaCO3]
lime_kgCO2pkgCa = tab_pars['Value']['lime_kgCO2pkgCa']  # [kg CO2/kg Ca]
ef_kgCO2pkgMg =  tab_pars['Value']['ef_kgCO2pkgMg']  # [kg CO2/kg Mg]
# default utilisation periods of different land use classes
util_arable = tab_pars['Value']['util_arable']  # by definition
util_past_int = tab_pars['Value']['util_past_int']
util_past_ext = tab_pars['Value']['util_past_ext']
util_fruit_trees = tab_pars['Value']['util_fruit_trees']
util_vineyards = tab_pars['Value']['util_vineyards']
# load variables for the calucation of CO2 emissions for organic soil
ef_org_arable =  tab_pars['Value']['ef_org_arable']
ef_org_c_min =   tab_pars['Value']['ef_org_c_min']
ef_org_c_diff =  tab_pars['Value']['ef_org_c_diff']
cn_ratio = tab_pars['Value']['cn_ratio']


# load input from SALCAfield_prep
# incorporation after x hours:
sman_incorp_h = fi_field_prep['sman_incorp_h']
# area of the field [ha]
fi_fia_ha = fi_field_prep['fi_fia_ha']
# pH of the soil
fi_pH = fi_field_prep['fi_pH']
# codes of land use type of crops on the field.
c_area_code = fi_field_prep['c_area_code']
# area per crop on the field * fraction of the year [ha*a]
c_areatime = fi_field_prep['c_areatime']
# list of the areas of the crops on the field [ha]
c_ca_ha = fi_field_prep['c_ca_ha']

# humus percentage in soil
fi_humus_perc = fi_field_prep['fi_humus_perc']

# N from crop hres_kg/ha [kg N]
hres_kgN = fi_field_prep['hres_kgN']
# monthly mean temperature [°C]
# array of 12 entries, jan - dec
temp_mean_deg = np.array(fi_field_prep['temp_mean_deg'])
# monthly data of mean humidity [%]
# array of 12 entries, jan - dec
humidity_mean_perc = np.array(fi_field_prep['humidity_mean_perc'])
# N content of slurry and manure from SALCAanimal_farm [kg N/m3, kg N/t]
f_lman_kgNpm3 = fi_field_prep['f_lman_kgNpm3']
f_sman_kgNpt = fi_field_prep['f_sman_kgNpt']
# soluble NH4-N in slurry/manure [kg NH4-N/m3, kg NH4-N/t]
f_lman_kgTANpm3 = fi_field_prep['f_lman_kgTANpm3']
f_sman_kgTANpt = fi_field_prep['f_sman_kgTANpt']
# nh4n for cattle, pigs, poultry and others from SALCAanimal_farm [kg NH4-N]
f_sman_NH4N_from_cattle_frac = fi_field_prep['f_sman_NH4N_from_cattle_frac']
f_sman_NH4N_from_pigs_frac = fi_field_prep['f_sman_NH4N_from_pigs_frac']
f_sman_NH4N_from_poul_frac = fi_field_prep['f_sman_NH4N_from_poul_frac']
f_sman_NH4N_from_others_frac = fi_field_prep['f_sman_NH4N_from_others_frac']
# efs for slurry and manure from SALCAanimal [NH3-N/kg TAN]
f_ef_lman_frac = fi_field_prep['f_ef_lman_frac']
cf_lman_appl_frac = fi_field_prep['cf_lman_appl_frac']
f_ef_sman_frac = fi_field_prep['f_ef_sman_frac']
# N applied per month from liquid manure
monthly_lman_kgN = np.array(fi_field_prep['monthly_lman_kgN'])
monthly_lman_kgTAN = np.array(fi_field_prep['monthly_lman_kgTAN'])
# N applied per month from solid manure
monthly_sman_kgN = np.array(fi_field_prep['monthly_sman_kgN'])
monthly_sman_kgTAN = np.array(fi_field_prep['monthly_sman_kgTAN'])
# N from fertilisers [kg N]
an_kgN = fi_field_prep['an_kgN']
urea_kgN = fi_field_prep['urea_kgN']
uan_kgN = fi_field_prep['uan_kgN']
map_dap_kgN = fi_field_prep['map_dap_kgN']
anp_kgN = fi_field_prep['anp_kgN']
can_kgN = fi_field_prep['can_kgN']
as_kgN = fi_field_prep['as_kgN']
nk_kgN = fi_field_prep['nk_kgN']
mf_others_kgN = fi_field_prep['mf_others_kgN']
lime_kgCa = fi_field_prep['lime_kgCa']
carbonation_kgCa = fi_field_prep['carbonation_kgCa']
algae_kgCa = fi_field_prep['algae_kgCa']
mg_kgMg = fi_field_prep['mg_kgMg']

# soil water level
fi_soil_water_level_m =  fi_field_prep['fi_soil_water_level_m']

# start date of the evaluation of the farm
start_evaluation = dt.datetime.strptime(fi_field_prep['start_evaluation'],
                                        '%Y-%m-%d')
# end date of the evaluation of the farm
end_evaluation = dt.datetime.strptime(fi_field_prep['end_evaluation'],
                                      '%Y-%m-%d')

# area * time for the field
fi_duration = end_evaluation-start_evaluation  # datetime object
fi_area_time_year_ha = fi_fia_ha*fi_duration.days/365  # [ha*a]

# P and K fertiliser amounts: calculate application per ha and year on field level
fert_kgP2O5phapa = sum(total_kgP2O5_crop.values())/fi_area_time_year_ha  # P2O5 total per ha [kg P2O5/ha/year]
fert_kgK2Ophapa = sum(total_kgK2O_crop.values())/fi_area_time_year_ha  # K2O total per ha [kg K2O/ha/year]
fert_kgMgphapa = mg_kgMg/fi_area_time_year_ha # Mg total per ha [kg Mg/ha/year]

# %% calculation ==============================================================

# CO2 emissions from org soil [Unit: kg CO2] Source: Tiemayer, 2020
# The emissions apply only to organic soil.
# Therefore this value is calculated only if the humus percentage is above 30%
if fi_humus_perc >= 0.3:
    e_orgSoil_tC = ef_org_c_min + ef_org_c_diff * math.e ** (-7.52 * math.e ** (12.97*-fi_soil_water_level_m))
    e_orgSoil_kgC = e_orgSoil_tC *1000
    e_orgSoil_kgCO2 = e_orgSoil_kgC*44/12  # Conversion C -> CO2
    if e_orgSoil_kgCO2 > ef_org_arable:
        e_orgSoil_kgCO2 = ef_org_arable
    elif e_orgSoil_kgCO2 < 0:
        e_orgSoil_kgCO2 = 0
else:
    e_orgSoil_kgCO2 = 0  # for mineral soils (humus percentage < 30%)
    e_orgSoil_kgC = 0
e_orgSoil_kgCO2 = e_orgSoil_kgCO2 * np.mean(c_areatime)  # multiplication with areatime [kg CO2/ha/yr * ha * yr = kg CO2]


# sum N from  fertilisers [kg N]
fert_min_kgN = (an_kgN + urea_kgN + uan_kgN + map_dap_kgN + anp_kgN
                + can_kgN + as_kgN + nk_kgN + mf_others_kgN)

# calculation N2O
# N from manure, slurry and fertilisers [kg N]
fert_kgN = (sum(monthly_sman_kgN)
            + sum(monthly_lman_kgN)
            + fert_min_kgN)
# soluble N from manure, slurry and mineral fertilisers [kg N]
# assumes 100% soluble N from mineral fertilisers
fert_kgTAN = (sum(monthly_sman_kgTAN)
              + sum(monthly_lman_kgTAN)
              + fert_min_kgN)
# N total per ha [kg N/ha/year]
fert_kgNphapa = fert_kgN/fi_area_time_year_ha
# correction factor N2O emissions, see Nemecek & Ledgard (2016)
# the factor 0.1 comes from a unit conversion
if fert_kgN == 0:
    n2o_cf = 0
else:
    n2o_cf = 0.1*(n2o_cf1/fert_kgNphapa+n2o_cf2+n2o_cf3*fert_kgNphapa)

# N2O from mineralisation of SOM [kg N]
nmin_som_kgN = e_orgSoil_kgC/cn_ratio

# Direct N2O emissions from the field [kg N2O-N]
e_direct_kgN2O_N = ((ef_1_kgN20_NpkgN*fert_kgTAN
                     + ef_2_kgN20_NpkgN*(fert_kgN-fert_kgTAN))
                     * n2o_cf+ef_1_kgN20_NpkgN*hres_kgN
                     + ef_1_kgN20_NpkgN*nmin_som_kgN)

# calculation nitrogen oxide emissions [kg NOx-N]
e_fert_kgNOx_N = fert_kgN * ef_6_kgNOx_NpkgN

# calculation of NH3 emissions
# calculate monthly saturation deficit from humidity and temperature
# Note: as it is a physical relationship, the factors are constants
saturation_deficit_m = ((1-humidity_mean_perc)*6.112
                        * np.power(np.ones(12)*math.exp(1),
                                   (17.67 * temp_mean_deg)
                                   / (243.5+temp_mean_deg))
                        )
# soluble N in slurry and manure per month [kg TAN]
lman_m_kgTAN = monthly_lman_kgTAN
sman_m_kgTAN = monthly_sman_kgTAN

# reduction factors for NH3 from manure [%/100]
# threshold values for incorporation time [h]
list_incorp_time_h = [72, 24, 8, 4, 1, 0]
list_incorp_time_cf_1 = incorp_time_cf.loc['list_incorp_time_cf_1',
                                           '72':'no incorporation'].to_list()  # cattle and pigs
list_incorp_time_cf_2 = incorp_time_cf.loc['list_incorp_time_cf_2',
                                           '72':'no incorporation'].to_list()  # poultry

# evaluate the reduction factors from incorporation time
i = 0
while sman_incorp_h <= list_incorp_time_h[i]:
    i = i+1
    if i == len(list_incorp_time_h):
        break
cf_sman_cattle_pig_frac = list_incorp_time_cf_1[i]  # cattle and pigs
cf_sman_poul_frac = list_incorp_time_cf_2[i]  # poultry
# combine to a mean reduction factor, weighted by applied amounts of N from
# different manure types
if (f_sman_NH4N_from_cattle_frac + f_sman_NH4N_from_pigs_frac +
        f_sman_NH4N_from_poul_frac + f_sman_NH4N_from_others_frac) > 0:
    cf_manu_frac = ((cf_sman_cattle_pig_frac *
                     (f_sman_NH4N_from_cattle_frac + f_sman_NH4N_from_pigs_frac)
                     + cf_sman_poul_frac * f_sman_NH4N_from_poul_frac)
                    / (f_sman_NH4N_from_cattle_frac + f_sman_NH4N_from_pigs_frac
                       + f_sman_NH4N_from_poul_frac + f_sman_NH4N_from_others_frac)
                    )
else:  # if no manure from pigs, cattle, poultry, others
    cf_manu_frac = 0
# make sure, the reduction factor is <= 1
cf_manu_frac = np.min([1, cf_manu_frac])

# NH3 emission factors
# Add nh3_ef's for imported organic manure to the nh3_ef's for
# farm manure calculated in SALCAanimal_farm, weighted by their relative amounts.
if amount_lman_farm_m3+amount_lman_imported_m3 > 0:
    frac_lman_imported = amount_lman_imported_m3/(amount_lman_farm_m3+amount_lman_imported_m3)
else:
    frac_lman_imported = 0
if amount_sman_farm_t+amount_sman_imported_t > 0:
    frac_sman_imported = amount_sman_imported_t/(amount_sman_farm_t+amount_sman_imported_t)
else:
    frac_sman_imported = 0

f_ef_sman_frac2 = (tab_EF_NH3.loc[tab_EF_NH3['manure class'] == "Unassigned",'EF_solid']).values[0]\
                    * frac_sman_imported\
                    + (1-frac_sman_imported) * f_ef_sman_frac
f_ef_lman_frac2 = (tab_EF_NH3.loc[tab_EF_NH3['manure class'] == "Unassigned",'EF_liquid']).values[0]\
                    * frac_lman_imported\
                    + (1-frac_lman_imported) * f_ef_lman_frac

# nh3 from manure per month, corrected by f_ef_sman_frac from SALCAanimal_agrammon [kg NH3-N]
sman_m_kgNH3_N = (sman_m_kgTAN*f_ef_sman_frac2
                  * (1+0.03*(saturation_deficit_m/100-0.042)/0.01))
# nh3 from manure per year, corrected by the reduction factor for incorporation time calculated in this module [kg NH3-N]
sman_kgNH3_N = np.sum(sman_m_kgNH3_N) * cf_manu_frac
# nh3 from slurry per month, corrected by the reduction factors from SALCAanimal_agrammon [kg NH3-N]
lman_m_kgNH3_N = (lman_m_kgTAN*f_ef_lman_frac2*cf_lman_appl_frac
                  * (1+0.03*(saturation_deficit_m/100-0.042)/0.01))
# nh3 from slurry per year [kg NH3-N]
lman_kgNH3_N = np.sum(lman_m_kgNH3_N)


# %%  NH3-N from mineral fertilisers [kg NH3-N] ===============================
'''list of fertilisers:
    Ammonium sulphate (AS),
    Ammonium nitrate (AN),
    Calcium ammonium nitrate (CAN),
    Anhydrous ammonia (AH),
    Urea (UREA),
    Urea ammonium nitrate (UAN),
    Di-ammonium phosphate (DAP),
    Mono-ammonium phosphate (MAP),
    NK mixtures (NK),
    Other complex NK, NPK fertilizers (NPK),
    Urea ammonium sulphate (UAS)
'''
# from EMEP/EEA2019
# g NH3/kg N
list_low_pH_gNH3pkgN = np.array(
    nh3_mineral_fertilisers.loc['list_low_pH_gNH3pkgN','Ammonium sulphate (AS)':'Urea ammonium sulphate (UAS)'].to_list())
list_high_pH_gNH3pkgN = np.array(
    nh3_mineral_fertilisers.loc['list_high_pH_gNH3pkgN','Ammonium sulphate (AS)':'Urea ammonium sulphate (UAS)'].to_list())
# convert kg NH3 to kg N
list_low_pH_kgNH3_NpkgN = list_low_pH_gNH3pkgN/1000*(14/17)
list_high_pH_kgNH3_NpkgN = list_high_pH_gNH3pkgN/1000*(14/17)
# interpolation factor
if fi_pH <= 5.5:
    interpolation_factor = 1
elif fi_pH > 7.3:
    interpolation_factor = 0
else:
    interpolation_factor = (7.3-fi_pH)/(7.3-5.5)
# factors in kg NH3-N/kg N
ef_as_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[0]
                     + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[0])
ef_an_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[1]
                     + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[1])
ef_can_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[2]
                      + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[2])
ef_urea_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[4]
                       + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[4])
ef_uan_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[5]
                      + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[5])
ef_dap_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[6]
                      + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[6])
ef_nk_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[8]
                     + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[8])
ef_npk_kgNH3_NpkgN = (interpolation_factor*list_low_pH_kgNH3_NpkgN[9]
                      + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN[9])
ef_mean_kgNH3_NpkgN = np.mean(interpolation_factor*list_low_pH_kgNH3_NpkgN
                              + (1-interpolation_factor)*list_high_pH_kgNH3_NpkgN)

# Calculate NH3 emissions [kg NH3-N]
an_kgNH3_N = an_kgN * ef_an_kgNH3_NpkgN
urea_kgNH3_N = urea_kgN * ef_urea_kgNH3_NpkgN
uan_kgNH3_N = uan_kgN * ef_uan_kgNH3_NpkgN
map_dap_kgNH3_N = map_dap_kgN * ef_dap_kgNH3_NpkgN
anp_kgNH3_N = anp_kgN * ef_npk_kgNH3_NpkgN
can_kgNH3_N = can_kgN * ef_can_kgNH3_NpkgN
as_kgNH3_N = as_kgN * ef_as_kgNH3_NpkgN
nk_kgNH3_N = nk_kgN * ef_nk_kgNH3_NpkgN
mf_others_kgNH3_N = mf_others_kgN * ef_mean_kgNH3_NpkgN
# sum of the fertiliser NH3_N [kg NH3-N]
min_fert_kgNH3_N = (an_kgNH3_N + urea_kgNH3_N
                    + uan_kgNH3_N + map_dap_kgNH3_N
                    + anp_kgNH3_N + can_kgNH3_N
                    + as_kgNH3_N + nk_kgNH3_N
                    + mf_others_kgNH3_N)
# sum of the fertiliser, manure and slurry NH3-N [kg NH3-N]
e_fert_kg_NH3_N = sman_kgNH3_N + lman_kgNH3_N + min_fert_kgNH3_N

# N loss rate (is needed by SALCAnitrate)
# if there is N at all
if fert_kgN != 0:
    # calculate loss rate through NH3, N2O (only direct) and NOx
    loss_rate_N_frac = (e_fert_kg_NH3_N+e_direct_kgN2O_N+e_fert_kgNOx_N) / \
        fert_kgN  # [kg N/kg N]
    loss_rate_N_frac = min(1.0, loss_rate_N_frac)  # cannot be >1
else:
    loss_rate_N_frac = 0  # [kg N/kg N]

# Loss rate of TAN
if fert_kgTAN != 0:
    # calculate loss rate through NH3, N2O and NOx
    loss_rate_TAN_frac = (e_fert_kg_NH3_N+e_direct_kgN2O_N+e_fert_kgNOx_N) / \
        fert_kgTAN  # [kg TAN/kg TAN]
    loss_rate_TAN_frac = min(1.0, loss_rate_TAN_frac)  # cannot be >1
else:
    loss_rate_TAN_frac = 0  # [kg TAN/kg TAN]

# CO2 from urea [kg CO2]
e_urea_kgCO2 = urea_kgCO2pkgN * (urea_kgN+0.5*uan_kgN)
# CO2  from lime [kg CO2]
e_lime_kgCO2 = (lime_kgCO2pkgCa*(lime_kgCa+carbonation_kgCa+algae_kgCa)
              + ef_kgCO2pkgMg*mg_kgMg)


# induced N2O emissions from NH3 and NOx [kg N2O-N]
# induced N2O from NO3 are calculated in SALCAnitrate
e_induced_kg_N2O_N = ef_4_kgN20_NpkgN * \
    (e_fert_kg_NH3_N+e_fert_kgNOx_N)
    
# %% output ===================================================================

# output occupation - to SimaPro
occ_arable_m2a = sum_areatime_by_code(c_areatime, c_area_code, 1)
occ_past_int_m2a = sum_areatime_by_code(c_areatime, c_area_code, 2)
occ_past_ext_m2a = sum_areatime_by_code(c_areatime, c_area_code, 3)
occ_fruit_trees_m2a = sum_areatime_by_code(c_areatime, c_area_code, 4)
occ_vineyards_m2a = sum_areatime_by_code(c_areatime, c_area_code, 5)
# output transformation
transf_from_arable_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 1)/util_arable
transf_from_past_int_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 2)/util_past_int
transf_from_past_ext_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 3)/util_past_ext
transf_from_fruit_trees_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 4)/util_fruit_trees
transf_from_vineyards_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 5)/util_vineyards
transf_to_arable_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 1)/util_arable
transf_to_past_int_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 2)/util_past_int
transf_to_past_ext_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 3)/util_past_ext
transf_to_fruit_trees_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 4)/util_fruit_trees
transf_to_vineyards_m2 = sum_areatime_by_code(c_ca_ha, c_area_code, 5)/util_vineyards

# kg Ammonia (NH3, emission to air)
fi_e_kgNH3 = 17/14*e_fert_kg_NH3_N
# kg CO2 (emission to air)
fi_e_air_kgCO2 = (e_lime_kgCO2+e_urea_kgCO2)

# kg NOx (emission to air)
fi_e_air_kgNOX = 46/14*e_fert_kgNOx_N
# kg N2O (emission to air)
fi_e_air_kgN2O_field = 44/28*(e_direct_kgN2O_N+e_induced_kg_N2O_N)


out.fi_occ_arable = occ_arable_m2a
out.fi_occ_past_int = occ_past_int_m2a
out.fi_occ_past_ext = occ_past_ext_m2a
out.fi_occ_fruit_trees = occ_fruit_trees_m2a
out.fi_occ_vineyards = occ_vineyards_m2a

out.fi_transf_from_arable = transf_from_arable_m2
out.fi_transf_from_past_int = transf_from_past_int_m2
out.fi_transf_from_past_ext = transf_from_past_ext_m2
out.fi_transf_from_fruit_trees = transf_from_fruit_trees_m2
out.fi_transf_from_vineyards = transf_from_vineyards_m2

out.fi_transf_to_arable = transf_to_arable_m2
out.fi_transf_to_past_int = transf_to_past_int_m2
out.fi_transf_to_past_ext = transf_to_past_ext_m2
out.fi_transf_to_fruit_trees = transf_to_fruit_trees_m2
out.fi_transf_to_vineyards = transf_to_vineyards_m2

out.fi_e_orgSoil_kgCO2 = e_orgSoil_kgCO2  # emissions from land use change on organic soils (peat oxidation)

out.fi_e_kgNH3 = fi_e_kgNH3
out.fi_e_air_kgCO2 = fi_e_air_kgCO2
out.fi_e_air_kgNOX = fi_e_air_kgNOX
out.fi_e_air_kgN2O_field = fi_e_air_kgN2O_field
out.fi_N_loss_frac = loss_rate_N_frac
out.fi_TAN_loss_frac = loss_rate_TAN_frac

# total kg N applied on the crop (for SALCA-BD)
out.fi_total_kgN_crop = js.dumps(total_kgN_crop)
# details about fertilisation on field level
fi_fert_info = {'fert_kgN':fert_kgN, 
                'fert_kgTAN':fert_kgTAN, 
                'fert_kgNphapa':fert_kgNphapa, 
                'fert_kgP2O5':sum(total_kgP2O5_crop.values()), 
                'fert_kgP2O5phapa':fert_kgP2O5phapa, 
                'fert_kgK2O':sum(total_kgK2O_crop.values()), 
                'fert_kgK2Ophapa':fert_kgK2Ophapa, 
                'fert_kgMg':mg_kgMg, 
                'fert_kgMgphapa':fert_kgMgphapa, 
                'fi_area_time_year_ha':fi_area_time_year_ha, 
                'fi_duration_days':fi_duration.days}
out.fi_fert_info = js.dumps(fi_fert_info)


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
