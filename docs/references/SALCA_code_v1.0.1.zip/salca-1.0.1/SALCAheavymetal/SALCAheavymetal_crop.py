# -*- coding: utf-8 -*-
"""
File name: SALCAheavymetal_crop.py
Created on Wed May 29 12:56:06 2019

Author: Agroscope, "Life Cycle Assessment" Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script estimates heavy metal emission from different sources (e.g.
    fertilizers, manure, plant protection products or seeds).

Calculation level:
    Crop

Related scripts: 
    SALCAanimal_farm.py, SALCAprep_crop.py, SALCAtables.py

"""

# %% import modules and starting sequence =====================================
import json as js
import datetime as dt
import logging
from importlib import reload
from typing import Any, List, Dict

import pandas as pd
import numpy as np  
from numpy import float64

from salcaconnector import create_salca_context

MODULE_NAME: str = "SALCAheavymetal crop"

# starting sequence
reload(logging)
logging.basicConfig(
    format = "%(message)s",
    level = logging.DEBUG) # can be logging.DEBUG or logging.INFO

start = dt.datetime.now(tz = None)

logging.info("")
logging.info(f"Start {MODULE_NAME}")
logging.info(f"Starting time: {start}")
logging.info("")

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% setup =====================================================================

c_crop_type: str = ctx.crop.crop_definition_name
metals: List[str] = [
    "Cd", "Cu", "Zn", "Pb", "Ni", "Cr", "Hg"
]
# column headers
cols: List[str] = [
    "Cd_content", "Cu_content", "Zn_content", "Pb_content", \
    "Ni_content", "Cr_content", "Hg_content"
]

# %% define constants ==========================================================

# density of slurry in kg/m3
density_slurry_kgpm3 = 1000

# %% define functions ==========================================================

def create_empty_heavy_metal_dict() -> Dict[str, List[Any]]:
    """function to set a new dictionary up for a specific heavy metal"""
    return {
        "Module": [],
        "Variable": [],
        "Amount input": [],
        "Amount hm [mg]": []
    }


def update_hm_contribution(dict_update: Dict[str, List[Any]],
                           ref: Dict[str, List[Any]],
                           metal: str,
                           hm_content: pd.DataFrame,
                           mapping: pd.DataFrame,
                           frac: float
                           ) -> Dict[str, List[Any]]:
    """
    Update a dictionary of heavy metal contributions by another contribution
    group.

    Parameters
    ----------
    dict_update : Dict[str, List[Any]]
        already setup dictionary of module, variable, amount and
        heavy metal amount.
    
    ref : Dict[str, List[Any]]
        dictionary with module, variable and amount of one contribution group.
    
    metal : str
        heavy metal to choose the corresponding column in tab.
    
    hm_content : pd.DataFrame
        table with the dry weight and heavy metal
            contents of the contribution group.
    
    mapping : pd.DataFrame
        table to match name of flow with corresponding HM contents
            if mapping="" go directly in the hm_content table
    
    frac : float
        fraction of heavy metal taken into account. It is always 1, expect for
            PPP, where 100% of the input is accounted for, but 5% are exported
            with the harvested products

    Returns
    -------
    dict_update : Dict[str, List[Any]]
        Returns updated dictionary.

    """
    
    dict_update["Variable"].extend(ref["Variable"])
    dict_update["Amount input"].extend(ref["Amount"])
    
    dw = []  # set up an empty array for the dry weights.
    for i in range(len(ref["Amount"])):
        dict_update["Module"].extend(ref["Module"])
        
        # in tab_crops, main product, co-product and seed has to be distinguished
        if ref["Module"][0] == "Seed":
            map_name: str = "HM: seed"
        
        elif ref["Module"][0] == "Harv":
            map_name: str = "HM: main product"
        
        elif ref["Module"][0] == "Harv_sepr":
            map_name: str = "HM: co-product"
        
        else:
            map_name: str = "HM_mapping"
        
        # to respect the number of events entered in the contribution group,
        # multiply the amount entered with its dry weight
        flow_name: str = mapping[map_name][ref["Variable"][i]]
        dw.append(ref["Amount"][i]*hm_content["DM_content"][flow_name])
        
        # update the dictionary with the new amount entries
        # to respect the amount of events entered in the contribution group,
        # multiply the dry weight with the heavy metal content
        dict_update["Amount hm [mg]"].append(
            dw[i] * hm_content[metal][flow_name] * frac)
        
    return dict_update

def update_hm_contribution_manure(dict_update: Dict[str, List[Any]],
                                  ref: Dict[str, List[Any]],
                                  metal: str,
                                  manu_HM_cont: Dict[str, float or int],
                                  frac: float
                                  ) -> Dict[str, List[Any]]:
    
    """ explanations see def update_dict """
    
    amount_manu = []
    dict_update["Variable"].extend(ref["Variable"])
    dict_update["Amount input"].extend(ref["Amount"])
    
    for i in range(len(ref["Amount"])):
        dict_update["Module"].extend(ref["Module"])

        if ref["Variable"][i] == "liquid_farm_manure":
            hm_content: float or int = manu_HM_cont[f"lman_mg{metal}pm3"]
            amount_manu.append(ref["Amount"][i])
            
        elif ref["Variable"][i] == "solid_farm_manure": # solid manure [t]
            hm_content: float or int = manu_HM_cont[f"sman_mg{metal}pt"]
            amount_manu.append(ref["Amount"][i])
            
        else:
            if tab_manu["Liquid?"][ref["Variable"][i]] == 1:
                unit_conv_to_kg: int = density_slurry_kgpm3  # liquid: convert m3 to kg
            else:
                unit_conv_to_kg = 1000  # solid: convert t to kg
            
            flow_name: str = tab_manu["HM_mapping"][ref["Variable"][i]]
            hm_content: float or int = tab_hm[f"{metal}_content"][flow_name]
            
            amount_manu_kgdm: float or int = ref["Amount"][i] \
                * tab_hm["DM_content"][flow_name] \
                * unit_conv_to_kg
            
            amount_manu.append(amount_manu_kgdm)

        hm_flow: float or int = amount_manu[i] * hm_content
        dict_update["Amount hm [mg]"].append(hm_flow * frac)
    
    return dict_update

def load_input_dataframe(json_string: str) -> pd.DataFrame:
    """
    Convert a JSON string to a dataframe

    Parameters
    ----------
    json_string : str
        JSON string to be loaded as dataframe.

    Returns
    -------
    pd.DataFrame
        Loaded pandas dataframe from the JSON string.

    """
    
    json_loaded = js.loads(json_string)
    return pd.DataFrame(data = json_loaded["data"],
                        columns = json_loaded["columns"],
                        index = json_loaded["index"])

# %% load tables from input module =============================================

tab_hm: pd.DataFrame = load_input_dataframe(json_string = inp.tab_hm)
tab_crops: pd.DataFrame = load_input_dataframe(json_string = inp.tab_crops)
tab_manu: pd.DataFrame = load_input_dataframe(json_string = inp.tab_manu)
tab_fert: pd.DataFrame = load_input_dataframe(json_string = inp.tab_fert)
tab_ppp: pd.DataFrame = load_input_dataframe(json_string = inp.tab_ppp)

input_dataframes: List[pd.DataFrame] = [
    tab_hm, tab_crops, tab_manu, tab_fert, tab_ppp
]

for df in input_dataframes:
    try:
        df.set_index("NameEN", inplace = True)
    except Exception as e:
        raise ValueError(
            "Could not set index since column" \
            "'NameEN' is not available\n\n" \
            f"{str(e)}"
        )

# %% load inputs ===============================================================
logging.info(f"Starting time of peraration part: {dt.datetime.now(tz = None)}")

c_crop_type: str = ctx.crop.crop_definition_name
c_ca_ha: float = inp.c_ca_ha  # area of the crop [ha]

# amount of erosion on the field [kg/ha], from SALCAerosion
fi_eros: float = inp.fi_eros_kgphapa

# percentage of drainage on the field [%]
fi_drai_perc: float = inp.fi_drai_perc

# distance from field to drainage collector [m], unknown: 0 m
fi_drai_dis_m: float = inp.fi_drai_dis_m

# soil density on the field [kg/m3]
fi_soil_kgpm3: float = inp.fi_soil_kgpm3

# load SALCAprep_crop
c_salcaprep: Dict[str, Any] = js.loads(inp.c_salcaprep)

# last harvest date (precrop)
c_prha_date: str = c_salcaprep["c_prha_date"]

# data for crop treatments
# harvest date and amount [kg]
c_harv_date: str = c_salcaprep["c_end"]
c_harv_amount: List[float] = c_salcaprep["tr_harv"]["amount_kg"]

# harvest amount for co-products (secondary products)
c_harv_sepr_amount: List[float] = c_salcaprep["tr_harv_sepr"]["amount_kg"]

# sowing date and amount [kg]
c_sowi_date: str = c_salcaprep["c_start"]
c_sowi_amount: List[float] = c_salcaprep["tr_sowi"]["amount_kg"]

# data for manure
# liquid manure type and amount [m3] (diluted)
c_manure_l_variable: List[str] = c_salcaprep["tr_manure_l"]["variable"]
c_manure_l_amount: List[float] = c_salcaprep["tr_manure_l"]["amount_m3"]

# solid manure type and amount [t]
c_manure_s_variable: List[str] = c_salcaprep["tr_manure_s"]["variable"]
c_manure_s_amount: List[float] = c_salcaprep["tr_manure_s"]["amount_t"]

c_manure_variable: List[str] = c_manure_l_variable + c_manure_s_variable
c_manure_amount: List[float] = c_manure_l_amount + c_manure_s_amount

# data for mineral fertilisation variables and amount [kg]
c_fert_variable: List[str] = c_salcaprep["tr_fert"]["variable"]
c_fert_amount: List[float] = c_salcaprep["tr_fert"]["amount_kg"]

# data of plant protection products variables and amount [kg]
# combining the lists per treatment to single lists for all treatments
c_ppp_variable: List[List[str]] = c_salcaprep["tr_ppp"]["variable"]
c_ppp_variable: List[str] = [
    item
    for sublist in c_ppp_variable
    for item in sublist
    if item != ""
]

c_ppp_amount: List[List[float]] = c_salcaprep["tr_ppp"]["amount_kg"]
c_ppp_amount: List[float] = [
    item
    for sublist in c_ppp_amount
    for item in sublist
    if item is not None
]

c_manure_module: List[str] = ["Manure"]  # module of manure variables
c_sowi_module: List[str] = ["Seed"]
c_harv_module: List[str] = ["Harv"]
c_harv_sepr_module: List[str] = ["Harv_sepr"]
c_fert_module: List[str] = ["Fert"]  # module of fertiliser variables
c_ppp_module: List[str] = ["PPP"]  # modules of plant protection product variables


# %% Output of peraration HM ===================================================

# store input data of SALCAheavymetal_crop in a dictionary
prep_heavymetal: Dict[str, Any] = {
    "c_prha_date": c_prha_date,
    "c_sowi_date": c_sowi_date,
    "c_harv_date": c_harv_date,
    "duration_d": c_salcaprep["c_duration_days"],
    "duration_y": c_salcaprep["c_duration_years"],
    "c_ca_ha": c_ca_ha,
    "fi_eros": fi_eros,
    "fi_drai_perc": fi_drai_perc,
    "fi_drai_dis_m": fi_drai_dis_m,
    "c_manure_module": c_manure_module,
    "c_manure_variable": c_manure_variable,
    "c_manure_amount": c_manure_amount,
    "c_harv_module": c_harv_module,
    "c_harv_variable": [c_crop_type] * len(c_harv_amount),
    "c_harv_amount": c_harv_amount,
    "c_harv_sepr_module": c_harv_sepr_module,
    "c_harv_sepr_variable": [c_crop_type] * len(c_harv_sepr_amount),
    "c_harv_sepr_amount": c_harv_sepr_amount,
    "c_sowi_module": c_sowi_module,
    "c_seed_variable": [c_crop_type]*len(c_sowi_amount),
    "c_seed_amount": c_sowi_amount,
    "c_fert_module": c_fert_module,
    "c_fert_variable": c_fert_variable,
    "c_fert_amount": c_fert_amount,
    "fi_soil_kgpm3": fi_soil_kgpm3,
    "c_ppp_module": c_ppp_module,
    "c_ppp_variable":  c_ppp_variable,
    "c_ppp_amount": c_ppp_amount
}

logging.info("End time of preparation part: %s", dt.datetime.now(tz = None))

# %% load import data ==========================================================
logging.info("Start time of calculation part: %s", dt.datetime.now(tz = None))

# assign prep variable to heavymetal input
hm_input: Dict[str, Any] = prep_heavymetal

# load HM contents of manure from SALCAanimal_farm
# convert string to dictionary [mg per t or m3]
manu_HM_cont: Dict[str, float or int] = js.loads(inp.f_manu_HM_cont)

# input data of the field assigned in the class structure in_par
in_par: Dict[str, float] = {
    "c_ca_ha": hm_input["c_ca_ha"],
    "fi_eros": hm_input["fi_eros"],
    "fi_drai_perc": hm_input["fi_drai_perc"],
    "fi_drai_dis_m": hm_input["fi_drai_dis_m"]
}

# Assign the different modules, variables and amounts of contributors
# to one dictionary per type.

# manure input data
in_manure: Dict[str, List[float or str]] = {
    "Module": hm_input["c_manure_module"],
    "Variable": hm_input["c_manure_variable"],
    "Amount": hm_input["c_manure_amount"]
    # list of the imported manure amounts in t, liquid manure in m3.
}

# harvest input data
in_harv: Dict[str, List[float or str]] = {
    "Module": hm_input["c_harv_module"],
    "Variable": hm_input["c_harv_variable"],
    "Amount": hm_input["c_harv_amount"]
}

# co-product harvest input data
in_harv_sepr: Dict[str, List[float or str]] = {
    "Module": hm_input["c_harv_sepr_module"],
    "Variable": hm_input["c_harv_sepr_variable"],
    "Amount": hm_input["c_harv_sepr_amount"]
}

# seed input data
in_seed: Dict[str, List[float or str]] = {
    "Module": hm_input["c_sowi_module"],
    "Variable": hm_input["c_seed_variable"],
    "Amount": hm_input["c_seed_amount"]
}

# mineral fertiliser input data
in_fert: Dict[str, List[float or str]] = {
    "Module": hm_input["c_fert_module"],
    "Variable": hm_input["c_fert_variable"],
    "Amount": hm_input["c_fert_amount"]
}

# plant protection product input data
in_ppp: Dict[str, List[float or str]] = {
    "Module": hm_input["c_ppp_module"],
    "Variable": hm_input["c_ppp_variable"],
    "Amount": hm_input["c_ppp_amount"]}

# %% Calculations ==============================================================

# difference in time between harvest of the previous crop and the current crop
# as calculated in SALCAprep_crop
duration_d: int = hm_input["duration_d"]  # in number of days
duration_y: float = hm_input["duration_y"]  # in fraction of a year

logging.info("Output SALCAheavymetal crop")
logging.info(f"for farm {ctx.farm.farm_name} with ID {ctx.farm.farm_id}")
logging.info(f"for field {ctx.field[1]} with ID {ctx.field_id}")
logging.info(f"for crop {ctx.crop[2]}" \
             f"with ID {ctx.crop_id}" \
             f" with name {ctx.crop[1]}")
logging.info("")

# %% Import of heavy metals ====================================================
# Setup of a dictionary containing the module, variable names and amounts of
# the input under the keys "Module", "Variable" and "Amount input". The resul-
# ting heavy metal content is stored in the key "Amount hm [mg]" while the con-
# sidered heavy metal is specified by the name of the dictionary.



# Setup empty dictionaries
Cd: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Cu: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Zn: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Pb: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Ni: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Cr: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Hg: Dict[str, List[Any]] = create_empty_heavy_metal_dict()

# append HM from manure
Cd = update_hm_contribution_manure(Cd, in_manure, "Cd", manu_HM_cont, 1.0)
Cu = update_hm_contribution_manure(Cu, in_manure, "Cu", manu_HM_cont, 1.0)
Zn = update_hm_contribution_manure(Zn, in_manure, "Zn", manu_HM_cont, 1.0)
Pb = update_hm_contribution_manure(Pb, in_manure, "Pb", manu_HM_cont, 1.0)
Ni = update_hm_contribution_manure(Ni, in_manure, "Ni", manu_HM_cont, 1.0)
Cr = update_hm_contribution_manure(Cr, in_manure, "Cr", manu_HM_cont, 1.0)
Hg = update_hm_contribution_manure(Hg, in_manure, "Hg", manu_HM_cont, 1.0)

# append HM from seed
Cd = update_hm_contribution(Cd, in_seed, "Cd_content", tab_hm, tab_crops, 1.0)
Cu = update_hm_contribution(Cu, in_seed, "Cu_content", tab_hm, tab_crops, 1.0)
Zn = update_hm_contribution(Zn, in_seed, "Zn_content", tab_hm, tab_crops, 1.0)
Pb = update_hm_contribution(Pb, in_seed, "Pb_content", tab_hm, tab_crops, 1.0)
Ni = update_hm_contribution(Ni, in_seed, "Ni_content", tab_hm, tab_crops, 1.0)
Cr = update_hm_contribution(Cr, in_seed, "Cr_content", tab_hm, tab_crops, 1.0)
Hg = update_hm_contribution(Hg, in_seed, "Hg_content", tab_hm, tab_crops, 1.0)

# append HM from fertiliser
Cd = update_hm_contribution(Cd, in_fert, "Cd_content", tab_hm, tab_fert, 1.0)
Cu = update_hm_contribution(Cu, in_fert, "Cu_content", tab_hm, tab_fert, 1.0)
Zn = update_hm_contribution(Zn, in_fert, "Zn_content", tab_hm, tab_fert, 1.0)
Pb = update_hm_contribution(Pb, in_fert, "Pb_content", tab_hm, tab_fert, 1.0)
Ni = update_hm_contribution(Ni, in_fert, "Ni_content", tab_hm, tab_fert, 1.0)
Cr = update_hm_contribution(Cr, in_fert, "Cr_content", tab_hm, tab_fert, 1.0)
Hg = update_hm_contribution(Hg, in_fert, "Hg_content", tab_hm, tab_fert, 1.0)

# append HM from fungicides (Plant protection products)
depField: float = 1.0 - 0.1  # fraction deposited in the field (crop + soil) 

# Average rate of emissions of fungicides to air and to off-field surfaces is 0.1
Cd = update_hm_contribution(Cd, in_ppp, "Cd_content", tab_hm, tab_ppp, depField)
Cu = update_hm_contribution(Cu, in_ppp, "Cu_content", tab_hm, tab_ppp, depField)
Zn = update_hm_contribution(Zn, in_ppp, "Zn_content", tab_hm, tab_ppp, depField)
Pb = update_hm_contribution(Pb, in_ppp, "Pb_content", tab_hm, tab_ppp, depField)
Ni = update_hm_contribution(Ni, in_ppp, "Ni_content", tab_hm, tab_ppp, depField)
Cr = update_hm_contribution(Cr, in_ppp, "Cr_content", tab_hm, tab_ppp, depField)
Hg = update_hm_contribution(Hg, in_ppp, "Hg_content", tab_hm, tab_ppp, depField)

# sum up the different inputs per heavy metal
imp_sum: Dict[str, float64] = {
    "Cd": float(np.sum(Cd["Amount hm [mg]"])),
    "Cu": float(np.sum(Cu["Amount hm [mg]"])),
    "Zn": float(np.sum(Zn["Amount hm [mg]"])),
    "Pb": float(np.sum(Pb["Amount hm [mg]"])),
    "Ni": float(np.sum(Ni["Amount hm [mg]"])),
    "Cr": float(np.sum(Cr["Amount hm [mg]"])),
    "Hg": float(np.sum(Hg["Amount hm [mg]"]))
}

# Deposition
# read the deposition data from the table
deposition: List[float64] = tab_hm.loc["deposition", "Cd_content": "Hg_content"].tolist()

# deposition is calculated as 'deposition rate * area * duration'
Inputs = pd.DataFrame(np.array([deposition]) * in_par["c_ca_ha"] * duration_y,
                      columns = metals, index = ["Deposition"])

# %% Allocation crop (inputs) ==================================================
# factor to exclude the deposition from heavy metal flows
# Sum of the agricultural inputs / (sum of the inputs + deposition)
# Note: should not become negative, unless there is no deposition
Alloc_crop: Dict[str, float64] = {
    "Cd": imp_sum["Cd"] / (imp_sum["Cd"] + Inputs.loc["Deposition"]["Cd"]),
    "Cu": imp_sum["Cu"] / (imp_sum["Cu"] + Inputs.loc["Deposition"]["Cu"]),
    "Zn": imp_sum["Zn"] / (imp_sum["Zn"] + Inputs.loc["Deposition"]["Zn"]),
    "Pb": imp_sum["Pb"] / (imp_sum["Pb"] + Inputs.loc["Deposition"]["Pb"]),
    "Ni": imp_sum["Ni"] / (imp_sum["Ni"] + Inputs.loc["Deposition"]["Ni"]),
    "Cr": imp_sum["Cr"] / (imp_sum["Cr"] + Inputs.loc["Deposition"]["Cr"]),
    "Hg": imp_sum["Hg"] / (imp_sum["Hg"] + Inputs.loc["Deposition"]["Hg"])
}

# %% Export of heavy metals from harvest ======================================


# Setup of a dictionary containing the module, variable names and amounts of
# the export under the keys "Module", "Variable" and "Amount input". The resul-
# ting heavy metal content is stored in the key "Amount hm [mg]" while the con-
# sidered heavy metal is specified by the name of the dictionary.
Cd_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Cu_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Zn_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Pb_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Ni_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Cr_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()
Hg_ex: Dict[str, List[Any]] = create_empty_heavy_metal_dict()

# fraction of the PPP that is exported with the harvest
# no allocation here, since PPP are farm inputs
ppp2harv: float = 0.05  # default ppp-uptake by the crop at harvest

Cd_ex = update_hm_contribution(Cd_ex, in_ppp, "Cd_content", tab_hm, tab_ppp, ppp2harv)
Cu_ex = update_hm_contribution(Cu_ex, in_ppp, "Cu_content", tab_hm, tab_ppp, ppp2harv)
Zn_ex = update_hm_contribution(Zn_ex, in_ppp, "Zn_content", tab_hm, tab_ppp, ppp2harv)
Pb_ex = update_hm_contribution(Pb_ex, in_ppp, "Pb_content", tab_hm, tab_ppp, ppp2harv)
Ni_ex = update_hm_contribution(Ni_ex, in_ppp, "Ni_content", tab_hm, tab_ppp, ppp2harv)
Cr_ex = update_hm_contribution(Cr_ex, in_ppp, "Cr_content", tab_hm, tab_ppp, ppp2harv)
Hg_ex = update_hm_contribution(Hg_ex, in_ppp, "Hg_content", tab_hm, tab_ppp, ppp2harv)

# Add the harvest data with allocation, since this comes from the soil
Cd_ex = update_hm_contribution(Cd_ex, in_harv, "Cd_content", tab_hm, tab_crops, Alloc_crop["Cd"])
Cu_ex = update_hm_contribution(Cu_ex, in_harv, "Cu_content", tab_hm, tab_crops, Alloc_crop["Cu"])
Zn_ex = update_hm_contribution(Zn_ex, in_harv, "Zn_content", tab_hm, tab_crops, Alloc_crop["Zn"])
Pb_ex = update_hm_contribution(Pb_ex, in_harv, "Pb_content", tab_hm, tab_crops, Alloc_crop["Pb"])
Ni_ex = update_hm_contribution(Ni_ex, in_harv, "Ni_content", tab_hm, tab_crops, Alloc_crop["Ni"])
Cr_ex = update_hm_contribution(Cr_ex, in_harv, "Cr_content", tab_hm, tab_crops, Alloc_crop["Cr"])
Hg_ex = update_hm_contribution(Hg_ex, in_harv, "Hg_content", tab_hm, tab_crops, Alloc_crop["Hg"])

# Add the co-product harvest data with allocation, since this comes from the soil
Cd_ex = update_hm_contribution(Cd_ex, in_harv_sepr, "Cd_content", tab_hm, tab_crops, Alloc_crop["Cd"])
Cu_ex = update_hm_contribution(Cu_ex, in_harv_sepr, "Cu_content", tab_hm, tab_crops, Alloc_crop["Cu"])
Zn_ex = update_hm_contribution(Zn_ex, in_harv_sepr, "Zn_content", tab_hm, tab_crops, Alloc_crop["Zn"])
Pb_ex = update_hm_contribution(Pb_ex, in_harv_sepr, "Pb_content", tab_hm, tab_crops, Alloc_crop["Pb"])
Ni_ex = update_hm_contribution(Ni_ex, in_harv_sepr, "Ni_content", tab_hm, tab_crops, Alloc_crop["Ni"])
Cr_ex = update_hm_contribution(Cr_ex, in_harv_sepr, "Cr_content", tab_hm, tab_crops, Alloc_crop["Cr"])
Hg_ex = update_hm_contribution(Hg_ex, in_harv_sepr, "Hg_content", tab_hm, tab_crops, Alloc_crop["Hg"])

# %% Sum exports ===============================================================
# calculate the sum of the exports (fraction of PPP and harvested products)
exp_sum: Dict[str, float64] = {
    "Cd": np.sum(Cd_ex["Amount hm [mg]"]),
    "Cu": np.sum(Cu_ex["Amount hm [mg]"]),
    "Zn": np.sum(Zn_ex["Amount hm [mg]"]),
    "Pb": np.sum(Pb_ex["Amount hm [mg]"]),
    "Ni": np.sum(Ni_ex["Amount hm [mg]"]),
    "Cr": np.sum(Cr_ex["Amount hm [mg]"]),
    "Hg": np.sum(Hg_ex["Amount hm [mg]"])
}


# %% Setup Erosion ============================================================
# derive f_eros from the drainage distance.
# if fi_drai_dis_m == 0, then set to default (0.2)
if (in_par["fi_drai_dis_m"] < 3) and (float(in_par["fi_drai_dis_m"]) > 0):
    f_eros = 0

elif (in_par["fi_drai_dis_m"] < 30) or (in_par["fi_drai_dis_m"] == 0):
    f_eros = 0.2

elif in_par["fi_drai_dis_m"] < 100:
    f_eros = 0.15

else:
    f_eros = 0.05

e_eros = 1.86  # enrichement factor
b_eros: float = in_par["fi_eros"]  # erosion in kg per ha, from SALCAerosion


# %% heavy metal load per group ================================================
# The following part summarizes the emissions per contribution group
groups = list(set(Cd["Module"]))

for i in np.arange(len(groups)):  # For every module type
    
    gr_cd, gr_cu, gr_zn, gr_pb = [], [], [], []
    gr_ni, gr_cr, gr_hg = [], [], []

    for j, x in enumerate(Cd["Module"]):

        if x == groups[i]:
            # at the position, where the current module is present
            # append the corresponding heavy metal amounts
            gr_cd.append(Cd["Amount hm [mg]"][j])
            gr_cu.append(Cu["Amount hm [mg]"][j])
            gr_zn.append(Zn["Amount hm [mg]"][j])
            gr_pb.append(Pb["Amount hm [mg]"][j])
            gr_ni.append(Ni["Amount hm [mg]"][j])
            gr_cr.append(Cr["Amount hm [mg]"][j])
            gr_hg.append(Hg["Amount hm [mg]"][j])
            
    # Sum up the contributions of one heavy metal for the current module.
    df_contribution_sum: pd.DataFrame = pd.DataFrame(
        np.array([
            [sum(gr_cd), sum(gr_cu), sum(gr_zn), sum(gr_pb),
             sum(gr_ni), sum(gr_cr), sum(gr_hg)]
            ]
        ),
        columns = metals,
        index = [groups[i]]
    )
    
    # Extend the df with the new module.
    Inputs = pd.concat([Inputs, df_contribution_sum])
    
Inputs = Inputs.sort_index()  # sort alphabetically

# setup empty list of size 7, for each heavy metal
Harvest: List[float] = [0.0] * 7

# append the sum of harvest contributions
for metal in range(0, 7):
    Harvest[metal] = exp_sum[metals[metal]]

Outputs = pd.DataFrame(
    np.array([Harvest]),
    columns = metals,
    index = ["Harv"]
)

# %% Erosion ===================================================================

# get the land use type
land_use_type: str = tab_crops["HM: Land Use"][c_crop_type]

# extract the HM contents of soil from the HM table
soil_hm: List[float64] = tab_hm.loc[
    land_use_type,
    "Cd_content":"Hg_content"
].tolist()

# heavy metals removed by erosion [mg]
erosion_data: pd.DataFrame = pd.DataFrame(
    np.array([soil_hm])  # heavy metal content of the soil [mg/kg soil]
    * b_eros  # erosion [kg soil/ha]
    * e_eros  # enrichment factor []
    * f_eros  # f_eros []
    * in_par["c_ca_ha"],  # crop area [ha]
    columns = cols,
    index = ["erosion"]
)

# multiplied by the allocation factor, as deposition is excluded
# duration not to be considered, since already included in the eroded amount
erosion = {}
for metal in metals:
    erosion[metal] = erosion_data.loc[
        "erosion",
        f"{metal}_content"
    ] * Alloc_crop[metal]

# %% leaching ==================================================================

# background leaching in mg/ha/yr
leaching = {}

for metal in metals:
    leaching[metal] = (
        tab_hm.loc["leaching", f"{metal}_content"]  # leaching
        * in_par["c_ca_ha"]  # crop area [ha]
        * duration_y  # duration
        * Alloc_crop[metal]  # multiplied by the allocation factor, as depositition is excluded
    )

# %% soil input ================================================================
# calculate hm flow to the soil [mg] from the mass balance on level crop
soil = {}

for metal in metals:
    soil[metal] = (
        imp_sum[metal]  # inputs
        - exp_sum[metal]  # exports (allocated)
        - leaching[metal]  # leaching(allocated)
        - erosion[metal]  # erosion(allocated)
    )

# %% Groundwater & surface water & harvest =====================================
# amount of heavy metals reaching the groundwater/surface water and harvest [mg]
groundwater = {}
surfacewater = {}
plant_removed = {}

for metal in metals:
    groundwater[metal] = (1 - in_par["fi_drai_perc"]) * leaching[metal]
    surfacewater[metal] = (in_par["fi_drai_perc"]) * leaching[metal]
    plant_removed[metal] = -exp_sum[metal]

# %% output ===================================================================
Input_dict: Dict[str, dict] = Inputs.to_dict("dict")
Output_dict: Dict[str, dict] = Outputs.to_dict("dict")

hm_crop: Dict[str, dict] = {
    "inputs": Input_dict,
    "outputs": Output_dict,
    "soil": soil,
    "groundwater": groundwater,
    "surfacewater": surfacewater,
    "plant_removed": plant_removed
}


# input of heavy metals [mg] into the soil is stored in the SALCA database per
# heavy metal. 
# Used in SALCAsoilquality and is mapped to SimaPro for the heavy metal emissions.
out.c_e_soil_cd_mg = soil["Cd"]
out.c_e_soil_cu_mg = soil["Cu"]
out.c_e_soil_zn_mg = soil["Zn"]
out.c_e_soil_pb_mg = soil["Pb"]
out.c_e_soil_ni_mg = soil["Ni"]
out.c_e_soil_cr_mg = soil["Cr"]
out.c_e_soil_hg_mg = soil["Hg"]

# input of heavy metals [mg] into the groundwater is stored in the SALCA
# database per heavy metal. 
# Is mapped to SimaPro for the heavy metal emissions.
out.c_e_gw_cd_mg = groundwater["Cd"]
out.c_e_gw_cu_mg = groundwater["Cu"]
out.c_e_gw_zn_mg = groundwater["Zn"]
out.c_e_gw_pb_mg = groundwater["Pb"]
out.c_e_gw_ni_mg = groundwater["Ni"]
out.c_e_gw_cr_mg = groundwater["Cr"]
out.c_e_gw_hg_mg = groundwater["Hg"]

# input of heavy metals [mg] into the surface water is stored in the SALCA
# database per heavy metal. 
# Is mapped to SimaPro for the heavy metal emissions.
out.c_e_sw_cd_mg = surfacewater["Cd"]
out.c_e_sw_cu_mg = surfacewater["Cu"]
out.c_e_sw_zn_mg = surfacewater["Zn"]
out.c_e_sw_pb_mg = surfacewater["Pb"]
out.c_e_sw_ni_mg = surfacewater["Ni"]
out.c_e_sw_cr_mg = surfacewater["Cr"]
out.c_e_sw_hg_mg = surfacewater["Hg"]


# %% print output ==============================================================
Emissions: pd.DataFrame = pd.DataFrame(
    data = soil,
    index = ["to soil"]
)

Emissions = Emissions.append(
    pd.DataFrame(
        groundwater,
        index=["to groundwater"]
    )
)

Emissions = Emissions.append(
    pd.DataFrame(
        surfacewater,
        index = ["to surface water"]
    )
)

Emissions = Emissions.append(
    pd.DataFrame(
        plant_removed,
        index = ["removed by plants"]
    )
)

logging.info("HM Inputs:")
for name, item in Input_dict.items():
    for key, value in item.items():
        logging.info("{} {} = {} mg".format(key, name, value))
    logging.info("")
    
logging.info("HM Outputs:")
for name, item in Output_dict.items():
    for key, value in item.items():
        logging.info("{} {} = {} mg".format(key, name, value))
logging.info("")

logging.info("HM Emissions:")
for name, item in Emissions.to_dict().items():
    for key, value in item.items():
        logging.info("{} {} = {} mg".format(name, key, value))
    logging.info("")

# %% end sequence ==============================================================
end = dt.datetime.now(tz = None)
logging.info(f"End time: {end}")

diff: dt.timedelta = end - start
logging.info(f"Time delta: {diff}")
