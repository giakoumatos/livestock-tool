# -*- coding: utf-8 -*-
"""
File name: SALCAmapping_crop.py
Created on Fri Jun 11 14:02:42 2021

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script maps inputs and emissions at the crop level to the respective
    technosphere and biosphere flows.

Calculation level:
    Crop
"""

# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import logging
import warnings as w
from importlib import reload
from sys import stderr

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAmapping_crop'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% input ====================================================================

# crop area [ha]
c_ca_ha = inp.c_ca_ha

# density of liquid manure [kg/m3]
density_slurry_kgpm3 = 1000

# mean transport distance between field and farm [km]
tran_dist_km = 2

# load tables
# load table for mineral fertilizers
tab_fert = pd.DataFrame(data=js.loads(inp.tab_fert)['data'],
                        columns=js.loads(inp.tab_fert)['columns'],
                        index=js.loads(inp.tab_fert)['index']
                        )
tab_fert_part = tab_fert[["NameEN", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact", "transport_distance_level"]]
# load table for organic fertilizers and manure
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                        columns=js.loads(inp.tab_manu)['columns'],
                        index=js.loads(inp.tab_manu)['index']
                        )
tab_manu_part = tab_manu[["NameEN", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact"]]
# load crop table for seeds
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )
tab_crops_part = tab_crops[["NameEN", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact", "transport_distance_level"]]
# load table for irrigation supplies
tab_supp = pd.DataFrame(data=js.loads(inp.tab_supp)['data'],
                        columns=js.loads(inp.tab_supp)['columns'],
                        index=js.loads(inp.tab_supp)['index']
                        )
# load table for machinery
tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                        columns=js.loads(inp.tab_mach)['columns'],
                        index=js.loads(inp.tab_mach)['index']
                        )
# load table for feedstuff
tab_feed = pd.DataFrame(data=js.loads(inp.tab_feed)['data'],
                        columns=js.loads(inp.tab_feed)['columns'],
                        index=js.loads(inp.tab_feed)['index']
                        )


# load machine combinations present on the farm
maco_list = inp.get_events('treatment_maco_event')

# get crop type and name of the current crop
c_crop_type = ctx.crop.crop_definition_name
c_crop_name = ctx.crop.crop_name

# get treatment input data
c_salcaprep = js.loads(inp.c_salcaprep)

# %% mapping calculations for machine usage on the crops ======================


# give a series of all machines with its number of usage on the crop
# dataframe with all machine combinations present on the farm (farm level)
mc_dict = pd.DataFrame(maco_list)

# machine combinations used in the treatments executed on the crop
treatment_maco_list = []
trea_ext_exec_list = []
tr_event = {}  # loads events from SALCAprep
tr_event["sowi"] = c_salcaprep['tr_sowi']
tr_event["ppp"] = c_salcaprep['tr_ppp']
tr_event["fert"] = c_salcaprep['tr_fert']
tr_event["harv"] = c_salcaprep['tr_harv']
tr_event["sepr"] = c_salcaprep['tr_harv_sepr']
tr_event["maint"] = c_salcaprep['tr_maint']
tr_event["l_man"] = c_salcaprep['tr_manure_l']
tr_event["s_man"] = c_salcaprep['tr_manure_s']
tr_event["soil"] = c_salcaprep['tr_soil']

for key in tr_event:
    for mc, ext in zip(tr_event[key]["MC"],tr_event[key]["external_exec"]):
        if ext == False:
            # for self executed treatments, map the machine combination used
            treatment_maco_list.append(mc)
        else:
            treatment_maco_list.append(mc)
            trea_ext_exec_list.append(mc)
# add the machine combinations used as additional treatments on harvest of main
# (harv) and harvest of secondary (sepr) products
for key in ["harv", "sepr"]:
    for j, element in enumerate(tr_event[key]["date"]):
        # get indices to select the MC_ff with the same date as the harvest
        # date of the crop
        indices = [k for k, x in enumerate(tr_event[key]["date_ff"]) if x == element]
        mc = [tr_event[key]["MC_ff"][i] for i in indices]
        if tr_event[key]["external_exec"][j] == False:
            # for self-executed treatments, map the machine combination used
            treatment_maco_list.extend(mc)
        else:
            treatment_maco_list.extend(mc)
            trea_ext_exec_list.extend(mc)

# convert treatment_maco_list from machine combinations into single machines
tr_maco_count = pd.DataFrame(pd.Series(treatment_maco_list).value_counts(), columns=['passage_count'])
df_maco_count = pd.merge(mc_dict,tr_maco_count, how="inner", left_on="f_maco_id", right_index=True)
df_main = df_maco_count.filter(items=['f_maco_main', 'passage_count'])
df_front = df_maco_count.filter(items=['f_maco_front', 'passage_count'])
df_back = df_maco_count.filter(items=['f_maco_back', 'passage_count'])
df_main.rename({'f_maco_main': 'f_mach_name'}, axis=1, inplace=True)
df_front.rename({'f_maco_front': 'f_mach_name'}, axis=1, inplace=True)
df_back.rename({'f_maco_back': 'f_mach_name'}, axis=1, inplace=True)
df_mach_passages = df_main.append(df_front).append(df_back)
# area treated: multiply number of passages with the crop area
df_mach_passages["treated_area"] = df_mach_passages["passage_count"] * c_ca_ha
# list of all machines used on the crop with number of passages, sum over
# duplicate machines
c_mach_passages = df_mach_passages.groupby("f_mach_name")[["passage_count", "treated_area"]].agg('sum')

# this resulting list is used in SALCAmapping_farm to finish the machine mapping



# amounts of liquid and solid manure spread on the crop (farm manure and
# imported organic manure) needed for the respective workprocesses which are
# based on amount instead of area:
sp_slurry_spread_m3 = np.sum(pd.DataFrame(c_salcaprep['tr_manure_l'])["amount_m3"])
sp_manure_spread_t = np.sum(pd.DataFrame(c_salcaprep['tr_manure_s'])["amount_t"])

# %% calculation of fuel usage based on c_mach_passages =======================

# merge the fuel consumption from SALCAtables_machinery with the machines used
# on the crop
mach4fuel = c_mach_passages.copy()
mach4fuel.index = map(lambda a: a[4:],c_mach_passages.index)
df_fuel_consumption = pd.merge(mach4fuel, tab_mach, how="left", left_index=True, right_on="PythonName")
# calculate total diesel consumption on the crop [l]
df_sum_diesel = df_fuel_consumption["treated_area"] * df_fuel_consumption['Dieselverbrauch [Liter/ha]']
c_diesel_consumption_l = np.nansum(df_sum_diesel)

# %% calculation of transport & baling to pass on to SALCAmapping_farm ========

# For transport and baling, the harvest of both the main and the secondary
# product (e.g., straw) are important, including their respecting harvested
# amounts.

# extend the treatment events with machines used and their mapped workprocesses
harv_amount_tran_t = {'harv':[],'sepr':[]}
for key in ["harv", "sepr"]:
    tr_event[key]["mach"] = []
    tr_event[key]["workprocesses"] = []
    for j, element in enumerate(tr_event[key]["date"]):
        tr_event[key]["mach"].append([])
        tr_event[key]["workprocesses"].append([])
        # get indices to select the MC_ff with the same date as the harvest
        indices = [k for k, x in enumerate(tr_event[key]["date_ff"]) if x == element]
        mc = [tr_event[key]["MC_ff"][i] for i in indices]
        mc.append(tr_event[key]["MC"][j])
        for maco in mc:
            if df_maco_count.loc[df_maco_count['f_maco_id'] == maco].empty == False:
                tr_event[key]["mach"][j].append(df_maco_count.loc[df_maco_count['f_maco_id'] == maco,'f_maco_main'].item()[4:])
                tr_event[key]["mach"][j].append(df_maco_count.loc[df_maco_count['f_maco_id'] == maco,'f_maco_front'].item()[4:])
                tr_event[key]["mach"][j].append(df_maco_count.loc[df_maco_count['f_maco_id'] == maco,'f_maco_back'].item()[4:])
            else:
                w.warn('')
                w.warn(f'No machinery found for maco: {maco}')
                w.warn('')
                stderr.flush()
        for machinery in tr_event[key]["mach"][j]:
            # add the mapped workprocesses to the treatment
            workprocess = tab_mach.loc[tab_mach['PythonName'] == machinery, "SP_mapping_variable_workprocess"].item()
            if pd.isna(workprocess) == False:
                tr_event[key]["workprocesses"][j].append(workprocess)

# calculate transport [tkm]
c_tran_tkm = 0
for key in ["harv", "sepr"]:
    for j, element in enumerate(tr_event[key]["date"]):
        if 'sp_trea_tran_tkm' in tr_event[key]["workprocesses"][j]:
            c_tran_tkm += tr_event[key]["amount_kg"][j] / 1000 * tran_dist_km


logging.info('Crop type: %s', c_crop_type)
logging.info('Crop name: %s', c_crop_name)
logging.info('transports in tkm for the crop: %.3f', c_tran_tkm)


# Baling and fodder loading

# bale weights according to Wirz Handbuch Betrieb und Familie 2023, p.286:
bale_weight_silage_t = 0.7
bale_weight_hay_t = 0.3
bale_weight_straw_t = 0.25
# weight per m3 for fodder loading:
# as a simplification, we assume that the average loaded feed is silage with
# 40% dry matter and a density of 200 kg DM/m3. Source: Handbuch „Futter und
# Fütterung-Rinder“ LWK Niedersachsen, 2005.
kg_to_m3_conversion = 200
# dry matter content of silage and hay on the field:
conv_dmtofm_silage = 0.4
conv_dmtofm_hay = 0.8

# calculate the number of silage bales (haba_p) and hay/straw bales (habh_p)
c_haba_p = 0
c_habh_p = 0
c_total_yield_kgDM = 0
c_loaded_yield_m3 = 0
c_loaded_yield_leg_m3 = 0

# Attention: the amount kg for harvest is assumed to have been entered in kg
# dry matter, therefore here it is converted to kg fresh matter first.
for key in ["harv", "sepr"]:
    for j, element in enumerate(tr_event[key]["date"]):
        if key == "sepr":
            # Attention: The machinery list (SALCAtables_machinery)
            # distinguishes between hay and silage bales. However, for
            # secondary products (e.g. straw), the number of bales is always
            # calculated based on the straw weight, but they are assigned to
            # either habh_p or haba_p to make sure they can be mapped to the
            # work process associated with the machinery used.
            if 'sp_trea_habh_p' in tr_event[key]["workprocesses"][j]:
                c_habh_p += tr_event[key]["amount_kg"][j] / 1000 / bale_weight_straw_t
            if 'sp_trea_haba_p' in tr_event[key]["workprocesses"][j]:
                c_haba_p += tr_event[key]["amount_kg"][j] / 1000 / bale_weight_straw_t
        else:
            c_total_yield_kgDM += tr_event[key]["amount_kg"][j]
            
            # depending on the choice of machinery and its mapped workprocess
            # (see SALCAtables_machinery), the yield is converted into the
            # number of silage or hay bales. Whenever there is baling, we model
            # bale loading for the total number of bales as well
            # (see SALCAmapping_farm).
            if 'sp_trea_haba_p' in tr_event[key]["workprocesses"][j]:
                c_haba_p += tr_event[key]["amount_kg"][j] / conv_dmtofm_silage / 1000 / bale_weight_silage_t
            elif 'sp_trea_habh_p' in tr_event[key]["workprocesses"][j]:
                c_habh_p += tr_event[key]["amount_kg"][j] / conv_dmtofm_hay / 1000 / bale_weight_hay_t
            if 'sp_trea_hafo_m3' in tr_event[key]["workprocesses"][j]:
                # Fodder loading:
                c_loaded_yield_m3 += tr_event[key]["amount_kg"][j] / kg_to_m3_conversion
            if 'sp_trea_halo_m3' in tr_event[key]["workprocesses"][j]:
                # Harvest goods loading:
                c_loaded_yield_leg_m3 += tr_event[key]["amount_kg"][j] / kg_to_m3_conversion
                
logging.info('Number of hay/straw bales on the crop: %d', c_habh_p)
logging.info('Number of silage bales on the crop: %d', c_haba_p)
logging.info('')


# %% mapping calculations for field work processes ============================

if c_mach_passages.empty == False:
    c_wopr_pass = c_mach_passages.copy()
    c_wopr_pass.index = map(lambda a: a[4:],c_mach_passages.index)
    sp_workprocess = pd.merge(c_wopr_pass, tab_mach, how="left", left_index=True, right_on="PythonName")
    sp_workprocess["amount_conv"] = sp_workprocess["treated_area"]*sp_workprocess["SP_mapping_conv_fact"]
    sp_workprocess_sum = sp_workprocess.groupby("SP_mapping_variable_workprocess")["amount_conv"].agg('sum')
    # sum up the amounts transported on the farm for the transport work process
    # and replace the treated area with tkm transported on the farm
    if "sp_trea_tran_tkm" in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_tran_tkm"] = c_tran_tkm
        
    # sum up the number of bales on the farm for the baling work processes
    # and replace the treated area with number of bales baled on the farm
    if 'sp_trea_haba_p' in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_haba_p"] = c_haba_p
    if 'sp_trea_habh_p' in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_habh_p"] = c_habh_p
    # bale loading: whenever baling is done on the farm, we assume that the
    # bale loading process needs to be included:
    if 'sp_trea_haba_p' in sp_workprocess_sum.keys() or 'sp_trea_habh_p' in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_habl_p"] = c_haba_p + c_habh_p
        
    # sum up the amounts loaded for the fodder loading work process and replace
    # the treated area with m3 loaded on the farm
    if 'sp_trea_hafo_m3' in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_hafo_m3"] = c_loaded_yield_m3
    if 'sp_trea_halo_m3' in sp_workprocess_sum.keys():
        sp_workprocess_sum["sp_trea_halo_m3"] = c_loaded_yield_leg_m3
    
    # The original sp mapping variables for field work processes are defined on farm level. Now that
    # we moved the workprocess mapping to crop level, we need new sp mapping variables with different
    # names.
    sp_workprocess_sum.index = sp_workprocess_sum.index.str.replace('sp_','sp_c_', 1)


# %% mapping calculations for fertilisers and seeds ===========================

# mineral fertilisers applied:
fert = pd.DataFrame(c_salcaprep['tr_fert'])
fert_appl = fert.filter(items=['variable', 'amount_kg'])
sp_fert = pd.merge(fert_appl,tab_fert_part, how="inner", left_on="variable", right_on="NameEN")
sp_fert["amount_kg_conv"] = sp_fert["amount_kg"]*sp_fert["SP_mapping_conv_fact"]
sp_fert_sum = sp_fert.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')

# imported organic fertilisers directly applied on the field:
# - select only imported organic fertilisers, drop liquid and solid farm manure
# - organic fertilisers imported into the manure storage are mapped on farm level
# liquid:
org_fert_lman = pd.DataFrame(c_salcaprep['tr_manure_l'])
org_fert_lman = org_fert_lman[org_fert_lman['variable'] != 'liquid_farm_manure']
sp_org_lman = pd.merge(org_fert_lman,tab_manu_part, how="inner", left_on="variable", right_on="NameEN")
# convert amounts from m3 to kg
sp_org_lman["amount_kg"] = sp_org_lman["amount_m3"] * density_slurry_kgpm3
sp_org_lman["amount_kg_conv"] = sp_org_lman["amount_kg"] *\
                                sp_org_lman["SP_mapping_conv_fact"]
sp_org_lman_sum = sp_org_lman.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')
# solid:
org_fert_sman = pd.DataFrame(c_salcaprep['tr_manure_s'])
org_fert_sman = org_fert_sman[org_fert_sman['variable'] != 'solid_farm_manure']
sp_org_sman = pd.merge(org_fert_sman,tab_manu_part, how="inner", left_on="variable", right_on="NameEN")
# convert amounts from t to kg
sp_org_sman["amount_kg_conv"] = sp_org_sman["amount_t"] *\
                                sp_org_sman["SP_mapping_conv_fact"] * 1000
sp_org_sman_sum = sp_org_sman.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')

# seeds from sowing events:
sowing = pd.DataFrame(c_salcaprep['tr_sowi'])
sowing["crop_type"] = c_crop_type
seed_appl = sowing.filter(items=['crop_type', 'amount_kg', 'seedling_amount_p'])
sp_seed = pd.merge(seed_appl,tab_crops_part, how="inner", left_on="crop_type", right_on="NameEN")
# For mapped seedling LCIs use the seedling amount in pieces, otherwise use the
# seed amount in kg
sp_seed['amount_conv'] = np.where(sp_seed['SP_mapping_variable'].str.contains('_p$'),
                            sp_seed["seedling_amount_p"]*sp_seed["SP_mapping_conv_fact"],
                            sp_seed["amount_kg"]*sp_seed["SP_mapping_conv_fact"])
sp_seed_sum = sp_seed.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# Warning for crops with a seedling LCI but no seedling amount
df_warning = sp_seed.loc[(sp_seed['SP_mapping_variable'].str.contains('_p$')) & ((sp_seed['seedling_amount_p'] == 0) | (sp_seed['seedling_amount_p'].isna())),"crop_type"]
if df_warning.size > 0:
    w.warn('')
    w.warn(f'These crops miss a seedling amount: {df_warning.values}')
    w.warn('')
    stderr.flush()


# %% mapping of transports for lime and seeds =================================

# If variables for transport distances do not exist or there is some error,
# the standard values are used!
try:
    tran_dist_dict = {'local': inp.f_trans_dist_local_km, 'regional': inp.f_trans_dist_regional_km, 'national': inp.f_trans_dist_national_km, 'none': 0}
except:
    tran_dist_dict = {'local': 10, 'regional': 50, 'national': 100, 'none': 0}

# lime
df_tran_lime = sp_fert.loc[sp_fert["transport_distance_level"] != "none",]
# replace transport distance levels with their distance
df_tran_lime["trans_dist"] = df_tran_lime["transport_distance_level"].map(tran_dist_dict)
sp_tran_lime_tkm = np.sum(df_tran_lime["amount_kg_conv"]/1000 * df_tran_lime["trans_dist"])

# seeds
df_tran_seed = sp_seed.copy()
# replace transport distance levels with their distance
df_tran_seed["trans_dist"] = df_tran_seed["transport_distance_level"].map(tran_dist_dict)
sp_tran_seed_tkm = np.sum(df_tran_seed["amount_conv"]/1000 * df_tran_seed["trans_dist"])


# %% mapping calculations for irrigation ======================================

df_irri = pd.DataFrame(inp.get_events('c_irrigation'))
# map irrigation
if df_irri.empty == False:
    sp_irri = pd.merge(df_irri, tab_supp, how="inner", left_on="c_02_irri_type", right_on="NameEN")
    sp_irri["amount_conv"] = sp_irri["c_01_water_amount_m3"]*sp_irri["SP_mapping_conv_fact"]
    sp_irri_sum = sp_irri.groupby("SP_mapping_variable")["amount_conv"].agg('sum')


# %% calculating energy and CO2 contained in harvested products ===============


# get the amount of seeds in kg:
if sp_seed["amount_kg"].empty:
    sp_seed["amount_kg"] = pd.Series([0])

# get the harvested amounts in kg fresh matter for main and secondary product:
c_amount_harv = 0
c_amount_sepr = 0

for key in ["harv", "sepr"]:
    for j, element in enumerate(tr_event[key]["date"]):
        if key == "sepr":
                c_amount_sepr += tr_event[key]["amount_kg"][j]
        else:
            # total yield:
            c_amount_harv += tr_event[key]["amount_kg"][j]

# get the mapping columns from SALCAtables_crops
crop_mapping_entries = tab_crops.loc[tab_crops["NameEN"] == c_crop_type,['C&energy: main product', 'C&energy: co-product', 'C&energy: seed', 'HP: TS', 'NP: TS']]
# get the mapped values from SALCAtables_feed
nutrient_values = tab_feed.loc[tab_feed['NameEN'].isin(crop_mapping_entries.values.flatten().tolist()),[
    'NameEN', 'DM_content', 'AM: gross energy', 'AM: NfE content', 'AM: raw fibre content', 'AM: raw protein', 'AM: raw lipid content']]

# Dry matter content according to SALCAtables_crops:
# The nutrient values in SALCAtables_feed are per kg dry matter. 
# Therefore the dry matter content for the main and secondary products of the
# crop are needed according to SALCAtables_crops.
# For the seeds, the dry matter content is taken according to SALCAtables_feed,
# because the seeds have the same moisture as the corresponding feed.
# For the harvested products of a crop, this is not necessarily true.
if c_amount_harv != 0:
    dm_content_crop = float(crop_mapping_entries['HP: TS'].values[0])/100
else:
    dm_content_crop = 0
if c_amount_sepr != 0:
    dm_content_sepr = float(crop_mapping_entries['NP: TS'].values[0])/100
else:
    dm_content_sepr = 0

# calculate gross energy content of the crop:
gross_energy_mj =  (c_amount_harv * \
                nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: main product'].values[0], 'AM: gross energy'].item() * \
                dm_content_crop) \
                + \
                (c_amount_sepr * \
                nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: co-product'].values[0], 'AM: gross energy'].item() * \
                dm_content_sepr) \
                - \
                (np.sum(sp_seed["amount_kg"]) * \
                nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: seed'].values[0], 'AM: gross energy'] * \
                nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: seed'].values[0], 'DM_content']).item()
                
# calculate C content of the crop:
harv_nutri_values_dict = nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: main product'].values[0],:].to_dict(orient='list')
sepr_nutri_values_dict = nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: co-product'].values[0],:].to_dict(orient='list')
seed_nutri_values_dict = nutrient_values.loc[nutrient_values['NameEN']== crop_mapping_entries['C&energy: seed'].values[0],:].to_dict(orient='list')
harv_nutri_values_dict = {k: x[0] for k, x in harv_nutri_values_dict.items()}
sepr_nutri_values_dict = {k: x[0] for k, x in sepr_nutri_values_dict.items()}
seed_nutri_values_dict = {k: x[0] for k, x in seed_nutri_values_dict.items()}
    
charv = c_amount_harv * dm_content_crop *\
    (0.44 * (harv_nutri_values_dict['AM: NfE content'] + harv_nutri_values_dict['AM: raw fibre content']) \
     + 0.53 * harv_nutri_values_dict['AM: raw protein'] \
     + 0.75 * harv_nutri_values_dict['AM: raw lipid content'])
csepr = c_amount_sepr * dm_content_sepr *\
    (0.44 * (sepr_nutri_values_dict['AM: NfE content'] + sepr_nutri_values_dict['AM: raw fibre content']) \
     + 0.53 * sepr_nutri_values_dict['AM: raw protein'] \
     + 0.75 * sepr_nutri_values_dict['AM: raw lipid content'])
cseed = sp_seed["amount_kg"].item() *seed_nutri_values_dict['DM_content'] *\
    (0.44 * (seed_nutri_values_dict['AM: NfE content'] + seed_nutri_values_dict['AM: raw fibre content']) \
     + 0.53 * seed_nutri_values_dict['AM: raw protein'] \
     + 0.75 * seed_nutri_values_dict['AM: raw lipid content'])

co2_uptake_kg = 44/12 * (charv + csepr - cseed)


# %% mapping of harvested products as output ==================================

sp_harv_sum = pd.Series({}, dtype='float64')
sp_harv_sepr_sum = pd.Series({}, dtype='float64')

# get the SP_mapping variables:
crop_mapping_variables = tab_crops.loc[tab_crops["NameEN"] == c_crop_type,['Product', 'Secondary Product', 'SP_mapping_product', 'SP_mapping_secondary_prod']]

# exported harvested amount of the main product and secondary product:
harv_amount_exported_kg = sum([amount * frac_expo for amount, frac_expo in zip(tr_event['harv']['amount_kg'], tr_event['harv']['harv_expo'])])
harv_sepr_amount_exported_kg = sum([amount * frac_expo for amount, frac_expo in zip(tr_event['sepr']['amount_kg'], tr_event['sepr']['harv_expo'])])

# create the mapping dict:
if harv_amount_exported_kg > 0:
    sp_harv_sum = pd.Series({crop_mapping_variables['SP_mapping_product'].item(): harv_amount_exported_kg})
    if type(crop_mapping_variables['SP_mapping_product'].item()) != str:
        w.warn('')
        w.warn('Harvested product could not be mapped as an output!')
        w.warn(f'Crop type: {c_crop_type}')
        w.warn(f'Crop name: {c_crop_name}')
        w.warn('')
        stderr.flush()
if harv_sepr_amount_exported_kg > 0:
    sp_harv_sepr_sum = pd.Series({crop_mapping_variables['SP_mapping_secondary_prod'].item(): harv_sepr_amount_exported_kg})
    if type(crop_mapping_variables['SP_mapping_secondary_prod'].item()) != str:
        w.warn('')
        w.warn('Harvested secondary product could not be mapped as an output!')
        w.warn(f'Crop type: {c_crop_type}')
        w.warn(f'Crop name: {c_crop_name}')
        w.warn('')
        stderr.flush()


# %% output ===================================================================

# mineral fertiliser
if sp_fert_sum.empty == False: 
    out.set_many(sp_fert_sum)
    out.set_many(pd.Series({'sp_tran_lime_tkm': sp_tran_lime_tkm}))  # transports of imported lime
else:
    logging.info('No mineral fertiliser present for SimaPro mapping.')
    
# imported organic fertilisers directly applied on the field:
if sp_org_lman_sum.empty == False: 
    out.set_many(sp_org_lman_sum)
else:
    logging.info('No imported organic fertilisers (liquid) mapped on the crop.')
if sp_org_sman_sum.empty == False: 
    out.set_many(sp_org_sman_sum)
else:
    logging.info('No imported organic fertilisers (solid) mapped on the crop.')

# slurry and manure spreading workprocesses
out.set_many(pd.Series({'sp_trea_felm_m3': sp_slurry_spread_m3, 'sp_trea_fesm_kg': sp_manure_spread_t * 1000}))
logging.info('Amount of slurry spread (farm and imported slurry): %.3f m3', sp_slurry_spread_m3)
logging.info('Amount of solid manure spread (farm and imported manure): %.3f t', sp_manure_spread_t)
logging.info('')

# seeds:
if sp_seed_sum.empty == False: 
    out.set_many(sp_seed_sum)
    out.set_many(pd.Series({'sp_tran_seed_tkm': sp_tran_seed_tkm}))  # transports of imported seeds
else:
    logging.info('No seeds present for SimaPro mapping.')

# irrigation
if df_irri.empty == False:
    out.set_many(sp_irri_sum)
    logging.info('Irrigated crop, irrigation has been mapped.')

# field work processes
if c_mach_passages.empty == False:
    out.set_many(sp_workprocess_sum.to_dict())
else:
    logging.info('No machinery/work process present for mapping to LCIs for that crop.')

# machines list with number of passages on current crop for SALCAmapping_farm
if c_mach_passages.empty == False: 
    out.c_mach_passages = c_mach_passages.to_json()
    out.c_map_croptype = c_crop_type
    out.c_diesel_consumption_l = c_diesel_consumption_l
    out.c_tran_tkm = c_tran_tkm
    out.c_haba_p = c_haba_p
    out.c_habh_p = c_habh_p
    out.c_loaded_yield_m3 = c_loaded_yield_m3
    out.c_loaded_yield_leg_m3 = c_loaded_yield_leg_m3
    logging.info("Machinery and their treatments have been prepared.")
    logging.info("%d machine entries have been listed with their number of passages for", len(c_mach_passages))
    logging.info("crop type: %s", c_crop_type)
else:
    # save empty output too to circumvent an error in SALCAmapping_farm.py
    out.c_mach_passages = js.dumps({'passage_count':{},'treated_area':{}}) # empty dict to json
    out.c_map_croptype = c_crop_type
    logging.info('No machinery on crop level present for SimaPro mapping.')

# energy content and co2 uptake:
out.c_gross_energy_mj = gross_energy_mj
out.c_co2_uptake_kg = co2_uptake_kg

# output products:
if sp_harv_sum.empty == False: 
    out.set_many(sp_harv_sum)
if sp_harv_sepr_sum.empty == False: 
    out.set_many(sp_harv_sepr_sum)


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)