# -*- coding: utf-8 -*-
"""
File name: SALCAmapping_farm.py
Created on Tue Jun  8 07:49:31 2021

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script maps inputs and emissions at the farm level to the respective
    technosphere and biosphere flows.

Calculation level:
    Farm (entity comprising all fields, crops and animal groups)
"""


# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import logging
import warnings as w
from importlib import reload
from io import StringIO
from sys import stderr

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAmapping_farm'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define functions =========================================================

def read_table(path):
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    return tab

# %% input ====================================================================

# slurry density [kg/m3]
density_slurry_kgpm3 = 1000

# fuel consumption per crop
if hasattr(inp, 'c_diesel_consumption_l') and inp.c_diesel_consumption_l is not None:
    c_diesel_consumption_l = inp.c_diesel_consumption_l
else:
    c_diesel_consumption_l = [0]

# transport per crop [tkm]
if hasattr(inp, 'c_tran_tkm') and inp.c_tran_tkm is not None:
    c_tran_tkm = inp.c_tran_tkm
else:
    c_tran_tkm = [0]

# number of bales harvested [p]
if hasattr(inp, 'c_haba_p') and inp.c_haba_p is not None:
    c_haba_p = inp.c_haba_p
else:
    c_haba_p = [0]
if hasattr(inp, 'c_habh_p') and inp.c_habh_p is not None:
    c_habh_p = inp.c_habh_p
else:
    c_habh_p = [0]
# fodder loading
if hasattr(inp, 'c_loaded_yield_m3') and inp.c_loaded_yield_m3 is not None:
    c_loaded_yield_m3 = inp.c_loaded_yield_m3
else:
    c_loaded_yield_m3 = [0]
# harvest goods loading
if hasattr(inp, 'c_loaded_yield_leg_m3') and inp.c_loaded_yield_leg_m3 is not None:
    c_loaded_yield_leg_m3 = inp.c_loaded_yield_leg_m3
else:
    c_loaded_yield_leg_m3 = [0]

# crop prep data from all crops on the farm
c_salcaprep = []
if hasattr(inp, 'c_salcaprep') and inp.c_salcaprep is not None:
    for i in inp.c_salcaprep:
        c_salcaprep.append(js.loads(i))

# straw use from animal categories
if hasattr(inp, 'ls_straw_use_kg') and inp.ls_straw_use_kg is not None:
    ls_straw_use_list = inp.ls_straw_use_kg
else:
    ls_straw_use_list = []

# distances for transports of purchased supplies:
# If variables for transport distances do not exist or there is some error, the
# standard values are used!
try:
    tran_dist_dict = {'local': inp.f_trans_dist_local_km, 'regional': inp.f_trans_dist_regional_km, 'national': inp.f_trans_dist_national_km, 'none': 0}
except:
    tran_dist_dict = {'local': 10, 'regional': 50, 'national': 100, 'none': 0}

# load tables
# load table with conversion factors
tab_pars = read_table('SALCAmapping_pars.csv')
tab_pars.dropna(subset = ["NameEN"], inplace = True)
# load table for buildings
tab_build = pd.DataFrame(data=js.loads(inp.tab_build)['data'],
                        columns=js.loads(inp.tab_build)['columns'],
                        index=js.loads(inp.tab_build)['index']
                        )
tab_build_part = tab_build[["SelectionName", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact", "lifespan"]]
# load table for energy carriers
tab_enca = pd.DataFrame(data=js.loads(inp.tab_enca)['data'],
                        columns=js.loads(inp.tab_enca)['columns'],
                        index=js.loads(inp.tab_enca)['index']
                        )
# load table for supplies
tab_supp = pd.DataFrame(data=js.loads(inp.tab_supp)['data'],
                        columns=js.loads(inp.tab_supp)['columns'],
                        index=js.loads(inp.tab_supp)['index']
                        )
# load table for machinery
tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                         columns=js.loads(inp.tab_mach)['columns'],
                         index=js.loads(inp.tab_mach)['index']
                         )
tab_mach_part = tab_mach[['PythonName','SP_mapping_variable']]
# load table for manure
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                         columns=js.loads(inp.tab_manu)['columns'],
                         index=js.loads(inp.tab_manu)['index']
                         )
tab_manu_part = tab_manu[["NameEN", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact"]]
# load crops table for straw
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )

# load inputs
# read the machines list from SALCAmapping_crop for each crop
c_mach_passages = []
# There is no c_mach_passages when no crop is modelled:
if hasattr(inp, 'c_mach_passages') and inp.c_mach_passages is not None:
    for i in inp.c_mach_passages:
        c_mach_passages.append(pd.read_json(StringIO(i), typ = 'frame', orient = 'records'))
    # list of the crops that the machines were used on 
    c_map_croptype = inp.c_map_croptype

    # Even when crops are modeled, there might be no machinery (but it's
    # unlikely): Pass on an empty list as c_mach_passages
    if all([len(s)==0 for s in c_mach_passages]):
        c_mach_passages = []
    else:
        # control logs: check if list order is identical between crop type & machines
        try:
            logging.debug('')
            logging.debug('Machinery mapping control:\n')
            logging.debug('first crop type in list: %s', c_map_croptype[0])
            logging.debug('length of its machinelist: %d', len(c_mach_passages[0].index))
            logging.debug('last item in its machinelist: %s', c_mach_passages[0].index[-1])
            logging.debug('last crop type in list: %s', c_map_croptype[-1])
            logging.debug('length of its machinelist: %d', len(c_mach_passages[-1].index))
            logging.debug('last item in its machinelist: %s', c_mach_passages[-1].index[-1])
        except:
            logging.debug('')
            logging.debug('Machinery mapping control:\n')
            logging.debug('An error occured while printing the machine list (c_mach_passages)')
            logging.debug('lenght c_mach_passages = %d', len(c_mach_passages[-1].index))
else:
    logging.info('')
    logging.info('Machinery mapping:\n')
    logging.info('No machinery allocation to crops possible. No crops are modelled.')

# read the machines list from SALCAmapping_ls for each livestock group
ls_mach_usage = []
# There is no ls_mach_usage when no livestock is modelled:
if hasattr(inp, 'ls_mach_usage') and inp.ls_mach_usage is not None:
    for i in inp.ls_mach_usage:
        ls_mach_usage.append(pd.read_json(StringIO(i), typ = 'series', orient = 'records'))
    # list of the livestock groups that the machines were used in 
    ls_map_type = inp.ls_map_type

    # Even when livestock is modeled, there might be no machinery: Pass on an
    # empty list as ls_mach_usage
    if all([len(s)==0 for s in ls_mach_usage]):
        ls_mach_usage = []
    else:
        # control logs: check if list order is identical between livestock type & machines
        try:
            logging.debug('')
            logging.debug('Machinery mapping control:\n')
            logging.debug('first livestock type in list: %s', ls_map_type[0])
            logging.debug('last item in its machinelist: %s', ls_mach_usage[0].keys()[-1])
            logging.debug('last livestock type in list: %s', ls_map_type[-1])
            logging.debug('last item in its machinelist: %s', ls_mach_usage[-1].keys()[-1])
        except:
            logging.debug('')
            logging.debug('Machinery mapping control:\n')
            logging.debug('An error occured while printing the machine list (ls_mach_usage)')
            logging.debug('lenght ls_mach_usage = %d', len(ls_mach_usage[-1].keys()))
else:
    logging.info('')
    logging.info('Machinery mapping control:\n')
    logging.info('No machinery allocation to livestock possible. No livestock is modelled.')


# %% SP mapping for buildings =================================================

# list of all buildings on the farm:
build_cain = inp.get_events('cattle_infrastructure')
build_milk = inp.get_events('building_milking')
build_piin = inp.get_events('pigs_infrastructure')
build_poin = inp.get_events('poul_infrastructure')
build_hous = inp.get_events('building_housing')
build_mstl = inp.get_events('key_manstor_l')
build_msts = inp.get_events('key_manstor_s')
build_yard = inp.get_events('building_yard')
build_fest = inp.get_events('building_feedstor')
build_gene = inp.get_events('building_general')
build_irri = inp.get_events('building_irrigation')
build_grho = inp.get_events('building_greenhouse')
build_orch = inp.get_events('building_orchard')
build_sola = inp.get_events('building_solarpower')
build_cain = pd.DataFrame(build_cain)
build_milk = pd.DataFrame(build_milk)
build_piin = pd.DataFrame(build_piin)
build_poin = pd.DataFrame(build_poin)
build_hous = pd.DataFrame(build_hous)
build_mstl = pd.DataFrame(build_mstl)
# no dataframe needed for build_msts
build_yard = pd.DataFrame(build_yard)
build_fest = pd.DataFrame(build_fest)
build_gene = pd.DataFrame(build_gene)
build_irri = pd.DataFrame(build_irri)
build_grho = pd.DataFrame(build_grho)
build_orch = pd.DataFrame(build_orch)
build_sola = pd.DataFrame(build_sola)

# map cattle infrastructure
if build_cain.empty == False:
    cain_with_m2 = ['cattle_infr_09','cattle_infr_10','cattle_infr_11']  # list of buildings with m2 as unit
    build_cain['cain_with_m2'] = np.isin(build_cain['f_catt_01_infr_build'],cain_with_m2)
    build_cain_filt = build_cain.filter(items=['f_catt_01_infr_build',
                                           'f_catt_02_infr_places',
                                           'f_catt_02_infr_m2',
                                           'cain_with_m2'])
    build_cain_filt = build_cain_filt.fillna(0)
    build_cain_filt['amount_mixed'] = build_cain_filt['f_catt_02_infr_m2'] * build_cain_filt['cain_with_m2'] + build_cain_filt['f_catt_02_infr_places'] * (1-build_cain_filt['cain_with_m2'])
    sp_cain = pd.merge(build_cain_filt, tab_build_part, how="inner", left_on="f_catt_01_infr_build", right_on="SelectionName")
    sp_cain["amount_conv"] = sp_cain["amount_mixed"]*sp_cain["SP_mapping_conv_fact"]/sp_cain["lifespan"]
    sp_cain_sum = sp_cain.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map milking system
if build_milk.empty == False:
    # milk cooling tank:
    # careful: the volume of the milk cooling tank is appended to the column
    # 'f_02_infr_mipl_p' in order to be processed with the other amount values,
    # although the column name does not fit for it.
    mico_tank = {'f_01_infr_milk':'999_milk_cool_tank','f_02_infr_mipl_p':build_milk['f_03_infr_mita_l']}
    build_milk = build_milk.append(pd.DataFrame(mico_tank))
    build_milk.rename(columns={'f_02_infr_mipl_p': 'amount'}, inplace=True)
    sp_milk = pd.merge(build_milk, tab_build_part, how="inner", left_on="f_01_infr_milk", right_on="SelectionName")
    sp_milk["amount_conv"] = sp_milk["amount"]*sp_milk["SP_mapping_conv_fact"]/sp_milk["lifespan"]
    sp_milk_sum = sp_milk.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map pig infrastructure
if build_piin.empty == False:
    piin_with_m2 = ['pigs_infr_08','pigs_infr_09','pigs_infr_10']  # list of buildings with m2 as unit
    build_piin['piin_with_m2'] = np.isin(build_piin['f_pigs_01_infr_build'],piin_with_m2)
    build_piin_filt = build_piin.filter(items=['f_pigs_01_infr_build',
                                           'f_pigs_02_infr_places',
                                           'f_pigs_02_infr_m2',
                                           'piin_with_m2'])
    build_piin_filt = build_piin_filt.fillna(0)
    build_piin_filt['amount_mixed'] = build_piin_filt['f_pigs_02_infr_m2'] * build_piin_filt['piin_with_m2'] + build_piin_filt['f_pigs_02_infr_places'] * (1-build_piin_filt['piin_with_m2'])
    sp_piin = pd.merge(build_piin_filt, tab_build_part, how="inner", left_on="f_pigs_01_infr_build", right_on="SelectionName")
    sp_piin["amount_conv"] = sp_piin["amount_mixed"]*sp_piin["SP_mapping_conv_fact"]/sp_piin["lifespan"]
    sp_piin_sum = sp_piin.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map poultry infrastructure
if build_poin.empty == False:
    # Broiler housing is converted from places to m2 in the SP_mapping_conv_fact
    # from SALCAtables_buildings based on the following definition:
    # "The functional unit is 1 m2, corresponding to 13.3 broilers with a mean
    # weight of 2.5 kg (legal animal-density limit in Switzerland: 30 kg/m2)"
    sp_poin = pd.merge(build_poin, tab_build_part, how="inner", left_on="f_poul_01_infr_build", right_on="SelectionName")
    sp_poin["amount_conv"] = sp_poin["f_poul_02_infr_places"]*sp_poin["SP_mapping_conv_fact"]/sp_poin["lifespan"]
    sp_poin_sum = sp_poin.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map other animal housing
if build_hous.empty == False:
    sp_hous = pd.merge(build_hous, tab_build_part, how="inner", left_on="f_anim_01_infr_build", right_on="SelectionName")
    sp_hous["amount_conv"] = sp_hous["f_anim_02_infr_m2"]*sp_hous["SP_mapping_conv_fact"]/sp_hous["lifespan"]
    sp_hous_sum = sp_hous.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map liquid manure storage infrastructure
if build_mstl.empty == False:
    # the standard assumption for not_specified is uncovered. Replace the
    # values accordingly:
    build_mstl['f_lman_02_stor_vari'].replace({"000_not_specified": "003_farmManureCover_noCover"}, inplace=True)
    # combine the two variables for the building material and type of cover:
    build_mstl['f_lman_type'] = build_mstl['f_lman_01_infr_build'] + '_' + build_mstl['f_lman_02_stor_vari']
    # merge dataframes, convert the storage volumes with the conversion factor
    # and assign the volumes to the corresponding SP_mapping variables:
    sp_mstl = pd.merge(build_mstl, tab_build_part, how="inner", left_on="f_lman_type", right_on="SelectionName")
    sp_mstl["amount_conv"] = sp_mstl["f_lman_03_m3"]*sp_mstl["SP_mapping_conv_fact"]/sp_mstl["lifespan"]
    sp_mstl_sum = sp_mstl.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map solid manure storage infrastructure
if len(build_msts) > 0:  # build_msts is a list, not a dataframe
    sman_stor = {
        'sman_cover_type': [variable['f_sman_01_stor_vari'] for variable in build_msts],
        'sman_stor_size_m2': [variable['f_sman_02_m2'] for variable in build_msts]
        }
    sp_sman_nocover_m2 = 0
    sp_sman_cover_m2 = 0
    for i, sman_type in enumerate(sman_stor['sman_cover_type']):
        # there are only two types of solid manure storage: with and without cover
        # not_specified is treated as uncovered
        if sman_type in ('000_not_specified', '002_farmManureCoverStock_noCover'):
            sp_sman_nocover_m2 += sman_stor['sman_stor_size_m2'][i]
        else:
            sp_sman_cover_m2 += sman_stor['sman_stor_size_m2'][i]
    tablerow_nocover = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_sman_nocover_m2']
    tablerow_nocover.set_index('SP_mapping_variable', inplace=True, drop=False)
    tablerow_cover = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_sman_cover_m2']
    tablerow_cover.set_index('SP_mapping_variable', inplace=True, drop=False)
    sp_sman_nocover_m2 = sp_sman_nocover_m2 * tablerow_nocover["SP_mapping_conv_fact"] / tablerow_nocover["lifespan"]
    sp_sman_cover_m2 = sp_sman_cover_m2 * tablerow_cover["SP_mapping_conv_fact"] / tablerow_cover["lifespan"]

# map yard infrastructure
if build_yard.empty == False:
    sp_yard = pd.merge(build_yard, tab_build_part, how="inner", left_on="f_yard_01_type", right_on="SelectionName")
    sp_yard["amount_conv"] = sp_yard["f_yard_02_m2"]*sp_yard["SP_mapping_conv_fact"]/sp_yard["lifespan"]
    sp_yard_sum = sp_yard.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map feed storage
if build_fest.empty == False:
    sp_fest = pd.merge(build_fest, tab_build_part, how="inner", left_on="f_01_stor_feed", right_on="SelectionName")
    sp_fest["amount_conv"] = sp_fest["f_02_stor_m3"]*sp_fest["SP_mapping_conv_fact"]/sp_fest["lifespan"]
    sp_fest_sum = sp_fest.groupby("SP_mapping_variable")["amount_conv"].agg('sum')
    # unloading equipment (unloading sucker blower and grabcrane): only one
    # each is accounted for
    tablerow_teha = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_unlo_teha_p']
    tablerow_teha.set_index('SP_mapping_variable', inplace=True, drop=False)
    tablerow_grcr = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_unlo_grcr_p']
    tablerow_grcr.set_index('SP_mapping_variable', inplace=True, drop=False)
    if any(build_fest['f_03_unlo_teha']) is True:
        # telescopic handler is only considered once per farm (amount = 1)
        sp_unlo_teha_p = 1 * tablerow_teha["SP_mapping_conv_fact"] / tablerow_teha["lifespan"]
    else:
        # to ensure identical var type
        sp_unlo_teha_p = 0 * tablerow_teha["SP_mapping_conv_fact"] / tablerow_teha["lifespan"]
    if any(build_fest['f_04_unlo_grcr']) is True:
        # grabcrane is only considered once per farm (amount = 1)
        sp_unlo_grcr_p = 1 * tablerow_grcr["SP_mapping_conv_fact"] / tablerow_grcr["lifespan"]
    else:
        # to ensure identical var type
        sp_unlo_grcr_p = 0 * tablerow_grcr["SP_mapping_conv_fact"] / tablerow_grcr["lifespan"] 

# map general buildings (storage buildings)
if build_gene.empty == False:
    gene_with_m2 = ['004_garage_fireprot','003_shed_large_nofireprot']  # list of buildings with m2 as unit
    build_gene['gene_with_m2'] = np.isin(build_gene['f_01_gen_build'],gene_with_m2)
    # these buildings are assessed either in m3 (calculate area*height) or m2
    # (count area only)
    build_gene['amount_mixed'] = build_gene['f_02_infr_area_m2']\
                                 * build_gene['f_03_infr_height_m']\
                                 * (1-build_gene['gene_with_m2'])\
                                 + build_gene['f_02_infr_area_m2']\
                                 * build_gene['gene_with_m2']
    sp_gene = pd.merge(build_gene, tab_build_part, how="inner", left_on="f_01_gen_build", right_on="SelectionName")
    sp_gene["amount_conv"] = sp_gene["amount_mixed"]*sp_gene["SP_mapping_conv_fact"]/sp_gene["lifespan"]
    sp_gene_sum = sp_gene.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map irrigation infrastructure
if build_irri.empty == False:
    sp_irri_pipe_m = 0
    sp_irri_pump_m3 = 0
    for i, infrtype in enumerate(build_irri['f_01_infr_irri']):
        if infrtype == '001_irri_pipeline':
            sp_irri_pipe_m += build_irri['f_02_irri_leng_m'][i]
        elif infrtype == '002_irri_pumpingStation':
            sp_irri_pump_m3 += build_irri['f_03_infr_irri_m3'][i]
        else:
            raise Exception(str("Error: invalid irrigation infrastructure. Admin needs to compare code and building table."))
    tablerow_pipe = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_irri_pipe_m']
    tablerow_pump = tab_build_part.loc[tab_build_part['SP_mapping_variable'] == 'sp_irri_pump_m3']
    tablerow_pipe.set_index('SP_mapping_variable', inplace=True, drop=False)
    tablerow_pump.set_index('SP_mapping_variable', inplace=True, drop=False)
    sp_irri_pipe_m = sp_irri_pipe_m * tablerow_pipe["SP_mapping_conv_fact"] / tablerow_pipe["lifespan"]
    sp_irri_pump_m3 = sp_irri_pump_m3 * tablerow_pump["SP_mapping_conv_fact"] / tablerow_pump["lifespan"]

# map greenhouse and tunnel infrastructure
if build_grho.empty == False:
    sp_grho = pd.merge(build_grho, tab_build_part, how="inner", left_on="f_01_infr_grho", right_on="SelectionName")
    sp_grho["amount_conv"] = sp_grho["f_02_infr_area_m2"]*sp_grho["SP_mapping_conv_fact"]/sp_grho["lifespan"]
    sp_grho_sum = sp_grho.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map orchard infrastucture
if build_orch.empty == False:
    sp_orch = pd.merge(build_orch, tab_build_part, how="inner", left_on="f_01_infr_orch", right_on="SelectionName")
    sp_orch["amount_conv_ha"] = sp_orch["f_02_infr_area_m2"]*sp_orch["SP_mapping_conv_fact"]/sp_orch["lifespan"]/10000
    sp_orch_sum = sp_orch.groupby("SP_mapping_variable")["amount_conv_ha"].agg('sum')

# map solarpower infrastructure
if build_sola.empty == False:
    sp_sola = pd.merge(build_sola, tab_build_part, how="inner", left_on="f_01_infr_sola", right_on="SelectionName")
    sp_sola["amount_conv"] = sp_sola["f_02_sola_area_m2"]*sp_sola["SP_mapping_conv_fact"]/sp_sola["lifespan"]
    sp_sola_sum = sp_sola.groupby("SP_mapping_variable")["amount_conv"].agg('sum')


# %% SP mapping for machinery =================================================

# Machinery can be mapped either to ecoinvent work processes (see section
# mapping calculations for field work processes) that combine machinery
# production, diesel consumption, emissions from diesel combustion, emissions
# from tyre abrasion, and sheds for machinery parking.
# Or machinery can be mapped to machinery production only, while modelling of
# diesel consumption and sheds on farm level is done separately (see this
# section).

# Note: Currently, there is no code to consider machinery used on livestock for
# the workprocess mapping.


# crop machinery

# c_mach_passages is an empty list when no crop (or no machinery on crop) are
# modelled:
if c_mach_passages != []:
    # calculation of usage fractions per machine and crop (not crop type!)
    c_mach_treated_area = [df['treated_area'] for df in c_mach_passages]
    # total machine use:
    f_mach_tot_pass = pd.Series([], dtype = float)
    for s in c_mach_treated_area:
        f_mach_tot_pass = f_mach_tot_pass.add(s, fill_value = 0)
    # usage fractions (share of usage of each machine in each crop)
    mach_index = f_mach_tot_pass.index  # list of all machines as keys
    # build a Series of all machines with usage count of zero:
    usage_zero = pd.Series([0] * len(mach_index), index = mach_index, dtype = float)
    # add unused machines on crop level to allow division, using usage_zero:
    c_mach_passages_full = []
    for s in c_mach_treated_area:
        c_mach_passages_full.append(usage_zero.add(s, fill_value = 0))
    # calculate usage fractions by division of usage per crop with total usage on farm
    c_mach_usage_frac = []
    for i, usage_nbr in enumerate(c_mach_passages_full):
        c_mach_usage_frac.append(usage_nbr.div(f_mach_tot_pass, fill_value = 0))
    # convert f_mach_tot_pass from Series to DataFrame
    f_mach_tot_pass = pd.DataFrame(f_mach_tot_pass, columns=["passage_count"])
    
    # dataframe for machinery usage fractions per machine and per crop
    df_mach_crop = pd.concat(c_mach_usage_frac, axis='columns', keys=c_map_croptype)
    # transpose and sum up over croptypes as rows (combine duplicate croptypes)
    df_mach_crop = df_mach_crop.transpose()
    df_mach_crop['Croptype'] = df_mach_crop.index
    df_mach_crop = df_mach_crop.groupby('Croptype').sum()
    
    # combine machines into the machine categories as they are mapped to SimaPro
    # transpose again, get machinery mapping and sum up over mapping vars in the rows
    df_mach_crop = df_mach_crop.transpose()
    # remove number from machine string in index:
    df_mach_crop.index = df_mach_crop.index.str.slice(start=4)
    sp_mach_crop = pd.merge(df_mach_crop, tab_mach_part, how="inner", left_index=True, right_on="PythonName")
    # add a column with the count for each SP_mapping_variable
    sp_mach_crop['count_per_type'] = sp_mach_crop.groupby('SP_mapping_variable')\
                                    ['SP_mapping_variable'].transform('count')
    # sum up usage fractions over the SP_mapping_variable and divide by the count
    # result is the proper usage fraction per SP_mapping_variable per crop type
    sp_mach_mapping_crop = sp_mach_crop.groupby(['SP_mapping_variable',\
                                          'count_per_type']).agg('sum')
    sp_mach_mapping_crop.reset_index(level=1, inplace=True)
    sp_mach_mapping_crop = sp_mach_mapping_crop.div(sp_mach_mapping_crop['count_per_type'], axis=0)
    sp_mach_mapping_crop.drop(columns=['count_per_type'], inplace=True)
    
    # control: fractions need to sum up to 1
    mach_control = pd.Series([], dtype = float)
    for s in c_mach_usage_frac:
        mach_control = mach_control.add(s, fill_value = 0)
    
    if (round(sp_mach_mapping_crop.sum(axis=1),3) == 1).all() == True:
    	if (round(mach_control,3) == 1).all() == True:
    		logging.debug('Machine usage fraction per crop: Calculation successful')
    	else:
    		logging.debug('Error in Machine usage fraction per crop: First calculation did not sum up to 1.')
    else:
    	logging.debug('Error in Machine usage fraction per crop: Second calculation did not sum up to 1.')
    
else:
    # when no crops are modelled, f_mach_tot_pass needs to be an empty dataframe:
    f_mach_tot_pass = pd.DataFrame(columns=["passage_count"])
    logging.info('Machine usage fraction per crop: No crop machinery data available')

# calculation of machine amounts per year (machine weight / service life)
if f_mach_tot_pass.empty == False:
    # for all machines on the farm, remove number from machine string in index:
    f_mach_tot_pass.index = f_mach_tot_pass.index.str.slice(start=4)
    # relevant subset of tab_mach for the farm:
    df_mach_farm = tab_mach[tab_mach.PythonName.isin(list(f_mach_tot_pass.index))]
    # relevant amount of used machines, calculated as machine weight divided by
    # service life
    df_mach_farm = df_mach_farm.assign(machine_amount = (df_mach_farm['Gewicht [kg]']\
                                    / df_mach_farm['Nutzungsdauer [yr]']))
    
    # mapping to the simapro variables
    # without distribution per crop or livestock, whole farm only
    df_mach_farm["amount_conv"] = (df_mach_farm["machine_amount"]*df_mach_farm["SP_mapping_conv_fact"])
    sp_mach_sum_crop = df_mach_farm.groupby("SP_mapping_variable")["amount_conv"].agg('sum')


# livestock machinery

# ls_mach_usage is an empty list when no livestock or no machinery on livestock
# are modelled:
if ls_mach_usage != []:
    # calculation of usage fractions per machine and livestock (not livestock type!)
    # total machine use:
    f_mach_tot_use = pd.Series([], dtype = float)
    for s in ls_mach_usage:
        f_mach_tot_use = f_mach_tot_use.add(s, fill_value = 0)
    # usage fractions
    mach_index = f_mach_tot_use.keys()  # list of all machines as keys
    # build a Series of all machines with usage count of zero:
    usage_zero = pd.Series([0] * len(mach_index), index = mach_index, dtype = float)
    # add unused machines on livestock level to allow division, using usage_zero:
    ls_mach_usage_full = []
    for s in ls_mach_usage:
        ls_mach_usage_full.append(usage_zero.add(s, fill_value = 0))
    # calculate usage fractions by division of usage per livestock with total
    # usage on farm
    ls_mach_usage_frac = []
    for i, usage_nbr in enumerate(ls_mach_usage_full):
        ls_mach_usage_frac.append(usage_nbr.div(f_mach_tot_use, fill_value = 0))
    
    # dataframe for machinery usage fractions per machine and per livestock
    df_mach_ls = pd.concat(ls_mach_usage_frac, axis='columns', keys=ls_map_type)
    # transpose and sum up over livestock as rows (combine duplicate livestock types)
    df_mach_ls = df_mach_ls.transpose()
    df_mach_ls['Livestocktype'] = df_mach_ls.index
    df_mach_ls = df_mach_ls.groupby('Livestocktype').sum()
    
    # combine machines into the machine categories as they are mapped to SimaPro
    # transpose again, get machinery mapping and sum up over mapping vars in the rows
    df_mach_ls = df_mach_ls.transpose()
    # remove number from machine string in index:
    df_mach_ls.index = df_mach_ls.index.str.slice(start=4)
    sp_mach_ls = pd.merge(df_mach_ls, tab_mach_part, how="inner", left_index=True, right_on="PythonName")
    # add a column with the count for each SP_mapping_variable
    sp_mach_ls['count_per_type'] = sp_mach_ls.groupby('SP_mapping_variable')\
                                    ['SP_mapping_variable'].transform('count')
    # sum up usage fractions over the SP_mapping_variable and divide by the count
    # result is the proper usage fraction per SP_mapping_variable per livestock type
    sp_mach_mapping_ls = sp_mach_ls.groupby(['SP_mapping_variable',\
                                          'count_per_type']).agg('sum')
    sp_mach_mapping_ls.reset_index(level=1, inplace=True)
    sp_mach_mapping_ls = sp_mach_mapping_ls.div(sp_mach_mapping_ls['count_per_type'], axis=0)
    sp_mach_mapping_ls.drop(columns=['count_per_type'], inplace=True)
    
    # control: fractions need to sum up to 1
    # all values for both ls_mach_usage_frac and sp_mach_mapping_ls == 1?
    mach_control = pd.Series([], dtype = float)
    for s in ls_mach_usage_frac:
        mach_control = mach_control.add(s, fill_value = 0)
    
    if (round(sp_mach_mapping_ls.sum(axis=1),3) == 1).all() == True:
    	if (round(mach_control,3) == 1).all() == True:
    		logging.debug('Machine usage fraction per livestock: Calculation successful')
    	else:
    		logging.debug('Error in Machine usage fraction per livestock: First calculation did not sum up to 1.')
    else:
    	logging.debug('Error in Machine usage fraction per livestock: Second calculation did not sum up to 1.')
    
else:
    # when no livestock is modelled, f_mach_tot_use needs to be an empty dataframe:
    f_mach_tot_use = pd.DataFrame()
    logging.info("Machine usage fraction per livestock: No livestock machinery data available")


# calculation of machine amounts per year (machine weight / service life)
if f_mach_tot_use.empty == False:
    # for all machines on the farm, remove number from machine string in index:
    f_mach_tot_use.index = f_mach_tot_use.index.str.slice(start=4)
    # relevant subset of tab_mach for the farm:
    df_mach_farm_ls = tab_mach[tab_mach.PythonName.isin(list(f_mach_tot_use.index))]
    # relevant amount of used machines, calculated as machine weight divided by
    # service life
    df_mach_farm_ls = df_mach_farm_ls.assign(machine_amount = (df_mach_farm_ls['Gewicht [kg]']\
                                    / df_mach_farm_ls['Nutzungsdauer [yr]']))
    
    df_mach_farm_ls["amount_conv"] = (df_mach_farm_ls["machine_amount"]*df_mach_farm_ls["SP_mapping_conv_fact"])
    sp_mach_sum_ls = df_mach_farm_ls.groupby("SP_mapping_variable")["amount_conv"].agg('sum')


# combine machines on crops and machines for livestock

try:
    sp_mach_sum = sp_mach_sum_crop.add(sp_mach_sum_ls, fill_value=0)
except NameError:
    # if only livestock machinery is present
    if f_mach_tot_use.empty == False and f_mach_tot_pass.empty == True:
        sp_mach_sum = sp_mach_sum_ls
    # if only crop machinery is present
    if f_mach_tot_pass.empty == False and f_mach_tot_use.empty == True:
        sp_mach_sum = sp_mach_sum_crop


# calculate the allocation info

if f_mach_tot_pass.empty == False:
    # fraction of crop related machines:
    sp_mach_crop_div = sp_mach_sum_crop.div(sp_mach_sum, fill_value=0)
    # corrected machine usage:
    corr_factor_crop = sp_mach_crop_div[sp_mach_crop_div.index.isin(sp_mach_mapping_crop.index)].copy()
    sp_mach_mapping_crop = sp_mach_mapping_crop.mul(corr_factor_crop, axis=0)
    
    # sp_mach_mapping_crop contains the usage fraction per croptype for each
    # machinery inventory on the farm. For each croptype this is equal to an
    # allocation key for the different machine variables (SP_mapping_variable).
    # As result, those values are printed to the module log and can be manually
    # used for allocation from there.
    logging.info('')
    logging.info('Information on machine usage fraction per croptype:\n')
    for index, data in sp_mach_mapping_crop.iterrows():
        logging.info(index)
        logging.info(data)
        logging.info('')
    
if f_mach_tot_use.empty == False:
    # fraction of livestock related machines:
    sp_mach_ls_div = sp_mach_sum_ls.div(sp_mach_sum, fill_value=0)
    # corrected machine usage:
    corr_factor_ls = sp_mach_ls_div[sp_mach_ls_div.index.isin(sp_mach_mapping_ls.index)].copy()
    sp_mach_mapping_ls = sp_mach_mapping_ls.mul(corr_factor_ls, axis=0)
        
    # sp_mach_mapping_ls contains the usage fraction per livestocktype for each
    # machinery inventory on the farm. For each livestocktype this is equal to
    # an allocation key for the different machine variables (SP_mapping_variable).
    # As result, those values are printed to the module log and can be manually
    # used for allocation from there.
    logging.info('')
    logging.info('Information on machine usage fraction per livestocktype:\n')
    for index, data in sp_mach_mapping_ls.iterrows():
        logging.info(index)
        logging.info(data)
        logging.info('')


# %% mapping calculations for field work processes ============================
# field work processes are now mapped on crop level in SALCAmapping_crop





# %% SP mapping for energy carriers ===========================================

enca_fuel = inp.get_events('energy_carriers_fuel')
enca_fuel = pd.DataFrame(enca_fuel)
enca_burn = inp.get_events('energy_carriers_burn')
enca_burn = pd.DataFrame(enca_burn)
enca_gas = inp.get_events('energy_carriers_gas')
enca_gas = pd.DataFrame(enca_gas)
enca_heat = inp.get_events('energy_carriers_heat')
enca_heat = pd.DataFrame(enca_heat)
enca_elec = inp.get_events('energy_carriers_elec')
enca_elec = pd.DataFrame(enca_elec)

# fuel consumption from crop level summed up:
f_diesel_consumption_kg = sum(c_diesel_consumption_l) * tab_pars.loc[tab_pars["NameEN"] == "cf_001_diesel", "Value"][0]
logging.info('')
logging.info('Calculated Diesel consumption from treatments: %s kg', f_diesel_consumption_kg)

# map energy carriers - fuels (unit conversion l to kg needed)
if enca_fuel.empty == False:
    sp_fuel = pd.merge(enca_fuel, tab_enca, how="inner", left_on="f_01_fuel_vari", right_on="NameEN")
    # conversion from l to kg according to tab_pars:
    sp_fuel["conversion_key"] = "cf_" + sp_fuel["f_01_fuel_vari"]
    sp_fuel = pd.merge(sp_fuel, tab_pars, how="inner", left_on="conversion_key", right_on="NameEN")
    sp_fuel["amount_conv"] = sp_fuel["f_02_fuel_amount_l"]\
                            * sp_fuel["SP_mapping_conv_fact"]\
                            * sp_fuel["Value"]  # kg/l therefore multiplication!
    sp_fuel_1st_sum = sp_fuel.groupby("SP_mapping_variable")["amount_conv"].agg('sum')
    # secondary mapping (for fuel combustion):
    sp_fuel["amount_2nd_conv"] = sp_fuel["f_02_fuel_amount_l"]\
                                * sp_fuel["SP_2nd_mapping_conv_fact"]\
                                * sp_fuel["Value"]  # kg/l therefore multiplication!
    sp_fuel_2nd_sum = sp_fuel.groupby("SP_2nd_mapping_variable")["amount_2nd_conv"].agg('sum')
    # combine both series:
    sp_fuel_sum = pd.concat([sp_fuel_1st_sum, sp_fuel_2nd_sum])
    
    # add fuel consumption from crop level:
    if 'sp_enca_diesel_kg' in sp_fuel_sum.keys():
        sp_fuel_sum['sp_enca_diesel_kg'] = sp_fuel_sum['sp_enca_diesel_kg'] + f_diesel_consumption_kg
        sp_fuel_sum['sp_enca_comb_diesel_kg'] = sp_fuel_sum['sp_enca_comb_diesel_kg'] + f_diesel_consumption_kg
    if 'sp_enca_petrol_kg' in sp_fuel_sum.keys():
        sp_fuel_sum['sp_enca_petrol_kg'] = sp_fuel_sum['sp_enca_petrol_kg'] + 0
        sp_fuel_sum['sp_enca_comb_petrol_kg'] = sp_fuel_sum['sp_enca_comb_petrol_kg'] + 0
else:
    # fuel consumption from crop level:
    fuel_dict = {'sp_enca_diesel_kg': f_diesel_consumption_kg, 
                 'sp_enca_comb_diesel_kg': f_diesel_consumption_kg, 
                 'sp_enca_petrol_kg': 0, 
                 'sp_enca_comb_petrol_kg': 0}
    sp_fuel_sum = pd.Series(data=fuel_dict)

# map energy carriers - burning materials (unit conversion from m3 or l to kg or t needed)
if enca_burn.empty == False:
    sp_burn = pd.merge(enca_burn, tab_enca, how="inner", left_on="f_01_burn_vari", right_on="NameEN")
    # unit conversion to kg according to f_03_burn_unit and tab_pars:
    sp_burn["conversion_key"] = sp_burn["f_01_burn_vari"] + "_" + sp_burn["f_03_burn_unit"]
    sp_burn = pd.merge(sp_burn, tab_pars, how="left", left_on="conversion_key", right_on="NameEN")
    if any(pd.isna(sp_burn['Value'])):
        index = np.where(pd.isna(sp_burn['Value']) == True)[0]
        logging.info('')
        logging.info('burning materials mapping:\n')
        w.warn('burning material and unit do not fit. Unit conversion failed.')
        stderr.flush()
        logging.info('Mapping was not possible for: %s', sp_burn["f_01_burn_vari"][index])
        logging.info('')
    # conversion from kg to MJ according to tab_pars:
    sp_burn["conversion_key_MJ"] = "hv_" + sp_burn["f_01_burn_vari"]
    sp_burn = pd.merge(sp_burn, tab_pars[["NameEN","Value"]], how="inner", left_on="conversion_key_MJ", right_on="NameEN")
    sp_burn["amount_conv_kg"] = sp_burn["f_02_burn_amount_spec"]\
                            * sp_burn["SP_mapping_conv_fact"]\
                            / sp_burn["Value_x"]  #unit/kg therefore division!
    sp_burn["amount_conv"] = sp_burn["amount_conv_kg"] * sp_burn["Value_y"]  # MJ/kg therefore multiplication!
    sp_burn_sum = sp_burn.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map energy carriers - gas
if enca_gas.empty == False:
    sp_gas = pd.merge(enca_gas, tab_enca, how="inner", left_on="f_01_gas_vari", right_on="NameEN")
    # conversion from Nm3 to MJ according to tab_pars:
    sp_gas["conversion_key_MJ"] = "hv_" + sp_gas["f_01_gas_vari"]
    sp_gas = pd.merge(sp_gas, tab_pars[["NameEN","Value"]], how="inner", left_on="conversion_key_MJ", right_on="NameEN")
    sp_gas["amount_conv"] = sp_gas["f_02_gas_amount_Nm3"]\
                            * sp_gas["SP_mapping_conv_fact"]\
                            * sp_gas["Value"]  # MJ/Nm3 therefore multiplication!
    sp_gas_sum = sp_gas.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map energy carriers - heat
if enca_heat.empty == False:
    sp_heat = pd.merge(enca_heat, tab_enca, how="inner", left_on="f_01_heat_vari", right_on="NameEN")
    sp_heat["amount_conv"] = sp_heat["f_02_heat_amount_MJ"]*sp_heat["SP_mapping_conv_fact"]
    sp_heat_sum = sp_heat.groupby("SP_mapping_variable")["amount_conv"].agg('sum')

# map energy carriers - electricity
if enca_elec.empty == False:
    logging.debug('')
    logging.debug('electricity mapping:\n')
    for index, row in enca_elec.iterrows():
        if row.f_01_elec_vari == '019_electricity_grid':
            if pd.isna(row.f_02_elec_usage_kWh):
                w.warn('electricity usage is missing in the data for one event.')
                stderr.flush()
        else:
            if pd.isna(row.f_02_elec_usage_kWh) or row.f_02_elec_usage_kWh == 0:
                enca_elec.loc[index,'f_02_elec_usage_kWh'] = row.f_03_elec_prod_kWh - row.f_04_elec_sold_kWh
            else:
                if pd.isna(row.f_03_elec_prod_kWh) or row.f_03_elec_prod_kWh == 0:
                    enca_elec.loc[index,'f_03_elec_prod_kWh'] = row.f_02_elec_usage_kWh + row.f_04_elec_sold_kWh
                else:
                    if pd.isna(row.f_04_elec_sold_kWh) or row.f_04_elec_sold_kWh == 0:
                        enca_elec.loc[index,'f_04_elec_sold_kWh'] = row.f_03_elec_prod_kWh - row.f_02_elec_usage_kWh
                    else:
                        difference = row.f_03_elec_prod_kWh - row.f_04_elec_sold_kWh - row.f_02_elec_usage_kWh
                        if round(difference,3) != 0:
                            w.warn(f'Difference in electricity production is {difference} kWh')
                            stderr.flush()
            if any(pd.isna(row)):
                w.warn('Not all needed values were included in the data. Please check the electricity events of your farm.')
                stderr.flush()
                    
    sp_elec = pd.merge(enca_elec, tab_enca, how="inner", left_on="f_01_elec_vari", right_on="NameEN")
    sp_elec["amount_conv"] = sp_elec["f_02_elec_usage_kWh"]*sp_elec["SP_mapping_conv_fact"]
    sp_elec_sum = sp_elec.groupby("SP_mapping_variable")["amount_conv"].agg('sum')
    logging.info('electricity mapping completed')
    logging.info('')



# %% SP mapping for other inputs, including transports where applicable =======

supp_foil = inp.get_events('supplies_foil')
supp_foil = pd.DataFrame(supp_foil)
supp_water = inp.get_events('supplies_water')
supp_water = pd.DataFrame(supp_water)
f_plantpots_quan = inp.f_plantpots_quan
f_grease_kg = inp.f_grease_kg
# define transport variables
tran_supp_pp_tkm = 0
tran_supp_gr_tkm = 0
tran_foil_tkm = 0

# map supplies - grease and plant pots
if f_plantpots_quan != None:
    tablerow_plpots = tab_supp.loc[tab_supp['SP_mapping_variable'] == 'sp_plantpots_p']
    tablerow_plpots.set_index('SP_mapping_variable', inplace=True, drop=False)
    sp_plantpots_p = tablerow_plpots['SP_mapping_conv_fact'] * f_plantpots_quan
    # transports:
    tran_supp_pp_tkm = sp_plantpots_p.values[0] * tablerow_plpots['specific_weight'].values[0]/1000 *\
        tran_dist_dict[tablerow_plpots['transport_distance_level'].values[0]]

if f_grease_kg != None:
    tablerow_grease = tab_supp.loc[tab_supp['SP_mapping_variable'] == 'sp_grease_kg']
    tablerow_grease.set_index('SP_mapping_variable', inplace=True, drop=False)
    sp_grease_kg = tablerow_grease['SP_mapping_conv_fact'] * f_grease_kg
    # transports:
    tran_supp_gr_tkm = sp_grease_kg.values[0]/1000 *\
        tran_dist_dict[tablerow_grease['transport_distance_level'].values[0]]

# map supplies - foils and nets
if supp_foil.empty == False:
    sp_foil = pd.merge(supp_foil, tab_supp, how="inner", left_on="f_01_foil_type", right_on="NameEN")
    sp_foil["amount_conv"] = sp_foil["f_02_foil_amount_m2"]*sp_foil["SP_mapping_conv_fact"]
    sp_foil_sum = sp_foil.groupby("SP_mapping_variable")["amount_conv"].agg('sum')
    # transports:
    sp_foil["trans_dist"] = sp_foil["transport_distance_level"].map(tran_dist_dict)  # replace transport distance levels with their distance
    # transports: weight of imported foils in tons multiplied with transport
    # distance and summed over all foils
    tran_foil_tkm = sum(sp_foil["amount_conv"]/1000 * sp_foil["trans_dist"])
sp_tran_supp_tkm = tran_supp_pp_tkm + tran_supp_gr_tkm + tran_foil_tkm

# map supplies - water use
if supp_water.empty == False:
    sp_water = pd.merge(supp_water, tab_supp, how="inner", left_on="f_01_water_type", right_on="NameEN")
    sp_water["amount_conv"] = sp_water["f_02_water_amount_m3"]*sp_water["SP_mapping_conv_fact"]
    # unit conversion for tap water from m3 to kg:
    sp_water.loc[sp_water["SP_mapping_variable"] == "sp_water_tap_kg","amount_conv"] =\
    sp_water.loc[sp_water["SP_mapping_variable"] == "sp_water_tap_kg","amount_conv"] * 1000
    sp_water_sum = sp_water.groupby("SP_mapping_variable")["amount_conv"].agg('sum')


# %% SP mapping for organic fertilisers imported into the manure storage ======

# imported organic fertilisers directly applied onto the field are mapped on
# crop level
org_fert_lman = pd.DataFrame(inp.get_events('import_manure_l'))
org_fert_sman = pd.DataFrame(inp.get_events('import_manure_s'))

# liquid:
if org_fert_lman.empty == False:
    sp_org_lman = pd.merge(org_fert_lman,tab_manu_part, how="inner", left_on="f_01_lman_vari", right_on="NameEN")
    # Correct amount with dilution and convert to kg 
    sp_org_lman["amount_kg"] = sp_org_lman["f_02_impo_m3"] *\
                                    sp_org_lman["f_03_manu_dilu_perc"] *\
                                    density_slurry_kgpm3
    sp_org_lman["amount_kg_conv"] = sp_org_lman["amount_kg"]*sp_org_lman["SP_mapping_conv_fact"]
    # Change the SP_mapping_variable to a 2nd SP_mapping_variable on farm level.
    # Explanation: organic fertilisers are assigned to a mapping variable at
    # crop level in tab_manu, because they are mapped at crop level in
    # SALCAmapping_crop when they are imported and directly applied to a field.
    # Here, we import into the manure storage and therefore need to map at the
    # farm level. The solution is, we need a second set of SP_mapping_variables
    # at farm level for organic fertilisers!
    sp_org_lman["SP_mapping_variable"] = sp_org_lman["SP_mapping_variable"].str.replace('sp_','sp_f_')
    sp_org_lman_sum = sp_org_lman.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')


# solid:
if org_fert_sman.empty == False:
    sp_org_sman = pd.merge(org_fert_sman,tab_manu_part, how="inner", left_on="f_01_sman_vari", right_on="NameEN")
    sp_org_sman["amount_kg_conv"] = sp_org_sman["f_02_impo_t"] *\
                                    sp_org_sman["SP_mapping_conv_fact"] * 1000
    # Change the SP_mapping_variable to a 2nd SP_mapping_variable on farm level.
    # Explanation: organic fertilisers are assigned to a mapping variable at
    # crop level in tab_manu, because they are mapped at crop level in
    # SALCAmapping_crop when they are imported and directly applied to a field.
    # Here, we import into the manure storage and therefore need to map at the
    # farm level. The solution is, we need a second set of SP_mapping_variables
    # at farm level for organic fertilisers!
    sp_org_sman["SP_mapping_variable"] = sp_org_sman["SP_mapping_variable"].str.replace('sp_','sp_f_')
    
    sp_org_sman_sum = sp_org_sman.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')


# %% mapping of straw imports (if use > production) ===========================

# Straw used for bedding is either harvested on the farm or imported. To
# determine the amount that is imported, we calculate the harvested straw that
# is not sold/exported but used on the farm. If part of the harvested straw is
# used as feedstuff, it is not available for bedding.
# Straw imported for feed is mapped separately under feedstuffs in SALCAmapping_ls.

# straw amount harvested but not sold from all straw producing crops
straw_crops = tab_crops.loc[tab_crops['Nebenprodukt\nBezeichnung']=='Stroh','NameEN']
amount_straw2use_kg = 0
for crop_data in c_salcaprep:
    if straw_crops.str.contains(crop_data['crop_name']).any():
        amount_straw2use_kg += sum(amount * (1 - exported) for amount, exported in \
                                   zip(crop_data['tr_harv_sepr']['amount_kg'], 
                                       crop_data['tr_harv_sepr']['harv_expo'])
                                   )
# amount of straw needed as bedding for all animal categories
f_straw_use_kg = sum(ls_straw_use_list)
# amount of farm grown straw consumed as feed
straw_fed = sum([feed['ls_02_amts_kg'] * (1-feed['ls_03_frac_impo']) for feed in \
                 inp.get_events('ls_feedstuff_r') if 'stroh' in feed['ls_01_rofe_type']])
# straw imported = straw used for bedding - harvested straw neither sold nor
# fed to animals
f_straw_imports_kg = max(0, f_straw_use_kg-(amount_straw2use_kg-straw_fed))


# %% output ===================================================================

# set the variables in the list inside the output object
# buildings
if build_cain.empty == False: out.set_many(sp_cain_sum.to_dict())
if build_milk.empty == False: out.set_many(sp_milk_sum.to_dict())
if build_piin.empty == False: out.set_many(sp_piin_sum.to_dict())
if build_poin.empty == False: out.set_many(sp_poin_sum.to_dict())
if build_hous.empty == False: out.set_many(sp_hous_sum.to_dict())
if build_mstl.empty == False: out.set_many(sp_mstl_sum.to_dict())
if len(build_msts) > 0:  # build_msts is a list, not a dataframe
    out.set_many(sp_sman_cover_m2.to_dict())
    out.set_many(sp_sman_nocover_m2.to_dict())  
if build_yard.empty == False: out.set_many(sp_yard_sum.to_dict())
if build_fest.empty == False:
    out.set_many(sp_fest_sum.to_dict())
    out.set_many(sp_unlo_teha_p.to_dict())
    out.set_many(sp_unlo_grcr_p.to_dict())
if build_gene.empty == False: out.set_many(sp_gene_sum.to_dict())
if build_irri.empty == False:
    out.set_many(sp_irri_pipe_m.to_dict())
    out.set_many(sp_irri_pump_m3.to_dict())
if build_grho.empty == False: out.set_many(sp_grho_sum.to_dict())
if build_orch.empty == False: out.set_many(sp_orch_sum.to_dict())
if build_sola.empty == False: out.set_many(sp_sola_sum.to_dict())

# machinery
if f_mach_tot_pass.empty == False:
    out.set_many(sp_mach_sum.to_dict())
else:
    logging.info('No machinery present for mapping to LCIs.')

# energy carriers
if sp_fuel_sum.empty == False: out.set_many(sp_fuel_sum.to_dict())
if enca_burn.empty == False: out.set_many(sp_burn_sum.to_dict())
if enca_gas.empty  == False: out.set_many(sp_gas_sum.to_dict())
if enca_heat.empty == False: out.set_many(sp_heat_sum.to_dict())
if enca_elec.empty == False: out.set_many(sp_elec_sum.to_dict())

# supplies
if f_plantpots_quan != None: out.set_many(sp_plantpots_p.to_dict())
if f_grease_kg != None: out.set_many(sp_grease_kg.to_dict())
if supp_foil.empty == False: out.set_many(sp_foil_sum.to_dict())
if supp_water.empty == False: out.set_many(sp_water_sum.to_dict())

# transports for supplies
out.set_many(pd.Series({'sp_tran_supp_tkm': sp_tran_supp_tkm}))

# organic fertilisers imported into the manure storage:
if org_fert_lman.empty == False: 
    out.set_many(sp_org_lman_sum.to_dict())
else:
    logging.info('No imported organic fertilisers (liquid) on farm level present for mapping to LCIs.')
if org_fert_sman.empty == False: 
    out.set_many(sp_org_sman_sum.to_dict())
else:
    logging.info('No imported organic fertilisers (solid) on farm level present for mapping to LCIs.')

# imported straw
out.f_straw_impo_kg = f_straw_imports_kg


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)