# -*- coding: utf-8 -*-
"""
File name: SALCAmapping_ls.py
Created on Mon Jun 21 15:00:42 2021

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script maps inputs and emissions at the level of animal groups to the
    respective technosphere and biosphere flows.

Calculation level:
    Livestock
"""


# %% import modules and starting sequence =====================================

import datetime as dt
import json as js
import logging
import warnings as w
from importlib import reload
from sys import stderr

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO
                    
start = dt.datetime.now(tz=None)
module_name = 'SALCAmapping_ls'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')


# create salca context
ctx = create_salca_context('livestock')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define functions ==========================================================



# %% map the weight of imported animals to the corresponding SP_mapping_variable

# load table for animal categories
tab_ls = pd.DataFrame(data=js.loads(inp.tab_ls)['data'],
                        columns=js.loads(inp.tab_ls)['columns'],
                        index=js.loads(inp.tab_ls)['index']
                        )
# name of the animal type
animal_type = ctx.livestock.livestock_definition_name
# live weight of imported animals
ls_impo_kg = [variable['ls_02_impo_kg']
              for variable in inp.get_events('ls_import_livestock')]
if len(ls_impo_kg)>0:
    sp_ls_var = tab_ls.loc[tab_ls['NameEN'] == animal_type,
                            'SP_mapping_variable'].values[0]
    
    if sp_ls_var == 'sp_chicks_p':
        # recalculate the number of chicks imported, based on the weight per
        # head given in tab_ls; necessary because the LCI for chicks has the
        # unit p (pieces)
        animal_weight_kg = tab_ls.loc[tab_ls['NameEN'] == animal_type,
                                'AM: head2kg'].values[0]
        sp_ls_sum = dict({sp_ls_var:sum(ls_impo_kg)/animal_weight_kg})
    else:
        sp_ls_sum = dict({sp_ls_var:sum(ls_impo_kg)})


# %% map the imported feedstuffs to the corresponding SP_mapping_variable =====

# load table for feedstuff
tab_feed = pd.DataFrame(data=js.loads(inp.tab_feed)['data'],
                        columns=js.loads(inp.tab_feed)['columns'],
                        index=js.loads(inp.tab_feed)['index']
                        )
tab_feed_part = tab_feed[["NameEN", "SP_mapping_variable", "SP_mapping", "SP_mapping_conv_fact",
                          "SP_2nd_mapping_variable", "SP_2nd_mapping", "SP_2nd_mapping_conv_fact", "transport_distance_level"]]
# load the roughage and supplement feed used
ls_feed_r = pd.DataFrame(inp.get_events('ls_feedstuff_r'))
ls_feed_s = pd.DataFrame(inp.get_events('ls_feedstuff_s'))
ls_feed_s.columns = ls_feed_s.columns = ['feed_type' if x=='ls_01_sufe_type' else x for x in ls_feed_s.columns]
ls_feed_r.columns = ls_feed_r.columns = ['feed_type' if x=='ls_01_rofe_type' else x for x in ls_feed_r.columns]
ls_feed_s.columns = ls_feed_s.columns = ['feed_amount' if x=='ls_02_amfs_kg' else x for x in ls_feed_s.columns]
ls_feed_r.columns = ls_feed_r.columns = ['feed_amount' if x=='ls_02_amts_kg' else x for x in ls_feed_r.columns]
ls_feed_tot = pd.concat([ls_feed_r, ls_feed_s])
if ls_feed_tot.empty == False:
    # calculate the imported amounts of feed. Only imported feed has to be
    # mapped to LCIs. Feed produced directly on the farm is included in the
    # model calculations at the crop and field level.
    ls_feed_tot["amount_impo_kg"] = ls_feed_tot["feed_amount"]*ls_feed_tot["ls_03_frac_impo"]
    
    # map feed amounts to the SP_mapping_variable
    sp_feed = pd.merge(ls_feed_tot,tab_feed_part, how="inner", left_on="feed_type", right_on="NameEN")
    sp_feed["amount_kg_conv"] = sp_feed["amount_impo_kg"]*sp_feed["SP_mapping_conv_fact"]
    sp_feed_1st_sum = sp_feed.groupby("SP_mapping_variable")["amount_kg_conv"].agg('sum')
    sp_feed["amount_kg_2nd_conv"] = sp_feed["amount_impo_kg"]*sp_feed["SP_2nd_mapping_conv_fact"]
    sp_feed_2nd_sum = sp_feed.groupby("SP_2nd_mapping_variable")["amount_kg_2nd_conv"].agg('sum')
    sp_feed_sum = pd.concat([sp_feed_1st_sum, sp_feed_2nd_sum])
    
    # mapping of feedstuff, processing:
    if 'ls_04_sufe_proc' in ls_feed_tot.columns:
        # replace the values from ls_04_sufe_proc with the corresponding
        # SP_mapping_variable. When there is no processing, there is no LCI to map.
        proc_mapping_dict = {'001_no_processing': np.nan,
                             '002_sufe_proc_expanding': 'sp_feed_proc_exp_kg', 
                             '003_sufe_proc_no_expanding': 'sp_feed_proc_noexp_kg'}
        sp_feed['ls_04_sufe_proc'] = sp_feed['ls_04_sufe_proc'].replace(proc_mapping_dict)
        sp_feed_processing = sp_feed.groupby("ls_04_sufe_proc")["amount_kg_conv"].agg('sum')
        sp_feed_sum = pd.concat([sp_feed_sum, sp_feed_processing])


# %% mapping calculations for machine usage per livestock =====================

# get the number of usages for each machine used in the current animal group

# load machine combinations present on the farm
maco_list = inp.get_events('treatment_maco_event')
# get livestock type of the current animal group
ls_type = ctx.livestock.livestock_definition_name
mc_dict = pd.DataFrame(maco_list)

# machine combinations used in the current animal group
ls_event = inp.get_events('ls_maco_feedtech')
ls_maco_list = []
for event in ls_event:
    ls_maco_list.append(event['ls_01_maco_id'])


if maco_list != []:
    # convert treatment_maco_list from machine combinations into single machines
    ls_maco_count = pd.DataFrame(pd.Series(ls_maco_list).value_counts(), columns=['count'])
    df_maco_count = pd.merge(mc_dict,ls_maco_count, how="inner", left_on="f_maco_id", right_index=True)
    df_main = df_maco_count.filter(items=['f_maco_main', 'count'])
    df_front = df_maco_count.filter(items=['f_maco_front', 'count'])
    df_back = df_maco_count.filter(items=['f_maco_back', 'count'])
    df_main.rename({'f_maco_main': 'f_mach_name'}, axis=1, inplace=True)
    df_front.rename({'f_maco_front': 'f_mach_name'}, axis=1, inplace=True)
    df_back.rename({'f_maco_back': 'f_mach_name'}, axis=1, inplace=True)
    df_mach_passages = df_main.append(df_front).append(df_back)
    # list of all machines used in the animal group with number of passages,
    # sum over duplicate machines
    ls_mach_usage = df_mach_passages.groupby("f_mach_name")["count"].agg('sum')
    
    # this resulting list is used in SALCAmapping_farm to finish the machine
    # mapping
else:
    ls_mach_usage = pd.DataFrame()


# %% mapping of transports for purchased animals and feedstuffs ===============

# If variables for transport distances do not exist or there is some error,
# the standard values are used!
try:
    tran_dist_dict = {'local': inp.f_trans_dist_local_km, 'regional': inp.f_trans_dist_regional_km, 'national': inp.f_trans_dist_national_km, 'none': 0}
except:
    tran_dist_dict = {'local': 10, 'regional': 50, 'national': 100, 'none': 0}


# transport distance level for the imported animal type:
trans_dist_level = tab_ls.loc[tab_ls['NameEN'] == animal_type,
                        'transport_distance_level'].values[0]
sp_tran_ls_tkm = sum(ls_impo_kg)/1000 * tran_dist_dict[trans_dist_level]


# transports for the imported feedstuffs:
if ls_feed_tot.empty == False:
    df_trans_feed = sp_feed.copy()
    # replace transport distance levels with their distance
    df_trans_feed["trans_dist"] = df_trans_feed["transport_distance_level"].map(tran_dist_dict)
    sp_tran_feed_tkm = sum(df_trans_feed["amount_kg_conv"]/1000 * df_trans_feed["trans_dist"])



# %% mapping of live animals and animal products as output ====================

# load the tables for exports of animal products and live animals:
tab_anpr = pd.DataFrame(data=js.loads(inp.tab_anpr)['data'],
                        columns=js.loads(inp.tab_anpr)['columns'],
                        index=js.loads(inp.tab_anpr)['index']
                        )
tab_ls_export = pd.DataFrame(data=js.loads(inp.tab_ls_export)['data'],
                        columns=js.loads(inp.tab_ls_export)['columns'],
                        index=js.loads(inp.tab_ls_export)['index']
                        )

# exported live animals
logging.info('Mapping of exported animals and products as produced outputs.')
# if an animal type is not present in the event, nothing will be mapped
ls_expo_dict = {}
for event in inp.get_events('ls_export_livestock'):
    if 'ls_03_anim_type' in event.keys():
        if event['ls_03_anim_type'] != '':
            if event['ls_03_anim_type'] in ls_expo_dict.keys():
                # In case of multiple events with the same animal type
                ls_expo_dict[event['ls_03_anim_type']] += event['ls_02_expo_kg']
            else:
                ls_expo_dict[event['ls_03_anim_type']] = event['ls_02_expo_kg']
        else:
            w.warn('No animal type has been given in the event "ls_export_livestock". Export could not be mapped!')
            w.warn('Event:')
            w.warn(js.dumps(event, indent=2))
            stderr.flush()
    else:
        w.warn('The event "ls_export_livestock" has not yet been updated and is missing the variable "ls_03_anim_type". Export could not be mapped!')
        w.warn('Event:')
        w.warn(js.dumps(event, indent=2))
        stderr.flush()

animal_type_detail = ls_expo_dict.keys()

# exported animal products
ls_anpr_expo_dict = {}
for variable in inp.get_events('ls_export_animal_p'):
    if variable['ls_01_anpr_vari'] in ls_anpr_expo_dict.keys():
        # In case when there are multiple events from the same animal product
        ls_anpr_expo_dict[variable['ls_01_anpr_vari']] += variable['ls_02_anpr_kg']
    else:
        ls_anpr_expo_dict[variable['ls_01_anpr_vari']] = variable['ls_02_anpr_kg']
product_type = ls_anpr_expo_dict.keys()

# get the SP_mapping variables:
ls_mapping_vars = tab_ls_export.loc[tab_ls_export["NameEN"].isin(animal_type_detail),['NameEN','SP_mapping_variable']]
anpr_mapping_vars = tab_anpr.loc[tab_anpr["NameEN"].isin(product_type),['NameEN','SP_mapping_variable']]

# create the mapping dict:
sp_anim_kglw_sum = {ls_mapping_vars.loc[ls_mapping_vars["NameEN"]==key,'SP_mapping_variable'].item(): ls_expo_dict[key] for key in ls_expo_dict}
sp_anpr_sum = {anpr_mapping_vars.loc[anpr_mapping_vars["NameEN"]==key,'SP_mapping_variable'].item(): ls_anpr_expo_dict[key] for key in ls_anpr_expo_dict}


# %% output ===================================================================

# set the variables in the list inside the output object
# imported animals
if len(ls_impo_kg)>0:
    out.set_many(sp_ls_sum)
    out.set_many(pd.Series({'sp_tran_ls_tkm': sp_tran_ls_tkm}))  # transports of imported animals
else:
    logging.info('No imported animals present for mapping to LCIs.')

# imported feed
if ls_feed_tot.empty == False:
    out.set_many(sp_feed_sum)
    out.set_many(pd.Series({'sp_tran_feed_tkm': sp_tran_feed_tkm}))  # transports of imported feed
else:
    logging.info('No imported feed present for mapping to LCIs.')

# machines list with usage numbers for current livestock for SALCAmapping_farm
if ls_mach_usage.empty == False: 
    out.ls_mach_usage = ls_mach_usage.to_json()
    out.ls_map_type = ls_type
    logging.debug('livestock type: %s', ls_type)
    logging.debug('last item in machinelist: %s', ls_mach_usage.keys()[-1])
else:
    # save empty output too to circumvent an error in SALCAmapping_farm.py
    out.ls_mach_usage = js.dumps({})
    out.ls_map_type = ls_type
    logging.info('No (feeding) machinery on livestock level present for mapping to LCIs.')

# output products (animals & animal products):
if len(sp_anim_kglw_sum) != 0: 
    out.set_many(sp_anim_kglw_sum)
else:
    logging.info('No exported animals mapped as outputs for mapping to LCIs.')
if len(sp_anpr_sum) != 0: 
    out.set_many(sp_anpr_sum)
else:
    logging.info('No exported animal products mapped as outputs for mapping to LCIs.')


# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)