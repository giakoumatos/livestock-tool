# -*- coding: utf-8 -*-
"""
File name: SALCAmapping_ppp.py
Created on Fri Jun 11 14:02:42 2021

Author: Agroscope, "Life Cycle Assessment" Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script maps pesticide inputs and emissions based on the applied
    active ingredients according to the OLCApest model.

Calculation level:
    Crop

Related scripts: 
    SALCAprep_crop.py, SALCAtables.py

"""

# %% import modules and starting sequence ======================================
import json as js
import datetime as dt
import logging
from importlib import reload
from typing import Any, List, Dict

import pandas as pd

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(
    format = "%(message)s",
    level = logging.DEBUG) # can be logging.DEBUG or logging.INFO

start = dt.datetime.now(tz = None)

module_name: str = "SALCAmapping_ppp"
logging.info("")
logging.info(f"Start {module_name}")
logging.info(f"Starting time: {start}")
logging.info("")

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define functions ==========================================================
def read_table(filename: str,
               sep: str = ";",
               skip_header_lines: int = 6,  # start at line 7, i.e. skip 6 lines (header)
               encoding: str = "utf-8-sig"
               ) -> pd.DataFrame:
    """
    Reads a table as a pandas DataFrame

    Parameters
    ----------
    filename : str
        Filename to read.
    
    sep : str, optional
        Separator that is used in the original table. The default is ";".
    
    skip_header_lines : int, optional
        The amount of lines to be skipped when reading the table.
        The default is 6.
    
    encoding : str, optional
        The encoding that the table uses. The default is "utf-8-sig".

    Returns
    -------
    df : pd.DataFrame
        Return the loaded table as a pandas DataFrame.

    """
    df: pd.DataFrame = pd.read_csv(
        filename,
        sep = sep,
        header = skip_header_lines,
        encoding = encoding
        ).dropna(how = 'all')  # skip blank lines
    return df

# %% input =====================================================================
c_crop_type: str = ctx.crop.crop_definition_name
c_salcaprep: Dict[str, Any] = js.loads(inp.c_salcaprep)  # treatment input data

# read ppp table
tab_ppp: pd.DataFrame = pd.DataFrame(
    data = js.loads(inp.tab_ppp)["data"],
    columns = js.loads(inp.tab_ppp)["columns"],
    index = js.loads(inp.tab_ppp)["index"]
)

# select and reorder columns
tab_ppp_part: pd.DataFrame = tab_ppp[
    ["NameEN", "SP_mapping_variable", 
     "SP_emission_variable", "SP_mapping",
     "SP_mapping_conv_fact", "SP_emission_conv_fact",
     "OLCA-Pest_type","HM_mapping"]
]

# read crop table
tab_crops: pd.DataFrame = pd.DataFrame(
    data = js.loads(inp.tab_crops)["data"],
    columns = js.loads(inp.tab_crops)["columns"],
    index=js.loads(inp.tab_crops)["index"]
)

tab_crops_part: pd.DataFrame = tab_crops[["NameEN","OLCA-Pest crop type"]]

# get OLCA Pest Crop Type from Crop Table
olca_pest_crop_type: str = tab_crops_part.loc[
    tab_crops_part["NameEN"] == c_crop_type
].values[0][1]

# read table OLCApest_BufferRes
ppp_OLCApest: pd.DataFrame = read_table("tabOLCApest_BufferRes.csv")
ppp_OLCApest_part: pd.DataFrame = ppp_OLCApest.loc[
    ppp_OLCApest["Crop"] == olca_pest_crop_type
]

# %% mapping calculations plant protection products ============================
# combine the lists per treatment to single lists for all treatments
c_ppp_variable: List[List[str]] = c_salcaprep["tr_ppp"]["variable"]
c_ppp_variable: List[str] = [
    item
    for sublist in c_ppp_variable
    for item in sublist
    if item != ""  # remove empty variables
]

c_ppp_amount: List[List[float]] = c_salcaprep["tr_ppp"]["amount_kg"]
c_ppp_amount: List[float] = [
    item
    for sublist in c_ppp_amount
    for item in sublist
    if item is not None  # remove None
]

# PPP applied - collect in Dataframe:
ppp: pd.DataFrame = pd.DataFrame(c_salcaprep["tr_ppp"])
ppp_appl: pd.DataFrame = ppp.filter(items = ["variable", "amount_kg"])

ppp_appl: pd.DataFrame = pd.DataFrame(
    {"variable": c_ppp_variable,
     "amount_kg": c_ppp_amount},
    columns = ["variable", "amount_kg"])

sp_ppp: pd.DataFrame = pd.merge(
    ppp_appl,
    tab_ppp_part,
    how = "inner",
    left_on = "variable",
    right_on = "NameEN"
)
sp_ppp_final: pd.DataFrame = pd.merge(
    sp_ppp,
    ppp_OLCApest_part,
    how = "inner",
    left_on = "OLCA-Pest_type",
    right_on = "Pest_class"
)

# Create SimaPro emission mapping variables
SP_evar: pd.Series = sp_ppp_final["SP_emission_variable"]
col_SP_evar_soil_agri: str = "SP_emission_variable_soil_agri"
col_SP_evar_soil_forest: str = "SP_emission_variable_soil_forest"
col_SP_evar_water: str = "SP_emission_variable_water"
col_SP_evar_air: str = "SP_emission_variable_air"
col_SP_evar_crop: str = "SP_emission_variable_crop"


sp_ppp_final[col_SP_evar_soil_agri] = SP_evar + "_soil_agri"
sp_ppp_final[col_SP_evar_soil_forest] = SP_evar + "_soil_forest"
sp_ppp_final[col_SP_evar_water] = SP_evar + "_water"
sp_ppp_final[col_SP_evar_air] = SP_evar + "_air"
sp_ppp_final[col_SP_evar_crop] = SP_evar + "_crop"

# Multiply amounts with the conversion factor
amount: pd.Series = sp_ppp_final["amount_kg"]
conv: pd.Series = sp_ppp_final["SP_mapping_conv_fact"]

sp_ppp_final["amount_kg_prod"] = amount * conv
sp_ppp_final["amount_kg_soil_agri"] = amount * conv * sp_ppp_final["soil, agricultural"]
sp_ppp_final["amount_kg_water"] = amount * conv * sp_ppp_final["water, surface/river"]
sp_ppp_final["amount_kg_soil_forest"] = amount * conv * sp_ppp_final["soil, natural/forest"]
sp_ppp_final["amount_kg_air"] = amount * conv * sp_ppp_final["air, low population density"]
sp_ppp_final["amount_kg_crop"] = amount * conv * sp_ppp_final["crop (compartment)"]

# for pesticides containing copper and zinc, emissions to soil_agri and
# to crop must be set to zero since they are calculated already in
# SALCAheavymetal_crop (in order to prevent a double counting)
df_doublecount: pd.DataFrame = sp_ppp_final.loc[
    sp_ppp_final["HM_mapping"] != "zero_HM",
    ["NameEN","amount_kg_soil_agri","amount_kg_crop"]
]

if df_doublecount.empty == False:
    logging.info("The following copper or zinc pesticides had their amounts " \
                 "set to zero, since they are considered in SALCAheavymetal:")
    for index, row in df_doublecount.iterrows():
        logging.info(row)
    logging.info('')

sp_ppp_final.loc[
    sp_ppp_final["HM_mapping"] != "zero_HM",
    ["amount_kg_soil_agri","amount_kg_crop"]
] = 0

# sum per ppp mapping variable
sp_ppp_sum = sp_ppp_final.groupby("SP_mapping_variable")["amount_kg_prod"].agg("sum")
sp_ppp_e_soil_sum = sp_ppp_final.groupby(col_SP_evar_soil_agri)["amount_kg_soil_agri"].agg("sum")
sp_ppp_e_crop_sum = sp_ppp_final.groupby(col_SP_evar_crop)["amount_kg_crop"].agg("sum")
sp_ppp_e_soil_forest_sum = sp_ppp_final.groupby(col_SP_evar_soil_forest)["amount_kg_soil_forest"].agg("sum")
sp_ppp_e_water_sum = sp_ppp_final.groupby(col_SP_evar_water)["amount_kg_water"].agg("sum")
sp_ppp_e_air_sum = sp_ppp_final.groupby(col_SP_evar_air)["amount_kg_air"].agg("sum")

# exclude zero emissions from the mapping (for the copper and zinc correction)
sp_ppp_e_soil_sum = sp_ppp_e_soil_sum.loc[sp_ppp_e_soil_sum != 0]
sp_ppp_e_crop_sum = sp_ppp_e_crop_sum.loc[sp_ppp_e_crop_sum != 0]

# %% output ====================================================================

# plant protection products
if not sp_ppp_sum.empty: 
    out.set_many(sp_ppp_sum)
else:
    logging.info("No plant protection products present for SimaPro mapping.")
    logging.info('')

if not sp_ppp_e_soil_sum.empty: 
    out.set_many(sp_ppp_e_soil_sum)

if not sp_ppp_e_water_sum.empty: 
    out.set_many(sp_ppp_e_water_sum)

if not sp_ppp_e_air_sum.empty: 
    out.set_many(sp_ppp_e_air_sum)
    
if not sp_ppp_e_soil_forest_sum.empty: 
    out.set_many(sp_ppp_e_soil_forest_sum)

if not sp_ppp_e_crop_sum.empty: 
    out.set_many(sp_ppp_e_crop_sum)

# %% end sequence ==============================================================

end = dt.datetime.now(tz = None)
logging.info(f"End {module_name}")
logging.info(f"End time: {end}")

diff: dt.timedelta = end - start
logging.info(f"Time delta: {diff}")
