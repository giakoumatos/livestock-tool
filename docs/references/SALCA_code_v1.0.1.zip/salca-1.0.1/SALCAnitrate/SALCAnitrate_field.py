# -*- coding: utf-8 -*-
"""
SALCAnitrate_field
Created on Tue Aug 20 09:01:02 2019

File name: SALCAnitrate_field.py
Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script calculates NO3 emissions from leaching to ground water and runoff
    to surface water and includes related N2O emissions.

Calculation level:
    Field

Related scripts: -
    SALCAnitrate_field does not provide any further inputs to other scripts.
"""

# import modules ==============================================================

import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAnitrate field'
logging.info('')
logging.info('Start: %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('field')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define functions =========================================================

def c_month(in_month):
    ''' function to assign a corrected value to the month entered into the
    function. This covers the possibility that the months of cultivation span
    over two years.
    Months without N mineralisation are skipped.
    Months of the previous year are represented by months 1 - 12.
    Months of the current year are represented by the months 13-24. Winter
    months (dec, jan, feb) all get the value of february (2 for the winter
    in the begining of the first year or 14 for the winter between years 1
    and 2), except for december of the second year.
    Input: array of months
    Output: array of corrected months
    '''
    # import the numpy module again for the SALCAfuture environment
    import numpy as np
    # generate an array with zeros the length of the input
    m_month = list(np.zeros(len(in_month)))
    # for each month in the input list
    for i in range(len(in_month)):
        # returns 0 for no event
        # 1-12 for months of the previous year
        # 13-24 for months of the current year
        # months dec and jan are returned as february of the current year
        if in_month[i] == 1:
            m_month[i] = 2
        elif (in_month[i] == 12) or (in_month[i] == 13):
            m_month[i] = 14
        else:
            m_month[i] = in_month[i]
    return m_month


def corr_plowing(mon, m_til_long, c_meadow_til_long, m_til_short,
                       c_meadow_til_short, m_grain_til, c_grain_leg_til,
                       m_catch_crop_til, c_catch_crop_til,
                       m_incorp_sugarbeet, c_incorp_sugarbeet_leaf):
    ''' function to calculate the correction for tillage for a month based
    on the events of tillage on the field.
    mon: months from 1 to 24
    returns 1 for jan, feb, dec
    Corrections differ between year 1 and year 2
    '''
    def prev_year(m):
        # subroutine. Returns 1 if the entered month is < 12 (previous year)
        if m < 12:
            return 1
        else:
            return 0

    # standard correction factor = 1
    c = 1
    if mon in [1, 2, 12, 13, 14, 24]:  # no correction for winter months without N mineralisation
        return c
    elif (mon >= 3) and (mon < 12):  # for non-winter months of the first year
        # for each type of treatment, check if a treatment was applied (>0)
        # and if the current month is after the treatment (effects of the
        # treatment are counted only after the treatment occurred).
        # Effects of the treatment only last for a given number of months,
        # specified per treatment.
        # if the requirements are met, the correction factor of the treatment
        # (that was previously weighted by the area fraction of its contri-
        # bution) is added to the returned correction factor.
        if (m_til_long > 0) and (m_til_long < mon) \
                and (mon-m_til_long <= tab_pars['Value']['dur_incr_meadow_til_long']):
            c += c_meadow_til_long
        if (m_til_short > 0) and (m_til_short < mon) \
                and (mon-m_til_short <= tab_pars['Value']['dur_incr_meadow_til_short']):
            c += c_meadow_til_short
        if (m_grain_til > 0) and (m_grain_til < mon) \
                and (mon-m_grain_til <= tab_pars['Value']['dur_incr_grain_leg_til']):
            c += c_grain_leg_til
        if (m_catch_crop_til > 0) and (m_catch_crop_til < mon) \
                and (mon-m_catch_crop_til <= tab_pars['Value']['dur_incr_catch_crop_til']):
            c += c_catch_crop_til
        if (m_incorp_sugarbeet > 0) and (m_incorp_sugarbeet < mon) \
                and (mon-m_incorp_sugarbeet <= tab_pars['Value']['dur_incr_sugarbeet_til']):
            c += c_incorp_sugarbeet_leaf
        return c
    elif (mon >= 15) and (mon < 24):  # non-winter months of the second year
        # Similar routine as for the first year.
        # Additionally, the treatments of the previous year can have a contri-
        # bution and the winter months (dec, jan, feb) are ignored in the
        # number of months, the effects of the treatment lasts.
        if (m_til_long > 0) and (m_til_long < mon) \
                and (mon-m_til_long-prev_year(m_til_long)*3
                     <= tab_pars['Value']['dur_incr_meadow_til_long']):
            c += c_meadow_til_long
        if (m_til_short > 0) and (m_til_short < mon) \
                and (mon-m_til_short-prev_year(m_til_short)*3
                     <= tab_pars['Value']['dur_incr_meadow_til_short']):
            c += c_meadow_til_short
        if (m_grain_til > 0) and (m_grain_til < mon) \
                and (mon-m_grain_til-prev_year(m_grain_til)*3
                     <= tab_pars['Value']['dur_incr_grain_leg_til']):
            c += c_grain_leg_til
        if (m_catch_crop_til > 0) and (m_catch_crop_til < mon) \
                and (mon-m_catch_crop_til-prev_year(m_catch_crop_til)*3
                     <= tab_pars['Value']['dur_incr_catch_crop_til']):
            c += c_catch_crop_til
        if (m_incorp_sugarbeet > 0) and (m_incorp_sugarbeet < mon) \
                and (mon-m_incorp_sugarbeet-prev_year(m_incorp_sugarbeet)*3
                     <= tab_pars['Value']['dur_incr_sugarbeet_til']):
            c += c_incorp_sugarbeet_leaf
        return c

def read_table(path):  # read CSV file
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    # in all tables start at line 7, i.e. skip 6 lines (header)
    return tab

def read_pars(path):  # read CSV file
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    # for parameters start at line 1
    tab = tab.set_index('NameEN')
    return tab

def sumproduct(list1, list2, year):
    # year = 0 for previous year
    # year = 1 for current year (year of harvest)
    # the sums of the cumulated months have to be calculated separately for both years
    sumproduct = 0.0
    offset = year*12
    for i in range(0+offset,12+offset):
        sumproduct += list1[i]*list2[i]
    return sumproduct

def convert_dates(c_salcaprep_dict):
    ''' convert the dates in c_salcaprep from string to date.datetime
    Can later be imported from the SALCAfuture function library.
    '''
    import datetime as dt
    # list of the different treatment types
    treatments = ['tr_fert', 'tr_harv', 'tr_manure_l', 'tr_manure_s',
                  'tr_soil', 'tr_sowi']
    for tr in treatments:  # iterate through treatment types
        # iterate through the different treatments per type
        for i, date in enumerate(c_salcaprep_dict[tr]['date_dt']):
            # convert the date from string to date.datetime
            c_salcaprep_dict[tr]['date_dt'][i] = dt.datetime.strptime(
                c_salcaprep_dict[tr]['date_dt'][i], '%Y-%m-%d')
    # return the dictionary
    return c_salcaprep_dict


def correction_month(date, harv_date):
    '''
    returns 1 if both dates are in the same year.
    returns 0 if the year differ.
    '''
    if date.year == harv_date.year:
        # event and harvest in the same year
        c_month = 1

    else:
        # event in the previous year.
        c_month = 0
    return c_month

# %% nitrate preparation ======================================================

logging.info("Start of preparation part: %s", dt.datetime.now(tz=None))

# === load tables ===
# crop data from SALCAtables.
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index'])
# fert data from SALCAtables.
tab_fert = pd.DataFrame(data=js.loads(inp.tab_fert)['data'],
                         columns=js.loads(inp.tab_fert)['columns'],
                         index=js.loads(inp.tab_fert)['index'])
# organic manure data from SALCAtables.
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                         columns=js.loads(inp.tab_manu)['columns'],
                         index=js.loads(inp.tab_manu)['index'])

# === Imported data - input from database ===
# list of python names of the crops on the field
in_crop_code = []
# list of crop_ids of the crops on the field
in_crop_id = []
field = ctx.field[2]
for crop in sorted(field.values()):
    in_crop_code.append(crop[2])
    in_crop_id.append(crop[0])

# area of each crop (array) [ha]
in_area_crop = inp.c_ca_ha
# python name of location of the farm. Valley, hill or mountain incl. 00X prefix
# extracts the location from the python name, removes the prefix
# e.g. 001 Tal --> 1
in_region = inp.f_region[2]  # extract the 3. letter (position 2)

# area of the field [ha]
in_area_field = inp.fi_fia_ha

# depth of the soil on the current field [cm]
in_soil_depth = inp.fi_soil_depth_cm
# clay content on the current field [0,1]
in_clay = inp.fi_clay_frac
# humus content on the current field [%/100]
in_humus = inp.fi_humus_perc

# array of mean monthly precipitation from October (first entry) to March (sixth
# entry) [mm]
# derived from salcaprep_farm
f_salcaprep_string = inp.f_salcaprep
# convert string to dictionary
f_salcaprep = js.loads(f_salcaprep_string)
# extract the array of monthly precipitation [mm]
monthly_prec = f_salcaprep['precipitation']
# extract precipitation values october (index 9) to march (index 2)
in_prec = monthly_prec[9:12]+monthly_prec[0:3]
# mean annual precipitation [mm]
in_prec_annual = f_salcaprep['annual_precipitation']
# reference winter precipitation:
# climatological mean winter precipitation [mm], Switzerland
# mean precipitation 1981-2010, MeteoSchweiz, all stations <700m,
# except TI and inner Alpine valleys
in_prec_winter = 490
# fraction of drainage on the field [%]
in_drainage = inp.fi_drai_perc
# Mean fertilizing livestock units (LU) on the farm [DGVE/ha]
in_organic_fert = inp.f_quan_LU
# array for each crop whether the meadow is older than 9 months at the start
# of the evaluation, boolean (0 or 1)
in_meadow9 = inp.c_gras9_bool
# loss rate of TAN, from SALCAfield_field [%/100]
# used to correct the N inputs
in_TAN_loss = inp.fi_TAN_loss_frac

# N-content in manure
f_lman_kgNpm3 = inp.f_lman_kgNpm3
f_sman_kgNpt = inp.f_sman_kgNpt

# %% derive information from treatments on the field ==========================

# load salcaprep on crop level as a list of strings
c_salcaprep = inp.c_salcaprep

# set up empty lists, where the resulting length is not predetermined.
in_intense_til = []
id_intense_til = []

# number of crops on the field
n_crops = len(in_crop_code)
# setup lists of zeros for lists with exactly one entry per crop
in_harv = list(np.zeros(n_crops))
in_sowi_date = list(np.zeros(n_crops))
in_harv_date = list(np.zeros(n_crops))
in_harv_date_prev = list(np.zeros(n_crops))

# set up lists with one zero per crop in the field for intense tillage events.
# zero means that no intense tillage event occured for that crop.
# in the following, a number indicating the month of the treatment indicates
# intense tillage for a crop on the field. Numbers 13 - 24 represent months of
# the year, in which the crop was harvested. Numbers 1 - 12 represent months
# of the year before.
in_meadow_til_short = list(np.zeros(n_crops))  # meadow, pasture <= 9 months
in_meadow_til_long = list(np.zeros(n_crops))  # meadow, pasture > 9 months
in_grain_leg_til = list(np.zeros(n_crops))  # grain legumes
in_catch_crop_til = list(np.zeros(n_crops))  # catch crops
in_incorp_sugarbeet = list(np.zeros(n_crops))  # incorporation sugarbeet leaves
# repeat for the area fraction. There, not the month of the tillage is
# indicated but the fraction of the field area affected
af_meadow_til_long = list(np.zeros(n_crops))
af_meadow_til_short = list(np.zeros(n_crops))
af_grain_leg_til = list(np.zeros(n_crops))
af_catch_crop_til = list(np.zeros(n_crops))
af_incorp_sugarbeet = list(np.zeros(n_crops))
# setup for the list of N fertilisation
in_N_fert = list(np.zeros(n_crops))

for i, crop in enumerate(in_crop_code):
    # crop is a string of the python-name of the current crop, i the index
    # load the dictionary from the string in c_salcaprep[i]
    c_salcaprep_dict = js.loads(c_salcaprep[i])
    # take the sowing date, if not defined the start date
    if c_salcaprep_dict['tr_sowi']['date_dt'] == []:  # no sowing date
        in_sowi_date[i] = c_salcaprep_dict['c_start']
    else:
        in_sowi_date[i] = c_salcaprep_dict['tr_sowi']['date_dt'][-1]

    in_harv_date_prev[i] = c_salcaprep_dict['c_prha_date']
    in_harv_date[i] = c_salcaprep_dict['c_end']
    in_harv[i] = np.sum(c_salcaprep_dict['tr_harv']['amount_kg'])

    # convert dates to datetime format
    c_salcaprep_dict = convert_dates(c_salcaprep_dict)
    if c_salcaprep_dict['tr_harv']['date_dt'] == []:  # no harvest date
        harv_date = c_salcaprep_dict['c_end']
    else:
        harv_date = c_salcaprep_dict['tr_harv']['date_dt'][-1]

    # get type of precrop influencing N mineralisation
    precrop_type = inp.c_prcr_type[i]

    # incorporation of precrops increasing N mineralisation:
    # get the month of the earliest soil or sowing treatment.
    # harvest residues are incorporated at that moment.
    dates = c_salcaprep_dict['tr_soil']['date_dt'] + c_salcaprep_dict['tr_sowi']['date_dt']
    if dates != []: 
        # meaning there is no incorporation of precrops because no tr_soil and 
        # no tr_sowi took place in the evaluation period.
        date = min(dates)
        mon = date.month + (12*correction_month(date, harv_date))
        if precrop_type == '002_meadow_long':  # pasture > 9 months
            in_meadow_til_long[i] = mon
            af_meadow_til_long[i] = in_area_crop[i] / in_area_field
        elif precrop_type == '003_meadow_short':  # pasture <= 9 months
            in_meadow_til_short[i] = mon
            af_meadow_til_short[i] = in_area_crop[i] / in_area_field
        elif precrop_type == '004_grain_leg':  # grain legumes
            in_grain_leg_til[i] = mon
            af_grain_leg_til[i] = in_area_crop[i] / in_area_field
        elif precrop_type == '005_catch_crop_hardy':  # catch crops
            in_catch_crop_til[i] = mon
            af_catch_crop_til[i] = in_area_crop[i] / in_area_field
        elif precrop_type == '007_sugarbeet_and_leaves':  # incorporated sugar beet leaves
            in_incorp_sugarbeet[i] = mon
            af_incorp_sugarbeet[i] = in_area_crop[i] / in_area_field

    # intensive tillage increases N mineralisation in the month of occurrence
    # get the month when intensive tillage occurred (can be soil_treatment,
    # sowing, or harvest of potatoes or beets)
    for index, value in enumerate(c_salcaprep_dict['tr_soil']['intense_trea']):
        if value == True:  # for intensive soil treatment
            # date of the treatment
            date = c_salcaprep_dict['tr_soil']['date_dt'][index]
            mon = date.month + 12*correction_month(date, harv_date)
            # append the month of intense tillage
            in_intense_til.append(mon)
            # append the ID of the crop
            id_intense_til.append(in_crop_id[i])
    for index, value in enumerate(c_salcaprep_dict['tr_sowi']['intense_trea']):
        if value == True:  # for intensive soil treatment
            # date of the treatment
            date = c_salcaprep_dict['tr_sowi']['date_dt'][index]
            mon = date.month + 12*correction_month(date, harv_date)
            # append the month of intense tillage
            in_intense_til.append(mon)
            # append the ID of the crop
            id_intense_til.append(in_crop_id[i])
    for index, value in enumerate(c_salcaprep_dict['tr_harv']['intense_trea']):
        if value == True:  # for intensive soil treatment
            # date of the treatment
            date = c_salcaprep_dict['tr_harv']['date_dt'][index]
            mon = date.month + 12*correction_month(date, harv_date)
            # append the month of intense tillage
            in_intense_til.append(mon)
            # append the ID of the crop
            id_intense_til.append(in_crop_id[i])
    logging.info("month of intense tillage:")
    logging.info(in_intense_til)
    logging.info("crop_id_intense_til:")
    logging.info(id_intense_til)
    logging.info('')
    
    # store applied N fertilisation in the correct month
    in_N_fert[i] = list(np.zeros(24))
    # kg N from mineral fertiliser
    for index, variable in enumerate(c_salcaprep_dict['tr_fert']['variable']):
        amount_n = c_salcaprep_dict['tr_fert']['amount_kg'][index]
        date = c_salcaprep_dict['tr_fert']['date_dt'][index]
        mon = date.month + 12*correction_month(date, harv_date)
        # remove number from variable
        variable = ' '.join(variable.split(' ')[1:])
        if variable.startswith('N'):
            mon_corrected = mon
            in_N_fert[i][mon_corrected-1] += amount_n
    # kg N from liquid manure (farm manure & imported organic fertilisers)
    for index, variable in enumerate(c_salcaprep_dict['tr_manure_l']['variable']):
        amount = c_salcaprep_dict['tr_manure_l']['amount_m3'][index]
        date = c_salcaprep_dict['tr_manure_l']['date_dt'][index]
        mon_corrected = date.month + 12*correction_month(date, harv_date)
        if variable == 'liquid_farm_manure':
            in_N_fert[i][mon_corrected-1] += amount * f_lman_kgNpm3
        else:
            # N-content of other organic fertiliser (liquid) comes from tab_manu
            n_cont_lman = tab_manu['AM: N after storage'][tab_manu['NameEN']
                                                  == variable].values[0]
            in_N_fert[i][mon_corrected-1] += amount * n_cont_lman
    # kg N from solid manure (farm manure & imported organic fertilisers)
    for index, variable in enumerate(c_salcaprep_dict['tr_manure_s']['variable']):
        amount = c_salcaprep_dict['tr_manure_s']['amount_t'][index]
        date = c_salcaprep_dict['tr_manure_s']['date_dt'][index]
        mon_corrected = date.month + 12*correction_month(date, harv_date)
        if variable == 'solid_farm_manure':
            in_N_fert[i][mon_corrected-1] += amount * f_sman_kgNpt
        else:
            # N-content of other organic fertiliser (solid) comes from tab_manu
            n_cont_sman = tab_manu['AM: N after storage'][tab_manu['NameEN']
                                                  == variable].values[0]
            in_N_fert[i][mon_corrected-1] += amount * n_cont_sman


# %% Output of preparation ====================================================

prep_nitrate = {
    'in_crop_code': in_crop_code,
    'in_crop_id': in_crop_id,
    'in_area_crop': in_area_crop,
    'in_region': in_region,
    'in_harv': in_harv,
    'in_organic_fert': in_organic_fert,
    'in_harv_date_prev': in_harv_date_prev,
    'in_sowi_date': in_sowi_date,
    'in_harv_date': in_harv_date,
    'in_soil_depth': in_soil_depth,
    'in_clay': in_clay,
    'in_humus': in_humus,
    'in_prec': in_prec,
    'in_prec_annual': in_prec_annual,
    'in_prec_winter': in_prec_winter,
    'in_drainage': in_drainage,
    'in_meadow9': in_meadow9,
    'in_meadow_til_long': in_meadow_til_long,
    'in_meadow_til_short': in_meadow_til_short,
    'in_grain_leg_til': in_grain_leg_til,
    'in_catch_crop_til': in_catch_crop_til,
    'in_incorp_sugarbeet': in_incorp_sugarbeet,
    'af_meadow_til_long': af_meadow_til_long,
    'af_meadow_til_short': af_meadow_til_short,
    'af_grain_leg_til': af_grain_leg_til,
    'af_catch_crop_til': af_catch_crop_til,
    'af_incorp_sugarbeet': af_incorp_sugarbeet,
    'in_intense_til': in_intense_til,
    'id_intense_til': id_intense_til,
    'in_N_fert': in_N_fert,
    'in_TAN_loss': in_TAN_loss
}
logging.info("End of preparation part: %s", dt.datetime.now(tz=None))

# %% read data from prep modules ==============================================

logging.info("Start of calculation part: %s", dt.datetime.now(tz=None))
# table to map codes for N-loss from the crops table to the corresponding label
tab_codes_to_labels = {
    0: 'others',
    1: 'winter_cereals',
    2: 'summer_cereals',
    3: 'mais_soy',
    4: 'winter_rapeseed',
    5: 'potatoes',
    6: 'beet',
    7: 'winter_bean',
    8: 'summer_bean',
    9: 'sunflowers',
    10: 'carrot',
    11: 'cabage',
    12: 'catch_crops',
    13: 'templey_april',
    14: 'templey_may',
    15: 'templey_aug',
    16: 'pasture_ext',
    17: 'pasture_int',
    18: 'apple',
    19: 'Miscanthus1',  # 1st year
    20: 'Miscanthus2',  # 2nd year
    21: 'Miscanthus3+'  # 3rd and following years
}

# === Imported data from preparation modules ===
# load input data from SALCAnitrate_prep
prep_nitrate = prep_nitrate

# list of python names of the crops on the field
in_crop_code = prep_nitrate['in_crop_code']
# list of crop_ids of the crops on the field
in_crop_id = prep_nitrate['in_crop_id']
n_crops = len(in_crop_id)
# area of the crops on the field
in_area_crop = prep_nitrate['in_area_crop']
# region, location of the farm. Valley, hill or mountain. String.
in_region = prep_nitrate['in_region']
# list of amount harvested per crop [kg]
in_harv = prep_nitrate['in_harv']
# mean population of cattle on the farm [DGVE/ha]
in_organic_fert = prep_nitrate['in_organic_fert']
# list of previous harvest date for the crops on the field
in_harv_date_prev = []  # setup
for date in prep_nitrate['in_harv_date_prev']:
    # convert string to datetime format
    in_harv_date_prev.append(dt.datetime.strptime(date, '%Y-%m-%d'))
# list of sowing dates of the crops on the field
in_sowi_date = []  # setup
for date in prep_nitrate['in_sowi_date']:
    # convert string to datetime format
    in_sowi_date.append(dt.datetime.strptime(date, '%Y-%m-%d'))
# list of harvest dates of the crops on the field
in_harv_date = []  # setup
for date in prep_nitrate['in_harv_date']:
    # convert string to datetime format
    in_harv_date.append(dt.datetime.strptime(date, '%Y-%m-%d'))
# soil depth on the field [cm]
in_soil_depth = prep_nitrate['in_soil_depth']
# clay content of the soil [%/100]
in_clay = prep_nitrate['in_clay']
# humus content [%/100]
in_humus = prep_nitrate['in_humus']
# array of mean monthly precipitation for october (first entry) to march (sixth
# entry) [mm]
in_prec = prep_nitrate['in_prec']
# mean annual precipitation [mm]
in_prec_annual = prep_nitrate['in_prec_annual']
# reference winter precipitation in Zürich Reckenholz [mm]
in_prec_winter = prep_nitrate['in_prec_winter']
# fraction of drainage on the field [%]
in_drainage = prep_nitrate['in_drainage']
# array for each crop whether the meadow is older than 9 months at the start
# of the evaluation, boolean (0 or 1)
in_meadow9 = prep_nitrate['in_meadow9']
# array with one entry per crop on the field specifying the month of tillage
# of pastures older than 9 months.
in_meadow_til_long = prep_nitrate['in_meadow_til_long']
# array with one entry per crop on the field specifying the month of tillage
# of pastures younger than 9 months.
in_meadow_til_short = prep_nitrate['in_meadow_til_short']
# array with one entry per crop on the field specifying the month of tillage
# of grain legumes.
in_grain_leg_tilaf = prep_nitrate['in_grain_leg_til']
# array with one entry per crop on the field specifying the month of tillage
# of catch crops.
in_catch_crop_til = prep_nitrate['in_catch_crop_til']
# array with one entry per crop on the field specifying the month of the
# incorporation of sugarbeet leaves.
in_incorp_sugarbeet = prep_nitrate['in_incorp_sugarbeet']
# array with one entry per crop on the field specifying the area fraction []
# affected by the tillage of pastures older than 9 months.
af_meadow_til_long = prep_nitrate['af_meadow_til_long']
# array with one entry per crop on the field specifying the area fraction []
# affected by the tillage of pastures younger than 9 months.
af_meadow_til_short = prep_nitrate['af_meadow_til_short']
# array with one entry per crop on the field specifying the area fraction []
# affected by the tillage of grain legumes.
af_grain_leg_til = prep_nitrate['af_grain_leg_til']
# array with one entry per crop on the field specifying the area fraction []
# affected by the tillage of catch crops
af_catch_crop_til = prep_nitrate['af_catch_crop_til']
# array with one entry per crop on the field specifying the area fraction []
# affected by the incorporation of sugarbeet leaves.
af_incorp_sugarbeet = prep_nitrate['af_incorp_sugarbeet']
# list of crop_ids that contain intensive tillage
id_intense_til = prep_nitrate['id_intense_til']
# list of months with intensive tillage
in_intense_til = prep_nitrate['in_intense_til']
# array with entries per crop
# each entry consists of 24 values representing the amount of N applied [kg N]
# from fertilisers in the respective month for the respective crop.
in_N_fert = prep_nitrate['in_N_fert']
# loss rate of TAN, from SALCAfield_field, between 0 and 1
in_TAN_loss = prep_nitrate['in_TAN_loss']

# %% read tables from CSV files ===============================================

# table for growing degree days, runs over 2 years (730 days)
tab_gdd = read_table('GDD.csv')
# table for relative N uptake (%, values 0-100)
tab_relNUp = read_table('RelNUp.csv')
# table for fertiliser leaching [%/100]
tab_fert_leaching = read_table('Fert_leaching.csv')
# load the table with information about mineralisation. Depends on the region.
tab_min = read_table('Mineralisation'+in_region+'.csv')
# load table with cumulated months
if in_region == '3': # mountain region
    reg_code = '3'
else: # same table for valley and hill region
    reg_code = '12'
# The sum of GDD in the hill region is much closer than to the valley than
# to the mountain region
# load the table with cumulated months. Depends on the region.
# 1 = cumulated, 0 = not cumulated
tab_cum_mon = read_table('CumMonths'+reg_code+'.csv')
# parameter table
tab_pars = read_pars('SALCAnitrate_pars.csv')

# %% Calculation Part =========================================================

# === Correction factors ===

# Correction factor mineralisation for clay and humus content of the soil based on equation.
# 1 = no correction.
# This formula is an approximation of the table in the report.
humus_perc = np.min([15, in_humus*100])  # values >15% set to 15%
clay_perc = np.min([50, in_clay*100])    # values >50% set to 50%
corr_clay_humus = 1 + (humus_perc-2)*(0.04-0.001*(clay_perc-15)) \
                - (0.01*(clay_perc-15))
# Correction factor mineralisation for organic fertilisation.
# Baseline 1 livestock unit (LU), correction of 0.1 per LU. Reference: Chapter 3.3
corr_LU = 1.0+(in_organic_fert-1.0)*tab_pars['Value']['min_incr_LU']
# Correction factor leaching for soil depth. Based on Chapter 5.4.1
corr_soil_depth = np.max([0, np.min([0.35, 0.005*(100-in_soil_depth)])])+1
# Correction factor for bulk density (standard = 1350 kg/m3)
bulk_dens = inp.fi_soil_kgpm3
corr_dens = bulk_dens/1350
# extract information from harvest and sowing dates. Derive year, month, day,
# julian day of year. Occassional correction to account for previous and
# evaluated year.
# The harvest year is always the second year. Prev. crop harv. and sowing
# can be in the same or the previous year
year_prev_harv = list(np.zeros(n_crops))
mon_prev_harv  = list(np.zeros(n_crops))
day_prev_harv  = list(np.zeros(n_crops))

year_crop_sowi = list(np.zeros(n_crops))
mon_crop_sowi  = list(np.zeros(n_crops))
day_crop_sowi  = list(np.zeros(n_crops))
jul_crop_sowi  = list(np.zeros(n_crops))

year_crop_harv = list(np.zeros(n_crops))
mon_crop_harv  = list(np.zeros(n_crops))
day_crop_harv  = list(np.zeros(n_crops))
jul_crop_harv  = list(np.zeros(n_crops))

for i in range(n_crops):
    # for each crop, extract:
    # year of the harvest date
    year_crop_harv[i] = in_harv_date[i].year
    # month of the current harvest date
    mon_crop_harv[i] = in_harv_date[i].month+12
    # day of month for the harvest date
    day_crop_harv[i] = in_harv_date[i].day
    # harvest date, julian
    jul_crop_harv[i] = in_harv_date[i].timetuple().tm_yday+365

    # year of the previous harvest date
    year_prev_harv[i] = in_harv_date_prev[i].year
    # day of month for the previous harvest date
    day_prev_harv[i] = in_harv_date_prev[i].day
    # month and julian day of the previous harvest date
    if year_prev_harv[i] < year_crop_harv[i]:
        mon_prev_harv[i] = in_harv_date_prev[i].month
    else:
        mon_prev_harv[i] = in_harv_date_prev[i].month+12

    # year of the sowing date
    year_crop_sowi[i] = in_sowi_date[i].year
    # day of month for the sowing date
    day_crop_sowi[i] = in_sowi_date[i].day
    # month and julian day of the sowing date
    # correction according to differences in years
    if year_crop_sowi[i] < year_crop_harv[i]:
        mon_crop_sowi[i] = in_sowi_date[i].month
        jul_crop_sowi[i] = in_sowi_date[i].timetuple().tm_yday
    else:
        mon_crop_sowi[i] = in_sowi_date[i].month+12
        jul_crop_sowi[i] = in_sowi_date[i].timetuple().tm_yday+365

# %% dates and crop info ======================================================

n_crops = len(in_crop_code)  # Crop, could be replaced.
# to differentiate between arable crops, vegetables and apple for
# respective calculations
crop_module = list(np.zeros(n_crops))
for i, crop in enumerate(in_crop_code):
    crop_module[i] = tab_crops['Nitrate: Module'] \
                    [tab_crops['NameEN'] == crop].values[0]
# extract the code for N-loss from the crops table and assign labels
n_loss_code   = list(np.zeros(n_crops))
n_loss_labels = list(np.zeros(n_crops))
land_use_type = list(np.zeros(n_crops))
for i, crop in enumerate(in_crop_code):
    n_loss_code[i] = tab_crops['Nitrate: Code Fertilisation Loss'] \
                    [tab_crops['NameEN'] == crop].values[0]
    n_loss_labels[i] = tab_codes_to_labels[n_loss_code[i]]
# extract the code for the pasture type of the current
# crop from the crops table.
past_code = list(np.zeros(n_crops))
for i, crop in enumerate(in_crop_code):
    past_code[i] = tab_crops['Nitrate: Type Pasture'] \
                  [tab_crops['NameEN'] == crop].values[0]
    land_use_type[i] = tab_crops['land use'] \
                      [tab_crops['NameEN'] == crop].values[0]
    if land_use_type[i] == 'Temporary grassland':
        if mon_crop_sowi[i] > 0 and mon_crop_sowi[i] <= 4:  # sowing in April
            n_loss_code[i] = 13
        elif mon_crop_sowi[i] >= 5 and mon_crop_sowi[i] <= 6:  # sowing in May
            n_loss_code[i] = 14
        elif mon_crop_sowi[i] >= 7 and mon_crop_sowi[i] <= 12:  # sowing in August
            n_loss_code[i] = 15
        elif mon_crop_sowi[i] >= 13 and mon_crop_sowi[i] <= 24:  # treat like catch crop
            n_loss_code[i] = 4
        # in all other cases, leave n_loss_code unchanged

# sum of precipitation october to march [mm]
precip_oct_mar = sum(in_prec)
# measured winter precipitation compared to climatological winter
# precipitation in Zurich Reckenholz.
# factor for winter precipitation []
f_winter_precip = precip_oct_mar/in_prec_winter

# %% N after plowing ==========================================================

# Correction for tillage. Array with one entry per crop, indicating the month
# of the specified treatment.
# returns 0 for no event
# 1-12 for months of the previous year
# 13-24 for months of the current year
# tillage of pastures older than 9 months
m_til_long = c_month(in_meadow_til_long)
# tillage of pastures younger than 9 months
m_til_short = c_month(in_meadow_til_short)
# tillage of grain legumes
m_grain_til = c_month(in_grain_leg_tilaf)
# tillage of catch crops
m_catch_crop_til = c_month(in_catch_crop_til)
# incorporation of sugarbeet leaves
m_incorp_sugarbeet = c_month(in_incorp_sugarbeet)

# calculate the correction factors for the different treatments weighted by
# their areal contribution
# returns arrays per treatment with one correction factor [] per crop
# tillage of pastures older than 9 months, correction factor
c_meadow_til_long = np.array(af_meadow_til_long)*tab_pars['Value']['min_incr_meadow_til_long']
# tillage of pastures younger than 9 month, correction factor
c_meadow_til_short = np.array(af_meadow_til_short)*tab_pars['Value']['min_incr_meadow_til_short']
# tillage of grain legumes, correction factor
c_grain_leg_til = np.array(af_grain_leg_til)*tab_pars['Value']['min_incr_grain_leg_til']
# tillage of catch crops, correction factor
c_catch_crop_til = np.array(af_catch_crop_til)*tab_pars['Value']['min_incr_catch_crop_til']
# incorporation of sugarbeet leaves correction factor
c_incorp_sugarbeet_leaf = np.array(af_incorp_sugarbeet)*tab_pars['Value']['min_incr_sugarbeet_til']

# array of the combined correction factors for tillage
# one array per crop [first ID]
# entries 0 to 11 represent jan - dec of the previous year
# entries 12 to 23 represent jan - dec of the current year
corr_plowing_list = np.zeros([n_crops, 24])  # corr_plowing 1-24
for i in range(n_crops):  # for each crop
    for mon in np.arange(1, 25):  # for each month of two years
        # return the correction factor for tillage on the current crop for the
        # current month []
        corr_plowing_list[i][mon-1] = corr_plowing(
                                      mon, m_til_long[i],
                                      c_meadow_til_long[i],
                                      m_til_short[i],
                                      c_meadow_til_short[i],
                                      m_grain_til[i],
                                      c_grain_leg_til[i],
                                      m_catch_crop_til[i],
                                      c_catch_crop_til[i],
                                      m_incorp_sugarbeet[i],
                                      c_incorp_sugarbeet_leaf[i])

# %% N balance - Initialize variables =========================================

# NO3-N per area in groundwater [kg NO3-N/ha]
sum_NO3_N_gw_kgpha = list(np.zeros(n_crops))
# NO3-N per area in surface water [kg NO3-N/ha]
sum_NO3_N_sw_kgpha = list(np.zeros(n_crops))
# N2O-N per area [kg N2O-N/ha]
sum_N2O_N_kgpha = list(np.zeros(n_crops))

# total NO3 in groundwater per field [kg NO3/field]
sum_NO3_gw_kg = list(np.zeros(n_crops))
# total NO3 in surface water pre field [kg NO3/field]
sum_NO3_sw_kg = list(np.zeros(n_crops))
# total N2O per field [kg N2O/field]
sum_N2O_kg = list(np.zeros(n_crops))

# Setup lists for values per crop
dis_N_bal1   = list(np.zeros(n_crops))  # N balance 1 (non-cumulated months)
dis_N_loss   = list(np.zeros(n_crops))  # N loss from fert. (non-cumulated months)
dis_N_bal2   = list(np.zeros(n_crops))  # N balance 2 (cum. months)
dis_N_bal2_prev   = list(np.zeros(n_crops))  # N balance 2 (cum. months)
dis_N_bal2_curr   = list(np.zeros(n_crops))  # N balance 2 (cum. months)
dis_leaching = list(np.zeros(n_crops))  # final leaching

# %% Loop for all crops =======================================================
for crop in range(n_crops):
    # crop is an integer representing the position of the current crop in the
    # arrays that contain all the crops in the field.
    ID = in_crop_id[crop]  # extract ID of the crop

    # === Crops & Apples/Fruits ===
    if crop_module[crop] == 'Crop' or crop_module[crop] == 'Apple':
        row = jul_crop_sowi[crop]  # the row corresponds to the julian date
        # base_temp is not used in the code, but introduced here for testing
        base_temp = np.nan_to_num(tab_crops['Nitrate: Base Temperature'][
                        tab_crops['NameEN'] == in_crop_code[crop]].values[0], nan=0).astype(int)
        # code of the base temperature (Code) for the current crop
        code_temp = int(tab_crops['Nitrate Basistemp. Code'][
                        tab_crops['NameEN'] == in_crop_code[crop]].values[0])
        # adjust the code of the base temperature for the different regions
        if in_region == '1':  # valley uses the initial temperature code
            col = code_temp
        elif in_region == '3':  # mountain has an offset of 8
            col = code_temp+8
        else:  # hill has an offset of 4
            col = code_temp+4
        # as there is no base temperature of 10°C in the table, those cases
        # are mapped of the 7.5°C column for mountain climate.
        col = min([11, col])
        # Delay between physiological maturity and harvest (default 14 days)
        # derive table value
        Pys_maturity = int(jul_crop_harv[crop] \
                           - tab_crops['Nitrate: Correction Maturity'] \
                           [ tab_crops['NameEN'] == in_crop_code[crop]  \
                            ].values[0])
        # setup an empty list for the key dates 1 to 12
        key_date = np.zeros(12, dtype=int)
        # if the julian sowing date plus the remaining days of the month of
        # sowing is below the physiological maturity, the first key date is
        # set as the julian date of the end of the first month after sowing.
        # otherwise zero.
        if jul_crop_sowi[crop] + (31-day_crop_sowi[crop]) < Pys_maturity:
            key_date[0] = jul_crop_sowi[crop] + (31-day_crop_sowi[crop])
        # for the 11 remaining key dates
        for i in np.arange(1, 12):
            # if the previous key date + 30 days is still < the physiological
            # maturity and the previous key date is > 0, the next key date is
            # set to 30 days after the previous key date.
            if (key_date[i-1]+30 < Pys_maturity) and (key_date[i-1] > 0):
                key_date[i] = key_date[i-1]+30
        # growing degree days (GDD)
        # GDD sum until physiological maturity
        # derive the GDDs. Crop and region determine the column, the starting
        # row is determined by the julian sowing date, the end row is set to
        # the physiological maturity. returns the sum of the derived GDD values
        GDD_sum_pm = np.sum(tab_gdd[str(col)][row-1:Pys_maturity].values)
        # setup for the GDD sum for the 12 key dates
        GDD_sum = np.zeros(12)
        for i in range(12):  # for each key date
            # derive the sum of the GDDs from start (sowing date) to the key
            # date.
            GDD_sum[i] = np.sum(tab_gdd[str(col)][row-1:key_date[i]].values)
            # prevent division by 0 for the array of relative GDD sums
        if GDD_sum_pm == 0:
            GDD_sum_rel = np.zeros(12)
        else:
            # Array with the relative GDD sum for key dates 1-12
            GDD_sum_rel = GDD_sum/GDD_sum_pm

        # Norm N uptake (GRUD +10%)
        # derive table value for the current crop [kg N/ha]
        Norm_uptake = tab_crops['Nitrate: Standard Removal']\
                     [tab_crops['NameEN'] == in_crop_code[crop]].values[0]
        # Norm Yield (GRUD)
        # derive table value for the current crop [dt/ha]
        Norm_yield = tab_crops['Nitrate: Standard Yield']\
                    [tab_crops['NameEN'] == in_crop_code[crop]].values[0]
        # calculate yield factor for the current crop as the ratio of actual and
        # norm yield. Convert norm yield from dt to kg
        yield_factor = (in_harv[crop]/in_area_crop[crop]) \
                      /(Norm_yield*100)
        # correction factor yield based on the yield factor []
        # for 1% higher yield, the N uptake increases by 0.8%
        cf_yield = (yield_factor-1)*0.8+1
        
        
        # Adaptation of the Norm N update for Apples/Fruits (adding N-Uptake tree)
        if crop_module[crop] == 'Apple':
            # derive N uptake from the apple tree from the table
            NU_tree = tab_crops['Nitrate: N-Uptake Tree'][tab_crops['NameEN']
                                                          == in_crop_code[crop]
                                                          ].values[0]
            # calculate the N-uptake from apples based on the norm yield.
            # The yield correction is applied later with cf_yield.
            # Source GRUD2017 Ch. 13, Tab. 2, 40t of apples contain 20kg N,
            # i.e 0.5g N/kg apples
            NU_apple = (Norm_yield*100) * tab_pars['Value']['N_cont_apple']  # kg N/kg
            # Norm N uptake (incl. tree)
            Norm_uptake = NU_tree + NU_apple

        # derive the column for relative GDD sum and N-uptake for the current
        # crop
        col_gdd = int(tab_crops['Nitrate: Code %GDD'] \
                     [tab_crops['NameEN'] == in_crop_code[crop] \
                       ].values[0])
        # relative N-uptake until key date 1 - 12,
        # calculated as correction factor key date 1 - 12
        relNUp = np.zeros(12)
        # table values of relative N-uptake [] for the current crop
        relNUp_ls = tab_relNUp[str(col_gdd+1)].values/100
        # table values for the relative GDD sums [] for the current crop
        relGDD_ls = tab_relNUp[str(col_gdd)].values/100
        for i in np.arange(12):  # for each of the key dates
            # if the relative GDD sum of the current key date is below the
            # first entry of relative GDD sums on the list, the relative N-
            # uptake of the current key date is 0.
            if GDD_sum_rel[i] <= relGDD_ls[0]:
                relNUp[i] = 0
            # if the relative GDD sum of the current key date is
            # >= the last relative GDD sums entry on the list, the rela-
            # tive N-uptake of the current key date is the last entry in the
            # list of the relative N-uptake
            elif GDD_sum_rel[i] >= relGDD_ls[-1]:
                relNUp[i] = relNUp_ls[-1]
            # if the relative GDD sum of the current key date is in-between the
            # first and the last value on the GDD list, the relative N-uptake
            # of the current key date is the relative N-uptake from the list
            # corresponding in its position to the next smaller entry on the
            # relative GDD sums list
            else:
                relNUp[i] = relNUp_ls[np.where(
                    np.greater(relGDD_ls, GDD_sum_rel[i]))[0][0]]
        # the relative N-uptake at physiological maturity is assumed to be the
        # last entry on the list of relative N-uptake. []
        relNUp_pm = relNUp_ls[-1]

        # List of the norm N-uptake derived from relative N-uptake and norm
        # withdrawal. Calculated for the 12 key dates [kg N/ha]
        normNUptake = relNUp*Norm_uptake
        # List of the norm N-uptake derived from relative N-uptake and norm
        # withdrawal. Calculated for the physiological maturity [kg N/ha]
        normNUptake_pm = relNUp_pm*Norm_uptake

        # N uptake [kg/ha] (cumulative)
        # set up list of zeros for the 12 key dates
        NUptake = np.zeros(12)
        for i in np.arange(0, 12):  # for each of the key dates
            # The N-uptake at the current key date is calculated from the norm
            # N-uptake of the current key date, corrected by the yield correc-
            # tion factor and the relative N-uptake of the current key date.
            # The N-uptake at the current key date cannot be smaller than
            # it was on the previous key date.
            NUptake[i] = np.max([NUptake[i-1],
                                 normNUptake[i]*(cf_yield-1)*relNUp[i]
                                 + normNUptake[i]])
        NUptake_pm = np.max([NUptake[-1], normNUptake_pm *
                             (cf_yield-1)*relNUp_pm+normNUptake_pm])

        # Monthly N-Uptake
        # setup N-uptake [kg/ha], differences between the sowing date, key
        # dates and physiological maturity.
        n_uptake_crops = np.zeros(13)
        n_uptake_crops[0] = NUptake[0]  # sowing date to 1. key date
        for i in np.arange(1, 12):
            # 0 if either the later of the corresponding key dates or the N-
            # uptakes are 0.
            if (key_date[i] == 0) and (NUptake[i] == 0):
                n_uptake_crops[i] = 0
            # if there is a difference in the N uptake between the two compared
            # key dates, the entry is this difference
            elif NUptake[i] - NUptake[i-1] >= 0:
                n_uptake_crops[i] = NUptake[i] - NUptake[i-1]
            # if there is no difference between the N-uptake of the two compa-
            # red key dates, their difference to the N-uptake physiological
            # maturity is used
            else:
                n_uptake_crops[i] = NUptake_pm - NUptake[i-1]
        # N-uptake between the last key date and the physiological maturity
        n_uptake_crops[-1] = NUptake_pm - np.max(NUptake)

        # assign months to the key dates and the physiological maturity
        # list of zeros for the 12 key dates and the physiological maturity
        month_n_uptake_crops = np.zeros(13)
        for i in np.arange(12):  # for each of the key dates
            if key_date[i] > 0:  # if the key date is used
                # assign the month of the sowing date + i to key date i.
                month_n_uptake_crops[i] = mon_crop_sowi[crop] + i
        # the month of the physiological maturity is the latest month of the
        # key dates +1
        month_n_uptake_crops[12] = np.max(month_n_uptake_crops[0:-1])+1

    # === Vegetables ===

    if crop_module[crop] == 'Vegetables':
        # Norm N uptake (GRUD +10%)
        # derive table value for the current crop [kg/ha]
        Norm_uptake = tab_crops['Nitrate: Standard Removal'] \
                     [tab_crops['NameEN'] == in_crop_code[crop]].values[0]
        # Norm Yield (GRUD)
        # derive table value for the current crop [dt/ha]
        Norm_yield = tab_crops['Nitrate: Standard Yield'] \
                    [tab_crops['NameEN'] == in_crop_code[crop]].values[0]
        # effective N uptake [kg/ha] Norm uptake weighted by the ratio
        # of current to norm yield.
        N_uptake_effective = (in_harv[crop]/in_area_crop[crop]) \
                             /(Norm_yield*100)*Norm_uptake
        # days until start of N-uptake [days]
        # derive table value for the current crop
        days_till_NUptake = tab_crops['Nitrate: Approx.  Start of intense N-Accumulation'] \
                           [tab_crops['NameEN'] == in_crop_code[crop]].values[0]
        # duration of N removal[days]. Number of days between the start of N-
        # accumulation and harvest.
        duration_of_removal = (jul_crop_harv[crop] \
                             - jul_crop_sowi[crop] \
                             - days_till_NUptake)
        # average daily N withdrawal [kg N/ha/day]
        removal_daily = N_uptake_effective/duration_of_removal
        # start date of N-uptake (dt.date)
        start_n_uptake = in_sowi_date[crop] \
            + dt.timedelta(days=days_till_NUptake)
        # remaining days of uptake in the current month [days]
        until_end_of_month = 31-start_n_uptake.day
        # Code for the month of N uptake
        # setup list of zeros
        month_n_uptake_vegetables = np.zeros(12)
        # month of the harvest date
        mon_harv = mon_crop_harv[crop]
        # day of month, harvest date
        day_harv = day_crop_harv[crop]
        # if the start of N uptake and harvest occur in the same year, correct
        # the month of the start of N uptake by 12
        if year_crop_sowi[crop] == year_crop_harv[crop]:
            start_month_n_uptake = start_n_uptake.month + 12
        else:
            start_month_n_uptake = start_n_uptake.month
        # first entry marks the start of N uptake
        month_n_uptake_vegetables[0] = start_month_n_uptake

        for i in np.arange(1, 12):  # for the remaining entries
            # if the previous entry contains a month earlier than the month of
            # harvest, enter the month of the previous entry + 1 for the cur-
            # rent entry.
            if month_n_uptake_vegetables[i-1] < mon_harv:
                month_n_uptake_vegetables[i] = month_n_uptake_vegetables[i-1]+1
            else:
                break

        # monthly N uptake [kg N/ha]
        # setup list of zeros for 12 dates
        n_uptake_vegetables = np.zeros(12)
        # N uptake at the end of the month, in which N uptake started
        n_uptake_vegetables[0] = until_end_of_month*removal_daily
        for i in np.arange(1, 12):  # for the remaining months
            if month_n_uptake_vegetables[i] == 0:  # no month specified
                continue
            # if the corresponding month is earlier than the month of harvest
            elif month_n_uptake_vegetables[i] < mon_harv:
                # enter 30 times the daily N-uptake value
                n_uptake_vegetables[i] = 30*removal_daily
                # if the corresponding month is the same as the harvest month
            elif month_n_uptake_vegetables[i] == mon_harv:
                # contribution from the days in the month until harvest.
                n_uptake_vegetables[i] = day_harv * removal_daily

        # N loss fertilizers (factors)
        # month before the beginning of intensive N uptake
        one_month_before_int_NU  = tab_pars['Value']['vegs_Nloss_1mon']
        # two months before the beginning of intensive N uptake
        two_months_before_int_NU = tab_pars['Value']['vegs_Nloss_2mon']
        # all earlier months
        cf_fert_earlier_months   = tab_pars['Value']['vegs_Nloss_3mon']
        # all later months
        cf_fert_later_months     = tab_pars['Value']['vegs_Nloss_0mon']

    # === Mineralisation [kg N/ha] ===
    # setup array with zeros for mineralisation January of the previous year
    # to December of the current year
    r_mineralisation = np.zeros(24)
    # for each of the 24 months
    for i in np.arange(0, 24):
        # starts with 0 for january of the first year and ends with 23 for
        # december of the second year
        mon24 = i+1
        # corrects the month to match 1 with january of the first year
        # if the current month is between harvest of the previous and the
        # current crop:
        if      (mon_prev_harv[crop] <= mon24) \
            and (mon_crop_harv[crop] >= mon24):
            # derive the month of year, independent of the year.
            if mon24 > 12:
                mon12 = mon24-12  # 1 - 12
            else:
                mon12 = mon24  # 1 - 12
            # code for the pasture type of the current crop, represents the
            # used column in the mineralisation table.
            col = int(past_code[crop])
            if past_code == 2:  # temp. ley
                # adjust for meadows older than 9 months
                if in_meadow9:
                    col = 3  # like permanent grassland
                elif i - mon_crop_sowi[crop] > 9:
                    col = 3  # like permanent grassland
                else:
                    col = 1  # like arable land
            # indicator for intensive tillage. 0 by default, indicates no intensive
            # tillage. 1 indicates intensive tillage in the current month.
            int_ST = 0
            # set int_ST to 1 if there is an intensive tillage event in the cur-
            # rent month.
            for index_til, intense_til in enumerate(in_intense_til):
                if (mon24 == intense_til) & (id_intense_til[index_til] == ID):
                    int_ST = 1
            # derive mineralisation in the current month. Additional minerali-
            # zation is added, if there was a tillage event in this month.
            # corrected by the factors of clay&humus, org. fertiliser and
            # tillage. Monthly values
            offset = 2  # offset in the table
            r_mineralisation[i] = ((tab_min.iloc[mon12-1, col+offset]
                                  + tab_min.iloc[mon12-1, 6+offset] * int_ST) \
                                  * corr_clay_humus \
                                  * corr_dens \
                                  * corr_LU \
                                  * corr_plowing_list[crop][i])

            # Correction for days in the months of harvest of current and
            # previous crops. Only days within harvest events contribute to
            # the mineralsation.
            if mon_prev_harv[crop] == mon24:
                r_mineralisation[i] *= (31 - day_prev_harv[crop])/30
            elif mon_crop_harv[crop] == mon24:
                r_mineralisation[i] *= day_crop_harv[crop]/30

    # Setup array for cumulated months (0-23). 1 = cumulated, 0 = not cumulated
    cum_mon = tab_cum_mon[str(n_loss_code[crop])].tolist()

    # === N-uptake [kg N/ha] ===
    result_N_uptake = np.zeros(24)  # setup list with zeros for 24 months
    # for vegetables:
    if crop_module[crop] == 'Vegetables':
        # iterate through the list of months with N-uptake
        for i, mon in enumerate(month_n_uptake_vegetables):
            # assign the calculated N-uptake to the corresponding month.
            result_N_uptake[int(mon)-1] = n_uptake_vegetables[i]
    # for crops:
    elif crop_module[crop] == 'Crop' or crop_module[crop] == 'Apple':
        # iterate through the list of months with N-uptake
        for i, mon in enumerate(month_n_uptake_crops):
            # assign the calculated N-uptake to the corresponding month.
            result_N_uptake[int(mon)-1] = n_uptake_crops[i]

    # === N balance 1 [kg N/ha] ===
    # leaching from mineralisation and uptake.
    # setup array with zeros for N balance. january of the previous year
    # to december of the current year. The N balance is the difference of N
    # mineralisation and N withdrawal, but cannot be < 0.
    result_N_balance = np.zeros(24)  # setup
    for i in np.arange(24):
        result_N_balance[i] = np.max([0, r_mineralisation[i]
                                       - result_N_uptake[i]])
    # N balance distribution across the different groups
    # sum of non-cumulated months = total - cumulated months
    dis_N_bal1[crop] = np.sum(result_N_balance) \
        - sumproduct(result_N_balance, cum_mon, 0) \
        - sumproduct(result_N_balance, cum_mon, 1)

    # === N fertilisation kg N/ha ===
    # calculate N fertilisation [kg N/ha] from fertilisation input [kg N]
    # (array of 24 elements per crop, 12 for months of the previous year, 12
    # for the months of the current year), the area of the crop [ha] and the
    # loss rate of TAN [kg/kg].
    result_N_fertilisation = np.array(in_N_fert[crop])/in_area_crop[crop] \
                           * (1-in_TAN_loss)

    # === N loss from fertilisation [kg N/ha] ===
    # setup array with zeros for N loss from fertilisation. January of the
    # previous year to December of the current year.
    result_N_loss = np.zeros(24)
    for i in np.arange(24):
        # for crops
        if crop_module[crop] == 'Crop' or crop_module[crop] == 'Apple':
            # table value for fertilisation leaching [%/100]
            fertilisation_leaching = tab_fert_leaching[str(n_loss_code[crop])][i]
            # the loss depends on N input from fertilisation [kg N/ha], the
            # table value of the crop for fertilisation leaching [%/100] and
            # the correction factor for soil depth []
            result_N_loss[i] = (result_N_fertilisation[i] \
                                * fertilisation_leaching  \
                                * corr_soil_depth)
        # for vegetables:
        # 0 after N-uptake starts
        # one month before N-uptake starts:
        elif i+1 == start_month_n_uptake-1:
            # the resulting loss [kg N/ha] is derived from the input of N from
            # fertilisation in the current month [kg N/ha] and the correction
            # factor for the month before N uptake starts [].
            result_N_loss[i] = (result_N_fertilisation[i] \
                                * one_month_before_int_NU)
        elif i+1 == start_month_n_uptake-2:
            # the resulting loss [kg N/ha] is derived from the input of N from
            # fertilisation in the current month [kg N/ha] and the correction
            # factor for the month two months befor N uptake starts [].
            result_N_loss[i] = (result_N_fertilisation[i] \
                                * two_months_before_int_NU)
        elif i+1 <= start_month_n_uptake-3:
            # the resulting loss [kg N/ha] is derived from the input of N from
            # fertilisation in the current month [kg N/ha] and the correction
            # factor for the month earlier than two months before N uptake
            # starts [].
            result_N_loss[i] = result_N_fertilisation[i]*cf_fert_earlier_months
        # The loss of N from fertilisation cannot be larger than the input of
        # N from fertilisation in the same month.
        result_N_loss[i] = np.min([result_N_loss[i],
                                   result_N_fertilisation[i]])

    # N loss from fertilisation distribution
    # sum of non-cumulated months
    dis_N_loss[crop] = np.sum(result_N_loss) \
        - sumproduct(result_N_loss, cum_mon, 0) \
        - sumproduct(result_N_loss, cum_mon, 1)

    # === N-balance 2 [kg N/ha] ===
    # the second N balance is calculated from mineralisation [kg N/ha], effec-
    # tive fertilisation [kg N/ha] and N-uptake [kg N/ha]
    # balance2 = mineralisation + fertilisation - uptake
    # sum of cumulated months
    sum2_mineralisation_prev  = sumproduct(r_mineralisation, cum_mon, 0)
    sum2_mineralisation_curr  = sumproduct(r_mineralisation, cum_mon, 1)
    sum2_N_fertilisation_prev = sumproduct(result_N_fertilisation, cum_mon, 0)
    sum2_N_fertilisation_curr = sumproduct(result_N_fertilisation, cum_mon, 1)
    sum2_N_uptake_prev        = sumproduct(result_N_uptake, cum_mon, 0)
    sum2_N_uptake_curr        = sumproduct(result_N_uptake, cum_mon, 1)
    dis_N_bal2_prev[crop] = sum2_mineralisation_prev + sum2_N_fertilisation_prev - sum2_N_uptake_prev
    dis_N_bal2_curr[crop] = sum2_mineralisation_curr + sum2_N_fertilisation_curr - sum2_N_uptake_curr
    dis_N_bal2_prev[crop] = np.max([0, dis_N_bal2_prev[crop]])  # prevent negative values
    dis_N_bal2_curr[crop] = np.max([0, dis_N_bal2_curr[crop]])  # prevent negative values
    dis_N_bal2[crop]      = dis_N_bal2_prev[crop] + dis_N_bal2_curr[crop]

    # === N-leaching ===
    # setup the normal total [kg NO3-N/ha] as the sum of balance of minerali-
    # sation and leaching and the loss from fertilisation
    sum_normal = np.sum(result_N_loss) + np.sum(result_N_balance)

    # distribution accross the different crop types
    # leaching is calculated as the sum of leaching from mineralisation
    # and uptake, loss from fertilisation and, the second N-balance
    # this results in mineralisation-uptake+loss_from_fertilisation
    # +mineralisation-uptake.
    dis_leaching[crop] = dis_N_bal1[crop] \
                       + dis_N_loss[crop] \
                       + dis_N_bal2[crop]
    
    # === Results ===
    # total NO3-N/ha
    sum_no3_n = np.max([0, dis_leaching[crop]])
    # total leaching to groundwater [kg NO3-N/ha]
    # corrected for winter precipitation
    sum_NO3_N_gw_kgpha[crop] = sum_no3_n*(1-in_drainage)*f_winter_precip
    # total leaching to surface water [kg NO3-N/ha]
    sum_NO3_N_sw_kgpha[crop] = sum_no3_n*in_drainage*f_winter_precip
    # total N2O emission [kg N2O-N/ha]
    # EF5 for N2O from N leaching and runoff
    EF5 = tab_pars['Value']['EF5']
    sum_N2O_N_kgpha[crop] = (sum_NO3_N_gw_kgpha[crop] \
                           + sum_NO3_N_sw_kgpha[crop]) * EF5
    # amount per field and conversion to the final emissions
    # total leaching to groundwater [kg NO3/field]
    sum_NO3_gw_kg[crop] = (sum_NO3_N_gw_kgpha[crop] \
                         * in_area_crop[crop] * 62/14)
    # total leaching to surface water [kg NO3/field]
    sum_NO3_sw_kg[crop] = (sum_NO3_N_sw_kgpha[crop] \
                         * in_area_crop[crop] * 62/14)
    # total N2O emission [kg N2O/field]
    sum_N2O_kg[crop] = (sum_N2O_N_kgpha[crop] \
                      * in_area_crop[crop] * 44/28)
    logging.info("r_mineralisation[%s] = %s", crop, r_mineralisation)
    logging.info('result_N_fertilisation[%s] = %s', crop, result_N_fertilisation)
    logging.info('result_N_uptake[%s] = %s', crop, result_N_uptake)
    logging.info('')
    # End of crop loop

# %% Output ===================================================================

# sum over the different crops to calculate the output on field level
# total leaching to groundwater [kg NO3/field]
out.fi_e_gw_kgNO3 = sum(sum_NO3_gw_kg)
# total leaching to surface water [kg NO3/field]
out.fi_e_sw_kgNO3 = sum(sum_NO3_sw_kg)
# total N2O emission [kg N2O/field]
out.fi_e_air_kgN2O_nitrate = sum(sum_N2O_kg)

logging.info('dis_N_bal1= %s',dis_N_bal1)
logging.info('dis_N_loss= %s',dis_N_loss)
logging.info('dis_N_bal2= %s',dis_N_bal2)
logging.info('')

# print output summary to module log
logging.info('Output SALCAnitrate field')
logging.info('for farm %s with ID %s', ctx.farm.farm_name, ctx.farm.farm_id)
logging.info('for field %s with ID %s', ctx.field[1], ctx.field_id)
logging.info('')
logging.info('Total groundwater (kg NO3/field) : {0:.4f}'.format(sum(
    sum_NO3_gw_kg)))
logging.info('Total surface water (kg NO3/field) : {0:.4f}'.format(sum(
    sum_NO3_sw_kg)))
logging.info('Total N2O (kg N2O/field) : {0:.4f}'.format(sum(
    sum_N2O_kg)))
logging.info('')

# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End  %s' + module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
