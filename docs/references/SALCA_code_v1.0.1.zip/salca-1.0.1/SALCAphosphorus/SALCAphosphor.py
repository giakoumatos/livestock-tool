# -*- coding: utf-8 -*-
"""
File name: SALCAphosphor.py
Created on Mon Jan 27 09:58:26 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script estimates P emissions to freshwater.
    Four discharge paths are taken into account:
        (1) surface runoff
        (2) leaching to groundwater
        (3) drainage losses
        (4) soil erosion

Calculation level:
    Crop

Related script: SALCAerosion_field.py
    It uses input from this script.
"""

# %% import modules ===========================================================

import datetime as dt
import json as js
import logging
import warnings as w
from importlib import reload
from sys import stderr

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAphosphorus'
logging.info('')
logging.info('Start %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define classes ===========================================================

class Factors:
    mg2kg = 1e-6
    kgP2kgP2O5 = (31*2+16*5)/(31*2)
    kgP2kgPO4 = (31+4*16)/31

# %% define functions =========================================================

# Subroutine for determination of water regime (Codes)
def waterRegimeCode(soil_depth_cm, soil_waterRegime):
    """Finds the interval from a list of intervals that includes the value v"""
    def searchintervals(interval_boundaries, value):
        side = 'left'
        index = np.searchsorted(interval_boundaries, value, side)
        return index

    if soil_waterRegime == 'group_0':
        return 0
    watRegSel = {'group_1': ['a', 'b', 'c', 'd', 'e'],
                 'group_2': ['f', 'g', 'h', 'i'],
                 'group_3': ['k', 'l', 'm', 'n'],
                 'group_4': ['o', 'p'],
                 'group_5': ['q', 'r'],
                 'group_6': ['s', 't', 'u'],
                 'group_7': ['v', 'w'],
                 'group_8': ['x', 'y'],
                 'group_9': ['z']}.get(soil_waterRegime)
    # bounds in cm
    bound = {'a': [0, 30, 50, 70, 100],
             'f': [0, 30, 50, 70],
             'k': [0, 30, 50, 70],
             'o': [0, 50],
             'q': [0, 30],
             's': [0, 50, 70],
             'v': [0, 50],
             'x': [0, 30]}.get(watRegSel[0])

    if watRegSel[0] == 'z':
        waterRegCode = 'z'
    else:
        ind = searchintervals(bound, soil_depth_cm)
        # give code of water balance (one letter), reverse order
        waterRegCode = watRegSel[len(bound)-ind]
    return waterRegCode


# Computation granularity (Körnungsklasse)
def granularity(soil_content_clay, soil_content_sand):
    """
    Returns
    -------
    str
        Value for risk class
    """
    soil_content_silt = 1.0 - soil_content_clay - soil_content_sand
    if soil_content_silt < 0 or soil_content_silt > 1.0:
        raise NameError("Error : silt content outside of range [0,100]%")

    granularityCode = 'NA'
    if soil_content_clay > 0.5 and soil_content_silt < 0.5:
        granularityCode = "T"
    if 0.4 <= soil_content_clay <= 0.5 and soil_content_silt < 0.5:
        granularityCode = "IT"
    if 0.3 <= soil_content_clay <= 0.4 and soil_content_silt < 0.5:
        granularityCode = "tL"

    if 0.3 <= soil_content_clay <= 0.5 and soil_content_silt > 0.5:
        granularityCode = "tU"
    if 0.1 <= soil_content_clay <= 0.3 and soil_content_silt > 0.5:
        granularityCode = "IU"
    if soil_content_clay < 0.1 and soil_content_silt > 0.5:
        granularityCode = "U"

    if 0.2 <= soil_content_clay <= 0.3 and soil_content_silt < 0.5:
        granularityCode = "L"
    if 0.1 <= soil_content_clay <= 0.2 and soil_content_silt < 0.5:
        granularityCode = "sL"

    if 0.05 <= soil_content_clay <= 0.1 and soil_content_silt < 0.5:
        granularityCode = "IS"
    if soil_content_clay < 0.05 and soil_content_silt < 0.5:
        granularityCode = "S"
    return granularityCode


def read_pars(path):
    """read CSV file"""
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    tab = tab.set_index('NameEN')
    return tab


def read_table(path):
    """read CSV file"""
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    tab = tab.set_index('Index', drop=True)
    return tab


# %% input for preparation ====================================================

logging.info("Start time of preparation part %s", dt.datetime.now(tz=None))

crop = ctx.crop.crop_definition_name  # Python name of the crop

c_salcaprep = js.loads(inp.c_salcaprep)  # input from salcaprep_crop
# crop area multiplied by the duration of the evaluation / of the crop
areatime = c_salcaprep['c_areatime']

# erosion from SALCAerosion, kg soil eroded per ha per year [kg/ha/a]
fi_eros_kgphapa = inp.fi_eros_kgphapa
fi_soil_mgPpkg = inp.fi_soil_mgPpkg  # mg P / kg DM, default: 950 mg P/kg soil
fi_drai_dis_m = inp.fi_drai_dis_m  # drainage distance [m], 0 = unknnown
fi_drai_frac = inp.fi_drai_perc  # fraction of the field that is drained
# class of P supply. 00X Y. X: numbering, Y: supply class (A-E)
fi_Psupply = inp.fi_Psupply

# In SALCAfuture, input variables entered in percentage are automatically
# converted into fractions of the range [0,1]. While the input variables are
# named according to the entered values, calculation variables in the code are
# named with _frac to resemble that they are fractions with a range of [0,1].
fi_humus_frac = inp.fi_humus_perc  # humus content [0,1]
fi_clay_toso_frac = inp.fi_clay_toso_perc  # clay content in the topsoil [0,1]
fi_sand_toso_frac = inp.fi_sand_toso_perc  # sand content in the topsoil [0,1]
# clay content in the subsoil from SALCAprep_field [0,1]
fi_clay_suso_frac = inp.fi_clay_suso_frac
# sand content in the subsoil from SALCAprep_field [0,1]
fi_sand_suso_frac = inp.fi_sand_suso_frac
fi_soil_depth_cm = inp.fi_soil_depth_cm  # soil depth in cm
fi_skeleton_frac = inp.fi_skeleton_perc  # skeleton content of the soil [0,1]
# soil water regime classification
fi_soil_water_regime = inp.fi_soil_water_regime
fi_soil_compacted_bool = inp.fi_soil_compacted_bool  # compacted soil (boolean)
fi_slope_shape = inp.fi_slope_shape  # slope shape classification
# distance of water flow across the field [m], 0 = unknnown
fi_terrain_flow_dist_m = inp.fi_terrain_flow_dist_m
fi_slope_frac = inp.fi_slope_perc  # Slope gradient [%]
# outside water inflow (boolean)
fi_outside_water_inflow_bool = inp.fi_outside_water_inflow_bool
# water emergence on the slope (boolean)
fi_slope_water_discharge_bool = inp.fi_slope_water_discharge_bool
# list of applied amounts of slurry [m3]
slurry_amounts_m3 = c_salcaprep['tr_manure_l']['amount_m3']
# list of types of applied slurry
slurry_type = c_salcaprep['tr_manure_l']['variable']
# list of applied amounts of solid manure [kg]
manure_amounts_t = c_salcaprep['tr_manure_s']['amount_t']
# list of types of applied solid manure
manure_type = c_salcaprep['tr_manure_s']['variable']
# P2O5 content of solid manure [kg P2O5/t], from SALCAanimal_farm
f_sman_kgP2O5pt = inp.f_sman_kgP2O5pt
# P2O5 content of liquid manure [kg P2O5/m3], from SALCAanimal_farm
f_lman_kgP2O5pm3 = inp.f_lman_kgP2O5pm3
# list of amounts of fertiliser applied [kg nutrient] (N, P2O5, K2O, Mg)
fert_amount_kg = c_salcaprep['tr_fert']['amount_kg']
# list of types of fertiliser applied
fert_variable = c_salcaprep['tr_fert']['variable']

# %% calculation in preparation part ==========================================

# %%% load tables

# crop table
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index'])
# fertiliser table
tab_fert = pd.DataFrame(data=js.loads(inp.tab_fert)['data'],
                        columns=js.loads(inp.tab_fert)['columns'],
                        index=js.loads(inp.tab_fert)['index'])
# manure table
tab_manu = pd.DataFrame(data=js.loads(inp.tab_manu)['data'],
                        columns=js.loads(inp.tab_manu)['columns'],
                        index=js.loads(inp.tab_manu)['index'])

# table with parameters from csv - used in calculation
tab_pars = read_pars('SALCAphosphor_pars.csv')

tab_drainage_distance = read_table('Drainage_distance.csv')

tab_land_use = read_table('Land_use.csv')

tab_risk = read_table('Risk.csv')

tab_flow_path = read_table('Flow_path.csv')

tab_slope_shape = read_table('Slope_shape.csv')

# %%% consult tables

# land use type based on the crop type
land_use = tab_crops['land use'][tab_crops['NameEN'] == crop].values[0]

# calculate P or P2O5 amounts applied
fert_kg_P2O5 = []  # P2O5 amounts of fertilisers applied
lman_kg_P2O5 = []  # P2O5 amounts of slurry applied
manu_org_kg_P2O5 = []  # P2O5 amounts of other organic manure applied
sman_kg_P2O5 = []  # P2O5 amounts of solid manure applied
compost_kg_P2O5 = []  # P2O5 amounts of compost applied
sewage_kg_P2O5 = []  # P2O5 amounts of sewage sludge applied

manure_list = ['Cattle', 'Pigs', 'Poultry', 'Unassigned']

for i, manure_l in enumerate(slurry_type):
    if manure_l == 'liquid_farm_manure':
        # P2O5 content of liquid farm manure is calculated in SALCAanimal_farm
        lman_kg_P2O5.append(slurry_amounts_m3[i]*f_lman_kgP2O5pm3)
    else:
        # P2O5 content of other organic manure (liquid) comes from tab_manu
        p2o5_cont_lman = tab_manu['AM: P2O5'][tab_manu['NameEN']
                                          == manure_l].values[0]
        module = tab_manu['Module'][tab_manu['NameEN']
                                    == manure_l].values[0]
        if module in manure_list:
            lman_kg_P2O5.append(slurry_amounts_m3[i]*p2o5_cont_lman)
        else:
            # liquid sewage sludge and liquid other organic manure (Gärgülle)
            # are not differentiated from slurry
            lman_kg_P2O5.append(slurry_amounts_m3[i]*p2o5_cont_lman)

for i, manure_s in enumerate(manure_type):
    if manure_s == 'solid_farm_manure':
        # P2O5 content of solid farm manure is calculated in SALCAanimal_farm
        sman_kg_P2O5.append(manure_amounts_t[i]*f_sman_kgP2O5pt)
    else:
        # P2O5 content of other organic manure (solid) comes from tab_manu
        p2o5_cont_sman = tab_manu['AM: P2O5'][tab_manu['NameEN']
                                          == manure_s].values[0]
        module = tab_manu['Module'][tab_manu['NameEN']
                                    == manure_s].values[0]
        if module == 'Sewage sludge':
            sewage_kg_P2O5.append(manure_amounts_t[i]*p2o5_cont_sman)
        elif module == 'Compost':
            compost_kg_P2O5.append(manure_amounts_t[i]*p2o5_cont_sman)
        elif module in manure_list:
            sman_kg_P2O5.append(manure_amounts_t[i]*p2o5_cont_sman)
        else:
            manu_org_kg_P2O5.append(manure_amounts_t[i]*p2o5_cont_sman)

for i, fert in enumerate(fert_variable):
	# Conversion from fertiliser amount to amount of P2O5 handled in SALCAprep_crop
    module = tab_fert['Module'][tab_fert['NameEN']
                                == fert].values[0]
    p2o5_content = tab_fert['PH: P-Content'][tab_fert['NameEN']
                                          == fert].values[0]
    fert_kg_P2O5.append(fert_amount_kg[i]*p2o5_content)

# %%% classifications

# classification of drainage distance into distance classes
if fi_drai_dis_m == 0:
    drainage_dist_c = '3-30m'  # default
elif fi_drai_dis_m < 3:
    drainage_dist_c = '0-2m'
elif fi_drai_dis_m <= 30:
    drainage_dist_c = '3-30m'
elif fi_drai_dis_m <= 100:
    drainage_dist_c = '30-100m'
else:
    drainage_dist_c = '>100m'

# classification of terrain flow into distance classes
if fi_terrain_flow_dist_m == 0:
    flow_distance_class = '25-50m'  # default
elif fi_terrain_flow_dist_m <= 24:
    flow_distance_class = '0-24m'
elif fi_terrain_flow_dist_m <= 50:
    flow_distance_class = '25-50m'
elif fi_terrain_flow_dist_m <= 100:
    flow_distance_class = '51-100m'
else:
    flow_distance_class = '>100m'

# %% output of preparation part ===============================================

phosphorus_prep = {
    'areatime': areatime,  # fraction of the year covered
    'fi_eros_kgphapa': fi_eros_kgphapa,  # from SALCAerosion [kg/ha/a]
    'fi_soil_mgPpkg': fi_soil_mgPpkg,  # [mg P / kg DM]
    'drainage_dist_c': drainage_dist_c,
    'fi_drai_frac': fi_drai_frac,
    'land_use': land_use,
    'fi_Psupply': fi_Psupply,
    'fi_humus_frac': fi_humus_frac,
    'fi_clay_toso_frac': fi_clay_toso_frac,
    'fi_sand_toso_frac': fi_sand_toso_frac,
    'fi_clay_suso_frac': fi_clay_suso_frac,
    'fi_sand_suso_frac': fi_sand_suso_frac,
    'fi_soil_depth_cm': fi_soil_depth_cm,
    'fi_skeleton_frac': fi_skeleton_frac,
    'fi_soil_water_regime': fi_soil_water_regime,
    'fi_soil_compacted_bool': fi_soil_compacted_bool,  # boolean
    'fi_slope_shape': fi_slope_shape,
    'fi_terrain_flow_dist_m': flow_distance_class,
    'fi_slope_frac': fi_slope_frac,
    'fi_outside_water_inflow_bool': fi_outside_water_inflow_bool,  # boolean
    'fi_slope_water_discharge_bool': fi_slope_water_discharge_bool,  # boolean
    'fert_kg_P2O5': fert_kg_P2O5,  # list of P2O5 amounts of fertilisers applied
    'lman_kg_P2O5': lman_kg_P2O5,  # list of P2O5 amounts of liquid manure applied
    'sman_kg_P2O5': sman_kg_P2O5,  # list of P2O5 amounts of solid manure applied
    'manu_org_kg_P2O5': manu_org_kg_P2O5,  # list of P2O5 amounts of other organic manure applied
    'compost_kg_P2O5': compost_kg_P2O5,  # list of P2O5 amounts of compost applied
    'sewage_kg_P2O5': sewage_kg_P2O5  # list of P2O5 amounts of sewage sludge applied
}
logging.info("End time of preparation part %s", dt.datetime.now(tz=None))

# %% input ====================================================================

logging.info("Start time of calculation part %s", dt.datetime.now(tz=None))

phosphorus = phosphorus_prep  # assign preparation part to variable

area_year = phosphorus['areatime']  # crop area multiplied by crop duration [ha*year]
# from SALCAerosion [kg/ha/year]
fi_eros_kgpypha = phosphorus['fi_eros_kgphapa']
# [mg P / kg DM], default: 950 mg P/kg soil
fi_soil_mgPpkg = phosphorus['fi_soil_mgPpkg']
drainage_dist_c = phosphorus['drainage_dist_c']
fi_drai_frac = phosphorus['fi_drai_frac']
land_use = phosphorus['land_use']
fi_Psupply = phosphorus['fi_Psupply']
fi_humus_frac = phosphorus['fi_humus_frac']
fi_clay_toso_frac = phosphorus['fi_clay_toso_frac']
fi_sand_toso_frac = phosphorus['fi_sand_toso_frac']
fi_clay_suso_frac = phosphorus['fi_clay_suso_frac']
fi_sand_suso_frac = phosphorus['fi_sand_suso_frac']
fi_soil_depth_cm = phosphorus['fi_soil_depth_cm']
fi_skeleton_frac = phosphorus['fi_skeleton_frac']
fi_soil_water_regime = phosphorus['fi_soil_water_regime']
fi_soil_compacted_bool = phosphorus['fi_soil_compacted_bool']  # boolean
fi_slope_shape = phosphorus['fi_slope_shape']
fi_terrain_flow_dist_m = phosphorus['fi_terrain_flow_dist_m']
fi_slope_frac = phosphorus['fi_slope_frac']
# boolean
fi_outside_water_inflow_bool = phosphorus['fi_outside_water_inflow_bool']
# boolean
fi_slope_water_discharge_bool = phosphorus['fi_slope_water_discharge_bool']
# list of P2O5 amounts of fertilisers applied
fert_kg_P2O5 = phosphorus['fert_kg_P2O5']
# list of P2O5 amounts of liquid manure
lman_kg_P2O5 = phosphorus['lman_kg_P2O5']
# list of P2O5 amounts of solid manure applied
sman_kg_P2O5 = phosphorus['sman_kg_P2O5']
# list of P2O5 amounts of other organic manure applied
manu_org_kg_P2O5 = phosphorus['manu_org_kg_P2O5']
# list of P2O5 amounts of compost applied
compost_kg_P2O5 = phosphorus['compost_kg_P2O5']
# list of P2O5 amounts of sewage sludge applied
sewage_kg_P2O5 = phosphorus['sewage_kg_P2O5']

# %% calculation ==============================================================

# print setup
logging.info('Output SALCAphosphorus')
logging.info('for farm %s with ID %d', ctx.farm.farm_name, ctx.farm.farm_id)
logging.info('for field %s with ID %d', ctx.field[1], ctx.field_id)
logging.info('for crop %s with ID %d with name %s',
             ctx.crop[2], ctx.crop_id, ctx.crop[1])
logging.info('')

# %% risk factor leaching =====================================================


# set default value (this value leads to a soil factor" of 1.0)
leaching_riskclassNo = 2
# determine risk class for humus-rich soils (Moor, Halbmoor)
if fi_humus_frac > 0.3:
    leaching_riskclassNo = 4  # fraction of humus > 30% => risk class = 4

# compute water regime group
waterRegCode = waterRegimeCode(fi_soil_depth_cm, fi_soil_water_regime)

# determine risk factor depending on water regime group
if waterRegCode in ['a', 'b', 'f', 'k', 'o', 's']:
    leaching_riskclassNo = 1
elif waterRegCode in ['c', 'g', 'l', 'p', 'q', 't']:
    leaching_riskclassNo = 2
elif waterRegCode in ['d', 'h', 'm', 'r', 'v']:
    leaching_riskclassNo = 3
elif waterRegCode in ['e', 'i', 'n', 'w', 'x']:
    leaching_riskclassNo = 4
elif waterRegCode in ['u', 'y', 'z']:
    leaching_riskclassNo = 5

# compute change of risk factor by -1 / 0 / +1 depending on soil granulation
# compute granularity code for top- and subsoil
granularityCodeTopSoil = granularity(fi_clay_toso_frac, fi_sand_toso_frac)
granularityCodeSubSoil = granularity(fi_clay_suso_frac, fi_sand_suso_frac)

# default value for change of risk factor
leaching_riskclass_TopSoil_Change = 0
leaching_riskclass_SubSoil_Change = 0

if granularityCodeTopSoil in ['S', 'IS', 'sL']:
    leaching_riskclass_TopSoil_Change = -1
if granularityCodeTopSoil in ['T', 'IT', 'tL']:
    leaching_riskclass_TopSoil_Change = 1

if granularityCodeSubSoil in ['S', 'IS', 'sL']:
    leaching_riskclass_SubSoil_Change = -1
if granularityCodeSubSoil in ['T', 'IT', 'tL']:
    leaching_riskclass_SubSoil_Change = 1

leaching_riskclass_Change = round((2.0*leaching_riskclass_TopSoil_Change
                                   + leaching_riskclass_SubSoil_Change)/3.0)

if abs(leaching_riskclass_Change) > 1:
    leaching_riskclass_Change = 0
    w.warn('Leaching_riskclass_Change is not -1, 0 or 1 and was set to 0')
    stderr.flush()  # show warning immediately

leaching_riskclassNo = leaching_riskclassNo + leaching_riskclass_Change
logging.debug("leaching_riskclass_Change = %f\n", leaching_riskclass_Change)
logging.debug("leaching_riskclassNo = %f\n", leaching_riskclassNo)

if leaching_riskclassNo > 5:
    w.warn('Leaching_riskclassNo > 5. Was set to 5. Please check details.')
    stderr.flush()  # show warning immediately
    leaching_riskclassNo = 5
elif leaching_riskclassNo < 1:
    w.warn('Leaching_riskclassNo < 1. Was set to 1. Please check details.')
    stderr.flush()  # show warning immediately
    leaching_riskclassNo = 1

leaching_riskclass = 'risk class ' + str(leaching_riskclassNo)
logging.debug("leaching_riskclass = %s\n", leaching_riskclass)

# %% Computation of runoff risk factor ========================================

# compute water regime group
waterRegCode = waterRegimeCode(fi_soil_depth_cm, fi_soil_water_regime)
logging.debug("waterRegCode = %s\n", waterRegCode)

# determine risk class for humus- and skeleton-rich soils
if fi_humus_frac > 0.3:
    runoff_riskclassNo = 5  # fraction of humus > 30% => risk class = 5
elif fi_skeleton_frac > 0.5:
    runoff_riskclassNo = 1  # fraction of skeleton > 50% => risk class = 1

# determine risk factor depending on water regime group
elif waterRegCode in ['a', 'b', 'c', 'd', 'e']:
    runoff_riskclassNo = 2
elif waterRegCode in ['f', 'g', 'h', 'i', 'k', 'l', 'm', 'n']:
    runoff_riskclassNo = 3
elif waterRegCode in ['o', 'p', 's', 't', 'u']:
    runoff_riskclassNo = 4
elif waterRegCode in ['q', 'r', 'v', 'w', 'x', 'y', 'z']:
    runoff_riskclassNo = 5

else:
    runoff_riskclassNo = 3  # set default value
    w.warn(('Unexpected outcome while setting runoff_riskclassNo. '
            'runoff_riskclassNo was set to the default value 3. '
            'Please investigate the details.'))
    stderr.flush()  # show warning immediately

# compute change of risk factor by -1 / 0 / +1 depending on soil granulation
# default value 0, change only in "clear" cases (sand -> -1, clay -> +1)
runoff_riskclass_Change = 0
if granularityCodeTopSoil in ['T', 'tU']:
    runoff_riskclass_Change = 1
if granularityCodeTopSoil in ['S', 'IS', 'sL']:
    runoff_riskclass_Change = -1

if fi_soil_compacted_bool:
    runoff_riskclass_Change += 1

runoff_riskclassNo = runoff_riskclassNo + runoff_riskclass_Change
logging.debug("runoff_riskclass_Change = %d\n", runoff_riskclass_Change)
logging.debug("runoff_riskclassNo = %d\n", runoff_riskclassNo)

if runoff_riskclassNo > 5:
    runoff_riskclassNo = 5
elif runoff_riskclassNo < 1:
    runoff_riskclassNo = 1

# add 'risk class' so that it fits to the table entries
runoff_riskclass = 'risk class ' + str(runoff_riskclassNo)
logging.debug("runoff_riskclass = %s\n", runoff_riskclass)

# %% P2O5 fertilisation =======================================================

# kg P2O5 from fertilisation is used to correct the average P leaching and runoff
# in kg P by dimensionless fertilisation factors

# liquid manure
kgP2O5_from_fert_lman = sum(lman_kg_P2O5)
# solid manure
kgP2O5_from_fert_sman = sum(sman_kg_P2O5)
# compost
kgP2O5_from_compost = sum(compost_kg_P2O5)
# sewage
kgP2O5_from_sewage = sum(sewage_kg_P2O5)
# other organic manure
kgP2O5_from_manu_org = sum(manu_org_kg_P2O5)
# mineral fertilisers
kgP2O5_from_min_fert = sum(fert_kg_P2O5)

# %% P emissions from surface runoff ==========================================

# runoff_riskclass has been computed above
# the runoff_riskfactor is implemented as a look-up table

# Hint: A German translation is necessary, as the look-up table gives
# the names in German, while the entry via the web interface is in English
# (-> variable 'landUse_type_Deutsch').

flow_path_factor = tab_flow_path.loc[fi_terrain_flow_dist_m,
                                     'flow_path_factor']
slope_shape_factor = tab_slope_shape.loc[fi_slope_shape,
                                         'slope_shape_factor']
P2O5_fertilizing_factor1 = 1 + (0.2 * kgP2O5_from_min_fert / (area_year) +
                                0.7 * (kgP2O5_from_fert_lman
                                       + kgP2O5_from_sewage)
                                / (area_year)
                                + 0.4 * (kgP2O5_from_fert_sman +
                                         kgP2O5_from_compost +
                                         kgP2O5_from_manu_org)
                                / (area_year)) / 80.0
# kg P2O5 from fertiliser/manure per ha per year divided by 80 kg P2O5 per ha per year

drainage_factor1 = tab_drainage_distance.loc[drainage_dist_c,
                                             'drainage_distance_factor_1']
# P_test_factor
P_test_factor_dict = {'001 A': 0.8, '002 B': 0.9, '003 C': 1.0,
                      '004 D': 1.2, '005 E': 1.4, '000 0': 1.0}
P_test_factor = P_test_factor_dict[fi_Psupply]

runoff_riskfactor = tab_risk.loc[runoff_riskclass,
                                 'runoff_risk_factor']
# P runoff, initial [kg P/ha/year]
runoff_kgPphapy_initial = tab_land_use.loc[land_use,
                                           'Initial value for P runoff']
# average P runoff [kg P/crop]
runoff_kgP_average = runoff_kgPphapy_initial * area_year
# total P runoff [kgP/crop]

if fi_slope_frac > 0.03:
    runoff_kgP_total = (runoff_kgP_average * runoff_riskfactor
                        * slope_shape_factor * flow_path_factor
                        * (1 + 0.1 * fi_outside_water_inflow_bool)
                        * (1 + 0.1 * fi_slope_water_discharge_bool)
                        * drainage_factor1 * P2O5_fertilizing_factor1
                        * P_test_factor)
else:
    runoff_kgP_total = 0  # no P emissions through runoff (slope < 3°)
logging.info('P2O5 fertilising factor 2: %.4f', P2O5_fertilizing_factor1)
logging.info('runoff risk factor: %d', runoff_riskfactor)
logging.info('runoff P initial: %.4f kg P / ha / year', runoff_kgPphapy_initial)
logging.info('runoff P average: %.4f kg P / crop', runoff_kgP_average)
logging.info('runoff P total: %.4f kg P / crop', runoff_kgP_total)
logging.info('')

# %% P emissions from leaching to groundwater =================================

P2O5_fertilizing_factor2 = 1 + (0.2 * (kgP2O5_from_fert_lman +
                                       kgP2O5_from_sewage) / area_year) / 80.0
# kg P2O5 from fertiliser/manure per ha per year divided by 80 kg P2O5 per ha per year

leaching_riskfactor = tab_risk.loc[leaching_riskclass, 'leaching_risk_factor']
# initial P leaching [kg P/ha/year]
leaching_kgPphapy_initial = tab_land_use.loc[land_use,
                                             'Initial value for P leaching']
# average P leaching [kg P/crop]
leaching_kgP_average = leaching_kgPphapy_initial * area_year

# actual P leaching [kg P/crop]
em_kgP_leachingWater_field = (leaching_kgP_average * leaching_riskfactor
                              * P2O5_fertilizing_factor2
                              * P_test_factor) * (1.0-fi_drai_frac)

logging.info('P2O5 fertilising factor 1: %.4f', P2O5_fertilizing_factor2)
logging.info('leaching risk factor: %d', leaching_riskfactor)
logging.info('P leaching initial: %.4f kg P / ha / year', leaching_kgPphapy_initial)
logging.info('P leaching average: %.4f kg P / crop', leaching_kgP_average)
logging.info('P leaching to ground water: %.4f kg P', em_kgP_leachingWater_field)
logging.info('')

# %% P emissions from drainage ================================================

# drainage fraction: no drainage: 1, full drainage: 6
# P in drainage [kg P/crop]
drainage_kgP_total = (leaching_kgP_average
                      * leaching_riskfactor
                      * P2O5_fertilizing_factor2
                      * P_test_factor
                      * (fi_drai_frac*6))

logging.info('drainage P total [kg P / crop]: %.4f', drainage_kgP_total)
logging.info('')

# %% P emissions from soil erosion ============================================

drainage_factor2 = tab_drainage_distance.loc[drainage_dist_c,
                                             'drainage_distance_factor_2']

# estimated P emissions to surface water from soil erosion [kg per year per ha]
eros_kgPpypha = (fi_eros_kgpypha*drainage_factor2
                 * fi_soil_mgPpkg*Factors.mg2kg
                 * tab_pars['Value']['soil_eros_enrichment']
                 )

# estimated P emissions to surface water from soil erosion [kg]
eros_kgP = eros_kgPpypha * area_year
logging.info('P from erosion: %.4f kg P', eros_kgP)
logging.info('')

# %% output ===================================================================

# (w) Phosphates (PO4 3-, HPO4--, H2PO4-, H3PO4) [kg]
c_e_water_kgPO4 = Factors.kgP2kgPO4 * (drainage_kgP_total + runoff_kgP_total)
out.c_e_water_kgPO4 = c_e_water_kgPO4
# (w) Phosphorus (P) [kg]
out.c_P_eros_kgP = eros_kgP
# (wg) Phosphates (PO4 3-, HPO4--, H2PO4-, H3PO4)
c_e_wg_PO4 = Factors.kgP2kgPO4 * em_kgP_leachingWater_field
out.c_e_wg_PO4 = c_e_wg_PO4

# %% end sequence =============================================================

end = dt.datetime.now(tz=None)
logging.info('End SALCAphosphorus')
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
