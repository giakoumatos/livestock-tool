# -*- coding: utf-8 -*-
"""
File name: SALCAprep_bd_crop.py
Created on Mon May 13 17:37:05 2024

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script collects and transforms the input data intended for the
    SALCAbiodiversity horticultural extension (SALCAbd_horti.py). 
    If there is no need for an assessment of biodiversity on horticultural crops, 
    this module (as well as SALCAbd_horti) can be excluded from a SALCAfuture
    project, which leads to a more simplified data entry form without all these
    additional biodiversity data inputs.

Calculation level:
    Crop

Related script:
    SALCAbd_horti.py, SALCAbd_farm.py
"""

# %% import modules ===========================================================
import datetime as dt
import json as js
import logging
from importlib import reload

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAprep bd_crop'
logging.info('')
logging.info('Start: %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes and parameters ============================================

# %% define functions =========================================================

# %% input ====================================================================
in_crop_code = ctx.crop[2]  # crop definition name, python name
in_crop_id = ctx.crop[0]  # id of the crop

# %% calculation ==============================================================
# Setup treatment dictionary
treatment_bd = {
    'crop': {},  # only stores the python name of the crop
    'crop_id': {},  # only stores the id of the crop
    'c_cover_nets_tents': {},
    'c_fences_scaffolds': {},
    'c_ppp_insects': {},
    'c_ppp_rodents': {},
    'c_ppp_beneficials': {},
    'c_ppp_molluscs': {},
    'c_ppp_drift_red_equip': {},
    'c_ppp_drift_red_tech': {},
    'c_ppp_beneficials_structures': {},
    'c_maint_wood_leaves': {},
    'c_maint_auxi_prod': {},
    'c_ppp_greening': {},
    'c_ppp_weed_cover': {},
    'c_foliage_thinning': {},
    'c_fruit_thinning': {},
    'c_tree_shaping': {},
    'c_wood_cuts': {},
    'c_frost_equip': {},
    'c_vine_lifting': {},
    'c_vine_trimming': {},
    # list bd variables to ensure matching with the corresponding crop_id later on, on farm level
    'c_bd_frost_coats': inp.c_bd_frost_coats,
    'c_bd_mice_fence_orch': inp.c_bd_mice_fence_orch,
    'c_bd_mice_fence_root': inp.c_bd_mice_fence_root,
    'c_bd_repellents': inp.c_bd_repellents,
    'c_bd_alternance_interrow': inp.c_bd_alternance_interrow,
    'c_bd_disbudding': inp.c_bd_disbudding,
    'c_bd_suckering_trunk': inp.c_bd_suckering_trunk,
    'c_bd_suckering_head': inp.c_bd_suckering_head,
    'c_bd_suckering_manual': inp.c_bd_suckering_manual,
    'c_bd_suckering_chemical': inp.c_bd_suckering_chemical,
    'c_bd_suckering_mechanical': inp.c_bd_suckering_mechanical,
    'c_bd_vege_grho_bool': inp.c_bd_vege_grho_bool
}

# setup empty lits for the different entries.
# in a second step, they are filled with the entries from the treatment events.
treatment_bd['crop'] = in_crop_code
treatment_bd['crop_id'] = in_crop_id
treatment_bd['c_cover_nets_tents']['c_01_mesh_size'] = []
treatment_bd['c_cover_nets_tents']['c_02_cover_dimension'] = []
treatment_bd['c_cover_nets_tents']['c_03_cover_duration'] = []
treatment_bd['c_fences_scaffolds']['c_01_material'] = []
treatment_bd['c_fences_scaffolds']['c_02_sheaths'] = []
treatment_bd['c_ppp_insect_traps'] = []
treatment_bd['c_ppp_rodent_control'] = []
treatment_bd['c_ppp_beneficials'] = []
treatment_bd['c_ppp_mollusc_control'] = []
treatment_bd['c_ppp_drift_red_equip'] = []
treatment_bd['c_ppp_drift_red_tech'] = []
treatment_bd['c_ppp_beneficials_structures'] = []
treatment_bd['c_maint_wood_leaves']['c_02_wood_leaves'] = []
treatment_bd['c_maint_wood_leaves']['row_interrow'] = []
treatment_bd['c_maint_auxi_prod']['c_02_auxi_prod'] = []
treatment_bd['c_maint_auxi_prod']['row_interrow'] = []
treatment_bd['c_ppp_greening']['c_02_green_type'] = []
treatment_bd['c_ppp_greening']['c_03_green_duration'] = []
treatment_bd['c_ppp_greening']['c_04_green_seeding'] = []
treatment_bd['c_ppp_greening']['c_03_date_season'] = []
treatment_bd['c_ppp_greening']['row_interrow'] = []
treatment_bd['c_ppp_weed_cover']['c_02_weed_cover'] = []
treatment_bd['c_ppp_weed_cover']['row_interrow'] = []
treatment_bd['c_foliage_thinning']['c_01_thinning_type'] = []
treatment_bd['c_foliage_thinning']['c_03_date_month'] = []
treatment_bd['c_fruit_thinning']['c_01_fr_thinning_type'] = []
treatment_bd['c_fruit_thinning']['c_02_vine_thinning_type'] = []
treatment_bd['c_fruit_thinning']['c_03_date_month'] = []
treatment_bd['c_tree_shaping']['c_01_pruning_bool'] = []
treatment_bd['c_tree_shaping']['c_02_education_system_orch'] = []
treatment_bd['c_tree_shaping']['c_02_education_system_vine'] = []
treatment_bd['c_tree_shaping']['c_03_date_month'] = []
treatment_bd['c_wood_cuts']['c_01_woodcut_type'] = []
treatment_bd['c_wood_cuts']['c_02_wound_bool'] = []
treatment_bd['c_wood_cuts']['c_03_date_month'] = []
treatment_bd['c_frost_equip'] = []
treatment_bd['c_vine_lifting']['c_01_lifting_type'] = []
treatment_bd['c_vine_lifting']['c_02_lifting_rate'] = []
treatment_bd['c_vine_trimming']['c_01_trimming_type'] = []
treatment_bd['c_vine_trimming']['c_02_trimming_rate'] = []

# distribute the entries of the events into the treatment dictionary
for value in inp.get_events('c_cover_nets_tents'):
    treatment_bd['c_cover_nets_tents']['c_01_mesh_size'].append(
        value['c_01_mesh_size'])
    treatment_bd['c_cover_nets_tents']['c_02_cover_dimension'].append(
        value['c_02_cover_dimension'])
    treatment_bd['c_cover_nets_tents']['c_03_cover_duration'].append(
        value['c_03_cover_duration'])
for value in inp.get_events('c_fences_scaffolds'):
    treatment_bd['c_fences_scaffolds']['c_01_material'].append(
        value['c_01_material'])
    treatment_bd['c_fences_scaffolds']['c_02_sheaths'].append(
        value['c_02_sheaths'])
for value in inp.get_events('c_ppp_insects'):
    treatment_bd['c_ppp_insect_traps'].append(
        value['c_01_insect_traps'])
for value in inp.get_events('c_ppp_rodents'):
    treatment_bd['c_ppp_rodent_control'].append(
        value['c_01_rodent_control'])
for value in inp.get_events('c_ppp_beneficials'):
    treatment_bd['c_ppp_beneficials'].append(
        value['c_01_beneficials'])
for value in inp.get_events('c_ppp_molluscs'):
    treatment_bd['c_ppp_mollusc_control'].append(
        value['c_01_mollusc_control'])
for value in inp.get_events('c_ppp_drift_red_equip'):
    treatment_bd['c_ppp_drift_red_equip'].append(
        value['c_01_drift_red_equip'])
for value in inp.get_events('c_ppp_drift_red_tech'):
    treatment_bd['c_ppp_drift_red_tech'].append(
        value['c_01_drift_red_tech'])
for value in inp.get_events('c_ppp_beneficials_structures'):
    treatment_bd['c_ppp_beneficials_structures'].append(
        value['c_01_beneficials_structures'])
for value in inp.get_events('c_maint_wood_leaves'):
    treatment_bd['c_maint_wood_leaves']['c_02_wood_leaves'].append(
        value['c_02_wood_leaves'])
    # Is the treatment valid for row and/or interrow?
    if value['c_98_row_valid'] == True:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_maint_wood_leaves']['row_interrow'].append('both')
        else:
            treatment_bd['c_maint_wood_leaves']['row_interrow'].append('row')
    else:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_maint_wood_leaves']['row_interrow'].append('interrow')
        else:
            treatment_bd['c_maint_wood_leaves']['row_interrow'].append('none')
for value in inp.get_events('c_maint_auxi_prod'):
    treatment_bd['c_maint_auxi_prod']['c_02_auxi_prod'].append(
        value['c_02_auxi_prod'])
    # Is the treatment valid for row and/or interrow?
    if value['c_98_row_valid'] == True:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_maint_auxi_prod']['row_interrow'].append('both')
        else:
            treatment_bd['c_maint_auxi_prod']['row_interrow'].append('row')
    else:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_maint_auxi_prod']['row_interrow'].append('interrow')
        else:
            treatment_bd['c_maint_auxi_prod']['row_interrow'].append('none')
for value in inp.get_events('c_ppp_greening'):
    treatment_bd['c_ppp_greening']['c_02_green_type'].append(
        value['c_02_green_type'])
    treatment_bd['c_ppp_greening']['c_03_green_duration'].append(
        value['c_03_green_duration'])
    treatment_bd['c_ppp_greening']['c_04_green_seeding'].append(
        value['c_04_green_seeding'])
    treatment_bd['c_ppp_greening']['c_03_date_season'].append(
        value['c_03_date_season'])
    # Is the treatment valid for row and/or interrow?
    if value['c_98_row_valid'] == True:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_ppp_greening']['row_interrow'].append('both')
        else:
            treatment_bd['c_ppp_greening']['row_interrow'].append('row')
    else:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_ppp_greening']['row_interrow'].append('interrow')
        else:
            treatment_bd['c_ppp_greening']['row_interrow'].append('none')
for value in inp.get_events('c_ppp_weed_cover'):
    treatment_bd['c_ppp_weed_cover']['c_02_weed_cover'].append(
        value['c_02_weed_cover'])
    # Is the treatment valid for row and/or interrow?
    if value['c_98_row_valid'] == True:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_ppp_weed_cover']['row_interrow'].append('both')
        else:
            treatment_bd['c_ppp_weed_cover']['row_interrow'].append('row')
    else:
        if value['c_99_interrow_valid'] == True:
            treatment_bd['c_ppp_weed_cover']['row_interrow'].append('interrow')
        else:
            treatment_bd['c_ppp_weed_cover']['row_interrow'].append('none')
for value in inp.get_events('c_foilage_thinning'):
    treatment_bd['c_foliage_thinning']['c_01_thinning_type'].append(
        value['c_01_thinning_type'])
    treatment_bd['c_foliage_thinning']['c_03_date_month'].append(
        value['c_03_date_month'])
for value in inp.get_events('c_fruit_thinning'):
    treatment_bd['c_fruit_thinning']['c_01_fr_thinning_type'].append(
        value['c_01_fr_thinning_type'])
    treatment_bd['c_fruit_thinning']['c_02_vine_thinning_type'].append(
        value['c_02_vine_thinning_type'])
    treatment_bd['c_fruit_thinning']['c_03_date_month'].append(
        value['c_03_date_month'])
for value in inp.get_events('c_tree_shaping'):
    treatment_bd['c_tree_shaping']['c_01_pruning_bool'].append(
        value['c_01_pruning_bool'])
    treatment_bd['c_tree_shaping']['c_02_education_system_orch'].append(
        value['c_02_education_system_orch'])
    treatment_bd['c_tree_shaping']['c_02_education_system_vine'].append(
        value['c_02_education_system_vine'])
    treatment_bd['c_tree_shaping']['c_03_date_month'].append(
        value['c_03_date_month'])
for value in inp.get_events('c_wood_cuts'):
    treatment_bd['c_wood_cuts']['c_01_woodcut_type'].append(
        value['c_01_woodcut_type'])
    treatment_bd['c_wood_cuts']['c_02_wound_bool'].append(
        value['c_02_wound_bool'])
    treatment_bd['c_wood_cuts']['c_03_date_month'].append(
        value['c_03_date_month'])
for value in inp.get_events('c_frost_equip'):
    treatment_bd['c_frost_equip'].append(
        value['c_01_frost_dmg_equip'])
for value in inp.get_events('c_vine_lifting'):
    treatment_bd['c_vine_lifting']['c_01_lifting_type'].append(
        value['c_01_lifting_type'])
    treatment_bd['c_vine_lifting']['c_02_lifting_rate'].append(
        value['c_02_lifting_rate'])
for value in inp.get_events('c_vine_trimming'):
    treatment_bd['c_vine_trimming']['c_01_trimming_type'].append(
        value['c_01_trimming_type'])
    treatment_bd['c_vine_trimming']['c_02_trimming_rate'].append(
        value['c_02_trimming_rate'])
    
# %% output ===================================================================
out.c_salcaprep_bd = js.dumps(treatment_bd)


# %% end sequence =============================================================
end = dt.datetime.now(tz=None)
logging.info('End  %s' + module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
