# -*- coding: utf-8 -*-
"""
File name: SALCAprep_crop.py
Created on Mon May 11 07:01:54 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script collects and prepares data on crop level to serve other modules,
    especially the ones running on calculation levels other than crop but still
    need crop data as input.

Calculation level:
    Crop

Related script:
    SALCAprep_farm.py, SALCAphosphor.py, SALCAnitrate_field.py, SALCAheavymetal_crop.py,
    SALCAsoilquality_crop.py, SALCAsoilquality_farm.py, SALCAmapping_crop.py,
    SALCAmapping_farm.py, SALCAmapping_ppp.py, SALCAfield_crop.py, SALCAfield_field.py,
    SALCAerosion_field.py, SALCAbd_farm.py, SALCAbd_horti.py, SALCAanmial_farm.py,
    SALCAanimal_agrammon.py
"""

# %% import modules ===========================================================
import datetime as dt
import json as js
import re
from calendar import isleap
import logging
import warnings as w
from importlib import reload
from sys import stderr

import pandas as pd

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAprep crop'
logging.info('')
logging.info('Start: %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

def warning_format(message, category, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define classes and parameters ============================================

maco_id_error = "Machine combination could not be identified. Unknown ID: "
maco_id_error_p2 = """Please ensure that the ID corresponds to a machine combination ID on farm level or
use 'keine_befahrung' as a dummy."""

# %% define functions =========================================================
def treatment_output(treatment):
    ''' 
    Function to convert the dates in the date_dt entry of the given treatment
    dictionary from the dt.date format to a string and return the treatment
    dictionary as a string.
    '''
    import copy
    copy = copy.deepcopy(treatment)
    for i in range(len(copy['date_dt'])):
        # The dt.date format can't be dumped into a string.
        copy['date_dt'][i] = copy['date_dt'][i].strftime('%Y-%m-%d')
    return copy

# %% input ====================================================================
in_crop_code = ctx.crop[2]  # crop definition name, python name
in_crop_id = ctx.crop[0]  # id of the crop
# last harvest date
last_harv_date_str = inp.c_prha_date
# pre-harvest sowing
c_sowi_pre_harv = inp.c_sowi_pre_harv
# start date of the evaluation of the farm
start_evaluation = dt.datetime.strptime(inp.f_start_evaluation, '%Y-%m-%d')
# end date of the evaluation of the farm
end_evaluation = dt.datetime.strptime(inp.f_end_evaluation, '%Y-%m-%d')
# only for permanent crops: end date of the permanent crop, if ended within the
# evaluation period.
c_perma_culture_end_date_str = inp.c_perma_culture_end_date
# for permanent crops: older than 9 months at the start of the evaluation?
c_gras9_bool = inp.c_gras9_bool
# incorporation of the crop residues (SALCA-BD)
c_hare_inco_bool = inp.c_hare_inco_bool
# rodent regulation (SALCA-BD)
c_rodent_regulation = inp.c_rodent_regulation

c_ca_ha = inp.c_ca_ha  # area occupied by the crop, in ha

# load machine combinations present on the farm (for soil treatment intensity)
mc_dict = pd.DataFrame(inp.get_events('treatment_maco_event'))

# load the crop table
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )
#load the fert market table
tab_fert_market = pd.DataFrame(data=js.loads(inp.tab_fert_market)['data'],
                         columns=js.loads(inp.tab_fert_market)['columns'],
                         index=js.loads(inp.tab_fert_market)['index']
                         )
tab_fert_market = tab_fert_market.set_index('NameEN')
#load machinery table
tab_mach = pd.DataFrame(data=js.loads(inp.tab_mach)['data'],
                           columns=js.loads(inp.tab_mach)['columns'],
                           index=js.loads(inp.tab_mach)['index'])

# %% calculation ==============================================================
# Setup treatment dictionary
treatment = {
    'crop': {},  # only stores the python name of the crop
    'crop_id': {},  # only stores the id of the crop
    'soil': {},
    'sowi': {},
    'fert': {},
    'ppp':  {},
    'maint': {},
    'lman': {},
    'sman': {},
    'harv': {},
    'harv_sepr': {},
    'irri': {},
    'grazing':{}
}

# setup empty lists for the different entries.
# in a second step, they are filled with the entries from the treatment events.
treatment['crop'] = in_crop_code
treatment['crop_id'] = in_crop_id
treatment['soil']['date'] = []
treatment['soil']['MC'] = []
treatment['soil']['intense_trea'] = []
treatment['soil']['looseness_before'] = []
treatment['soil']['looseness_after'] = []
treatment['soil']['external_exec'] = []
treatment['soil']['row_interrow'] = []
treatment['sowi']['date'] = []
treatment['sowi']['MC'] = []
treatment['sowi']['type'] = []
treatment['sowi']['amount_kg'] = []
treatment['sowi']['seedling_amount_p'] = []
treatment['sowi']['frac_impo'] = []
treatment['sowi']['intense_trea'] = []
treatment['sowi']['looseness_before'] = []
treatment['sowi']['looseness_after'] = []
treatment['sowi']['external_exec'] = []
treatment['fert']['date'] = []
treatment['fert']['MC'] = []
treatment['fert']['variable'] = []
treatment['fert']['amount_kg'] = []
treatment['fert']['external_exec'] = []
treatment['fert']['salcabd_type'] = []
treatment['fert']['row_interrow'] = []
treatment['ppp']['date'] = []
treatment['ppp']['MC'] = []
treatment['ppp']['variable'] = []
treatment['ppp']['amount_kg'] = []
treatment['ppp']['external_exec'] = []
treatment['ppp']['area_treated_perc'] = []
treatment['ppp']['type_fungicide'] = []
treatment['ppp']['type_insecticide'] = []
treatment['ppp']['type_bactericide'] = []
treatment['ppp']['row_interrow'] = []
treatment['maint']['date'] = []
treatment['maint']['MC'] = []
treatment['maint']['external_exec'] = []
treatment['maint']['variable'] = []
treatment['maint']['row_interrow'] = []
treatment['lman']['date'] = []
treatment['lman']['MC'] = []
treatment['lman']['variable'] = []
treatment['lman']['amount_m3'] = []
treatment['lman']['evening'] = []
treatment['lman']['practice'] = []
treatment['lman']['external_exec'] = []
treatment['lman']['row_interrow'] = []
treatment['sman']['date'] = []
treatment['sman']['MC'] = []
treatment['sman']['variable'] = []
treatment['sman']['amount_t'] = []
treatment['sman']['incorporation'] = []
treatment['sman']['external_exec'] = []
treatment['sman']['row_interrow'] = []
treatment['harv']['date'] = []
treatment['harv']['MC'] = []
treatment['harv']['MC_ff'] = []
treatment['harv']['date_ff'] = []
treatment['harv']['amount_kg'] = []
treatment['harv']['intense_trea'] = []
treatment['harv']['cutting_level'] = []
treatment['harv']['harv_expo'] = []
treatment['harv']['external_exec'] = []
treatment['harv']['value_rare_cut'] = []
treatment['harv']['harv_type'] = []
treatment['harv_sepr']['date'] = []
treatment['harv_sepr']['MC'] = []
treatment['harv_sepr']['MC_ff'] = []
treatment['harv_sepr']['date_ff'] = []
treatment['harv_sepr']['amount_kg'] = []
treatment['harv_sepr']['harv_expo'] = []
treatment['harv_sepr']['external_exec'] = []
treatment['irri']['amount_m3'] = []
treatment['irri']['type'] = []
treatment['irri']['type_detail'] = []
treatment['irri']['area_perc'] = []
treatment['irri']['duration'] = []
treatment['irri']['row_interrow'] = []
treatment['grazing']['date'] = []
treatment['grazing']['days'] = []
treatment['grazing']['LU'] = []
treatment['grazing']['animal_type'] = []
treatment['grazing']['row_interrow'] = []

# distribute the entries of the events into the treatment dictionary
for value in inp.get_events('treatment_soil'):
    treatment['soil']['date'].append(
        value['c_01_trea_date'])
    treatment['soil']['MC'].append(
        value['c_02_trea_maco'])
    treatment['soil']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # get the machines used
    if value['c_02_trea_maco'] not in mc_dict['f_maco_id'].values:
        raise ValueError(maco_id_error + value['c_02_trea_maco'], maco_id_error_p2)
    else:
        mach_back = mc_dict['f_maco_back'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
        mach_front = mc_dict['f_maco_front'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
    # get the treatment intensity from the machines used
    intensity_back = tab_mach['Intensive Bodenbearbeitung'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    intensity_front = tab_mach['Intensive Bodenbearbeitung'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    if intensity_back == 1 or intensity_front == 1:
        # intensive soil treatment is recognized for SALCAnitrate_field
        treatment['soil']['intense_trea'].append(True)
    else:
        treatment['soil']['intense_trea'].append(False)
    # get the degree of soil looseness before and after treatment from the machines used:
    # the initial soil treatments usually loosen the soil (from solid to loose)
    # secondary soil treatments keep the soil loose (and prepare the seeding bed)
    # if reduced soil treatment is applied, the soil looseness stays solid.
    soilstate_back = tab_mach['SQ soil before treatment'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    loose_back = tab_mach['SQ soil after treatment'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    soilstate_front = tab_mach['SQ soil before treatment'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    loose_front = tab_mach['SQ soil after treatment'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    if soilstate_back == 'locker' or soilstate_front == 'locker':
        treatment['soil']['looseness_before'].append('loose')
    else:
        treatment['soil']['looseness_before'].append('firm')
    if loose_back == 'locker' or loose_front == 'locker':
        treatment['soil']['looseness_after'].append('loose')
    else:
        treatment['soil']['looseness_after'].append('firm')
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['soil']['row_interrow'].append('both')
            else:
                treatment['soil']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['soil']['row_interrow'].append('interrow')
            else:
                treatment['soil']['row_interrow'].append('none')
    else:
        treatment['soil']['row_interrow'].append('none')
        
for value in inp.get_events('treatment_sowi'):
    treatment['sowi']['date'].append(
        value['c_01_trea_date'])
    treatment['sowi']['MC'].append(
        value['c_02_trea_maco'])
    treatment['sowi']['type'].append(
        value['c_05_trea_type_sowi_bool'])
    treatment['sowi']['amount_kg'].append(
        value['c_04_quan_kg'])
    treatment['sowi']['seedling_amount_p'].append(
        value['c_04_quan_seedling_p'])
    treatment['sowi']['frac_impo'].append(
        value['c_06_frac_impo'])
    treatment['sowi']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # get the machines used
    if value['c_02_trea_maco'] not in mc_dict['f_maco_id'].values:
        if value['c_02_trea_maco'] == 'keine_befahrung':
            mach_back = "000_no_back"
            mach_front = "000_no_front"
        else:
            raise ValueError(maco_id_error + value['c_02_trea_maco'], maco_id_error_p2)
    else:
        mach_back = mc_dict['f_maco_back'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
        mach_front = mc_dict['f_maco_front'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
    # get the treatment intensity from the machines used
    intensity_back = tab_mach['Intensive Bodenbearbeitung'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    intensity_front = tab_mach['Intensive Bodenbearbeitung'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    if intensity_back == 1 or intensity_front == 1:
        # intensive soil treatment during sowing is recognized for SALCAnitrate_field
        treatment['sowi']['intense_trea'].append(True)
    else:
        treatment['sowi']['intense_trea'].append(False)
    # get the degree of soil looseness before and after treatment from the machines used:
    # for common sowing techniques, soil looseness is loose (locker) before and
    # after sowing. for combined machines it is firm (fest) before and loose
    # after. And for soil friendly sowing technique, soil looseness stays firm.
    soilstate_back = tab_mach['SQ soil before treatment'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    loose_back = tab_mach['SQ soil after treatment'] \
        [tab_mach['PythonName'] == mach_back[4:]].values[0]
    soilstate_front = tab_mach['SQ soil before treatment'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    loose_front = tab_mach['SQ soil after treatment'] \
        [tab_mach['PythonName'] == mach_front[4:]].values[0]
    if soilstate_back == 'locker' or soilstate_front == 'locker':
        treatment['sowi']['looseness_before'].append('loose')
    else:
        treatment['sowi']['looseness_before'].append('firm')
    if loose_back == 'locker' or loose_front == 'locker':
        treatment['sowi']['looseness_after'].append('loose')
    else:
        treatment['sowi']['looseness_after'].append('firm')
        
for value in inp.get_events('treatment_fert'):    
    # factors for multiplications
    amount_kg_N = tab_fert_market['% N'][value['c_04_fert_vari']]/100 * value['c_04_quan_kg']
    amount_kg_P2O5 = tab_fert_market['% P2O5'][value['c_04_fert_vari']]/100 * value['c_04_quan_kg']
    amount_kg_K2O = tab_fert_market['% K2O'][value['c_04_fert_vari']]/100 * value['c_04_quan_kg']
    amount_kg_Mg = tab_fert_market['% Mg'][value['c_04_fert_vari']]/100 * value['c_04_quan_kg']
    amount_kg_Ca = tab_fert_market['%Ca'][value['c_04_fert_vari']]/100 * value['c_04_quan_kg']
    # split events in multiple events for different emissions
    # When we model single applications of fertiliser mixes by using multiple events
    # for individual nutrients, we usually use fertilizer_multiplication as a dummy
    # machinery combination.
    
    # When we model applications of market fertilisers, these are split into single
    # nutrients and additional dummy events are created here. These dummy events get
    # fertilizer_multiplication as the machinery combination. In this case, the 
    # fertiliser types for SALCA-BD are defined by the applied market fertiliser itself
    # and therefore the created dummy events do not have a salcabd_type.
    emissions = [amount_kg_N,amount_kg_P2O5,amount_kg_K2O,amount_kg_Mg, amount_kg_Ca]
    columns = ['N-mapping','P-mapping','K-mapping','Mg-mapping','Ca-mapping']
    count = 0
    for i, emission in enumerate(emissions):
        if emission > 0:
            if count == 0:
                treatment['fert']['MC'].append(
                    value['c_02_trea_maco'])
                treatment['fert']['salcabd_type'].append(int(
                    tab_fert_market['SALCA-BD_mapping'][value['c_04_fert_vari']]))
            else:
                treatment['fert']['MC'].append(
                    'fertilizer_multiplication')
                treatment['fert']['salcabd_type'].append(int(0))
            
            treatment['fert']['date'].append(
                value['c_01_trea_date'])
            treatment['fert']['variable'].append(
                tab_fert_market[columns[i]][value['c_04_fert_vari']])
            treatment['fert']['amount_kg'].append(
                emission)
            treatment['fert']['external_exec'].append(
                value['c_09_trea_ext_bool'])
            # For vineyard and orchard: Is the treatment valid for row and/or interrow?
            if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
                if value['c_98_row_valid'] == True:
                    if value['c_99_interrow_valid'] == True:
                        treatment['fert']['row_interrow'].append('both')
                    else:
                        treatment['fert']['row_interrow'].append('row')
                else:
                    if value['c_99_interrow_valid'] == True:
                        treatment['fert']['row_interrow'].append('interrow')
                    else:
                        treatment['fert']['row_interrow'].append('none')
            else:
                treatment['fert']['row_interrow'].append('none')
            count +=1
            
for value in inp.get_events('treatment_ppp'):
    treatment['ppp']['date'].append(
        value['c_01_trea_date'])
    treatment['ppp']['MC'].append(
        value['c_02_trea_maco'])
    treatment['ppp']['variable'].append(
        [value['c_03_ppp_vari1'],
        value['c_03_ppp_vari2'],
        value['c_03_ppp_vari3'],
        value['c_03_ppp_vari4'],
        value['c_03_ppp_vari5'],
        value['c_03_ppp_vari6'],
        value['c_03_ppp_vari7'],
        value['c_03_ppp_vari8']])
    treatment['ppp']['amount_kg'].append(
        [value['c_04_quan1_kg'],
        value['c_04_quan2_kg'],
        value['c_04_quan3_kg'],
        value['c_04_quan4_kg'],
        value['c_04_quan5_kg'],
        value['c_04_quan6_kg'],
        value['c_04_quan7_kg'],
        value['c_04_quan8_kg']])
    treatment['ppp']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    treatment['ppp']['area_treated_perc'].append(
        value['c_10_area_treated_perc'])
    if 'c_11_type_fungicide' in value.keys() and value['c_11_type_fungicide'] is not None:
        treatment['ppp']['type_fungicide'].append(
            value['c_11_type_fungicide'])
    else:
        treatment['ppp']['type_fungicide'].append(
            '001_none')
    if 'c_12_type_insecticide' in value.keys() and value['c_12_type_insecticide'] is not None:
        treatment['ppp']['type_insecticide'].append(
            value['c_12_type_insecticide'])
    else:
        treatment['ppp']['type_insecticide'].append(
            '004_unknown')
    if 'c_13_type_bactericide' in value.keys() and value['c_13_type_bactericide'] is not None:
        treatment['ppp']['type_bactericide'].append(
            value['c_13_type_bactericide'])
    else:
        treatment['ppp']['type_bactericide'].append(
            '001_none')
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['ppp']['row_interrow'].append('both')
            else:
                treatment['ppp']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['ppp']['row_interrow'].append('interrow')
            else:
                treatment['ppp']['row_interrow'].append('none')
    else:
        treatment['ppp']['row_interrow'].append('none')
for value in inp.get_events('treatment_maint'):
    treatment['maint']['date'].append(
        value['c_01_trea_date'])
    treatment['maint']['MC'].append(
        value['c_02_trea_maco'])
    treatment['maint']['variable'].append(
        value['c_03_trea_maint_vari'])
    treatment['maint']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['maint']['row_interrow'].append('both')
            else:
                treatment['maint']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['maint']['row_interrow'].append('interrow')
            else:
                treatment['maint']['row_interrow'].append('none')
    else:
        treatment['maint']['row_interrow'].append('none')
for value in inp.get_events('treatment_manure_l'):
    treatment['lman']['date'].append(
        value['c_01_trea_date'])
    treatment['lman']['MC'].append(
        value['c_02_trea_maco'])
    treatment['lman']['variable'].append(
        'liquid_farm_manure')  # Label for type liquid farm manure
    treatment['lman']['amount_m3'].append(
        value['c_04_quan_m3'])
    treatment['lman']['evening'].append(
        value['c_08_trea_time_manu_bool'])
    treatment['lman']['practice'].append(
        value['c_07_trea_tech_manu'])
    treatment['lman']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['lman']['row_interrow'].append('both')
            else:
                treatment['lman']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['lman']['row_interrow'].append('interrow')
            else:
                treatment['lman']['row_interrow'].append('none')
    else:
        treatment['lman']['row_interrow'].append('none')
# add liquid organic manure treatments to the same treatment dictionary
# together with liquid farm manure treatments for common processing in modules
for value in inp.get_events('treatment_manu_org_l'):
    treatment['lman']['date'].append(
        value['c_01_trea_date'])
    treatment['lman']['MC'].append(
        value['c_02_trea_maco'])
    treatment['lman']['variable'].append(
        value['c_03_lman_vari'])
    treatment['lman']['amount_m3'].append(
        value['c_04_quan_m3'])
    treatment['lman']['evening'].append(
        value['c_08_trea_time_manu_bool'])
    treatment['lman']['practice'].append(
        value['c_07_trea_tech_manu'])
    treatment['lman']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['lman']['row_interrow'].append('both')
            else:
                treatment['lman']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['lman']['row_interrow'].append('interrow')
            else:
                treatment['lman']['row_interrow'].append('none')
    else:
        treatment['lman']['row_interrow'].append('none')
for value in inp.get_events('treatment_manure_s'):
    treatment['sman']['date'].append(
        value['c_01_trea_date'])
    treatment['sman']['MC'].append(
        value['c_02_trea_maco'])
    treatment['sman']['variable'].append(
        'solid_farm_manure')  # Label for type solid farm manure
    treatment['sman']['amount_t'].append(
        value['c_04_quan_t'])
    treatment['sman']['incorporation'].append(
        value['c_07_trea_inco_manu_h'])
    treatment['sman']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['sman']['row_interrow'].append('both')
            else:
                treatment['sman']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['sman']['row_interrow'].append('interrow')
            else:
                treatment['sman']['row_interrow'].append('none')
    else:
        treatment['sman']['row_interrow'].append('none')
# add solid organic manure treatments to the same treatment dictionary
# together with solid farm manure treatments for common processing in modules
for value in inp.get_events('treatment_manu_org_s'):
    treatment['sman']['date'].append(
        value['c_01_trea_date'])
    treatment['sman']['MC'].append(
        value['c_02_trea_maco'])
    treatment['sman']['variable'].append(
        value['c_03_sman_vari'])
    treatment['sman']['amount_t'].append(
        value['c_04_quan_t'])
    treatment['sman']['incorporation'].append(
        value['c_07_trea_inco_manu_h'])
    treatment['sman']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['sman']['row_interrow'].append('both')
            else:
                treatment['sman']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['sman']['row_interrow'].append('interrow')
            else:
                treatment['sman']['row_interrow'].append('none')
    else:
        treatment['sman']['row_interrow'].append('none')
for value in inp.get_events('treatment_harv'):
    treatment['harv']['date'].append(
        value['c_01_trea_date'])
    treatment['harv']['MC'].append(
        value['c_02_trea_maco'])
    if 'c_02_trea_maco_ff' in value.keys() and value['c_02_trea_maco_ff'] is not None:
        # divide string into list of items on comma separation
        macos = re.split(r'\,+\s?', value['c_02_trea_maco_ff'])
        macos = [item for item in macos if item != '']  # remove empty strings
        treatment['harv']['MC_ff'].extend(macos)
        treatment['harv']['date_ff'].extend([value['c_01_trea_date']] * len(macos))
    treatment['harv']['amount_kg'].append(
        value['c_04_quan_kg'])
    treatment['harv']['cutting_level'].append(
        value['c_07_trea_cutting_level'])
    treatment['harv']['harv_expo'].append(
        value['c_08_trea_harv_use'])
    treatment['harv']['external_exec'].append(
        value['c_09_trea_ext_bool'])
    treatment['harv']['value_rare_cut'].append(
        value['c_10_trea_rare_cut'])
    treatment['harv']['harv_type'].append(
        value['c_11_harv_type'])
    # get the treatment intensity from the machines used
    if value['c_02_trea_maco'] not in mc_dict['f_maco_id'].values:
        if value['c_02_trea_maco'] == 'keine_befahrung':
            intensity_back = 0
            intensity_front = 0
        else:
            raise ValueError(maco_id_error, value['c_02_trea_maco'], maco_id_error_p2)
    else:
        mach_back = mc_dict['f_maco_back'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
        mach_front = mc_dict['f_maco_front'] \
            [mc_dict['f_maco_id'] == value['c_02_trea_maco']].values[0]
        intensity_back = tab_mach['Intensive Bodenbearbeitung'] \
            [tab_mach['PythonName'] == mach_back[4:]].values[0]
        intensity_front = tab_mach['Intensive Bodenbearbeitung'] \
            [tab_mach['PythonName'] == mach_front[4:]].values[0]
    if intensity_back == 1 or intensity_front == 1:
        # intensive soil treatment during harvest is recognized for SALCAnitrate_field
        treatment['harv']['intense_trea'].append(True)
    else:
        treatment['harv']['intense_trea'].append(False)
for value in inp.get_events('treatment_harv_sepr'):
    treatment['harv_sepr']['date'].append(
        value['c_01_trea_date'])
    treatment['harv_sepr']['MC'].append(
        value['c_02_trea_maco'])
    if 'c_02_trea_maco_ff' in value.keys() and value['c_02_trea_maco_ff'] is not None:
        # divide string into list of items on comma separation
        macos = re.split(r'\,+\s?', value['c_02_trea_maco_ff'])
        macos = [item for item in macos if item != '']  # remove empty strings
        treatment['harv_sepr']['MC_ff'].extend(macos)
        treatment['harv_sepr']['date_ff'].extend([value['c_01_trea_date']] * len(macos))
    treatment['harv_sepr']['amount_kg'].append(
        value['c_04_quan_kg'])
    treatment['harv_sepr']['harv_expo'].append(
        value['c_08_trea_harv_use'])
    treatment['harv_sepr']['external_exec'].append(
        value['c_09_trea_ext_bool'])
# irrigation events
missingValue = []
for value in inp.get_events('c_irrigation'):
    treatment['irri']['amount_m3'].append(
        value['c_01_water_amount_m3'])
    treatment['irri']['type'].append(
        value['c_02_irri_type'])
    if 'c_03_irri_area_perc' in value:
        treatment['irri']['area_perc'].append(
            value['c_03_irri_area_perc'])
    else:
        missingValue.append('c_03_irri_area_perc')
    if 'c_04_irri_type_detail' in value:
        treatment['irri']['type_detail'].append(
            value['c_04_irri_type_detail'])
    else:
        missingValue.append('c_04_irri_type_detail')
    if 'c_05_irri_duration' in value:
        treatment['irri']['duration'].append(
            value['c_05_irri_duration'])
    else:
        missingValue.append('c_05_irri_duration')
    # Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value and 'c_99_interrow_valid' in value:
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['irri']['row_interrow'].append('both')
            else:
                treatment['irri']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['irri']['row_interrow'].append('interrow')
            else:
                treatment['irri']['row_interrow'].append('none')
    else:
        missingValue.append('c_98_row_valid')
        missingValue.append('c_99_interrow_valid')
    if missingValue != []:
        logging.info("************")
        w.warn("The following values are missing in the event c_irrigation:")
        stderr.flush()
        logging.info(missingValue)
        logging.info(value['event_context'])
        logging.info("************")
        missingValue = []

# grazing events
for value in inp.get_events('c_grazing'):
    treatment['grazing']['date'].append(
        value['c_01_past_date'])
    treatment['grazing']['days'].append(
        value['c_past_d'])
    treatment['grazing']['LU'].append(
        value['c_past_LU'])
    treatment['grazing']['animal_type'].append(
        value['c_past_LU_type'])
    # For vineyard and orchard: Is the treatment valid for row and/or interrow?
    if 'c_98_row_valid' in value.keys() and value['c_99_interrow_valid'] in value.keys():
        if value['c_98_row_valid'] == True:
            if value['c_99_interrow_valid'] == True:
                treatment['grazing']['row_interrow'].append('both')
            else:
                treatment['grazing']['row_interrow'].append('row')
        else:
            if value['c_99_interrow_valid'] == True:
                treatment['grazing']['row_interrow'].append('interrow')
            else:
                treatment['grazing']['row_interrow'].append('none')
    else:
        treatment['grazing']['row_interrow'].append('none')

# convert the dates of the treatments into dt.time
for key in treatment.keys():
    # no dates in treatment['crop']
    if key == 'crop' or key == 'crop_id' or key == 'irri':
        continue
    treatment[key]['date_dt'] = []
    # convert every date into date.dt and append it to the newly created list.
    for i, date in enumerate(treatment[key]['date']):
        treatment[key]['date_dt'].append(
            dt.datetime.strptime(date, '%Y-%m-%d'))


# %% time and areatime ========================================================
'''
The time span considered for the evaluation of the crop differs between open
arable area and grassland area. For arable area, the time between harvest of
the previous crop and crop harvest is evaluated. For permanent crops, start and
end date of the evaluation as set on farm level are used.
'''
# permanent crop (1) or open arable area (0)?
permanent_crop = tab_crops.loc[tab_crops['NameEN'] ==
                                 in_crop_code]['SQ Arable land or permanent culture'].values[0]
c_eros_permaculture = 0  # setup indicator for SALCAerosion

# For SALCAerosion, temporary ley counts as permanent grassland if it is older than 9 months.
set_ley = ['07_grassland_01_Ley_intensive_valley',
           '07_grassland_02_Ley_intensive_hill',
           '07_grassland_03_Ley_intensive_mountian',
           '07_grassland_04_Ley_medium_intensive_valley',
           '07_grassland_05_Ley_medium_intensive_hill',
           '07_grassland_06_Ley_medium_intensive_mountain'
           ]

# for open arable area
if permanent_crop == 0:
    # Check the presence of a harvest date.
    if treatment['harv']['date_dt'] == []:
        raise ValueError('No harvest date found for arable crop.')
    else:
        harv_date = max(treatment['harv']['date_dt'])
    # Check the presence of a sowing date.
    if treatment['sowi']['date_dt'] == [] and in_crop_code not in set_ley:
        raise ValueError('No sowing date found for arable crop.')
    # check, that the harvest date is in the evaluated period
    if harv_date > end_evaluation:
        raise ValueError(
            'Latest harvest date entered is after the end \n \
            date of the evaluation and can not be evaluated.')
    c_start = dt.datetime.strptime(last_harv_date_str, '%Y-%m-%d')
    c_end = harv_date
# for permanent_crop and for grassland ley
if permanent_crop == 1 or in_crop_code in set_ley:
    # if there is the harvest of the previous crop present, it is used as the
    # starting date of the evaluation. Otherwise, the evaluation is started at
    # the starting date of the evaluation of the farm. Harvest of the previous
    # crop must not be longer than 1 year before evaluation start.
    # 1 day is subtracted from start_evaluation to be consistent with last_harv_date
    # (period of the crop starts 1 day after last_harv_date or at the start_evaluation date).
    if last_harv_date_str == '':
        c_start = start_evaluation - dt.timedelta(days=1)
    else:
        last_harv_date = dt.datetime.strptime(last_harv_date_str, '%Y-%m-%d')
        if start_evaluation-last_harv_date <= dt.timedelta(days=365):
            c_start = last_harv_date
        else:
            c_start = start_evaluation - dt.timedelta(days=1)
    # if there is an end date of the permanent crop that is earlier than the
    # end date of the evaluation of the farm, this date is used as the end date
    # of the evaluation of the permanent crop.
    if c_perma_culture_end_date_str == '':
        c_end = end_evaluation
    else:
        c_perma_culture_end_date = dt.datetime.strptime(
            c_perma_culture_end_date_str, '%Y-%m-%d')
        if c_perma_culture_end_date < end_evaluation:
            c_end = c_perma_culture_end_date
        else:
            c_end = end_evaluation
    # indicate the crop as permaculture for SALCAerosion
    c_eros_permaculture = 1
    if in_crop_code in set_ley and c_gras9_bool == False:
        c_eros_permaculture = 0


# calculate duration as dt.timedelta between start and end date of the
# evaluation of the crop. Leap years are considered.
c_duration = c_end - c_start
diffyears = c_end.year - c_start.year
difference  = c_end - c_start.replace(c_end.year)
days_in_year = isleap(c_end.year) and 366 or 365
difference_in_years = diffyears + (difference.days + difference.seconds/86400.0)/days_in_year
# duration in number of days
c_duration_days = c_duration.days
# duration as the fraction of a year
c_duration_year = difference_in_years
# fraction of the year multiplied by area (ha) to area time (ha*a)
c_areatime = c_ca_ha * c_duration_year

# %% protective sowing ========================================================

# if there is no conventional sowing, the crop was sown with protective sowing
if 1 not in treatment['sowi']['type']:
    c_protective_sowi = 1
elif permanent_crop == 1:
    c_protective_sowi = 1
elif in_crop_code in set_ley and c_gras9_bool:
    c_protective_sowi = 1
else:
    c_protective_sowi = 0

# %% output ===================================================================
c_salcaprep = {
    # convert dt.date to string for js.dumps
    'crop_id': treatment['crop_id'],
    'crop_name': treatment['crop'],
    'tr_fert': treatment_output(treatment['fert']),
    'tr_harv': treatment_output(treatment['harv']),
    'tr_harv_sepr': treatment_output(treatment['harv_sepr']),
    'tr_maint': treatment_output(treatment['maint']),
    'tr_manure_l': treatment_output(treatment['lman']),
    'tr_manure_s': treatment_output(treatment['sman']),
    'tr_ppp': treatment_output(treatment['ppp']),
    'tr_soil': treatment_output(treatment['soil']),
    'tr_sowi': treatment_output(treatment['sowi']),
    'tr_irri': treatment['irri'],  # no irrigation date is assessed, therefore no treatment_output function needed
    'tr_grazing': treatment_output(treatment['grazing']),
    'c_start': dt.date.strftime(c_start, '%Y-%m-%d'),
    'c_end': dt.date.strftime(c_end, '%Y-%m-%d'),
    'c_duration_days': c_duration_days,
    'c_duration_years': c_duration_year,
    'c_areatime': c_areatime,
    'c_prha_date': last_harv_date_str,
    'c_protective_sowi': c_protective_sowi,
    'c_eros_permaculture': c_eros_permaculture,
    'c_sowi_pre_harv': c_sowi_pre_harv,
    'c_hare_inco_bool': c_hare_inco_bool,
    'c_rodent_regulation': c_rodent_regulation
}

out.c_salcaprep = js.dumps(c_salcaprep)

# %% end sequence =============================================================
end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
