# -*- coding: utf-8 -*-
"""
File name: SALCAprep_farm.py
Created on Mon May 11 07:06:06 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script collects and prepares data on farm level to serve other modules,
    especially the ones running on calculation levels other than farm but still
    need farm data as input.

Calculation level:
    Farm

Related script:
    SALCAnitrate_field.py, SALCAfield_crop.py, SALCAfield_field.py, 
    SALCAerosion_field.py, SALCAanimal_ls.py
"""

# %% import modules ===========================================================
import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context


# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.INFO)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAprep farm'
logging.info('')
logging.info('Start: %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes and parameters ============================================
# to define the summercrop groups, only fields that contribute >5% to the total
# open arable area of the farm are considered.
parc_exclusion_threshold = 0.05

# %% define functions =========================================================

# %% input ====================================================================
# load location variable to check climate table.
# The routine further below allows manual entries for the climate variables
# (temperature, precipitation, humidity) which overwrite the defaults from table.
location = inp.f_location
# set default location, if no location is specified
if inp.f_location == '':
    location = '059_Zuerich / Affoltern'
tab_climate = pd.read_csv('SALCAprep_climate.csv', sep=';', header=0, encoding='utf-8')
climate = tab_climate.loc[tab_climate['Code'] == location, :]

# load the crop table
tab_crops = pd.DataFrame(data=js.loads(inp.tab_crops)['data'],
                         columns=js.loads(inp.tab_crops)['columns'],
                         index=js.loads(inp.tab_crops)['index']
                         )

# f_uaa_ha: not in use here, but listed to ensure presence in the data entry
# form through the dependency graph.
f_uaa_ha = inp.f_uaa_ha

# list of python names of the crops on the farm
in_crop_code = []
crops = ctx.farm[7]
# the crops need to be sorted by id to ensure that in_crop_code fits with
# inp.c_salcaprep since inp.c_salcaprep is ordered by crop id's.
for crop in sorted(crops.values()):
    in_crop_code.append(crop[2])
# load salcaprep_crop: There is no c_salcaprep when only livestock but no crop is modelled.
if hasattr(inp, 'c_salcaprep') and inp.c_salcaprep is not None:
    c_salcaprep_str = inp.c_salcaprep
else:
    c_salcaprep_str = ''
# setup arrays
c_areatime = []  # list of areatimes of crops [ha*a]
c_protective_sowi = []  # list of protective sowing
c_eros_permaculture = []  # list of definition of open arable area (0) vs. permanent crop (1)
# list of crop types according to Freiermuth (for erosion)
c_type_eros = ['']*len(in_crop_code)
for i, crop in enumerate(in_crop_code):
    # load the c_salcaprep dictionary of the current crop
    c_salcaprep_dict = js.loads(c_salcaprep_str[i])
    # append the areatime [ha*a]
    c_areatime.append(c_salcaprep_dict['c_areatime'])
    # append the protective sowing (0 or 1)
    c_protective_sowi.append(c_salcaprep_dict['c_protective_sowi'])
    # append the c_eros_permaculture value (0 or 1)
    c_eros_permaculture.append(c_salcaprep_dict['c_eros_permaculture'])
    # derive the crop type as used in SALCAerosion
    c_type_eros[i] = tab_crops.loc[tab_crops['NameEN']
                                   == crop]['Croptype_Erosion'].values[0]

# grazing livestock data
if hasattr(inp, 'ls_head') and inp.ls_head is not None:
    ls_head = inp.ls_head
else:
    ls_head = []
if hasattr(inp, 'ls_past_h') and inp.ls_past_h is not None:
    ls_past_h = inp.ls_past_h
else:
    ls_past_h = []
if hasattr(inp, 'ls_map_type') and inp.ls_map_type is not None:
    ls_map_type = inp.ls_map_type
else:
    ls_map_type = []

# %% calculation ==============================================================
'''
The first entry in the climate variable is the annual mean temperature. The
second to 13th value are the monthly mean temperatures (jan to dec). 14th is
the annual precipitation, followed on positions 15-27 by the monthly precipita-
tion (jan - dec). Position 28 is the annual mean of humidity. Entries 29-40 are
the monthly mean humidity values.
'''
mean_temperature = climate['Mean annual temperature'].values[0]  # [°C]
temperature = climate.loc[0:,'Mean temperature january':'Mean temperature december'].astype(np.float64).values.flatten().tolist()  # [°C]
annual_precipitation = climate['Mean annual percipitation'].values[0]  # [mm/year]
precipitation = climate.loc[0:,'Mean percipitation january':'Mean percipitation december'].astype(np.float64).values.flatten().tolist()  # [mm/mon]
mean_humi = climate['Mean annual humidity'].values[0]  # [%/100]
humidity = climate.loc[0:,'Mean humidity january':'Mean humidity december'].astype(np.float64).values.flatten().tolist()  # [%/100]

# overwrite with manually entered values for the climate (if present)
if hasattr(inp, 'f_temp_jan_degC') and inp.f_temp_jan_degC is not None:
    temperature[0] = inp.f_temp_jan_degC
if hasattr(inp, 'f_temp_feb_degC') and inp.f_temp_feb_degC is not None:
    temperature[1] = inp.f_temp_feb_degC
if hasattr(inp, 'f_temp_mar_degC') and inp.f_temp_mar_degC is not None:
    temperature[2] = inp.f_temp_mar_degC
if hasattr(inp, 'f_temp_apr_degC') and inp.f_temp_apr_degC is not None:
    temperature[3] = inp.f_temp_apr_degC
if hasattr(inp, 'f_temp_may_degC') and inp.f_temp_may_degC is not None:
    temperature[4] = inp.f_temp_may_degC
if hasattr(inp, 'f_temp_jun_degC') and inp.f_temp_jun_degC is not None:
    temperature[5] = inp.f_temp_jun_degC
if hasattr(inp, 'f_temp_jul_degC') and inp.f_temp_jul_degC is not None:
    temperature[6] = inp.f_temp_jul_degC
if hasattr(inp, 'f_temp_aug_degC') and inp.f_temp_aug_degC is not None:
    temperature[7] = inp.f_temp_aug_degC
if hasattr(inp, 'f_temp_sep_degC') and inp.f_temp_sep_degC is not None:
    temperature[8] = inp.f_temp_sep_degC
if hasattr(inp, 'f_temp_oct_degC') and inp.f_temp_oct_degC is not None:
    temperature[9] = inp.f_temp_oct_degC
if hasattr(inp, 'f_temp_nov_degC') and inp.f_temp_nov_degC is not None:
    temperature[10] = inp.f_temp_nov_degC
if hasattr(inp, 'f_temp_dec_degC') and inp.f_temp_dec_degC is not None:
    temperature[11] = inp.f_temp_dec_degC
if hasattr(inp, 'f_temp_annual_degC') and inp.f_temp_annual_degC is not None:
    mean_temperature = inp.f_temp_annual_degC

if hasattr(inp, 'f_humi_jan_perc') and inp.f_humi_jan_perc is not None:
    humidity[0] = inp.f_humi_jan_perc
if hasattr(inp, 'f_humi_feb_perc') and inp.f_humi_feb_perc is not None:
    humidity[1] = inp.f_humi_feb_perc
if hasattr(inp, 'f_humi_mar_perc') and inp.f_humi_mar_perc is not None:
    humidity[2] = inp.f_humi_mar_perc
if hasattr(inp, 'f_humi_apr_perc') and inp.f_humi_apr_perc is not None:
    humidity[3] = inp.f_humi_apr_perc
if hasattr(inp, 'f_humi_may_perc') and inp.f_humi_may_perc is not None:
    humidity[4] = inp.f_humi_may_perc
if hasattr(inp, 'f_humi_jun_perc') and inp.f_humi_jun_perc is not None:
    humidity[5] = inp.f_humi_jun_perc
if hasattr(inp, 'f_humi_jul_perc') and inp.f_humi_jul_perc is not None:
    humidity[6] = inp.f_humi_jul_perc
if hasattr(inp, 'f_humi_aug_perc') and inp.f_humi_aug_perc is not None:
    humidity[7] = inp.f_humi_aug_perc
if hasattr(inp, 'f_humi_sep_perc') and inp.f_humi_sep_perc is not None:
    humidity[8] = inp.f_humi_sep_perc
if hasattr(inp, 'f_humi_oct_perc') and inp.f_humi_oct_perc is not None:
    humidity[9] = inp.f_humi_oct_perc
if hasattr(inp, 'f_humi_nov_perc') and inp.f_humi_nov_perc is not None:
    humidity[10] = inp.f_humi_nov_perc
if hasattr(inp, 'f_humi_dec_perc') and inp.f_humi_dec_perc is not None:
    humidity[11] = inp.f_humi_dec_perc
if hasattr(inp, 'f_humi_annual_perc') and inp.f_humi_annual_perc is not None:
    mean_humi = inp.f_humi_annual_perc

if hasattr(inp, 'f_prec_jan_mm') and inp.f_prec_jan_mm is not None:
    precipitation[0] = inp.f_prec_jan_mm
if hasattr(inp, 'f_prec_feb_mm') and inp.f_prec_feb_mm is not None:
    precipitation[1] = inp.f_prec_feb_mm
if hasattr(inp, 'f_prec_mar_mm') and inp.f_prec_mar_mm is not None:
    precipitation[2] = inp.f_prec_mar_mm
if hasattr(inp, 'f_prec_apr_mm') and inp.f_prec_apr_mm is not None:
    precipitation[3] = inp.f_prec_apr_mm
if hasattr(inp, 'f_prec_may_mm') and inp.f_prec_may_mm is not None:
    precipitation[4] = inp.f_prec_may_mm
if hasattr(inp, 'f_prec_jun_mm') and inp.f_prec_jun_mm is not None:
    precipitation[5] = inp.f_prec_jun_mm
if hasattr(inp, 'f_prec_jul_mm') and inp.f_prec_jul_mm is not None:
    precipitation[6] = inp.f_prec_jul_mm
if hasattr(inp, 'f_prec_aug_mm') and inp.f_prec_aug_mm is not None:
    precipitation[7] = inp.f_prec_aug_mm
if hasattr(inp, 'f_prec_sep_mm') and inp.f_prec_sep_mm is not None:
    precipitation[8] = inp.f_prec_sep_mm
if hasattr(inp, 'f_prec_oct_mm') and inp.f_prec_oct_mm is not None:
    precipitation[9] = inp.f_prec_oct_mm
if hasattr(inp, 'f_prec_nov_mm') and inp.f_prec_nov_mm is not None:
    precipitation[10] = inp.f_prec_nov_mm
if hasattr(inp, 'f_prec_dec_mm') and inp.f_prec_dec_mm is not None:
    precipitation[11] = inp.f_prec_dec_mm
if hasattr(inp, 'f_prec_year_mm') and inp.f_prec_year_mm is not None:
    annual_precipitation = inp.f_prec_year_mm

# calculate the distribution of different crop types in the crop rotation
# weights according to areatime
set_crop_types = ['ley_fallow', 'winter_grain_rapeseed', 'maize',
                  'vegetables', 'catch_crop', 'others']

# setup dictionary for crop types in crop rotation
f_crop_rotation = {crop_type: 0 for crop_type in set_crop_types}
# There is no c_salcaprep when only livestock but no crop is modelled:
if hasattr(inp, 'c_salcaprep') and inp.c_salcaprep is not None:
    for crop_type in set_crop_types:
        # Fraction of crop type in the crop rotation for SALCAerosion [0,1]
        f_crop_rotation[crop_type] = np.sum(np.array(c_areatime)[
            np.array(c_type_eros) == crop_type])/np.sum(c_areatime)

# Fraction of sowing with reduced tillage in crop rotation for SALCAerosion [0,1]
f_protective_sowi = np.sum(np.multiply(c_protective_sowi, c_areatime)
                           / np.sum(c_areatime))
# Sum of open arable area (c_eros_arable is the inverse from c_eros_permaculture)
c_eros_arable = [element * -1 + 1 for element in c_eros_permaculture]
f_eros_arable = np.sum(np.multiply(c_eros_arable, c_areatime))

# %% erosion group fractions ==================================================
frac_crop_group1 = []
frac_crop_group2 = []
#  Routine to define the groups of summercrops each crop belongs to
for i, crop_type in enumerate(in_crop_code):
    # Fraction of the crop on total open arable area on the farm
    if c_eros_arable[i] == 1:
        fracParcCropArea = np.array(c_areatime)[i] / f_eros_arable
    else:
        fracParcCropArea = 0.0
    logging.debug('Crop = %s',crop_type)
    logging.debug('Crop fraction on total open arable area of the farm: %s', fracParcCropArea)

    group_1 = tab_crops.loc[tab_crops['NameEN']
                            == crop_type, 'SQ Erosion Groupe 1'].values[0] * fracParcCropArea
    group_2 = tab_crops.loc[tab_crops['NameEN']
                            == crop_type, 'SQ ErosionGroupe 2'].values[0] * fracParcCropArea
    
    # only fields that contribute >5% to the total open arable area of the farm are considered
    if group_1 > parc_exclusion_threshold:
        frac_crop_group1.append(group_1)
    else:
        frac_crop_group1.append(0.0)
    if group_2 > parc_exclusion_threshold:
        frac_crop_group2.append(group_2)
    else:
        frac_crop_group2.append(0.0)
    
    logging.debug(f"frac_crop_group1: {group_1:.3f}")
    logging.debug(f"frac_crop_group2: {group_2:.3f}")
    logging.debug('')
    
#  Fractions of summercrop group 1 and group 2 on farm level
f_summercrop_group_1 = np.sum(frac_crop_group1)
f_summercrop_group_2 = np.sum(frac_crop_group2)

logging.info(f'Fraction of group 1 summer crops on the farm = {f_summercrop_group_1:.2f}',)
logging.info(f'Fraction of group 2 summer crops on the farm = {f_summercrop_group_2:.2f}',)

# %% livestock data for pasture grazing =======================================
df_past_anim = pd.DataFrame({
    "head": ls_head,
    "pasture_hours": ls_past_h,
    "animal_type": ls_map_type
})
# weighted mean of pasture hours per animal category (for grazing assessment in SALCAsoilquality)
f_past_h = (df_past_anim.assign(prod=df_past_anim["pasture_hours"] * df_past_anim["head"])
          .groupby("animal_type").apply(lambda g: g["prod"].sum() / g["head"].sum()))

# %% output ===================================================================
f_salcaprep = {
    'mean_temperature': mean_temperature,
    'temperature': temperature,
    'annual_precipitation': annual_precipitation,
    'precipitation': precipitation,
    'mean_humi': mean_humi,
    'humidity': humidity,
    'f_crop_rotation': f_crop_rotation,
    'f_protective_sowi': f_protective_sowi,
    'f_summercrop_group_1': f_summercrop_group_1,
    'f_summercrop_group_2': f_summercrop_group_2,
    'f_past_h': f_past_h.to_dict()
}
# dump the dictionary into a string for database compatibility
out.f_salcaprep = js.dumps(f_salcaprep)

# %% end sequence =============================================================
end = dt.datetime.now(tz=None)
logging.info('End %s', module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
