# -*- coding: utf-8 -*-
"""
File name: SALCAprep_field.py
Created on Mon May 11 07:06:05 2020

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script collects and prepares data on field level to serve other modules,
    especially the ones running on calculation levels other than field but still
    need field data as input.

Calculation level:
    Field

Related script:
    SALCAfield_crop.py, SALCAnitrate_field.py, SALCAsoilquality_crop.py,
    SALCAphosphor.py, SALCAheavymetal_crop.py, SALCAerosion_field.py
"""

# import modules ==============================================================
import datetime as dt
import logging
from importlib import reload

import numpy as np

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
module_name = 'SALCAprep field'
logging.info('')
logging.info('Start: %s', module_name)
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('field')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define classes ===========================================================

# %% define functions =========================================================

# %% input ====================================================================
"""
In SALCAfuture, input variables entered in percentage are automatically
converted into fractions of the range [0,1]. While the input variables are
named according to the entered values, calculation variables in the code are
named with _frac to resemble that they are fractions with a range of [0,1]
"""
fi_clay_suso_frac = inp.fi_clay_suso_perc
fi_clay_toso_frac = inp.fi_clay_toso_perc

fi_sand_suso_frac = inp.fi_sand_suso_perc
fi_sand_toso_frac = inp.fi_sand_toso_perc

# %% calculation ==============================================================
if fi_clay_suso_frac:
    fi_clay_frac = np.mean([fi_clay_suso_frac, fi_clay_toso_frac])
else:
    fi_clay_frac = fi_clay_toso_frac
	# subsoil info is needed for SALCAphosphor. if no subsoil data entered, take topsoil data as a proxy.
    fi_clay_suso_frac = fi_clay_toso_frac
if fi_sand_suso_frac:
    fi_sand_frac = np.mean([fi_sand_suso_frac, fi_sand_toso_frac])
else:
    fi_sand_frac = fi_sand_toso_frac
    # subsoil info is needed for SALCAphosphor. if no subsoil data entered, take topsoil data as a proxy.
    fi_sand_suso_frac = fi_sand_toso_frac

# calculation of bulk density depending on clay content
fi_soil_kgpm3 = 1440 - 9*fi_clay_frac*100

# %% output ===================================================================
out.fi_clay_frac = fi_clay_frac
out.fi_sand_frac = fi_sand_frac
# fi_sand_frac is not used in any module, since SALCAphosphor uses fi_sand_toso_frac and fi_sand_suso_frac.
out.fi_clay_suso_frac = fi_clay_suso_frac  # for SALCAphosphor
out.fi_sand_suso_frac = fi_sand_suso_frac  # for SALCAphosphor
out.fi_soil_kgpm3 = fi_soil_kgpm3

# %% end sequence =============================================================
end = dt.datetime.now(tz=None)
logging.info('End  %s' + module_name)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
