# -*- coding: utf-8 -*-
"""
File name: SALCAsoilquality_crop.py
Created on Tue May 14 15:22:38 2019

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script assesses the impact of agricultural management practices on
    soil quality.

Calculation level:
    Crop

Related scripts: SALCAheavymetal_crop.py, SALCAanimal_farm.py
    It uses input from these scripts.
"""

# %% import modules ===========================================================

import datetime as dt
import json as js
import re
import logging
import warnings as w
from importlib import reload
from sys import stderr
from dataclasses import dataclass, field

import pandas as pd
import numpy as np

from salcaconnector import create_salca_context

# %% start sequence ===========================================================

reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
logging.info('Start SALCAsoilquality crop')
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('crop')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)

def warning_format(message, *args):
    """define formatting of warning messages"""
    return f'WARNING: {message}\n'
w.formatwarning = warning_format

# %% define input data classes ================================================

@dataclass
class FarmData:
    """Data class storing the farm-level input data."""

    climate_type: str
    climate_zone: str
    sman_kgospt: float
    lman_kgospm3: float

@dataclass
class FieldData:
    """Data class storing the field-level input data."""

    soil_type: str
    soil_kgpm3: float
    soil_depth_cm: float
    clay_frac: float
    humus_perc: float
    ph: float

@dataclass
class CropData:
    """Data class storing the crop-level input data."""

    crop: str
    ca_ha: float
    protective_sowi: int
    eros_permaculture: int

@dataclass
class GrazingData:
    """Data class storing the input data about grazing."""

    no_days: list
    no_lsu: list
    livestock_type: list
    h: list = field(init=False)

    def __post_init__(self):
        """Extract daily grazing hours based on the animal category."""
        self.h = [extract_past_h(val) for val in self.livestock_type]

@dataclass
class EventData:
    """Data class storing the input data about events."""

    harv: dict
    harv_sepr: dict
    sowi: dict
    maint: dict
    ppp: dict
    fertilisation: dict
    manure_l: dict
    manure_s: dict
    soil_trea: dict

@dataclass
class HeavyMetalData:
    """Data class storing the input data about heavy metals."""

    soil_cd_mgpa: float
    soil_cu_mgpa: float
    soil_zn_mgpa: float
    soil_pb_mgpa: float
    soil_ni_mgpa: float
    soil_cr_mgpa: float
    soil_hg_mgpa: float

@dataclass
class OrganicPollutantData:
    """Data class storing the input data about organic pollutants."""

    soil_pcdd_pcdf: float
    soil_pah: float
    soil_pcb: float

@dataclass
class PrepSQ:
    """Data class collecting the input data needed in this module."""

    f: FarmData
    fi: FieldData
    c: CropData
    in_past: GrazingData
    event: EventData
    hm: HeavyMetalData
    op: OrganicPollutantData
    mc_dict: list[dict]

# %% define other classes (for machines) ======================================

class MachineCombination:
    """
    Class representing a combination of machines based on the machine
    combination event. Automatically assigns several relevant characteristics
    for later calculations, as specified in the functions below.
    Keyword argument:
    event: Information from a machine combination event. Load with
        inp.get_events(). List of dictionaries containing the variables
        of the event as keys and their value as values.
    """

    def __init__(self, event):
        self.id = event['f_maco_id']
        self.vehicle = event['f_maco_main'][4:]
        self.front = event['f_maco_front'][4:]
        self.back = event['f_maco_back'][4:]

        self.weight = {'vehicle': (tab_vehicle['Gewicht [kg]']
                                   [tab_vehicle['PythonName'] == self.vehicle
                                    ]. values[0]),
                       'front': (tab_vehicle['Gewicht [kg]']
                                 [tab_vehicle['PythonName'] == self.front
                                  ]. values[0]),
                       'back': (tab_vehicle['Gewicht [kg]']
                                [tab_vehicle['PythonName'] == self.back
                                 ]. values[0])}
        self.type = {'vehicle': (tab_vehicle['Maschinentyp']
                                 [tab_vehicle['PythonName'] == self.vehicle
                                  ]. values[0]),
                     'front': (tab_vehicle['Maschinentyp']
                               [tab_vehicle['PythonName'] == self.front
                                ]. values[0]),
                     'back': (tab_vehicle['Maschinentyp']
                              [tab_vehicle['PythonName'] == self.back
                               ]. values[0])}
        self.width = {'vehicle': (tab_vehicle['Arbeitsbreite [m]']
                                  [tab_vehicle['PythonName'] == self.vehicle
                                   ]. values[0]),
                      'front': (tab_vehicle['Arbeitsbreite [m]']
                                [tab_vehicle['PythonName'] == self.front
                                 ]. values[0]),
                      'back': (tab_vehicle['Arbeitsbreite [m]']
                               [tab_vehicle['PythonName'] == self.back
                                ]. values[0])}
        self.category = {'vehicle': (tab_vehicle['Klassifikation']
                                     [tab_vehicle['PythonName'] == self.vehicle
                                      ]. values[0]),
                         'front': (tab_vehicle['Klassifikation']
                                   [tab_vehicle['PythonName'] == self.front
                                    ]. values[0]),
                         'back': (tab_vehicle['Klassifikation']
                                  [tab_vehicle['PythonName'] == self.back
                                   ]. values[0])}
        self.ps = (tab_vehicle['Leistung [PS]']
                   [tab_vehicle['PythonName'] == self.vehicle
                    ]. values[0])
        self.loadweight = {'vehicle': (tab_vehicle['Ladungs-gewicht [kg]']
                                       [tab_vehicle['PythonName'] == self.vehicle
                                        ]. values[0]),
                           'front': (tab_vehicle['Ladungs-gewicht [kg]']
                                     [tab_vehicle['PythonName'] == self.front
                                      ]. values[0]),
                           'back': (tab_vehicle['Ladungs-gewicht [kg]']
                                    [tab_vehicle['PythonName'] == self.back
                                     ]. values[0])}
        self.loadweight['total'] = (self.loadweight['vehicle']
                                    + self.loadweight['front']
                                    + self.loadweight['back'])
        self.totalweight =  {'vehicle': self.weight['vehicle'] +\
                             self.loadweight['vehicle'] * 0.75,
                             'front': self.weight['front'] +\
                                 self.loadweight['front'] * 0.75,
                                 'back': self.weight['back'] +\
                                     self.loadweight['back'] * 0.75}
        self.totalweight['total'] = (self.totalweight['vehicle']
                                     + self.totalweight['front']
                                     + self.totalweight['back'])

    def get_info(self):
        """
        Calculates characteristics of the machine combination relevant for
        soil compaction. The calculations account for two axles for the main
        vehicle with an optional additional axle on the front for a front-
        mounted machine and another optional axle on the back for a back-
        mounted machine. Two additional axles for trailers with two axles are
        currently not implemented.
        """
        def add_weight(axles, code_v, factor, weight, v_type):
            """
            Adds input weight to Axle1 and Axle2, if the vehicle type
            v_type matches the vehicle code code_v of the weight distribution.
            Keyword arguments:
            axles: Two axles to divide the added mass onto.
            code_v: Vehicle type for which the specified distribution of weight
                is designed. v_type needs to have the same vehichle type for
                the weight to be distributed onto the two axles.
            factor: Fraction of the weight added to Axle1. the remaining frac-
                tion of the weight is added to Axle2. (factor = 1 - "Lastkoeffizient")
            weight: The weight that needs to be distributed onto the two axles.
            v_type: Vehicle type of the machine, of which the weight is to be
                distributed.
            """
            if code_v == v_type:
                weight_axle = weight
                axles[0] += weight_axle*factor
                axles[1] += weight_axle*(1-factor)
            return axles
        # weight distribution to the axles and calculation of tyre dimensions:
        axle_front = 0
        axle_1 = 0
        axle_2 = 0
        axle_back = 0
        # With the following definitions for tyre dimensions, only the axles
        # from the vehicle and from trailers are considered for soil compaction.
        # Additional axles from front or back machines are neglected (weight is
        # distributed over huge tyre dimensions to equal zero). Only the share
        # of the machine weights that are distributed onto the vehicle axles
        # are therefore relevant for soil compaction in the model.
        tyre_width_m = [9999, 9999, 9999, 9999]
        tyre_diam_m = [9999, 9999, 9999, 9999]
        if self.type['back'] == 'Anhänger':
            tyre_diam_m[3] = (0.1047*self.weight['back']+303)/1000  # [m]
            tyre_width_m[3] = (0.0058*self.weight['back']+175.83)/1000  # [m]
        if self.type['vehicle'] == 'Selbstfahrend':
            tyre_diam_m[1] = (1.9983*self.ps+1022.5)/1000
            tyre_diam_m[2] = (2.5216*self.ps+1333.2)/1000
            tyre_width_m[1] = (0.7261*self.ps+381.15)/1000
            tyre_width_m[2] = (0.8997*self.ps+434.55)/1000

        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Selbstfahrend', 0.4,
                                    self.totalweight['vehicle'], self.type['vehicle'])
        # Category for trailers of transporters (rear mounting is fully
        # distributed across the tractor vehicle. Corresponds to an additional
        # weight for the tractor vehicle)
        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Heckanbau Aufleger', 0.4,
                                    self.totalweight['back'], self.type['back'])
        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Frontanbau hängend', 1.2,
                                    self.totalweight['front'], self.type['front'])
        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Heckanbau klein', -0.5,
                                    self.totalweight['back'], self.type['back'])
        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Heckanbau mittel', -1,
                                    self.totalweight['back'], self.type['back'])
        axle_1, axle_2 = add_weight([axle_1, axle_2], 'Heckanbau gross', -1.5,
                                    self.totalweight['back'], self.type['back'])
        axle_front, axle_1 = add_weight([axle_front, axle_1],
                                        'Frontanbau Stützrad', 0.5,
                                        self.totalweight['front'], self.type['front'])
        axle_2, axle_back = add_weight([axle_2, axle_back], 'Heckanbau Stützrad',
                                       0.5, self.totalweight['back'], self.type['back'])
        axle_2, axle_back = add_weight([axle_2, axle_back], 'Anhänger', 0.5,
                                       self.totalweight['back'], self.type['back'])

        axle_weights = [axle_front, axle_1, axle_2, axle_back]
        axle_distribution = list(np.array(axle_weights) / self.totalweight['total'])
        swath_m = max([self.width['front'], self.width['vehicle'], self.width['back']])
        return axle_distribution, tyre_diam_m, tyre_width_m, swath_m

@dataclass
class TreatmentMachineInfo:
    """Data class storing the machine info of treatments."""

    weight_kg: float
    axle_load_distr: list
    tyre_diam_m: list
    tyre_width_m: list
    swath_m: float

# %% define functions for input data ==========================================

def extract_past_h(val):
    """Extract daily grazing hours based on the animal category."""
    f_salcaprep = js.loads(inp.f_salcaprep)
    try:
        return f_salcaprep['f_past_h'][val]
    except KeyError as e:
        w.warn((f"KeyError with key {e}\n"
                f"Animal category {val} does not exist on the farm. "
                f"A standard grazing duration of 4 hours is assumed for this animal category."))
        stderr.flush()  # show warning immediately
        return 4


def read_table(path):
    """Read csv table."""
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    return tab


def read_pars(path):
    """Read CSV file."""
    tab = pd.read_csv(path,
                      sep=';',
                      header=0,
                      encoding='utf-8-sig')
    tab = tab.set_index('NameEN')
    return tab


def read_js_table(table):
    """Convert a JSON string to a data frame."""
    return pd.DataFrame(data=js.loads(table)['data'],
                        columns=js.loads(table)['columns'],
                        index=js.loads(table)['index'])


def get_from_table(tab, col, col2, name):
    """
    Derive a value from a table.

    Keyword arguments:
    tab: Table to extract values from.
    col: Column in the table to extract values from.
    col2: Column in the table with the condition of the row.
    name: Match in col2 to derive the row of the extracted value.
    """
    try:
        value = tab[col][tab[col2] == name].values[0]
    except ValueError as exc:
        raise ValueError(f"Value could not be found in the table for "
                         f"'{name}' in column '{col}'") from exc
    return value


# %% define functions for data preprocessing ==================================

def derive_month(dates):
    """Derive the month from a date string."""
    months = []
    for date_str in dates:
        date = dt.datetime.strptime(date_str, '%Y-%m-%d')
        months.append(date.month)
    return months


def derive_soil_state(application_types, c_eros_permaculture, looseness_after,
                      first_tr_soil_date):
    """
    derive soil state: 
    for every treatment we need to know what the soil looseness at the time
    of the treatment is. The soil treatments and sowing events are applied on 
    certain soil looseness which is defined in the machinery table. This is
    extracted as the looseness_before. Soil treatments and sowing events also
    determine what the soil looseness is for the later treatments, depending 
    on the soil looseness after the soil treatments and after sowing as well
    as the time passed since the last sowing event.
    """

    soil_states = []
    last_appl_date = dt.datetime(1000, 1, 1, 0, 0)

    # for multiple treatments in one harvest or harvest_sepr event, the
    # dates must be appended in order to derive a soil state for the additional
    # treatments as well [date_ff]:
    if 'date_ff' in application_types.keys():
        for date_ff in application_types['date_ff']:
            application_types['date_dt'].append(dt.datetime.strptime(date_ff, '%Y-%m-%d'))

    if c_eros_permaculture == 1 and 'looseness_before' in application_types:
        soil_states.extend(application_types['looseness_before'])
        w.warn("Soil_treatment/sowing on permanent crop. Soil " + \
               "looseness = 'firm' has been set for all treatments. " + \
               "Please check if this is valid.")
        stderr.flush()  # show warning immediately
        logging.debug("tr_on_permaculture: soil_states = %s", soil_states)
    elif c_eros_permaculture == 1 and 'looseness_before' not in application_types:
        soil_states.extend(['firm'] * len(application_types['date_dt']))
        logging.debug("tr_on_permaculture: soil_states = %s", soil_states)
    elif c_eros_permaculture != 1 and 'looseness_before' in application_types:
        # only soil treatments and sowing events have looseness_before as a key
        # in the dict and need to be treated different than other treatments.
        for looseness in application_types['looseness_before']:
            # soil looseness at the current treatment:
            soil_states.append(looseness)

        # determine the soil looseness after the last soil treatment
        # or sowing event:
        idx_max = application_types['date_dt'].index(max(application_types['date_dt']))
        last_appl_date = application_types['date_dt'][idx_max]
        last_appl_looseness = application_types['looseness_after'][idx_max]

        if last_appl_date > looseness_after['date_dt']:
            looseness_after['date_dt'] = last_appl_date
            looseness_after['looseness'] = last_appl_looseness
        logging.debug("tr_soil&sowing: soil_states = %s", soil_states)
    elif c_eros_permaculture != 1 and 'looseness_before' not in application_types:
        for tr_date in application_types['date_dt']:
            # soil_states definition for treatments before soil tr. and sowing
            if tr_date <= first_tr_soil_date or \
                first_tr_soil_date == dt.datetime(1000, 1, 1, 0, 0):
                soil_states.append('firm')
            # soil_states definition for treatments after soil tr. and sowing
            elif tr_date - looseness_after['date_dt'] >= dt.timedelta(days=28)\
                and looseness_after['looseness'] == 'loose':
                # loose soil will settle after some time (defined as 1 month)
                soil_states.append('settled')
            else:
                # treatments (e.g. fert/manure) between soil tr. and
                # sowing have the same soil_state like after sowing,
                # because once the soil is loose, it stays for a while.
                soil_states.append(looseness_after['looseness'])
        logging.debug("tr_after_sowing: soil_states = %s", soil_states)

    return soil_states, looseness_after


def prep_treatment_data(event_order, event_group, mc_lookup, eros_permaculture):
    """Extract data for treatments and machine combinations."""
    treatment_maco_list = []  # machine combination [number]
    tr_month = []  # month of treatment [month]
    tr_soil_state = []  # treatment soil state

    no_date = dt.datetime(1000, 1, 1, 0, 0)
    looseness_throughout = {'date_dt': no_date, 'looseness': []}
    # first soil treatment date
    if event_group.soil_trea['date_dt'] == []:
        first_tr_soil_date = no_date
    else:
        first_tr_soil_date = min(event_group.soil_trea['date_dt'])

    for event_name in event_order:
        evt = getattr(event_group, event_name)
        treatment_maco_list.extend(evt["MC"])
        tr_month.extend(derive_month(evt["date"]))
        if event_name in ["harv", "harv_sepr"]:
            treatment_maco_list.extend(evt["MC_ff"])
            tr_month.extend(derive_month(evt["date_ff"]))

        logging.debug('soil state during %s', event_name)
        soil_state, looseness_throughout = derive_soil_state(evt,
                                                             eros_permaculture,
                                                             looseness_throughout,
                                                             first_tr_soil_date)
        tr_soil_state.extend(soil_state)


    logging.debug("treatment_maco_list")
    logging.debug(treatment_maco_list)

    tr_maco_info = []

    # iterate over the treatments and calculate for the used machine combinations
    # the parameters needed to evaluate soil compaction
    for idx, mc in enumerate(treatment_maco_list):
        mc_data = mc_lookup.get(mc)
        if mc_data is not None:
            logging.debug("i=%d; mc=%s", idx, mc)
            maco = MachineCombination(mc_data)
            tr_maco_info.append(TreatmentMachineInfo(
                *[maco.totalweight['total'], *maco.get_info()]))
            logging.debug("i2=%d; mc=%s\n", idx, mc)
        else:
            w.warn((f"A machine combination couldn't be found for one of the treatments."
                    f"\nmaco in list: {mc}, treatment number: {idx}\n"))
            stderr.flush()  # show warning immediately
            tr_maco_info.append(TreatmentMachineInfo(0, [0], [0], [0], 0))
    return treatment_maco_list, tr_month, tr_soil_state, tr_maco_info


def prep_treatment_evaluation(*, month, maco_info, soil_state, soil_depth_cm,
                              soil_type, tab_somo, tab_m_cf):
    """
    Evaluation of a single treatment run on one crop on the risk of
    soil compaction.

    Keyword arguments:
    month: month of the treatment as integer (Januar: 1,
                                              Februar: 2,
                                              ...,
                                              Dezember: 12)
    weight_kg: Weight [kg] of the machine combination. This includes the main vehicle, 
        optional front and back elements as well as the load (additional weight). 
        For the additional weight that changes during the treatment (e.g. application of 
        a substance), 75% of the maximum load is used for the calculation.
    axle_load_distr: np.array containing the fractions [%/100] of load distributed 
        on all axles. Needs to sum to 100%.
    tyre_diam_m: np.array with tyre diameters [m] for all axles.
    tyre_width_m: np.array with tyre width [m] for all axles.
    swath_m: treatment swath [m]
    soil_state: Soil state. Allowed values are 'firm', 'settled' and 'loose'.
    fi_soil_depth_cm: Depth [m] of soil treatment. Standard: 0.35 m, common plough: 0.1 m.

    Output:
    mp_worked_area_frac: ideal fraction [%/100] of the area with direct contact to the tyres
    soil_pressure_max_kpa: maximum pressure on an axle [kPa]
    
    """

    # setup
    tyre_width_m = np.array(maco_info.tyre_width_m)
    tyre_diam_m = np.array(maco_info.tyre_diam_m)
    axle_load_distr = np.array(maco_info.axle_load_distr)

    # Calculate contact area [m^2] from tyre width [m] and tyre diameter [m]
    axle_contact_area_m2 = np.multiply(tyre_width_m, tyre_diam_m)*2.*0.27

    # Calculate contact pressure [kPa] from load on the axles [kg],
    # gravity [m/s^2] / contact area [m^2].
    # Division by 1000 for converting Pa -> kPa
    axle_load_kg = np.multiply(maco_info.weight_kg, np.array(axle_load_distr))
    contact_pressure_kpa = np.divide(axle_load_kg*9.81, axle_contact_area_m2*1000)

    # Calculate angle of the pressure in the soil [rad]
    pressure_angle_rad = np.arctan(np.divide(tyre_width_m,2.0)/(soil_depth_cm/100))

    # Derive factor for soil moisture
    somo_index = tab_somo[re.sub(r'[0-9]', '', soil_type).strip()][
        tab_somo['month'] == month].values[0]
    soil_cf = tab_m_cf[soil_state][tab_m_cf['soil moisture'] == somo_index]

    # Calculate pressure [kPa] applied to the soil per axle.
    soil_pressure_kpa = np.multiply(contact_pressure_kpa,
                                    (1 - np.cos(pressure_angle_rad)
                                     ** soil_cf.values[0]))
    logging.debug("maximal calculated pressure applied to soil per axle %s",
                  soil_pressure_kpa)

    # derive the pressure of the relevant axle (maximal pressure).
    soil_pressure_max_kpa = np.amax(soil_pressure_kpa)

    # derive relevant tyre width [m]
    mp_tyre_width_m = np.amax(tyre_width_m[
        np.where(soil_pressure_kpa == soil_pressure_max_kpa)])

    # Calculate the fraction of area, on which the relevant pressure was applied
    # -> fraction of worked area [%/100]
    mp_worked_area_frac = mp_tyre_width_m*2.0 / maco_info.swath_m

    # Derive the evaluation of the treatment from table.

    # return results of one treatment
    return [mp_worked_area_frac, soil_pressure_max_kpa]


def estimate_trampled_area(*, past_d, past_h, head, area,
                            dwd = None, sl = None, claw = None, anim_type):
    """
    Estimate trampled area as preparation for evaluation of soil compaction risk from grazing

    Parameters
    ----------
    past_d : float
        grazing period [days]
    past_h : float
        daily grazing hours [hours]
    head : int
        number of animals (can be livestock units if the default characteristics are used)
    area : float
        pasture area [ha]
    dwd : float, optional
        mean daily walking distance [km]
    sl : float, optional
        mean stride length [cm]
    claw : float, optional
        hoof or claw contact area [cm2]
    anim_type : str
        animal category
    
    Returns
    -------
    float
        Percentage of trampled area [%]
    """
    # no calculation without these inputs but warning
    if None in [past_d, past_h, head, area]:
        w.warn("The data are insufficient to evaluate soil compaction risk from grazing.")
        stderr.flush()  # show warning immediately
        return [np.nan, np.nan]

    # set default values if input not provided and warn user:
    # Animal categories other than dairy cattle can be approximated by LU numbers
    # as data input while using the default characteristics from dairy cattle.
    if None in [dwd, sl, claw]:
        w.warn("Some livestock characteristics were set to default"
               "values for the evaluation of soil compaction risk from grazing.")
        stderr.flush()  # show warning immediately
        if anim_type != "livestock_cattle_dairy":
            w.warn("The default values represent dairy cattle, but the assessed"
                   f" animal category is {anim_type}. This proxy can be valid if"
                   " livestock types are similar and/or if livestock units instead"
                   " of number of animals are provided.")
            stderr.flush()  # show warning immediately
    if dwd is None:
        dwd = 8
    if sl is None:
        sl = 81
    if claw is None:
        claw = 90

    # convert units
    area = area * 10000  # ha to m2
    dwd = dwd * 1000  # km to m
    sl = sl / 100  # cm to m
    claw = claw / 10000  # cm2 to m2

    # calculate percentage of trampled area [%]
    trampled_area = head * 2 * dwd/sl * claw/area * \
        past_d/365 * past_h/24 * 100

    return trampled_area


def estimate_soil_pressure(*, claw = None, mass = None,
                            soil_firm = "firm", soil_moist = "moist", anim_type):
    """
    Estimate soil pressure as preparation for evaluation of soil compaction risk from grazing

    Parameters
    ----------
    claw : float, optional
        hoof or claw contact area [cm2]
    mass : float, optional
        mass of animal [kg]
    soil_firm : str, optional
        soil firmness category ("loose", "settled", "firm")
    soil_moist : str, optional
        soil moisture category ("dry", "moist", "wet")
    anim_type : str
        animal category
    
    Returns
    -------
    float
        Soil pressure under the claws [kPa]
    """
    # set default values if input not provided and warn user:
    # Animal categories other than dairy cattle can be approximated by LU numbers
    # as data input while using the default characteristics from dairy cattle.
    if None in [claw, mass]:
        w.warn("Some livestock characteristics were set to default"
               "values for the evaluation of soil compaction risk from grazing.")
        stderr.flush()  # show warning immediately
        if anim_type != "livestock_cattle_dairy":
            w.warn("The default values represent dairy cattle, but the assessed"
                   f" animal category is {anim_type}. This proxy can be valid if"
                   " livestock types are similar and/or if livestock units instead"
                   " of number of animals are provided.")
            stderr.flush()  # show warning immediately

    if claw is None:
        claw = 90
    if mass is None:
        mass = 650

    # convert units
    claw = claw / 10000  # cm2 to m2

    # look up concentration factor
    conc_fact = pd.DataFrame([[4, 2, 2], [5, 3, 2], [6, 4, 3]],
                             index = ["dry", "moist", "wet"],
                             columns = ["loose", "settled", "firm"]).\
        loc[soil_moist, soil_firm]

    # estimate alpha
    alpha = np.arctan(
        np.sqrt(claw / 3.14) / # half width of hoof or claw [m] as circle radius
        0.1)  # reference soil depth [m]

    # calculate soil pressure under the claws [kPa], 1 Pa = 1 kg m-1 s-2
    soil_pressure = (mass * 9.81 /  # gravitational constant [m s-2]
        (2 * claw)) * (1 - np.cos(alpha)**conc_fact) / 1000

    return soil_pressure


def assess_compaction(area_perc, soil_pressure, tab_treatment):
    """
    Classification of compaction impact based on look-up table
    
    This function can be used for wheeling and grazing.

    Parameters
    ----------
    area_perc : float
        Percentage of wheeled or trampled area [%]
    soil_pressure_kpa : float
        Soil pressure under the tyre or claws [kPa]
    
    Returns
    -------
    int
        Evaluation (0, -1, or -2)
    """
    if all(~np.isnan([area_perc, soil_pressure])):
        evaluation = tab_treatment.iloc[
            np.min(np.where(tab_treatment.iloc[:,0] <= area_perc)),
            np.min(np.where(tab_treatment.columns[1:].astype(int) <= soil_pressure))+1]
        evaluation = int(evaluation)
    else:
        evaluation = np.nan

    return evaluation


def estimate_agricultural_threshold(threshold, is_agri):
    """
    Estimate the pollution thresholds under specific environmental conditions
    for either cropland or pasture.
    """
    sampling_depth_m = 0.2  # sampling depth [m]

    return prep_sq.c.ca_ha \
        * factors['ha2m2'] \
            * sampling_depth_m \
                * prep_sq.fi.soil_kgpm3 \
                    * threshold \
                        * is_agri


def estimate_manure_dm(*, os_stable_kg, os_degradable_kg,
                        manure_event, man, man_type, tab_pars, tab_manu):
    """Accumulate dry matter from manure applications."""
    if man_type == "liquid":
        amount = 'amount_m3'
    else:  # solid
        amount = 'amount_t'

    n_manure = len(manure_event[amount])  # number of manure applications

    # iterate through manure applications
    for idx in range(n_manure):
        if manure_event['variable'][idx] == man_type + '_farm_manure':
            manure_dmc = man * tab_pars['Value']['conv_osdm_manu']
        else:
            manure_dmc = get_from_table(tab_manu,'AM: OS', 'NameEN',
                                        manure_event['variable'][idx])
        # if the dry matter content is > 100 kg/m3 (~10%)
        if manure_dmc >= 100:
            # applies to stable organic substance
            os_stable_kg += manure_dmc*manure_event[amount][idx]
        else:
            # applies to degradable organic substance
            os_degradable_kg += manure_dmc*manure_event[amount][idx]

    return os_stable_kg, os_degradable_kg


# %% define functions for impact classes ======================================

def evaluate_wheeling(*, event_order, mc_dict, event_group, eros_permaculture,
                      soil_depth_cm, soil_type, tab_somo, tab_m_cf, tab_treatment):
    """Evaluate risk of soil compaction by wheeling."""
    logging.info("Impact Assessment Soil compaction: %s", dt.datetime.now(tz=None))

    # get machine combinations defined on farm level
    mc_lookup = {str(mc['f_maco_id']): mc
                 for mc in mc_dict}

    tr_maco_list, tr_month, tr_soil_state, tr_maco_info = \
        prep_treatment_data(event_order, event_group, mc_lookup, eros_permaculture)

    # number of treatments
    n_treatments = len(tr_maco_list)

    logging.debug('Verdichtungsrisiko durch Befahrungen')
    # evaluation of treatments
    tr_evaluation = np.zeros([n_treatments])
    # ideal fraction [%/100] of the area with direct contact to the tyres
    mp_worked_area_frac = np.zeros([n_treatments])
    # maximum pressure on an axle [kPa]
    soil_pressure_max_kpa = np.zeros([n_treatments])
    # iterate through treatments
    for idx, mc in enumerate(tr_maco_list):
        logging.debug('Treatment %i:', idx)
        if mc in mc_lookup:
            # evaluate the current treatment
            [mp_worked_area_frac[idx], soil_pressure_max_kpa[idx]
             ] = prep_treatment_evaluation(month = tr_month[idx],
                                           maco_info = tr_maco_info[idx],
                                           soil_state = tr_soil_state[idx],
                                           soil_depth_cm = soil_depth_cm,
                                           soil_type = soil_type,
                                           tab_somo = tab_somo,
                                           tab_m_cf = tab_m_cf)
            tr_evaluation[idx] = assess_compaction(mp_worked_area_frac[idx] * 100,
                                                   soil_pressure_max_kpa[idx],
                                                   tab_treatment)
            logging.debug('Fraction of worked area: %f', mp_worked_area_frac[idx])
            logging.debug('Maximum soil pressure: %f kPa', soil_pressure_max_kpa[idx])
            logging.debug('Evaluation: %i', tr_evaluation[idx])
            logging.debug('')
        else:
            logging.debug("Treatment with no machine combination match: mc = %s\n", mc)

    # sum of the evaluations per crop
    tr_evaluation_crop = np.sum(tr_evaluation)
    logging.debug('Evaluation Sum: %f', tr_evaluation_crop)
    logging.debug('')

    return tr_evaluation_crop


def evaluate_grazing(*, past_d, past_h, head, area, anim_type, tab_treatment):
    """Evaluate risk of soil compaction by grazing."""
    logging.info("Impact Assessment Soil compaction (grazing): %s", dt.datetime.now(tz=None))

    # number of grazing events
    n_events = len(past_d)

    logging.debug('Soil compaction risk from grazing')
    logging.debug('Number of grazing events on the crop: %d', n_events)
    # evaluation of events
    graz_evaluation = np.zeros(n_events)
    # percentage of trampled area [%]
    trampled_area_perc = np.zeros(n_events)
    # soil pressure under the claws [kPa]
    soil_pressure_kpa = np.zeros(n_events)
    # iterate through events (implemented as seasons)
    for idx in range(n_events):
        # evaluate the current event
        # more variables could be specified to avoid using default values
        trampled_area_perc[idx] = estimate_trampled_area(
            past_d = past_d[idx],  # grazing period [days]
            past_h = past_h[idx],  # daily grazing hours [hours]
            head = head[idx],  # number of animals
            area = area,  # pasture area [ha]
            anim_type = anim_type[idx])

        soil_pressure_kpa[idx] = estimate_soil_pressure(
            anim_type = anim_type[idx])

    # aggregation of the evaluations per crop
    trampled_area_perc_total = np.sum(trampled_area_perc)
    if n_events > 0:
        soil_pressure_kpac_average = np.average(soil_pressure_kpa, weights = trampled_area_perc)
    else:
        soil_pressure_kpac_average = 0
    graz_evaluation = assess_compaction(trampled_area_perc_total,
                                        soil_pressure_kpac_average,
                                        tab_treatment)
    logging.debug('Percentage of trampled area: %f', trampled_area_perc_total)
    logging.debug('Soil pressure: %f kPa', soil_pressure_kpac_average)
    logging.debug('Evaluation: %f\n', graz_evaluation)

    return graz_evaluation


def evaluate_structure_stabilisation(crop, is_grass, is_arable, tab_crops):
    """
    Evaluate stabilisation of soil structure by plants.
    This is also relevant to positive effects of plants on earthworm populations.
    """
    cultural_value = get_from_table(tab_crops, 'SQ Cultural Value', 'NameEN', crop)

    # cultural value adding to the crop rotation value of grassland and arable crops
    crop_rotation_grass = cultural_value * is_grass
    crop_rotation_arable = cultural_value * is_arable

    logging.debug('Soil texture stabilisation:')
    logging.debug('Crop rotation value grassland: %s', crop_rotation_grass)
    logging.debug('Crop rotation value arable crops: %s', crop_rotation_arable)
    logging.debug('')

    return crop_rotation_grass, crop_rotation_arable


def evaluate_structure_formation(crop, hres_present, tab_crops):
    """Evaluate structure build-up by straw amendment."""
    if get_from_table(tab_crops, 'SQ Crop Residues soil texture formation', 'NameEN', crop) == 1:
        # note the fraction of harvest residues []
        soil_texture_hres_frac = hres_present
    else:
        soil_texture_hres_frac = 0

    logging.debug('Soil texture formation:')
    logging.debug('Fraction of harvest residue affecting soil texture formation: %i',
                  soil_texture_hres_frac)
    logging.debug('')

    return soil_texture_hres_frac


def evaluate_humus_balance(*, crop, clay_frac, ph, soil_kgpm3, manure_s_event,
                           manure_l_event, ca_ha, hres_present, tab_manu, tab_crops):
    """Evaluate humus dynamics."""
    logging.info("Impact Assessment humus balance %s", dt.datetime.now(tz=None))

    # Average humus accumulation from solid and liquid farm manure (from tab_manu)
    f_sman_huac_kgcpt = get_from_table(tab_manu, 'SQ: SALCA Humusacc kgCpUnit',
                                       'NameEN', '008 Mist unspezifiziert')
    f_lman_huac_kgcpm3 = get_from_table(tab_manu, 'SQ: SALCA Humusacc kgCpUnit',
                                        'NameEN', '008 Guelle unspezifiziert')

    is_root_crop = get_from_table(tab_crops, 'SQ Root Crop', 'NameEN', crop)

    # temporary ley or wildflower fallow (1) or not
    is_temp_ley_wf_fallow = get_from_table(
        tab_crops, 'SQ Green Manure / Wildflower Fallow', 'NameEN', crop)

    # Prefered minimal humus content []
    m_humus_min = 0.53+(0.065*clay_frac*100)
    # mineralisation coefficient (gross)
    mineralisation_gross = 1.6-(0.012*clay_frac*100)
    # pH correction
    if ph > 7:
        mineralisation_ph = -0.2*(ph-7)
    else:
        mineralisation_ph = 0

    # soil treatment correction
    mineralisation_soil = min(0.2, is_root_crop*0.5)
    # correction for temporary ley and seed pasture
    mineralisation_temp_ley_wf_fallow = max(-0.2, -is_temp_ley_wf_fallow*0.5)

    # mineralisation coefficient (net)
    mineralisation_net = (mineralisation_gross
                          + mineralisation_ph
                          + mineralisation_soil
                          + mineralisation_temp_ley_wf_fallow
                          )

    # humus loss (kg/ha)
    # Here we apply the bulk density ("Lagerungsdichte") corrected by the clay content
    # for computing the mass of 1 ha (=100m*100m) soil with depth = 0.3 m
    humus_loss_kgpha = -soil_kgpm3*0.3*100*100*(m_humus_min/100)*(mineralisation_net/100)

    # humus formation from belowground residues [kg/ha]
    m_humus_from_residues_kgpha = \
        get_from_table(tab_crops, 'SQ Below ground and mandatory above ground crop residues',
                       'NameEN', crop)
    if np.isnan(m_humus_from_residues_kgpha):
        logging.debug('Humus balance: not assessed for this crop:')
        logging.debug(crop)
        logging.debug('')

        humus_balance_net_kg = float("nan")
        humus_balance_gross_kgpha = float("nan")
        ca_ha = float("nan")
    else:
        # humus formation from manure application [kg/ha]
        m_humus_from_fert_kg = []
        for idx in range(len(manure_s_event['amount_t'])):
            if manure_s_event['variable'][idx] == 'solid_farm_manure':
                # farm manure:
                # humus accumulation in kgCpt calculated in SALCAanimal
                m_humus_from_fert_kg.append(f_sman_huac_kgcpt * manure_s_event['amount_t'][idx])
            else:
                # imported organic manure:
                # humus accumulation in kgCpt coming from SALCAtables_manu
                m_humus_from_fert_kg.append(get_from_table(tab_manu,
                                                           'SQ: SALCA Humusacc kgCpUnit',
                                                           'NameEN',
                                                           manure_s_event['variable'][idx]
                                                           ) * manure_s_event['amount_t'][idx])
        for idx in range(len(manure_l_event['amount_m3'])):
            if manure_l_event['variable'][idx] == 'liquid_farm_manure':
                # farm manure:
                # humus accumulation in kgCpm3 calculated in SALCAanimal
                m_humus_from_fert_kg.append(f_lman_huac_kgcpm3 * manure_l_event['amount_m3'][idx])
            else:
                # imported organic manure:
                # humus accumulation in kgCpm3 coming from SALCAtables_manu
                m_humus_from_fert_kg.append(get_from_table(tab_manu,
                                                           'SQ: SALCA Humusacc kgCpUnit',
                                                           'NameEN',
                                                           manure_l_event['variable'][idx]
                                                           ) * manure_l_event['amount_m3'][idx])

        m_humus_from_fert_kgpha = np.nansum(m_humus_from_fert_kg)/ca_ha
        # Humus formation from aboveground harvest residues [kg/ha]
        # (intermediate crops are assessed as separate crops just like normal crops)
        if hres_present:
            m_humus_neubildung_oberfl_kgpha = \
                np.nansum(float(get_from_table(tab_crops, 'SQ Optional Above Ground Crop Residues',
                                               'NameEN', crop)))
        else:
            m_humus_neubildung_oberfl_kgpha = 0

        # Gross humus balance (kg/ha)
        humus_balance_gross_kgpha = (humus_loss_kgpha
                                     + m_humus_from_residues_kgpha
                                     + m_humus_from_fert_kgpha
                                     + m_humus_neubildung_oberfl_kgpha)
        # Net humus balance (kg)
        humus_balance_net_kg = humus_balance_gross_kgpha * ca_ha

        logging.debug('Humus balance:')
        logging.debug('per area: % .2f kg/ha: ', humus_balance_gross_kgpha)
        logging.debug('net: % i kg: ', humus_balance_net_kg)
        logging.debug('')

    return humus_balance_net_kg, humus_balance_gross_kgpha, ca_ha


def evaluate_earthworm_protection_cutting(harv_event, is_grass):
    """Evaluate positive effects of high cutting levels on earthworm populations."""
    logging.info("Impact Assessment physical protection and impact on earthworms %s",
                 dt.datetime.now(tz=None))

    # cutting level of grassland

    worm_protection_cutting_level = 0
    for idx in np.arange(len(harv_event['cutting_level'])):
        if harv_event['cutting_level'][idx] == '002 >8cm':
            worm_protection_cutting_level += is_grass * \
                1/len(harv_event['cutting_level'])  # weighted by number of harvest events

    logging.debug('Earthworm protection through cutting height > 8 cm: %s',
                  worm_protection_cutting_level)

    return worm_protection_cutting_level


def evaluate_earthworm_impact_tillage(crop, climate_zone, soil_trea_dates, tab_earthworm):
    """Evaluate potential impact of soil tillage on earthworms."""
    ew_phys_crops_list = ['04_root_01_Potatoes:_storage,_table,_industry,_fodder',
                          '04_root_02_Early_potatoes',
                          '04_root_04_Sugar_beed'
                          '04_root_05_Fodder_Beet']
    # harvest factor for physical disturbance of earthworms
    if crop in ew_phys_crops_list:
        ew_phys_harvest = 1.5
    else:
        ew_phys_harvest = 0

    if climate_zone == 'B':
        # the same table is used for zones A and B, but only indicated
        # in the table by A
        climate_zone = 'A'

    # physical disturbance from soil treatment
    ew_phys_soil_treatment = 0
    # 1 for every soil treatment in climate zones F or G
    if climate_zone in ['F', 'G']:
        for date_soil in soil_trea_dates:
            ew_phys_soil_treatment += 1
    # consult the table for climate zones A-E
    else:
        ew_doy_list = tab_earthworm['day'][tab_earthworm['climate_zone']
                                           == climate_zone]
        for date_soil in soil_trea_dates:
            ew_doy_code = np.max(ew_doy_list[ew_doy_list
                                             <= dt.datetime.timetuple(date_soil
                                                                      ).tm_yday])
            ew_phys_soil_treatment += tab_earthworm['factor'][(tab_earthworm['day']
                                                               == ew_doy_code)
                                                              & (tab_earthworm['climate_zone']
                                                                 == climate_zone)
                                                              ].values[0]

    # sum of both indexes
    ew_phys_sum = ew_phys_harvest + ew_phys_soil_treatment

    logging.debug('Earthworms, physical disturbance:')
    logging.debug('Harvest: %f', ew_phys_harvest)
    logging.debug('Soil treatments: %f', ew_phys_soil_treatment)
    logging.debug('Sum: %f', ew_phys_sum)

    return ew_phys_sum


def evaluate_earthworm_impact_seedbed(protective_sowi):
    """Evaluate potential impact of seedbed preparation on earthworms."""
    # protective sowing is evaluated in SALCAprep_crop
    logging.debug('protective sowing: %s', protective_sowi)
    logging.debug('')
    return protective_sowi


def evaluate_pollutants(*, pollutant, data, thresholds, is_grass, is_arable, counter):
    """
    Evaluate input of heavy metals and organic pollutants.
    This is done by estimating the time until reaching the pollution thresholds.
    """
    if counter == 0:
        pollutant_type = re.sub(r'(?<!^)(?=[A-Z])', ' ',
                                type(data).__name__.replace('Data','')) + 's'
        logging.info('Impact Assessment %s %s', pollutant_type.lower(),
                     dt.datetime.now(tz=None))
        logging.debug('%s, remaining years until reaching threshold', pollutant_type)

    threshold = thresholds[pollutant.replace('_mgpa', '')]
    threshold_arable = estimate_agricultural_threshold(threshold, is_arable)
    threshold_grass = estimate_agricultural_threshold(threshold, is_grass)

    # time until the threshold value is reached with the current input rate [a]
    # if there are no pollutants, a default number of years is returned
    # to avoid a division by zero
    default_a = 30000  # > 300 y -> evaluation will be 0

    pollutant_input = getattr(data, 'soil_' + pollutant)
    if pollutant_input > 0:
        time_to_threshold_arable_a = threshold_arable / pollutant_input
        time_to_threshold_grass_a = threshold_grass / pollutant_input
    else:
        time_to_threshold_arable_a = default_a
        time_to_threshold_grass_a = default_a

    if type(data).__name__ == 'HeavyMetalData':
        pollutant = pollutant.replace('_mgpa', '')
        pollutant = pollutant[0].upper() + pollutant[1]
    elif type(data).__name__ == 'HeavyMetalData':
        pollutant = pollutant.upper().replace('_','/')
    logging.debug('%s, grassland: %.0f years', pollutant, time_to_threshold_grass_a)
    logging.debug('%s, arable crop: %.0f years', pollutant, time_to_threshold_arable_a)
    logging.debug('')

    return time_to_threshold_grass_a, time_to_threshold_arable_a


def evaluate_slurry_application(n_manure_l, is_grass, is_arable):
    """Evaluate toxic effects of slurry application."""
    evaluation_slurry_grassland = 0
    evaluation_slurry_arable = 0

    # If more than three slurry events (grassland)
    if n_manure_l > 3:
        evaluation_slurry_grassland = is_grass
    # If more than one slurry event (arable areas)
    if n_manure_l > 1:
        evaluation_slurry_arable = is_arable

    logging.debug('Earthworm and microorganisms chemical disturbance:')
    logging.debug('Number of slurry applications, grassland: %d',
                  np.array(n_manure_l*is_grass))
    logging.debug('Evaluation of slurry applications, grassland: %i',
                  evaluation_slurry_grassland)
    logging.debug('Number of slurry applications, arable crops: %i',
                  np.array(n_manure_l*is_arable))
    logging.debug('Evaluation of slurry applications, arable crops: %i',
                  evaluation_slurry_arable)
    logging.debug('')

    return int(evaluation_slurry_grassland), int(evaluation_slurry_arable)


def evaluate_organic_substances(*, manure_s_event, manure_l_event, sman_kgospt,
                                lman_kgospm3, ca_ha, no_days, no_lsu,
                                tab_pars, tab_manu):
    """Evaluate input of stable and rapidly degradable organic fertiliser."""
    logging.info("Impact assessment organic substance amendment %s", dt.datetime.now(tz=None))


    # manure dry matter solid and liquid [kg DM/m3]/[kg DM/t]
    # calculate from organic substance content from SALCAanimal with conversion factor
    org_subst_stable_kg = 0  # stable organic substance [kg]
    org_subst_degradable_kg = 0  # degradable organic substance [kg]

    org_subst_stable_kg, org_subst_degradable_kg = estimate_manure_dm(
        os_stable_kg = org_subst_stable_kg, os_degradable_kg = org_subst_degradable_kg,
        manure_event = manure_s_event, man = sman_kgospt, man_type = 'solid',
        tab_pars = tab_pars, tab_manu = tab_manu)
    org_subst_stable_kg, org_subst_degradable_kg = estimate_manure_dm(
        os_stable_kg = org_subst_stable_kg, os_degradable_kg = org_subst_degradable_kg,
        manure_event = manure_l_event, man = lman_kgospm3, man_type = 'liquid',
        tab_pars = tab_pars, tab_manu = tab_manu)

    # conversion to kg/ha
    org_subst_stable_kgpha = org_subst_stable_kg/ca_ha
    org_subst_degradable_kgpha = org_subst_degradable_kg/ca_ha
    # add the contribution from grazing (applies to the same area)
    org_subst_stable_kgpha += tab_pars['Value']['org_stable_kgpLSUpa']/365*(
        np.sum(np.multiply(no_days, no_lsu)))
    org_subst_degradable_kgpha += tab_pars['Value']['org_degradable_kgpLSUpa']/365*(
        np.sum(np.multiply(no_days, no_lsu)))

    logging.debug('Applied organic substance:')
    logging.debug('Stable organic substance: %f kg/ha', org_subst_stable_kgpha)
    logging.debug('Degradable organic substance: %f kg/ha', org_subst_degradable_kgpha)
    logging.debug('')

    return org_subst_stable_kgpha, org_subst_degradable_kgpha


def evaluate_liming(ph, fertilisation_event, ca_ha, is_arable, is_grass):
    """Evaluate liming at pH < 6.2."""
    logging.info("Impact Assessment pH increase %s", dt.datetime.now(tz=None))

    # derive if the applied lime [kg] exceeds 10 dt/ha (= 1000 kg/ha)
    lime_kg = 0
    for idx, fert in enumerate(fertilisation_event['variable']):
        if fert in ['Ca Kalk', 'Ca Karbonationskalk', 'Ca Meeresalgenkalk']:
            lime_kg += fertilisation_event['lime_kg'][idx]
    if lime_kg*factors['kg2dt'] / ca_ha > 10:
        lime_10dt = 1
    else:
        lime_10dt = 0

    if ph < 6.2:
        ph_lime_arable = is_arable * lime_10dt
        ph_lime_grass = is_grass * lime_10dt
    else:
        ph_lime_arable = 0
        ph_lime_grass = 0
    logging.debug('pH increase')
    logging.debug('Arable area with pH < 6.2, lime applied: %i', ph_lime_arable)
    logging.debug('Grassland with pH < 6.2, lime applied: %i', ph_lime_grass)
    logging.debug('')

    return int(ph_lime_arable), int(ph_lime_grass)


def evaluate_ppp_application(n_ppp, is_grass, is_arable):
    """Evaluate toxic effects of pesticide application."""
    evaluation_ppp_grassland = 0
    evaluation_ppp_arable = 0

    # more than zero ppp events (grassland or arable areas)
    if n_ppp > 0:
        evaluation_ppp_grassland = is_grass
        evaluation_ppp_arable = is_arable

    logging.debug('Number of PPP applications, grassland: %d',
                  np.array(n_ppp*is_grass))
    logging.debug('Evaluation of PPP applications, grassland: %i',
                  evaluation_ppp_grassland)
    logging.debug('Number of PPP applications, arable crops: %i',
                  np.array(n_ppp*is_arable))
    logging.debug('Evaluation of PPP applications, arable crops: %i',
                  evaluation_ppp_arable)
    logging.debug('')

    return int(evaluation_ppp_grassland), int(evaluation_ppp_arable)


# %% load input data ==========================================================

logging.info("Start time for preparation part %s", dt.datetime.now(tz=None))

c_salcaprep_str = inp.c_salcaprep
c_salcaprep = js.loads(c_salcaprep_str)

prep_sq = PrepSQ(

    f = FarmData(
        climate_type = inp.f_climate_type,  # Climate type (arid, humid, wet)
        climate_zone = inp.f_climate_zone[4:],  # Climate zone (A - G)

        # organic substance (OS) content in farm manure (computed in SALCAanimal)
        sman_kgospt = inp.f_sman_kgOSpt,
        lman_kgospm3 = inp.f_lman_kgOSpm3),

    fi = FieldData(
        soil_type = inp.fi_soil_type,  # soil type (sand, loam, silt, clay)
        soil_kgpm3 = inp.fi_soil_kgpm3,  # soil density [kg/m3]
        clay_frac = inp.fi_clay_frac,  # clay content of the soil [0,1], from SALCAprep_field
        humus_perc = inp.fi_humus_perc,  # humus content of the soil [%]
        ph = inp.fi_pH,  # pH of the soil []
        soil_depth_cm = inp.fi_soil_depth_cm),  # soil depth [cm]

    # derive crop type from context (string, Python code of the crop)
    c = CropData(
        crop = ctx.crop.crop_definition_name,
        ca_ha = inp.c_ca_ha,  # crop area (cropland or pasture) [ha]

        # derive information from SALCAprep_crop
        # protective sowing applies for crop?
        protective_sowi = c_salcaprep['c_protective_sowi'],
        # is the crop a permanent crop or older grassland ley?
        eros_permaculture = c_salcaprep['c_eros_permaculture']),  # for soil looseness

    # grazing takes place at the crop level
    in_past = GrazingData(
        no_days = [value['c_past_d']
                   for value in inp.get_events('c_grazing')],  # days
        no_lsu = [value['c_past_LU']
                  for value in inp.get_events('c_grazing')],  # livestock units
        livestock_type = [value['c_past_LU_type']
                          for value in inp.get_events('c_grazing')]),  # livestock type

    # heavy metal inputs into the soil on crop level, from SALCAheavymetal [mg/a]
    hm = HeavyMetalData(
        soil_cu_mgpa = inp.c_e_soil_cu_mg,
        soil_cd_mgpa = inp.c_e_soil_cd_mg,
        soil_zn_mgpa = inp.c_e_soil_zn_mg,
        soil_pb_mgpa = inp.c_e_soil_pb_mg,
        soil_ni_mgpa = inp.c_e_soil_ni_mg,
        soil_cr_mgpa = inp.c_e_soil_cr_mg,
        soil_hg_mgpa = inp.c_e_soil_hg_mg),

    # organic pollutant inputs
    op = OrganicPollutantData(
        soil_pcdd_pcdf = np.nan,  # required input data not available
        soil_pah = np.nan,  # required input data not available
        soil_pcb = np.nan),  # required input data not available

    # derive information from SALCAprep_crop
    event = EventData(
        harv = c_salcaprep['tr_harv'],  # harvest
        harv_sepr = c_salcaprep['tr_harv_sepr'],  # harvest secondary product (e.g. straw)
        sowi = c_salcaprep['tr_sowi'],  # sowing
        maint = c_salcaprep['tr_maint'],  # maintenance events
        ppp = c_salcaprep['tr_ppp'],  # plant protection products
        fertilisation = c_salcaprep['tr_fert'],  # mineral fertilisation
        manure_l = c_salcaprep['tr_manure_l'],  # liquid manure
        manure_s = c_salcaprep['tr_manure_s'],  # solid manure
        soil_trea = c_salcaprep['tr_soil']),  # soil treatment

    mc_dict = inp.get_events('treatment_maco_event')  # machine combinations
)

# %% load reference tables ====================================================

factors = {'kg2dt': 1/100,  # convert kg to dt
           'ha2m2': 10000,  # convert ha to m2
           'density_slurry_kgpm3': 1000,  # slurry density [kg/m3]
           't2kg': 1000}  # convert tonnes to kg

# load crop table
tab_crops = read_js_table(inp.tab_crops)
# load fertiliser table
tab_manu = read_js_table(inp.tab_manu)
# load machine table
tab_vehicle = read_js_table(inp.tab_mach)

# load soil moisture tables
tab_somo = {'001 dry': read_table('SQ_tables_somo_dry.csv'),
            '002 humid': read_table('SQ_tables_somo_humid.csv'),
            '003 wet': read_table('SQ_tables_somo_wet.csv')}

# load table concentration factor
tab_m_cf = read_table('SQ_tables_m_cf.csv')

# load table evaluation of treatments
tab_treatment = read_table('SQ_tables_treatment.csv')
tab_treatment = tab_treatment.drop(tab_treatment.columns[0], axis=1)

# load earthworm table
tab_earthworm = read_table('SQ_tables_earthworm.csv')
tab_earthworm = tab_earthworm.drop(tab_earthworm.columns[0:4], axis=1)


# load table soil quality parameters
tab_pars = read_pars('SALCAsoilquality_pars.csv')

# threshold values for heavy metal content [mg/kgTS] of soil
hm_thresholds_mgpkg = {'cd': 0.8,
                       'cu': 40,
                       'zn': 150,
                       'pb': 50,
                       'ni': 50,
                       'cr': 50,
                       'hg': 0.5}

# threshold values for organic pollutant content of soil
op_thresholds = {'pcdd_pcdf': 5,  # [ng toxic equivalents (TEQ) kg-1 DM]
                 'pah': 1,  # [mg kg-1 DM]
                 'pcb': 0.2}  # [mg kg-1 DM]

logging.info("End time of preparation part %s", dt.datetime.now(tz=None))

# %% initiate print ===========================================================

logging.info('Output SALCAsoilquality crop')
logging.info('for farm %s with ID %d', ctx.farm.farm_name, ctx.farm.farm_id)
logging.info('for field %s with ID %d', ctx.field[1], ctx.field_id)
logging.info('for crop %s with ID %d with name %s', ctx.crop[2], ctx.crop_id,
             ctx.crop[1])
logging.info('')

# %% preprocess some data =====================================================

logging.info("Calc preparations %s", dt.datetime.now(tz=None))

# convert the date from string to date.datetime
for event_name in list(vars(prep_sq.event)):
    prep_sq.event.__dict__[event_name]["date_dt"] = \
        [dt.datetime.strptime(d, "%Y-%m-%d") for d \
         in prep_sq.event.__dict__[event_name]["date_dt"]]

# all event options with list(vars(prep_sq.event)), but they need to have a logical order
event_order = ['soil_trea', 'sowi', 'fertilisation', 'manure_l', 'manure_s',
               'ppp', 'maint', 'harv', 'harv_sepr',]

# harvest residues
# If an event for harvest of the secondary product (e.g. straw) is present
# (= has a date), there are no optional harvest residues, else there are.
hres_present = prep_sq.event.harv_sepr['date'] == []

# %% evaluate impact classes ==================================================

# dict to collect the results from the impact class evaluation
sq_crop = {}

# derive if the crop is grassland or arable land
sq_crop['c_is_grass'] = int(prep_sq.c.eros_permaculture)
sq_crop['c_is_arable'] = int(1-prep_sq.c.eros_permaculture)

# erosion only evaluated at the farm level

sq_crop['c_tr_evaluation'] = \
    evaluate_wheeling(event_order = event_order,
                      mc_dict = prep_sq.mc_dict,
                      event_group = prep_sq.event,
                      eros_permaculture = prep_sq.c.eros_permaculture,
                      soil_depth_cm = prep_sq.fi.soil_depth_cm,
                      soil_type = prep_sq.fi.soil_type,
                      tab_somo = tab_somo[prep_sq.f.climate_type],
                      tab_m_cf = tab_m_cf, tab_treatment = tab_treatment)

sq_crop['c_graz_evaluation'] = \
    evaluate_grazing(past_d = prep_sq.in_past.no_days,  # grazing period [days]
                     past_h = prep_sq.in_past.h,  # daily grazing hours [hours]
                     head = prep_sq.in_past.no_lsu,  # number of animals
                     area = prep_sq.c.ca_ha,  # pasture area [ha]
                     anim_type = prep_sq.in_past.livestock_type,
                     tab_treatment = tab_treatment)

sq_crop['c_crop_rotation_grass'], sq_crop['c_crop_rotation_arable'] = \
    evaluate_structure_stabilisation(prep_sq.c.crop, sq_crop['c_is_grass'],
                                     sq_crop['c_is_arable'], tab_crops)

sq_crop['c_soil_texture_hres_frac'] = \
    evaluate_structure_formation(prep_sq.c.crop, hres_present, tab_crops)

sq_crop['c_humus_balance_net_kg'], \
    sq_crop['c_humus_balance_gross_kgpha'], \
        sq_crop['c_humus_balance_area_ha'] = \
    evaluate_humus_balance(crop = prep_sq.c.crop, clay_frac = prep_sq.fi.clay_frac,
                           ph = prep_sq.fi.ph, soil_kgpm3 = prep_sq.fi.soil_kgpm3,
                           manure_s_event = prep_sq.event.manure_s,
                           manure_l_event = prep_sq.event.manure_l,
                           ca_ha = prep_sq.c.ca_ha, hres_present = hres_present,
                           tab_manu = tab_manu, tab_crops = tab_crops)

# positive effects of plants on earthworm populations evaluated through
# output of evaluate_structure_stabilisation

sq_crop['c_worm_protection_cutting_level']  = \
    evaluate_earthworm_protection_cutting(prep_sq.event.harv, sq_crop['c_is_grass'])

sq_crop['c_ew_phys_sum'] = \
    evaluate_earthworm_impact_tillage(prep_sq.c.crop, prep_sq.f.climate_zone,
                                      prep_sq.event.soil_trea['date_dt'], tab_earthworm)

sq_crop['c_protective_sowi'] = evaluate_earthworm_impact_seedbed(prep_sq.c.protective_sowi)

for i, hm in enumerate([hm.replace('soil_', '') for hm in list(vars(prep_sq.hm))]):
    sq_crop['c_ttt_grass_' + hm.replace('_mgpa', '') + '_a'], \
    sq_crop['c_ttt_arable_' + hm.replace('_mgpa', '') + '_a'] = \
            evaluate_pollutants(pollutant = hm, data = prep_sq.hm,
                                thresholds = hm_thresholds_mgpkg,
                                is_grass = sq_crop['c_is_grass'],
                                is_arable = sq_crop['c_is_arable'], counter = i)

for i, op in enumerate([op.replace('soil_', '') for op in list(vars(prep_sq.op))]):
    sq_crop['c_ttt_grass_' + op + '_a'], sq_crop['c_ttt_arable_' + op + '_a'] = \
            evaluate_pollutants(pollutant = op, data = prep_sq.op,
                                thresholds = op_thresholds,
                                is_grass = sq_crop['c_is_grass'],
                                is_arable = sq_crop['c_is_arable'], counter = i)

sq_crop['c_evaluation_slurry_grassland'], sq_crop['c_evaluation_slurry_arable'] = \
    evaluate_slurry_application(len(prep_sq.event.manure_l['amount_m3']),
                                sq_crop['c_is_grass'], sq_crop['c_is_arable'])

sq_crop['c_org_subst_stable_kgpha'], sq_crop['c_org_subst_degradable_kgpha'] = \
    evaluate_organic_substances(manure_s_event = prep_sq.event.manure_s,
                                manure_l_event = prep_sq.event.manure_l,
                                sman_kgospt = prep_sq.f.sman_kgospt,
                                lman_kgospm3 = prep_sq.f.lman_kgospm3,
                                ca_ha = prep_sq.c.ca_ha, no_days = prep_sq.in_past.no_days,
                                no_lsu = prep_sq.in_past.no_lsu,
                                tab_pars = tab_pars, tab_manu = tab_manu)

sq_crop['c_pH_lime_arable'], sq_crop['c_pH_lime_grass'] = \
    evaluate_liming(prep_sq.fi.ph, prep_sq.event.fertilisation, prep_sq.c.ca_ha,
                    sq_crop['c_is_arable'], sq_crop['c_is_grass'])

sq_crop['c_evaluation_ppp_grassland'], sq_crop['c_evaluation_ppp_arable'] = \
    evaluate_ppp_application(len(prep_sq.event.ppp['date']),
                             sq_crop['c_is_grass'], sq_crop['c_is_arable'])

# %% export output ============================================================

out.c_sq_output = js.dumps(sq_crop)

# %% end sequence =============================================================

logging.info('End SALCAsoilquality crop')

end = dt.datetime.now(tz=None)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)

