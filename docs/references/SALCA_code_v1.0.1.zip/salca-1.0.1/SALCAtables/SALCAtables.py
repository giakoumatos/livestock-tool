# -*- coding: utf-8 -*-
"""
File name: SALCAtables.py
Created on Tue Sep 17 08:07:40 2019

Author: Agroscope, 'Life Cycle Assessment' Research Group, Switzerland
Date: 2026-10-14
Version: 1.0.1
Licence: GNU LGPLv3

Description: 
    This script reads the SALCA tables and stores them as JSON-strings into the
    database, so that they are available for subsequent scripts.

Calculation level:
    Farm

Related script: all others
    All other scripts use the tables loaded from this script as inputs.
"""
# %% import modules ===========================================================
import datetime as dt
import json as js
import logging
from importlib import reload

import pandas as pd

from salcaconnector import create_salca_context

# starting sequence
reload(logging)
logging.basicConfig(format = '%(message)s',
                    level = logging.DEBUG)  # logging.DEBUG or logging.INFO

start = dt.datetime.now(tz=None)
logging.info('')
logging.info('Start SALCAtables')
logging.info('Starting time: %s', start)
logging.info('')

# create salca context
ctx = create_salca_context('farm')
inp, out = ctx.bind()

logging.info('Module run for:')
logging.info('inventory ID %s', ctx.farm.inventory_id)
logging.info('field ID %s', ctx.field_id)
logging.info('crop ID %s', ctx.crop_id)
logging.info('livestock ID %s', ctx.livestock_id)

# %% define functions =========================================================
def read_table(path):
    """read CSV file"""
    tab = pd.read_csv(path,
                      sep=';',
                      header=6,
                      encoding='utf-8-sig')
    return tab

# %% load csv tables ==========================================================
tab_anpr  = read_table('SALCAtables_anpr.csv')
tab_crops = read_table('SALCAtables_crops.csv')
tab_feed  = read_table('SALCAtables_feed.csv')
tab_fert  = read_table('SALCAtables_fert.csv')
tab_fert_market  = read_table('SALCAtables_fert_market.csv')
tab_ls    = read_table('SALCAtables_ls.csv')
tab_ls_export    = read_table('SALCAtables_ls_export.csv')
tab_manu  = read_table('SALCAtables_manu.csv')
tab_ppp   = read_table('SALCAtables_ppp.csv')
tab_build = read_table('SALCAtables_buildings.csv')
tab_mach  = read_table('SALCAtables_machinery.csv')
tab_hm    = read_table('HM_table.csv')
tab_enca  = read_table('SALCAtables_energy_carriers.csv')
tab_supp  = read_table('SALCAtables_supplies.csv')
logging.info('All tables read.')

# %% subset tables ============================================================
tab_build = tab_build[["EventName", 
                       "Variable name",
                       "SelectionName",
                       "Label {de}",
                       "Label {en}",
                       "Label {fr}",
                       "Bezeichnung DE\nPS Klima",
                       "Einheit\nPS Klima",
                       "SP_mapping_variable",
                       "SP_mapping",
                       "Unit\nSimaPro",
                       "SP_mapping_conv_fact",
                       "lifespan"]]

# remove empty lines / nan's in tab_hm:
tab_hm.dropna(how='all', inplace= True)

# %% output ===================================================================
# dump to string. extract information about index and col with 'split'.
out.tab_crops = js.dumps(tab_crops.to_dict('split'), ensure_ascii=False)
out.tab_manu  = js.dumps(tab_manu.to_dict('split'), ensure_ascii=False)
out.tab_fert  = js.dumps(tab_fert.to_dict('split'), ensure_ascii=False)
out.tab_fert_market  = js.dumps(tab_fert_market.to_dict('split'), ensure_ascii=False)
out.tab_anpr  = js.dumps(tab_anpr.to_dict('split'), ensure_ascii=False)
out.tab_ls    = js.dumps(tab_ls.to_dict('split'), ensure_ascii=False)
out.tab_ls_export    = js.dumps(tab_ls_export.to_dict('split'), ensure_ascii=False)
out.tab_feed  = js.dumps(tab_feed.to_dict('split'), ensure_ascii=False)
out.tab_ppp   = js.dumps(tab_ppp.to_dict('split'), ensure_ascii=False)
out.tab_build = js.dumps(tab_build.to_dict('split'), ensure_ascii=False)
out.tab_mach  = js.dumps(tab_mach.to_dict('split'), ensure_ascii=False)
out.tab_hm    = js.dumps(tab_hm.to_dict('split'), ensure_ascii=False)
out.tab_enca  = js.dumps(tab_enca.to_dict('split'), ensure_ascii=False)
out.tab_supp  = js.dumps(tab_supp.to_dict('split'), ensure_ascii=False)
logging.info('All tables written to out-Variable.')


# %% end sequence =============================================================
logging.info('End SALCAtables')
end = dt.datetime.now(tz=None)
logging.info('End time: %s', end)

diff = end - start
logging.info('Time delta: %s', diff)
